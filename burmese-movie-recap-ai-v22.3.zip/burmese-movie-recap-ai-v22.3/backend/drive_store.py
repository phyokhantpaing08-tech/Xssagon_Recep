"""Google Drive storage for the finished recap files.

Flow used by backend/app.py:  upload to Drive  ->  verify (size + MD5)  ->  delete the local copy  ->  show / link from Drive.

Only the `requests` package is needed (it is already in requirements.txt): the OAuth2 login and the Drive v3
REST calls are plain HTTPS.  The app asks for the narrow `drive.file` scope, so it can only see files and folders
that it created itself, never the rest of the user's Drive.
"""
import base64
import contextlib
import contextvars
import hashlib
import json
import os
import re
import secrets
import threading
import time
from pathlib import Path

import requests

ROOT = Path(__file__).resolve().parent.parent
DATA = ROOT / 'data'

AUTH_URL = 'https://accounts.google.com/o/oauth2/v2/auth'
TOKEN_URL = 'https://oauth2.googleapis.com/token'
REVOKE_URL = 'https://oauth2.googleapis.com/revoke'
API = 'https://www.googleapis.com/drive/v3'
UPLOAD_API = 'https://www.googleapis.com/upload/drive/v3'
SCOPE = 'https://www.googleapis.com/auth/drive.file'
FOLDER_MIME = 'application/vnd.google-apps.folder'
DEFAULT_FOLDER = 'Burmese Movie Recap'
FILE_FIELDS = 'id,name,size,md5Checksum,mimeType,webViewLink,webContentLink'

BACKOFF_BASE = 1.5          # seconds; doubles on every retry (tests set it to 0)
MAX_PENDING = 500            # half-done Google logins kept in memory at the same time
MAX_UPLOAD_FAILS = 8        # consecutive failed chunk attempts before the upload is given up
_ALIGN = 256 * 1024         # Drive wants every chunk (except the last) to be a multiple of 256 KiB


class DriveError(RuntimeError):
    pass


class DriveAuthError(DriveError):
    """Drive is not connected, or Google no longer accepts the saved login (user must connect again)."""


_lock = threading.Lock()            # protects _pending and the settings file
_tok_lock = threading.Lock()        # one token refresh at a time
_pending = {}                       # OAuth state -> {verifier, redirect_uri, ts, dir}

# The folder that holds drive_token.json / drive_settings.json is chosen per request / per job thread with use_dir();
# without it (the normal case: one user) the V20 location (data/) is used, so a Drive link made with V20 keeps working.
_user_dir = contextvars.ContextVar('drive_user_dir', default=None)


@contextlib.contextmanager
def use_dir(path):
    token = _user_dir.set(Path(path) if path else None)
    try:
        yield
    finally:
        _user_dir.reset(token)


def _base():
    return _user_dir.get() or DATA


# ------------------------------------------------------------------------------------------ small helpers
def _token_path():
    return _base() / 'drive_token.json'


def _settings_path():
    return _base() / 'drive_settings.json'


def _proxies():
    p = (os.getenv('DRIVE_PROXY') or '').strip()
    return {'http': p, 'https': p} if p else None


def _req(method, url, **kw):
    kw.setdefault('timeout', (15, 120))
    p = _proxies()
    if p:
        kw.setdefault('proxies', p)
    return requests.request(method, url, **kw)


def _sleep(attempt):
    time.sleep(min(30.0, BACKOFF_BASE * (2 ** attempt)))


def _write_json_private(path, data):
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + '.tmp')
    tmp.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding='utf-8')
    try:
        os.chmod(tmp, 0o600)            # best effort (no effect on Windows)
    except OSError:
        pass
    tmp.replace(path)


def _read_json(path):
    try:
        return json.loads(path.read_text(encoding='utf-8')) if path.exists() else {}
    except Exception:
        return {}


# ------------------------------------------------------------------------------------------ settings
def read_settings():
    s = _read_json(_settings_path())
    return {
        'share_anyone': bool(s.get('share_anyone', False)),
        'folder_name': (s.get('folder_name') or DEFAULT_FOLDER).strip() or DEFAULT_FOLDER,
        'folder_id': s.get('folder_id') or '',
    }


def save_settings(**changes):
    with _lock:
        s = _read_json(_settings_path())
        s.update(changes)
        _write_json_private(_settings_path(), s)


# ------------------------------------------------------------------------------------------ OAuth client + token
def client_config():
    """The Google OAuth client (id + secret) the user created in Google Cloud Console, or None."""
    cid = (os.getenv('GOOGLE_CLIENT_ID') or '').strip()
    sec = (os.getenv('GOOGLE_CLIENT_SECRET') or '').strip()
    if cid and sec:
        return {'client_id': cid, 'client_secret': sec, 'source': '.env'}
    cands = []
    env_file = (os.getenv('GOOGLE_CLIENT_SECRET_FILE') or '').strip().strip('"')
    if env_file:
        cands.append(Path(env_file))
    for d in (DATA, ROOT):
        cands.append(d / 'credentials.json')
        try:
            cands += sorted(d.glob('client_secret*.json'))      # the name Google gives the downloaded file
        except OSError:
            pass
    for p in cands:
        try:
            raw = json.loads(p.read_text(encoding='utf-8'))
        except Exception:
            continue
        block = raw.get('installed') or raw.get('web') if isinstance(raw, dict) else None
        if isinstance(block, dict) and block.get('client_id') and block.get('client_secret'):
            return {'client_id': block['client_id'], 'client_secret': block['client_secret'], 'source': p.name}
    return None


def _load_token():
    t = _read_json(_token_path())
    return t if t.get('refresh_token') else None


def _save_token(t):
    _write_json_private(_token_path(), t)


def is_connected():
    return _load_token() is not None


def _oauth_error(r):
    try:
        j = r.json()
        return f"{j.get('error', r.status_code)}: {j.get('error_description', '')}".strip(': ')
    except ValueError:
        return f'HTTP {r.status_code}'


def auth_url(redirect_uri):
    cfg = client_config()
    if not cfg:
        raise DriveError('Google OAuth client မတွေ့ပါ။ credentials.json ကို project ရဲ့ data ဖိုလ်ဒါထဲ ထည့်ပါ (README ကြည့်ပါ)။')
    state = secrets.token_urlsafe(24)
    verifier = secrets.token_urlsafe(64)
    challenge = base64.urlsafe_b64encode(hashlib.sha256(verifier.encode('ascii')).digest()).rstrip(b'=').decode('ascii')
    now = time.time()
    with _lock:
        for k in [k for k, v in _pending.items() if now - v['ts'] > 600]:
            _pending.pop(k, None)
        if len(_pending) >= MAX_PENDING:             # somebody keeps pressing "Connect": forget the oldest half-done logins
            for k in sorted(_pending, key=lambda k: _pending[k]['ts'])[:len(_pending) - MAX_PENDING + 1]:
                _pending.pop(k, None)
        _pending[state] = {'verifier': verifier, 'redirect_uri': redirect_uri, 'ts': now, 'dir': str(_base())}
    from urllib.parse import urlencode
    return AUTH_URL + '?' + urlencode({
        'client_id': cfg['client_id'], 'redirect_uri': redirect_uri, 'response_type': 'code', 'scope': SCOPE,
        'access_type': 'offline', 'prompt': 'consent', 'state': state,
        'code_challenge': challenge, 'code_challenge_method': 'S256'})


def finish_auth(state, code):
    """Second half of the login (called from the redirect URL). Saves the refresh token."""
    with _lock:
        p = _pending.pop(state or '', None)
    if not p or time.time() - p['ts'] > 600:
        raise DriveError('Login session သက်တမ်းကုန်သွားပါပြီ (သို့) မမှန်ပါ။ "Connect Google Drive" ကို ပြန်နှိပ်ပါ။')
    if p.get('dir') != str(_base()):
        raise DriveError('ဒီ Google Drive ချိတ်ဆက်မှုက တခြားနေရာကနေ စတင်ထားတာဖြစ်လို့ လက်မခံပါဘူး။ "Connect Google Drive" ကို ပြန်နှိပ်ပါ။')
    cfg = client_config()
    if not cfg:
        raise DriveError('Google OAuth client မတွေ့ပါ။')
    try:
        r = _req('POST', TOKEN_URL, data={
            'code': code, 'client_id': cfg['client_id'], 'client_secret': cfg['client_secret'],
            'redirect_uri': p['redirect_uri'], 'grant_type': 'authorization_code', 'code_verifier': p['verifier']})
    except requests.RequestException as e:
        raise DriveError(f'Google နဲ့ ချိတ်ဆက်လို့မရပါ: {e}')
    if not r.ok:
        raise DriveError('Google login မအောင်မြင်ပါ — ' + _oauth_error(r))
    tok = r.json()
    if SCOPE not in (tok.get('scope') or '').split():
        raise DriveError('Google Drive ခွင့်ပြုချက် (checkbox) ကို မအမှတ်ခဲ့ပါ။ ပြန် Connect လုပ်ပြီး Drive ခွင့်ပြုချက်ကို ရွေးပေးပါ။')
    if not tok.get('refresh_token'):
        raise DriveError('Google က refresh token မပေးပါ။ https://myaccount.google.com/permissions မှာ ဒီ app ကို ဖယ်ရှားပြီး ပြန် Connect လုပ်ပါ။')
    _save_token({'refresh_token': tok['refresh_token'], 'access_token': tok.get('access_token', ''),
                 'expires_at': time.time() + int(tok.get('expires_in', 3600)), 'scope': tok.get('scope', ''), 'email': ''})
    try:
        u = about()
        t = _load_token() or {}
        t['email'] = u.get('emailAddress') or u.get('displayName') or ''
        _save_token(t)
    except DriveError:
        pass            # the email is only shown on the website


def access_token(force=False):
    """A valid access token (refreshes it when it is about to expire)."""
    with _tok_lock:
        t = _load_token()
        if not t:
            raise DriveAuthError('Google Drive ကို မချိတ်ရသေးပါ။')
        if not force and t.get('access_token') and float(t.get('expires_at', 0)) - time.time() > 90:
            return t['access_token']
        cfg = client_config()
        if not cfg:
            raise DriveAuthError('Google OAuth client (credentials.json) မတွေ့တော့ပါ။')
        try:
            r = _req('POST', TOKEN_URL, data={'client_id': cfg['client_id'], 'client_secret': cfg['client_secret'],
                                              'refresh_token': t['refresh_token'], 'grant_type': 'refresh_token'})
        except requests.RequestException as e:
            raise DriveError(f'Google နဲ့ ချိတ်ဆက်လို့မရပါ: {e}')
        if r.status_code in (400, 401):
            try:
                err = r.json().get('error', '')
            except ValueError:
                err = ''
            if err in ('invalid_grant', 'invalid_client', 'unauthorized_client'):
                try:
                    _token_path().unlink()
                except OSError:
                    pass
                raise DriveAuthError('Google Drive ချိတ်ဆက်မှု သက်တမ်းကုန်သွားပါပြီ (သို့) ပယ်ဖျက်ခံရပါပြီ။ "Connect Google Drive" နဲ့ ပြန်ချိတ်ပါ။ '
                                     '(OAuth consent screen ကို Testing မှာ ထားရင် ၇ ရက်အတွင်း ကုန်ပါတယ် — README ကြည့်ပါ။)')
        if not r.ok:
            raise DriveError('Google token refresh မအောင်မြင်ပါ — ' + _oauth_error(r))
        j = r.json()
        t['access_token'] = j['access_token']
        t['expires_at'] = time.time() + int(j.get('expires_in', 3600))
        _save_token(t)
        return t['access_token']


def disconnect():
    t = _load_token()
    if t:
        try:
            _req('POST', REVOKE_URL, params={'token': t['refresh_token']}, timeout=(10, 20))
        except requests.RequestException:
            pass            # revoking is best effort; the local login is removed either way
    try:
        _token_path().unlink()
    except OSError:
        pass
    save_settings(folder_id='')


# ------------------------------------------------------------------------------------------ Drive REST helpers
def _error(r):
    msg, reasons = '', []
    try:
        j = r.json()
        e = j.get('error')
        if isinstance(e, dict):
            msg = e.get('message') or ''
            reasons = [x.get('reason', '') for x in (e.get('errors') or []) if isinstance(x, dict)]
        elif e:
            msg = f"{e} {j.get('error_description', '')}".strip()
    except ValueError:
        msg = r.text[:300]
    text = f'Google Drive API {r.status_code}: {msg}'.strip()
    low = (msg or '').lower()
    if 'storagequotaexceeded' in [x.lower() for x in reasons]:
        return DriveError(text + ' — Google Drive နေရာ ပြည့်နေပါတယ်။')
    if 'accessnotconfigured' in [x.lower() for x in reasons] or 'has not been used in project' in low or 'service_disabled' in low:
        return DriveError(text + ' — Google Cloud Console မှာ "Google Drive API" ကို Enable လုပ်ပါ။')
    if r.status_code == 401 or 'insufficientpermissions' in [x.lower() for x in reasons]:
        return DriveAuthError(text + ' — Drive ကို ပြန် Connect လုပ်ပါ။')
    return DriveError(text)


def _api(method, url, retries=5, headers=None, **kw):
    """One authorised Drive call. Retries network errors, 429/5xx and one expired token."""
    refreshed, last = False, ''
    for attempt in range(retries):
        h = dict(headers or {})
        h['Authorization'] = 'Bearer ' + access_token()
        try:
            r = _req(method, url, headers=h, **kw)
        except requests.RequestException as e:
            last = f'network error: {e}'
            _sleep(attempt)
            continue
        if r.status_code == 401 and not refreshed:
            refreshed = True
            access_token(force=True)
            continue
        rate_limited = r.status_code == 403 and 'ratelimitexceeded' in r.text.lower().replace(' ', '')
        if r.status_code in (429, 500, 502, 503, 504) or rate_limited:
            last = f'HTTP {r.status_code}'
            _sleep(attempt)
            continue
        return r
    raise DriveError(f'Google Drive ကို ချိတ်ဆက်လို့မရပါ ({last})')


def about():
    r = _api('GET', f'{API}/about', params={'fields': 'user(emailAddress,displayName)'})
    if not r.ok:
        raise _error(r)
    return r.json().get('user') or {}


def _q(s):
    return s.replace('\\', '\\\\').replace("'", "\\'")


def ensure_folder(name=None):
    """Id of the Drive folder that holds the recaps (found or created; remembered in drive_settings.json)."""
    st = read_settings()
    name = (name or st['folder_name']).strip() or DEFAULT_FOLDER
    fid = st['folder_id'] if st['folder_name'] == name else ''
    if fid:
        r = _api('GET', f'{API}/files/{fid}', params={'fields': 'id,trashed'})
        if r.ok and not r.json().get('trashed'):
            return fid
        if not r.ok and r.status_code != 404:
            raise _error(r)
    q = f"mimeType='{FOLDER_MIME}' and name='{_q(name)}' and trashed=false and 'root' in parents"
    r = _api('GET', f'{API}/files', params={'q': q, 'fields': 'files(id,name)', 'pageSize': 1, 'spaces': 'drive'})
    if not r.ok:
        raise _error(r)
    found = r.json().get('files') or []
    if found:
        fid = found[0]['id']
    else:
        r = _api('POST', f'{API}/files', params={'fields': 'id'}, json={'name': name, 'mimeType': FOLDER_MIME})
        if not r.ok:
            raise _error(r)
        fid = r.json()['id']
    save_settings(folder_id=fid, folder_name=name)
    return fid


def md5_file(path):
    h = hashlib.md5()
    with open(path, 'rb') as f:
        for block in iter(lambda: f.read(1 << 20), b''):
            h.update(block)
    return h.hexdigest()


def _next_offset(r):
    """Where the upload continues, from the `Range: bytes=0-N` header of a 308 answer (none = nothing stored yet)."""
    m = re.match(r'bytes=0-(\d+)$', (r.headers.get('Range') or '').strip())
    return int(m.group(1)) + 1 if m else 0


def _chunk_size(chunk):
    if not chunk:
        try:
            chunk = int(float(os.getenv('DRIVE_CHUNK_MB') or 8) * 1024 * 1024)
        except ValueError:
            chunk = 8 * 1024 * 1024
    return max(_ALIGN, chunk // _ALIGN * _ALIGN)


def upload_file(path, name, mime, folder_id, on_progress=None, chunk=None):
    """Resumable upload of one file into `folder_id`. Returns the Drive file resource (id, size, md5Checksum, links)."""
    path = Path(path)
    size = path.stat().st_size
    if size <= 0:
        raise DriveError(f'{path.name} ဖိုင်က အလွတ်ဖြစ်နေပါတယ်။')
    r = _api('POST', f'{UPLOAD_API}/files', params={'uploadType': 'resumable', 'fields': FILE_FIELDS},
             headers={'X-Upload-Content-Type': mime, 'X-Upload-Content-Length': str(size)},
             json={'name': name, 'parents': [folder_id]})
    if not r.ok:
        raise _error(r)
    session = r.headers.get('Location')
    if not session:
        raise DriveError('Google Drive က upload လိပ်စာ မပေးပါ။')
    step = _chunk_size(chunk)
    offset, fails, meta = 0, 0, None
    with open(path, 'rb') as f:
        while meta is None:
            f.seek(offset)
            data = f.read(min(step, size - offset))
            if not data:
                raise DriveError('Upload ဖတ်နေစဉ် ဖိုင်က မမျှော်လင့်ဘဲ တိုသွားပါတယ်။')
            hdr = {'Content-Range': f'bytes {offset}-{offset + len(data) - 1}/{size}',
                   'Authorization': 'Bearer ' + access_token()}
            retry = False
            try:
                r = _req('PUT', session, headers=hdr, data=data, timeout=(15, 600))
            except requests.RequestException:
                retry = True
            else:
                if r.status_code in (200, 201):
                    meta = r.json()
                    break
                if r.status_code == 308:
                    fails = 0
                    offset = _next_offset(r)
                    if on_progress:
                        on_progress(offset, size)
                    continue
                if r.status_code in (404, 410):
                    raise DriveError('Upload session သက်တမ်းကုန်သွားပါပြီ။')
                if r.status_code == 401:
                    access_token(force=True)
                    retry = True
                elif r.status_code in (429, 500, 502, 503, 504):
                    retry = True
                else:
                    raise _error(r)
            if retry:
                fails += 1
                if fails > MAX_UPLOAD_FAILS:
                    raise DriveError('Google Drive upload ကို အကြိမ်ကြိမ် ပြန်စမ်းပေမယ့် မအောင်မြင်ပါ (အင်တာနက်စစ်ပါ)။')
                _sleep(fails)
                # Ask Drive how much it really received, then continue from there (or finish if it is all there).
                try:
                    q = _req('PUT', session, headers={'Content-Range': f'bytes */{size}', 'Content-Length': '0',
                                                       'Authorization': 'Bearer ' + access_token()}, data=b'', timeout=(15, 60))
                    if q.status_code in (200, 201):
                        meta = q.json()
                        break
                    if q.status_code == 308:
                        offset = _next_offset(q)
                except requests.RequestException:
                    pass            # the next loop turn re-sends the same chunk from the same offset
    if on_progress:
        on_progress(size, size)
    return meta


def verify(meta, local_size, local_md5=None):
    """Raise unless Drive really holds the same bytes. Nothing local may be deleted before this passes."""
    if not isinstance(meta, dict) or not meta.get('id'):
        raise DriveError('Drive upload ရလဒ် မမှန်ပါ။')
    if int(meta.get('size') or -1) != int(local_size):
        raise DriveError(f"Drive ပေါ်က ဖိုင်အရွယ်အစား မကိုက်ပါ (local {local_size} bytes, Drive {meta.get('size')}).")
    remote = (meta.get('md5Checksum') or '').lower()
    if local_md5 and remote and remote != local_md5.lower():
        raise DriveError('Drive ပေါ်က ဖိုင်ရဲ့ MD5 မကိုက်ပါ — upload ပျက်စီးသွားနိုင်ပါတယ်။')


def make_public(file_id):
    """"Anyone with the link can view/download" (not listed in search)."""
    r = _api('POST', f'{API}/files/{file_id}/permissions',
             json={'type': 'anyone', 'role': 'reader', 'allowFileDiscovery': False})
    if not r.ok:
        raise _error(r)


def delete_remote(file_id):
    try:
        _api('DELETE', f'{API}/files/{file_id}', retries=2)
    except DriveError:
        pass            # used only to clean up a half-finished upload


def view_url(meta):
    return meta.get('webViewLink') or f"https://drive.google.com/file/d/{meta['id']}/view"


def download_url(meta):
    return meta.get('webContentLink') or f"https://drive.google.com/uc?export=download&id={meta['id']}"


def folder_url(folder_id):
    return f'https://drive.google.com/drive/folders/{folder_id}'


def open_stream(file_id, range_header=None):
    """Open the file's bytes (optionally a Range) as a streaming `requests` response, for playing it on the website."""
    r = None
    for attempt in (0, 1):
        h = {'Authorization': 'Bearer ' + access_token(force=attempt == 1), 'Accept-Encoding': 'identity'}
        if range_header:
            h['Range'] = range_header
        r = _req('GET', f'{API}/files/{file_id}', params={'alt': 'media'}, headers=h, stream=True, timeout=(15, 60))
        if r.status_code == 401 and attempt == 0:
            r.close()
            continue
        break
    return r


def status(check=True):
    """Everything the website's Google Drive card needs."""
    cfg = client_config()
    st = read_settings()
    out = {'client_configured': bool(cfg), 'client_source': cfg['source'] if cfg else '', 'connected': False,
           'email': '', 'error': '', 'share_anyone': st['share_anyone'], 'folder_name': st['folder_name']}
    t = _load_token()
    if t:
        out['connected'] = True
        out['email'] = t.get('email', '')
        if check:
            try:
                access_token()
            except DriveAuthError as e:
                out['connected'], out['error'] = False, str(e)
            except DriveError as e:
                out['error'] = str(e)       # e.g. no internet right now: still connected
    return out
