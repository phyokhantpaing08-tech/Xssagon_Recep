"""Media helpers (V21): ffmpeg, fonts, Burmese subtitles (ASS), blur band and the final render.

Moved out of app.py unchanged in behaviour (V18-V20 logic for subtitles / blur), plus:
* ffmpeg_run() can be cancelled while it works (should_stop),
* render_with_subtitles() takes a progress callback and a speed preset (RENDER_PRESET: ultrafast / veryfast / faster),
* write_subtitle_files() no longer depends on the web layer.
"""
import functools
import json
import os
import re
import shutil
import struct
import subprocess
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent


def _find_ffmpeg():
    env = (os.getenv('FFMPEG_PATH') or '').strip().strip('"')
    if env:
        return env
    try:
        import imageio_ffmpeg
        return imageio_ffmpeg.get_ffmpeg_exe()
    except Exception:
        return shutil.which('ffmpeg') or 'ffmpeg'


FFMPEG = _find_ffmpeg()
FFPROBE = os.getenv('FFPROBE_PATH') or shutil.which('ffprobe')


def looks_like_video(path):
    """True when the first bytes are those of a real video container: MP4 / MOV / M4V (ISO base media), Matroska / WebM or AVI.
    ffmpeg decides the format from the CONTENT of a file, not from its name, so a text file called "movie.mp4" could be an HLS /
    concat / SDP playlist that makes ffmpeg read other files of the server. Only real containers are let in."""
    try:
        with open(path, 'rb') as f:
            head = f.read(16)
    except OSError:
        return False
    if head[4:8] in (b'ftyp', b'moov', b'mdat', b'free', b'wide', b'skip', b'pnot'):
        return True
    if head[:4] == b'\x1a\x45\xdf\xa3':
        return True
    return head[:4] == b'RIFF' and head[8:12] == b'AVI '


class Stopped(Exception):
    """ffmpeg was stopped because the job was cancelled."""



def ffmpeg(*args):
    p = subprocess.run([FFMPEG, '-y', *map(str, args)], stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
    if p.returncode:
        raise RuntimeError(p.stderr[-5000:] or 'FFmpeg failed')
    return p


def duration(path):
    if FFPROBE:
        p = subprocess.run([FFPROBE, '-v', 'error', '-show_entries', 'format=duration', '-of', 'default=nw=1:nk=1', str(path)], stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
        if p.returncode == 0:
            try:
                return max(.01, float(p.stdout.strip()))
            except Exception:
                pass
    p = subprocess.run([FFMPEG, '-i', str(path)], stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
    m = re.search(r'Duration:\s*(\d+):(\d+):(\d+(?:\.\d+)?)', p.stderr)
    if not m:
        raise RuntimeError('Could not determine media duration.')
    return int(m.group(1)) * 3600 + int(m.group(2)) * 60 + float(m.group(3))

def _seconds(v):
    try:
        x = float(v)
        return x if x == x and abs(x) != float('inf') else None
    except (TypeError, ValueError):
        return None


def _tag_seconds(text):
    # "00:01:02.500000000" (the DURATION tag Matroska / WebM files carry) -> seconds
    m = re.match(r'^\s*(\d+):(\d+):(\d+(?:\.\d+)?)\s*$', str(text or ''))
    return int(m.group(1)) * 3600 + int(m.group(2)) * 60 + float(m.group(3)) if m else None


def _tail_end(path, guesses, fps=None):
    """End of the last picture (the last packet's time + its duration) on the file's own timeline, read from the packets of the final
    seconds only. `guesses` = where the file might end (Matroska counts its duration from 0, MP4 / TS from the first stream), tried
    in turn: the seek goes a few seconds before the guess. None when no packet is found."""
    for guess in guesses:
        try:
            p = subprocess.run([FFPROBE, '-v', 'error', '-select_streams', 'v:0', '-show_entries', 'packet=pts_time,duration_time',
                                '-of', 'json', '-read_intervals', f'{max(0.0, guess - 8.0):.3f}%', str(path)],
                               stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True, encoding='utf-8', errors='replace', timeout=120)
            packets = json.loads(p.stdout or '{}').get('packets') or []
        except (OSError, ValueError, subprocess.SubprocessError):
            continue
        best = None
        for k in packets:
            t = _seconds(k.get('pts_time'))
            if t is None:
                continue
            d = _seconds(k.get('duration_time'))
            t += d if d else (1.0 / fps if fps else 0.0)
            best = t if best is None else max(best, t)
        if best:
            return best
    return None


def probe_timing(path):
    """V22.2: what ffprobe says about WHEN things start and how long the PICTURE is, or None when it cannot be probed.
        v_start  presentation time of the first picture on the file's own timeline (MPEG-TS starts at ~1.4 s, an MKV may start at
                 any offset, a download may have the audio start earlier / later than the picture)
        a_start  the same for the audio (None = no audio)
        f_start  start time of the container = the earliest stream; ffmpeg subtracts it from every input unless -copyts is given
        offset   v_start - f_start: where ffmpeg puts the first picture on ITS timeline (0 for most phone / YouTube files)
        picture  length of the picture track in seconds (the video's real end, which can be shorter than the container: the audio
                 may run on) - None when nothing tells it
        fps      frames per second (None when unknown)"""
    if not FFPROBE:
        return None
    try:
        p = subprocess.run([FFPROBE, '-v', 'error', '-show_entries',
                            'format=start_time,duration:stream=index,codec_type,start_time,duration,nb_frames,r_frame_rate:stream_tags=DURATION',
                            '-of', 'json', str(path)], stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True,
                           encoding='utf-8', errors='replace', timeout=60)
        if p.returncode:
            return None
        data = json.loads(p.stdout or '{}')
    except (OSError, ValueError, subprocess.SubprocessError):
        return None
    fmt = data.get('format') or {}
    streams = data.get('streams') or []
    video = next((s for s in streams if s.get('codec_type') == 'video'), None)
    audio = next((s for s in streams if s.get('codec_type') == 'audio'), None)
    if not video:
        return None
    f_start = _seconds(fmt.get('start_time'))
    f_start = 0.0 if f_start is None else f_start
    v_start = _seconds(video.get('start_time'))
    v_start = f_start if v_start is None else v_start
    a_start = _seconds((audio or {}).get('start_time')) if audio else None
    fps = None
    try:
        num, den = str(video.get('r_frame_rate') or '').split('/')
        fps = float(num) / float(den) if float(den) else None
    except (ValueError, ZeroDivisionError):
        fps = None
    picture = _seconds(video.get('duration'))
    whole = _seconds(fmt.get('duration'))
    tag = _tag_seconds((video.get('tags') or {}).get('DURATION'))       # Matroska / WebM: a stream-duration tag, counted from 0 (not from v_start)
    if not picture or picture <= 0:
        # No stream duration (Matroska, WebM...): the exact end of the last picture, read from the packets of the final seconds only
        # (a quick seek, nothing is decoded). Neither the container duration nor the tag is trusted here: both can be counted from 0
        # instead of from the first picture when a file starts at an offset.
        guesses = [g for g in ((f_start + whole) if whole is not None else None, whole, tag) if g]
        end = _tail_end(path, guesses, fps) if guesses else None
        picture = max(0.01, end - v_start) if end else None
    if not picture or picture <= 0:
        picture = tag
    if not picture or picture <= 0:
        frames = _seconds(video.get('nb_frames'))
        picture = frames / fps if frames and fps else None
    if not picture or picture <= 0:                                   # last resort: the container's length from the first picture on
        picture = max(0.01, whole - max(0.0, v_start - f_start)) if whole else None
    return {'v_start': v_start, 'a_start': a_start, 'f_start': f_start, 'offset': v_start - f_start, 'picture': picture, 'fps': fps}


def picture_duration(path):
    """Length of the PICTURE (see probe_timing). Everything that must end 'where the video ends' - the narration, the subtitles
    - is measured against this, not against the container duration (which can be longer when the audio runs past the last frame)."""
    info = probe_timing(path)
    if info and info.get('picture'):
        return max(0.01, float(info['picture']))
    return duration(path)


def audio_track():
    """AUDIO_TRACK=N in .env: use the N-th audio stream (0 = the first) instead of ffmpeg's pick. Films with several audio tracks (dub +
    original, commentary, 5.1 + stereo) otherwise give whichever ffmpeg rates best - not always the one you hear. Empty = ffmpeg's choice."""
    raw = (os.getenv('AUDIO_TRACK') or '').strip()
    if not raw:
        return None
    try:
        n = int(raw)
    except ValueError:
        return None
    return n if n >= 0 else None


def extract_audio_wav(input_path, out_path, rate=16000, track=None):
    """The film's sound as a mono WAV whose sample 0 is the FIRST PICTURE of the video, so every time Whisper reports is a time
    on the picture's own timeline. Plain `ffmpeg -i x -ac 1` starts the WAV at the container's start instead; for an MKV / TS /
    download whose audio and picture do not start together that is 22 ms to 0.5 s of drift (V22.2 measurement):
    * -itsoffset moves the audio by the picture's offset (the sound before the first picture is dropped),
    * aresample first_pts=0 pads a late-starting audio with silence so it keeps its real distance from the picture."""
    info = probe_timing(input_path)
    shift = -float(info['offset']) if info else 0.0
    args = []
    if abs(shift) > 0.0005:
        args += ['-itsoffset', f'{shift:.6f}']
    track = audio_track() if track is None else track
    args += ['-i', input_path, '-vn']
    if track is not None:
        args += ['-map', f'0:a:{int(track)}']
    args += ['-af', 'aresample=async=1:first_pts=0', '-ac', '1', '-ar', rate, '-c:a', 'pcm_s16le', out_path]
    ffmpeg(*args)


def clean_repeated_text(text, previous=''):
    # Remove only obvious accidental full/near-full duplication; do not rewrite normal content.
    text = re.sub(r'\s+', ' ', str(text or '')).strip()
    if previous:
        a = re.sub(r'[၊။,!?\s]+', '', previous)
        b = re.sub(r'[၊။,!?\s]+', '', text)
        if a and b and (a == b or (len(a) > 18 and (a in b or b in a))):
            return '' if len(b) <= len(a) else text[len(previous):].strip(' ၊။,')
    return text

def _flag(v):
    return str(v).strip().lower() in ('1', 'true', 'on', 'yes', 'y')


def video_size(path):
    # (width, height) as the video is DISPLAYED (rotation applied). Falls back to 1280x720.
    try:
        p = subprocess.run([FFMPEG, '-hide_banner', '-i', str(path)], stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                           text=True, encoding='utf-8', errors='replace')
        info = p.stderr
        m = re.search(r'Video:.*?,\s*(\d{2,5})x(\d{2,5})(?=[\s,\[])', info)
        if m:
            w, h = int(m.group(1)), int(m.group(2))
            r = re.search(r'rotat\w*\s*(?:of|:)\s*(-?\d+(?:\.\d+)?)', info)
            if r and int(abs(float(r.group(1)))) % 180 == 90:
                w, h = h, w
            return w, h
    except Exception:
        pass
    return 1280, 720

@functools.lru_cache(maxsize=None)
def _ffmpeg_list(kind):
    p = subprocess.run([FFMPEG, '-hide_banner', '-' + kind], stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                       text=True, encoding='utf-8', errors='replace')
    return p.stdout


def ffmpeg_has(kind, name):
    # kind is 'filters' or 'encoders'
    return re.search(r'^\s*\S+\s+' + re.escape(name) + r'\s', _ffmpeg_list(kind), re.M) is not None


# ---- Burmese font -------------------------------------------------------------------------
FONT_DIR = ROOT / 'fonts'


def font_family_name(path):
    # Minimal OpenType/TrueType 'name' table reader (no extra package needed).
    # Returns the family name that libass / FreeType knows the font by, or None.
    try:
        data = Path(path).read_bytes()
        base = struct.unpack('>I', data[12:16])[0] if data[:4] == b'ttcf' else 0      # first font of a .ttc
        n_tables = struct.unpack('>H', data[base + 4:base + 6])[0]
        name_off = None
        for i in range(n_tables):
            tag, _sum, off, _len = struct.unpack('>4sIII', data[base + 12 + i * 16: base + 28 + i * 16])
            if tag == b'name':
                name_off = off
                break
        if name_off is None:
            return None
        _fmt, count, str_off = struct.unpack('>HHH', data[name_off:name_off + 6])
        found = {}
        for i in range(count):
            pid, _eid, lid, nid, ln, so = struct.unpack('>6H', data[name_off + 6 + i * 12: name_off + 18 + i * 12])
            if nid not in (1, 16):
                continue
            raw = data[name_off + str_off + so: name_off + str_off + so + ln]
            if pid in (0, 3):
                s = raw.decode('utf-16-be', 'ignore').strip()
            elif pid == 1:
                s = raw.decode('mac_roman', 'ignore').strip()
            else:
                continue
            if s:
                found.setdefault(nid, {}).setdefault(0 if (pid == 3 and lid == 0x409) else 1, s)
        for nid in (16, 1):                       # typographic family first, like FreeType does
            if nid in found:
                return found[nid][min(found[nid])]
    except Exception:
        return None
    return None


def find_burmese_font():
    # Returns (font_path, family_name) for a Burmese-capable font, or (None, None).
    # Order: SUBTITLE_FONT from .env, the project's fonts/ folder, then common system locations.
    cands = []
    env = (os.getenv('SUBTITLE_FONT') or '').strip().strip('"')
    if env:
        cands.append(Path(env))
    if FONT_DIR.is_dir():
        cands += sorted(p for p in FONT_DIR.iterdir() if p.suffix.lower() in ('.ttf', '.otf', '.ttc'))
    win = Path(os.getenv('WINDIR') or r'C:\Windows') / 'Fonts'
    cands += [win / 'mmrtext.ttf', win / 'mmrtextb.ttf']                      # "Myanmar Text" ships with Windows 10/11
    cands += [Path(p) for p in (
        '/usr/share/fonts/truetype/noto/NotoSansMyanmar-Regular.ttf',
        '/usr/share/fonts/opentype/noto/NotoSansMyanmar-Regular.ttf',
        '/usr/share/fonts/truetype/noto/NotoSerifMyanmar-Regular.ttf',
        '/usr/share/fonts/truetype/padauk/Padauk-Regular.ttf',
        '/System/Library/Fonts/Supplemental/NotoSansMyanmar.ttc',
        '/System/Library/Fonts/NotoSansMyanmar.ttc',
        '/System/Library/Fonts/Supplemental/Myanmar Sangam MN.ttc',
        '/Library/Fonts/Myanmar Sangam MN.ttc')]
    for p in cands:
        try:
            if p.is_file():
                name = (os.getenv('SUBTITLE_FONT_NAME') or '').strip() or font_family_name(p)
                if name:
                    return p, name
        except OSError:
            continue
    return None, None


def subtitle_problem():
    # '' when burned-in subtitles can work, otherwise a human-readable reason (shown on the website).
    if not ffmpeg_has('filters', 'ass'):
        return ('ဒီ FFmpeg မှာ စာတန်းထည့်ဖို့ လိုတဲ့ libass ("ass" filter) မပါပါဘူး။ .env ထဲမှာ FFMPEG_PATH ကို '
                'libass ပါတဲ့ full build (ဥပမာ gyan.dev ရဲ့ ffmpeg "full" build) ကို ညွှန်ပေးပါ။')
    if not find_burmese_font()[0]:
        return ('မြန်မာစာ ဖောင့် မတွေ့ပါ။ project ထဲက fonts ဖိုလ်ဒါထဲ မြန်မာ Unicode ဖောင့် (ဥပမာ NotoSansMyanmar-Regular.ttf '
                'သို့မဟုတ် Padauk-Regular.ttf) ထည့်ပြီး ပြန်စမ်းပါ။ (Windows မှာ Myanmar Text ရှိရင် အလိုအလျောက် သုံးပါတယ်။)')
    return ''


# Subtitle colour in ASS notation (&HAABBGGRR): yellow. White would be &H00FFFFFF.
SUBTITLE_COLOUR = '&H0000FFFF'


# ---- Subtitle text layout -----------------------------------------------------------------
def _syllable_starts(text):
    # Rough Burmese syllable boundaries (used only when a long line has no space to break at).
    out = []
    for i, ch in enumerate(text):
        if i == 0 or not ('\u1000' <= ch <= '\u1021' or ch in '\u1023\u1024\u1025\u1026\u1027\u1029\u102a'):
            continue
        nxt = text[i + 1] if i + 1 < len(text) else ''
        if text[i - 1] == '\u1039' or nxt in ('\u103a', '\u1039'):      # stacked consonant / final consonant (asat)
            continue
        out.append(i)
    return out


def wrap_burmese(text, max_chars):
    # Split a long subtitle into balanced lines (libass only wraps at spaces, Burmese often has few).
    text = re.sub(r'\s+', ' ', str(text or '')).strip()
    if len(text) <= max_chars:
        return text
    n = -(-len(text) // max_chars)
    per = len(text) / n
    soft = sorted({i + 1 for i, ch in enumerate(text[:-1]) if ch == ' ' or ch in '၊။,.!?;'})
    hard = _syllable_starts(text)
    cuts, last = [], 0
    for k in range(1, n):
        target = per * k
        pick = None
        for pool, spread in ((soft, 0.40), (hard, 0.40), (soft, 0.75), (hard, 0.75)):
            cand = [c for c in pool if abs(c - target) <= per * spread and c > last]
            if cand:
                pick = min(cand, key=lambda c: abs(c - target))
                break
        if pick:
            cuts.append(pick)
            last = pick
    parts, prev = [], 0
    for c in cuts + [len(text)]:
        parts.append(text[prev:c].strip())
        prev = c
    return '\n'.join(p for p in parts if p)


def ass_time(t):
    cs = max(0, int(round(float(t) * 100)))
    return f'{cs // 360000}:{cs // 6000 % 60:02d}:{cs // 100 % 60:02d}.{cs % 100:02d}'


def ass_escape(text):
    return str(text).replace('\\', '').replace('{', '(').replace('}', ')').replace('\r', '').replace('\n', '\\N')


# V22.1: the text is as big as the blurred band allows - no empty space above / below it. libass spaces the lines exactly
# one font size apart (measured with the bundled Padauk font: 1, 2, 3 lines are 1 x, 2 x, 3 x the size high), so a block of
# n lines is n x size high. A dark box (BorderStyle 3) adds its padding (edge() = 0.25 x size) above and below the block.
BOX_PAD = 0.5       # (the two paddings of a box, in font sizes)
BAND_LINES = 1.5    # at 100 % one line of text is 1/1.5 = two thirds of the band high; a longer subtitle is shrunk until it just fits


def band_size(band_h, font_pct=100.0, boxed=False):
    """Font size (px) of the subtitles in blur-band mode: it follows the HEIGHT OF THE BAND, so the text grows and shrinks with the
    box instead of staying tiny inside a big box (a subtitle that needs two or three lines is made smaller by fit_subtitle() until
    all its lines just fit). font_pct is the size slider of the review page (100 = the normal fill)."""
    return max(14, int(band_h / (BAND_LINES + (BOX_PAD if boxed else 0.0)) * float(font_pct) / 100.0))


def fit_subtitle(text, avail_width, band_h, size, boxed=False):
    # Wrap one subtitle and, if needed, shrink the font so every line fits INSIDE the blurred band (no more than that).
    pad = BOX_PAD if boxed else 0.0
    s = size
    while True:
        max_chars = int(max(10, min(90, avail_width / (s * 0.42))))
        wrapped = wrap_burmese(text, max_chars)
        lines = wrapped.count('\n') + 1
        if (lines + pad) * s <= band_h or s <= 12:
            return wrapped, s
        s -= 1                                             # the biggest size that fits (a jump to band_h / lines would overshoot)


LOOK_DEFAULT = {'font': 100.0, 'bottom': None, 'colour': None, 'box': False, 'box_alpha': 60.0, 'offset': 0.0}
BLUR_DEFAULT = {'strength': 100.0, 'dark': 30.0}


def _bounded(raw, key, lo, hi, default):
    try:
        v = float(raw.get(key))
    except (TypeError, ValueError):
        return default
    if v != v:                                             # NaN
        return default
    return max(lo, min(hi, v))


def clean_look(raw):
    """How the subtitles look (chosen on the review page) -> a plain, validated dict. Unknown keys are dropped and every
    number is clamped, so whatever the browser sends can never break the ASS file / the ffmpeg command.
      font       size in % of the normal size (the classic look = 100)
      bottom     None = automatic (centred in the blurred band, or the classic place near the bottom); a number = the
                 distance of the text from the bottom edge, in % of the picture height
      colour     '#RRGGBB' or None (= the classic yellow)
      box        a dark box behind the text;  box_alpha = how solid it is (%)
      offset     seconds every subtitle is moved (negative = earlier)"""
    raw = raw if isinstance(raw, dict) else {}
    bottom = raw.get('bottom')
    try:
        bottom = None if bottom is None or str(bottom).strip() == '' else max(0.0, min(80.0, float(bottom)))
        if bottom is not None and bottom != bottom:
            bottom = None
    except (TypeError, ValueError):
        bottom = None
    colour = str(raw.get('colour') or '').strip()
    return {'font': _bounded(raw, 'font', 40.0, 250.0, 100.0), 'bottom': bottom,
            'colour': colour.upper() if re.fullmatch(r'#[0-9a-fA-F]{6}', colour) else None,
            'box': _flag(raw.get('box')), 'box_alpha': _bounded(raw, 'box_alpha', 10.0, 100.0, 60.0),
            'offset': _bounded(raw, 'offset', -30.0, 30.0, 0.0)}


def clean_blur(raw):
    """The blurred band that hides the ORIGINAL text -> validated dict (or None = no blur).
    top = % from the top (None = glued to the bottom edge), height = % of the picture, strength = % (100 = classic),
    dark = how much the band is darkened (%, 30 = classic)."""
    if not isinstance(raw, dict):
        return None
    top = raw.get('top')
    try:
        top = None if top is None or str(top).strip() == '' or float(top) < 0 else max(0.0, min(96.0, float(top)))
        if top is not None and top != top:
            top = None
    except (TypeError, ValueError):
        top = None
    return {'top': top, 'height': _bounded(raw, 'height', 4.0, 60.0, 18.0),
            'strength': _bounded(raw, 'strength', 20.0, 300.0, BLUR_DEFAULT['strength']),
            'dark': _bounded(raw, 'dark', 0.0, 100.0, BLUR_DEFAULT['dark'])}


def ass_colour(rgb, alpha=0):
    """'#RRGGBB' -> ASS '&HAABBGGRR' (alpha 0 = solid, 255 = invisible)."""
    r, g, b = rgb[1:3], rgb[3:5], rgb[5:7]
    return '&H%02X%s%s%s' % (max(0, min(255, int(alpha))), b, g, r)


def build_ass(segs, width, height, font_name, band=None, look=None):
    # band = (y, h) in pixels: the ORIGINAL text is blurred there, and every Burmese subtitle is centred
    # (horizontally and vertically) inside that same band. band=None: plain subtitles near the bottom.
    # look = the appearance chosen on the review page (clean_look); None = the classic look, exactly as before.
    look = clean_look(look) if look is not None else None
    base = min(width, height)
    size = max(18, int(round(base * 0.055 * (look['font'] / 100.0 if look else 1.0))))
    margin_x = int(width * 0.06)
    margin_v = int(height * 0.07)
    manual = bool(look and look['bottom'] is not None)    # the person placed the text by its distance from the bottom edge
    boxed = bool(look and look['box'])
    if band and not manual:
        size = band_size(band[1], look['font'] if look else 100.0, boxed)     # the text fills the band (V22.1)

    def edge(fs):                                          # outline thickness (with a box it is the padding around the text)
        return max(2.0, round(fs * 0.25, 1)) if boxed else max(1.0, round(fs * 0.07, 1))
    outline = edge(size)
    max_chars = int(max(14, min(80, (width - 2 * margin_x) / (size * 0.42))))
    font_name = str(font_name).replace(',', ' ')
    primary = ass_colour(look['colour']) if look and look['colour'] else SUBTITLE_COLOUR
    if boxed:                                              # BorderStyle 3 = opaque box; libass paints it with the OutlineColour
        edge_colour = ass_colour('#000000', round((100.0 - look['box_alpha']) / 100.0 * 255))
        back, border_style, shadow = '&H80000000', 3, 0
    else:
        edge_colour, back, border_style, shadow = '&H00000000', '&H80000000', 1, 1
    head = (
        '[Script Info]\nScriptType: v4.00+\n'
        f'PlayResX: {width}\nPlayResY: {height}\nWrapStyle: 0\nScaledBorderAndShadow: yes\n\n'
        '[V4+ Styles]\n'
        'Format: Name, Fontname, Fontsize, PrimaryColour, SecondaryColour, OutlineColour, BackColour, Bold, Italic, '
        'Underline, StrikeOut, ScaleX, ScaleY, Spacing, Angle, BorderStyle, Outline, Shadow, Alignment, MarginL, MarginR, '
        'MarginV, Encoding\n'
        f'Style: Default,{font_name},{size},{primary},&H000000FF,{edge_colour},{back},0,0,0,0,100,100,0,0,{border_style},'
        f'{outline},{shadow},2,{margin_x},{margin_x},{margin_v},1\n\n'
        '[Events]\nFormat: Layer, Start, End, Style, Name, MarginL, MarginR, MarginV, Effect, Text\n'
    )
    rows = []
    for x in segs:
        raw = x.get('burmese', '')
        if not str(raw).strip():
            continue
        if manual:
            # \an2 = bottom-centre anchor: the text grows upwards from the chosen distance above the bottom edge.
            text = wrap_burmese(raw, max_chars)
            pad = edge(size)
            tag = '{\\an2\\pos(%d,%d)\\fs%d\\bord%s}' % (width // 2, int(round(height - height * look['bottom'] / 100.0 - pad)), size, pad)
        elif band:
            text, fs = fit_subtitle(raw, width - 2 * margin_x, band[1], size, boxed)
            # \an5 = middle-centre anchor, \pos = the middle of the blurred band.
            tag = '{\\an5\\pos(%d,%d)\\fs%d\\bord%s}' % (width // 2, band[0] + band[1] // 2, fs, edge(fs))
        else:
            text, tag = wrap_burmese(raw, max_chars), ''
        if text.strip():
            rows.append(f'Dialogue: 0,{ass_time(x["start"])},{ass_time(x["end"])},Default,,0,0,0,,{tag}{ass_escape(text)}')
    return head + '\n'.join(rows) + '\n'


def shift_segments(segs, offset, video_total):
    """Move every subtitle by `offset` seconds (negative = earlier). A line that ends up completely outside the video is dropped."""
    off = float(offset or 0.0)
    if abs(off) < 0.005:
        return segs
    out = []
    for x in segs:
        a, b = float(x['start']) + off, float(x['end']) + off
        if b <= 0.05 or a >= float(video_total) - 0.05:
            continue
        y = dict(x)
        y['start'], y['end'] = max(0.0, a), min(float(video_total), b)
        if y['end'] - y['start'] >= 0.05:
            out.append(y)
    return out


# Subtitle-only mode: a Burmese line is on screen ONLY while its speech is heard.
SUB_LEAD = 0.05     # seconds the line may appear before the first word
SUB_TAIL = 0.20     # seconds it may stay after the last word
SUB_MIN = 0.8       # shortest time a line stays visible (so a one-word line can still be read)


def prepare_subtitle_segments(segs, video_total):
    # Subtitle-only mode: there is no voice to fit, so every line follows the real speech (speech_start ..
    # speech_end from the VAD step). It is NOT held until the next line starts: when nobody speaks the
    # subtitle disappears.
    out, previous = [], ''
    for x in segs:
        text = clean_repeated_text(x.get('burmese', ''), previous)
        if not text:
            continue
        previous = text
        a = float(x.get('speech_start', x['start']))
        b = float(x.get('speech_end', x['end']))
        start = max(0.0, a - SUB_LEAD)
        end = min(max(b + SUB_TAIL, start + SUB_MIN), video_total)
        x['burmese'], x['start'], x['end'] = text, start, end
        out.append(x)
    # Never let two lines overlap (they would be drawn on top of each other).
    for cur, nxt in zip(out, out[1:]):
        if cur['end'] > nxt['start'] - 0.02:
            cur['end'] = max(cur['start'] + 0.1, nxt['start'] - 0.02)
    return [x for x in out if x['end'] - x['start'] >= 0.05]


def blur_band(height, top_pct=None, height_pct=18):
    # The band (y, h in pixels) that hides the ORIGINAL burned-in text. top_pct = where the band starts, as a
    # percentage of the picture height counted from the TOP (None = glued to the bottom edge).
    # Even numbers (yuv420), at least 16 px, always inside the picture.
    H = int(height) // 2 * 2
    h = int(round(H * max(4, min(60, float(height_pct))) / 100.0 / 2) * 2)
    h = max(16, min(h, H))
    if top_pct is None or float(top_pct) < 0:
        y = H - h
    else:
        y = int(round(H * max(0.0, min(96.0, float(top_pct))) / 100.0 / 2) * 2)
    y = max(0, min(y, H - h)) // 2 * 2
    return y, h


def build_video_filter(w, h, band, strength=100.0, dark=30.0):
    # Video filter graph. band=None -> no blur (just the subtitles).
    # With a band: that exact strip is cropped, blurred hard + slightly darkened, put back at the same place,
    # and the yellow Burmese subtitles are drawn on top of it.
    # strength (%): how many times the box blur is applied (100 = the classic 3 passes); dark (%): how much the strip is darkened.
    tail = 'ass=burmese.ass:fontsdir=fonts'
    if not band:
        return 'scale=trunc(iw/2)*2:trunc(ih/2)*2,' + tail
    # Work on the even-sized frame that build_ass() / ffmpeg will really use.
    w, h = w // 2 * 2, h // 2 * 2
    y, bh = band
    r = max(2, min(40, bh // 4 - 1))        # boxblur radius must stay below a quarter of the band (chroma plane)
    passes = max(1, min(8, int(round(3 * float(strength) / 100.0))))
    return (f'scale={w}:{h},split[main][b];'
            f'[b]crop={w}:{bh}:0:{y},boxblur=luma_radius={r}:luma_power={passes}:chroma_radius={r}:chroma_power={passes},'
            f'drawbox=x=0:y=0:w=iw:h=ih:color=black@{max(0.0, min(1.0, float(dark) / 100.0)):.2f}:t=fill[blur];'
            f'[main][blur]overlay=0:{y},' + tail + '[vout]')



# ------------------------------------------------------------------------------------------------ running ffmpeg
def ffmpeg_run(args, total=None, on_progress=None, cwd=None, should_stop=None, start=0.0):
    # Like ffmpeg(), but reads ffmpeg's -progress output so a long render can report a percentage, and can be cancelled:
    # should_stop() is asked about once a second; when it says True ffmpeg is killed and Stopped is raised.
    # `start` = the output time at which the picture begins (only not 0 with -copyts), so the percentage still runs from 0 to 100.
    cmd = [FFMPEG, '-y', '-hide_banner', '-loglevel', 'error', '-nostats', '-progress', 'pipe:1', *map(str, args)]
    p = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True,
                         encoding='utf-8', errors='replace', cwd=cwd)
    known = {'frame', 'fps', 'bitrate', 'total_size', 'out_time', 'dup_frames', 'drop_frames', 'speed', 'progress'}
    tail = []
    try:
        for line in p.stdout:
            if should_stop and should_stop():
                raise Stopped()
            line = line.strip()
            key, _, val = line.partition('=')
            if key in ('out_time_us', 'out_time_ms'):          # both are microseconds in ffmpeg
                try:
                    if on_progress and total:
                        on_progress(min(1.0, max(0.0, (int(val) / 1e6 - start) / total)))
                except ValueError:
                    pass
            elif key in known or key.startswith('stream_'):
                continue
            elif line:
                tail = (tail + [line])[-30:]
    except BaseException:
        p.kill()
        p.wait()
        raise
    finally:
        try:
            p.stdout.close()
        except Exception:
            pass
    if p.wait():
        raise RuntimeError('\n'.join(tail)[-5000:] or 'FFmpeg failed')


RENDER_PRESETS = ('ultrafast', 'superfast', 'veryfast', 'faster', 'fast', 'medium')


def render_preset(name=None):
    name = (name or os.getenv('RENDER_PRESET') or 'veryfast').strip().lower()
    return name if name in RENDER_PRESETS else 'veryfast'


def video_encoder(preset):
    if ffmpeg_has('encoders', 'libx264'):
        crf = {'ultrafast': 24, 'superfast': 23}.get(preset, 21)
        return ['-c:v', 'libx264', '-preset', preset, '-crf', str(crf), '-pix_fmt', 'yuv420p']
    return ['-c:v', 'mpeg4', '-q:v', '3', '-pix_fmt', 'yuv420p']


def render_with_subtitles(work, input_path, segs, narrated, out, video_total, blur=None, on_progress=None,
                          should_stop=None, preset=None, look=None):
    # Burn the Burmese subtitles into the picture (re-encodes the video). With `narrated` the
    # Burmese voice replaces the original audio, otherwise the original audio is kept.
    # blur = None, or {'top': % from the top (None = bottom edge), 'height': % of the picture height,
    #                  optional 'strength' / 'dark' in % (see build_video_filter)}.
    # look = None, or the appearance chosen on the review page (see clean_look / build_ass).
    # on_progress(0..1) is called while ffmpeg works.
    work = Path(work)
    font_path, font_name = find_burmese_font()
    if not font_path:
        raise RuntimeError(subtitle_problem() or 'Burmese font not found.')
    fonts = work / 'fonts'
    fonts.mkdir(exist_ok=True)
    shutil.copy2(font_path, fonts / font_path.name)
    w, h = video_size(input_path)
    w, h = w // 2 * 2, h // 2 * 2
    band = blur_band(h, blur.get('top'), blur.get('height', 18)) if blur else None
    (work / 'burmese.ass').write_text(build_ass(segs, w, h, font_name, band, look), encoding='utf-8')
    # Relative names + cwd=work avoid the Windows "C:\\" escaping problems inside ffmpeg filter strings.
    vf = build_video_filter(w, h, band, (blur or {}).get('strength', 100.0), (blur or {}).get('dark', 30.0))
    venc = video_encoder(render_preset(preset))
    complex_graph = vf.endswith('[vout]')           # blur needs a labelled graph (-filter_complex)
    # V22.2 timing (measured with a burned-in timecode and audio beeps, see tests/test_ffmpeg_timing.py):
    # * setpts=PTS-STARTPTS puts the first picture at 0 whatever the container says (MKV / TS offsets, a late-starting video), so the
    #   subtitles (drawn by frame time), the narration (starts at 0) and the first frame all begin together;
    # * the ORIGINAL sound (no narration) keeps its real distance from the picture: it is moved by the same offset (atrim/asetpts);
    # * no -shortest (it chopped the picture when the narration was shorter): the narration is cut / padded to the picture's length
    #   at sample level and -t ends the file exactly where the picture ends.
    info = probe_timing(input_path) or {}
    shift = max(0.0, float(info.get('offset') or 0.0))
    picture = float(info.get('picture') or 0.0) or float(video_total or 0.0)
    if narrated and picture > 0:
        _timing().fit_wav(narrated, picture)
    vf = 'setpts=PTS-STARTPTS,' + vf
    args = ['-i', input_path]
    if narrated:
        args += ['-i', narrated]
    args += ['-filter_complex', vf] if complex_graph else ['-vf', vf]
    args += ['-map', '[vout]' if complex_graph else '0:v:0']
    if narrated:
        args += ['-map', '1:a:0']
    else:
        args += ['-map', f'0:a:{audio_track() or 0}?']          # V22.3: the track Whisper listened to (AUDIO_TRACK) is the one that is heard
        if shift > 0.0005:
            args += ['-af', f'atrim=start={shift:.6f},asetpts=PTS-{shift:.6f}/TB']
    args += [*venc, '-c:a', 'aac', '-b:a', '192k', '-ar', '48000', '-ac', '2', '-movflags', '+faststart']
    if picture > 0:
        args += ['-t', f'{picture:.6f}']
    ffmpeg_run(args + [out], total=video_total, on_progress=on_progress, cwd=str(work), should_stop=should_stop)


def mux_narration(input_path, narrated, out, video_total=None, on_progress=None, should_stop=None):
    # Voice only: the picture is copied untouched (seconds, not minutes), the audio is the Burmese narration.
    #
    # V22.2 - how the narration is made to start EXACTLY at the first picture and the file to end exactly with it
    # (measured on generated films with a burned-in frame number and audio beeps, tests/test_ffmpeg_timing.py):
    # * `-copyts` keeps every timestamp of the source as it is, so the first picture stays at v_start on the file's own timeline
    #   (ffmpeg would otherwise subtract the container start, which is not the picture's start for MKV / TS / late-starting video);
    # * `-itsoffset v_start` puts narration sample 0 at that very moment - the same instant as the first picture;
    # * `-avoid_negative_ts make_zero` then shifts picture and sound together so the finished MP4 starts at 0 (the video's own
    #   B-frame delay makes its first picture 0.08 s; the narration starts together with that picture);
    # * no `-shortest` (it cut the picture off when the narration was shorter): the narration was cut / padded to the picture's
    #   length at sample level (timing.fit_wav) and `-t v_start + picture` ends the file on the picture's last frame (with -copyts
    #   the limit is on the source's timeline, hence the v_start).
    info = probe_timing(input_path) or {}
    v_start = float(info.get('v_start') or 0.0)
    picture = float(info.get('picture') or 0.0) or float(video_total or 0.0)
    if picture > 0:
        _timing().fit_wav(narrated, picture)
    args = ['-copyts', '-i', input_path, '-itsoffset', f'{v_start:.6f}', '-i', narrated, '-map', '0:v:0', '-map', '1:a:0',
            '-c:v', 'copy', '-c:a', 'aac', '-b:a', '192k', '-ar', '48000', '-ac', '2', '-movflags', '+faststart',
            '-avoid_negative_ts', 'make_zero']
    if picture > 0:
        args += ['-t', f'{v_start + picture:.6f}']
    ffmpeg_run(args + [out], total=picture or video_total, on_progress=on_progress, should_stop=should_stop, start=v_start)


def _timing():
    import timing                                        # (imported late: timing is a leaf module, this keeps media import-light)
    return timing


def write_subtitle_files(work, segs):
    # Burmese SRT + VTT next to the video.
    work = Path(work)

    def st(t):
        ms = int(round((t - int(t)) * 1000))
        base = int(t)
        if ms >= 1000:
            base += 1
            ms -= 1000
        return f'{base // 3600:02d}:{(base % 3600) // 60:02d}:{base % 60:02d},{ms:03d}'
    (work / 'burmese.srt').write_text('\n\n'.join(f'{i + 1}\n{st(x["start"])} --> {st(x["end"])}\n{x["burmese"]}' for i, x in enumerate(segs)), encoding='utf-8')
    (work / 'burmese.vtt').write_text('WEBVTT\n\n' + '\n\n'.join(f'{st(x["start"]).replace(",", ".")} --> {st(x["end"]).replace(",", ".")}\n{x["burmese"]}' for x in segs), encoding='utf-8')


# ------------------------------------------------------------------------------------------------ the review page (V21.1)
def font_metric_scale(path):
    """libass sizes a font so that ascent + descent (OS/2 winAscent + winDescent, else hhea) equals the ASS font size, while a
    web page sizes it by the em. Returns em / (ascent + descent): multiply an ASS font size by it to get the CSS font-size
    that looks the same size. None when the table cannot be read."""
    try:
        data = Path(path).read_bytes()
        base = struct.unpack('>I', data[12:16])[0] if data[:4] == b'ttcf' else 0
        n = struct.unpack('>H', data[base + 4:base + 6])[0]
        tables = {}
        for i in range(n):
            tag, _sum, off, _len = struct.unpack('>4sIII', data[base + 12 + i * 16: base + 28 + i * 16])
            tables[tag] = off
        upem = struct.unpack('>H', data[tables[b'head'] + 18: tables[b'head'] + 20])[0]
        total = 0
        if b'OS/2' in tables:
            o = tables[b'OS/2']
            total = struct.unpack('>H', data[o + 74:o + 76])[0] + struct.unpack('>H', data[o + 76:o + 78])[0]
        if not total and b'hhea' in tables:
            hh = tables[b'hhea']
            total = struct.unpack('>h', data[hh + 4:hh + 6])[0] - struct.unpack('>h', data[hh + 6:hh + 8])[0]
        return round(upem / total, 4) if upem and total > 0 else None
    except Exception:
        return None


def render_frame(input_path, work, at, text, blur, look, out_path, size=None, max_width=960):
    """ONE picture of what the finished video will look like at second `at`: the very same ASS file and the very same blur
    filter as the real render, with `text` as the subtitle. Written as a JPEG (at most `max_width` wide). Used by the review
    page's "see the real picture" button."""
    work = Path(work) / 'frame'
    (work / 'fonts').mkdir(parents=True, exist_ok=True)
    font_path, font_name = find_burmese_font()
    if not font_path:
        raise RuntimeError(subtitle_problem() or 'Burmese font not found.')
    shutil.copy2(font_path, work / 'fonts' / font_path.name)
    w, h = size or video_size(input_path)
    w, h = w // 2 * 2, h // 2 * 2
    blur = clean_blur(blur)
    band = blur_band(h, blur.get('top'), blur.get('height', 18)) if blur else None
    (work / 'burmese.ass').write_text(build_ass([{'start': 0.0, 'end': 600.0, 'burmese': text}], w, h, font_name, band, look or {}),
                                      encoding='utf-8')
    vf = build_video_filter(w, h, band, (blur or {}).get('strength', 100.0), (blur or {}).get('dark', 30.0))
    shrink = f'scale=min({int(max_width)}\\,iw):-2'
    if vf.endswith('[vout]'):
        graph, label = vf + f';[vout]{shrink}[shot]', '[shot]'
    else:
        graph, label = vf + ',' + shrink, None
    out_path = Path(out_path).resolve()
    # V22.2: the exact second. `at` is a time on the PICTURE's timeline; ffmpeg's -ss counts from the container start, so the
    # picture's offset is added. Hybrid seek: a quick jump (-ss BEFORE -i) to a few seconds earlier, then the exact position
    # (-ss AFTER -i) is decoded up to - frame-accurate, and still fast on a 2 hour film.
    info = probe_timing(input_path) or {}
    half = 0.5 / float(info['fps']) if info.get('fps') else 0.0       # -ss takes the first frame AT OR AFTER the time: half a frame earlier = the NEAREST frame
    target = max(0.0, float(at) + max(0.0, float(info.get('offset') or 0.0)) - half)
    coarse = max(0.0, target - 10.0)
    args = ['-ss', f'{coarse:.3f}', '-i', str(Path(input_path).resolve()), '-ss', f'{target - coarse:.3f}', '-frames:v', '1', '-q:v', '4']
    args += ['-filter_complex', graph, '-map', label] if label else ['-vf', graph]
    tmp = out_path.with_name(out_path.name + '.part.jpg')
    # cwd = work: the relative file names inside the filter graph (burmese.ass, fonts) are the same ones the real render uses
    p = subprocess.run([FFMPEG, '-y', '-hide_banner', '-loglevel', 'error', *args, str(tmp)], cwd=str(work),
                       stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True, encoding='utf-8', errors='replace', timeout=90)
    if p.returncode or not tmp.is_file():
        raise RuntimeError((p.stderr or 'FFmpeg failed')[-2000:])
    tmp.replace(out_path)


def browser_playable(path):
    """True when an ordinary web browser can play this file as it is (H.264 + AAC/MP3 in MP4 / MOV, or VP8 / VP9 / AV1 in
    WebM). The review page streams such a file directly; anything else (MKV, AVI, HEVC, 10-bit, AC3 sound...) gets a small
    MP4 copy made for the preview only."""
    try:
        p = subprocess.run([FFMPEG, '-hide_banner', '-i', str(path)], stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                           text=True, encoding='utf-8', errors='replace')
    except OSError:
        return False
    info = p.stderr
    head = re.search(r'Input #0, ([^\n]*?), from', info)
    formats = [f.strip().lower() for f in (head.group(1) if head else '').split(',')]
    suffix = Path(path).suffix.lower()
    v = re.search(r'Video:\s*([a-z0-9_]+)[^,\n]*,\s*([a-z0-9_]+)', info)
    if not v:
        return False
    codec, pix = v.group(1).lower(), v.group(2).lower()
    if suffix == '.webm':
        ok_container, ok_video = 'webm' in formats, codec in ('vp8', 'vp9', 'av1')
    else:
        ok_container = suffix in ('.mp4', '.m4v', '.mov') and ('mp4' in formats or 'mov' in formats)
        ok_video = codec == 'h264'
    if not (ok_container and ok_video) or not pix.startswith(('yuv420p', 'yuvj420p')) or '10' in pix or '12' in pix:
        return False
    a = re.search(r'Audio:\s*([a-z0-9_]+)', info)
    return a is None or a.group(1).lower() in ('aac', 'mp3', 'opus', 'vorbis')


def make_preview_copy(input_path, out_path, total=None, on_progress=None, should_stop=None, height=480):
    """A small, quick-to-stream MP4 (H.264 + AAC) of the video for the review page. False when this ffmpeg has no H.264 encoder."""
    if not ffmpeg_has('encoders', 'libx264'):
        return False
    tmp = Path(str(out_path) + '.part.mp4')
    # V22.2: the same alignment as the real render (first picture at 0, the sound keeps its distance from it), so the review page's
    # subtitles line up with this copy exactly as they will in the finished video.
    shift = max(0.0, float((probe_timing(input_path) or {}).get('offset') or 0.0))
    audio_fix = ['-af', f'atrim=start={shift:.6f},asetpts=PTS-{shift:.6f}/TB'] if shift > 0.0005 else []
    ffmpeg_run(['-i', input_path, '-map', '0:v:0', '-map', f'0:a:{audio_track() or 0}?', '-vf', f"setpts=PTS-STARTPTS,scale=-2:'min({int(height)},ih)'", *audio_fix,
                '-c:v', 'libx264', '-preset', 'veryfast', '-crf', '30', '-pix_fmt', 'yuv420p', '-c:a', 'aac', '-b:a', '64k',
                '-ac', '2', '-movflags', '+faststart', tmp], total=total, on_progress=on_progress, should_stop=should_stop)
    tmp.replace(out_path)
    return True
