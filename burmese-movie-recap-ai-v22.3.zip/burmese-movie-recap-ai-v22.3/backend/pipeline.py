"""The processing pipeline of one job (V22.3).

Two writing styles (presets.py), one AI: Gemini (gemini_client.py):

  style "direct" (line by line)
      extract audio -> [ Whisper -> AI translates line by line -> Burmese voice ] -> shorten what is still too long -> schedule
                    -> mix -> render -> (Google Drive)
      The three steps in the brackets work AT THE SAME TIME (a producer / consumer chain): while Whisper is still busy with
      minute 20 of the film, the AI is already translating minute 5 and the voice already speaks minute 3.

  style "story" (story telling)
      extract audio -> Whisper (ALL the text first) -> the text in time order goes to the AI in ONE request (a film too long for
                    one request goes in a few parts) and the AI TELLS the story -> fit the pieces to their time -> Burmese voice
                    -> shorten what is still too long -> schedule -> mix -> render -> (Google Drive)
      Nothing is translated line by line. What the AI writes (pieces that each cover a few rows of the transcript) replaces the
      Whisper lines for everything that follows: voice, timing, subtitles and the review page.

Everything that takes long is saved to disk as it is produced (Whisper chunks, written text, spoken lines), so a job that was
paused for a new API key, cancelled by a crash or restarted by the server continues where it stopped.

Review (optional - see review.py): with "review" switched on the job stops right after the Burmese text is written and WAITS
(status "review", no thread, no CPU) while the person reads / edits the text and sets the look of the subtitles and the blur.
"Continue" runs the job again: the voice is made from the EDITED text (only then), then mix and render.

Timing (see timing.py): the narrator speaks at ONE steady speed. Each line gets a time budget; the AI is asked to say less
where the time is short; lines that are still too long when spoken are shortened in one extra request; the clips are then
placed on the timeline, never cut off and only very rarely sped up (<= +18 %).
"""
import hashlib
import json
import os
import queue
import shutil
import threading
import time
import traceback
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path

import asr
import gemini_client as G
import media
import presets as P
import review
import rewrite as R
import timing as T
import voices as V
from jobs import JobCancelled


class Services:
    """Everything a job needs from the application (shared between jobs)."""

    def __init__(self, store, data_dir, heavy, users, drive=None, edge=None, calibration=None):
        self.store = store
        self.data_dir = Path(data_dir)
        self.heavy = heavy                                   # FifoSlots: Whisper chunks and renders, one at a time (by default)
        self.users = users
        self.drive = drive
        self.edge = edge or V.EdgeTTS()
        self.calibration = calibration or V.CalibrationStore(self.data_dir / 'calibration.json')


class Progress:
    """Maps the stages of a job onto one 0-100 bar (stages that are not needed get no share)."""

    def __init__(self, store, jid, plan):
        self.store, self.jid = store, jid
        total = float(sum(w for _, w in plan)) or 1.0
        self.span, base = {}, 1.0
        for key, w in plan:
            width = w / total * 98.0
            self.span[key] = (base, width)
            base += width
        self.last = 0.0
        self.lock = threading.Lock()

    def set(self, key, frac=0.0, stage=None, detail=None, **extra):
        base, width = self.span.get(key, (1.0, 0.0))
        with self.lock:
            value = max(self.last, min(99.0, base + width * max(0.0, min(1.0, frac))))
            self.last = value
        kw = dict(progress=int(value), **extra)
        if stage is not None:
            kw['stage'] = stage
        if detail is not None:
            kw['detail'] = detail
        self.store.update(self.jid, **kw)


class RewriteCache:
    """work/rewrite.json - the Burmese lines written so far (and the source line each one belongs to). Lines are always a
    prefix of the film, so resuming means "continue after the last saved line"."""

    def __init__(self, path, sig):
        self.path = Path(path)
        self.sig = sig
        self.lines, self.src = [], []
        try:
            d = json.loads(self.path.read_text(encoding='utf-8'))
            if d.get('sig') == sig and len(d.get('lines', [])) == len(d.get('src', [])):
                self.lines, self.src = list(d['lines']), list(d['src'])
        except Exception:
            pass

    def truncate(self, n):
        del self.lines[n:]
        del self.src[n:]
        self.save()

    def save(self):
        tmp = self.path.with_suffix('.tmp')
        tmp.write_text(json.dumps({'sig': self.sig, 'lines': self.lines, 'src': self.src}, ensure_ascii=False), encoding='utf-8')
        tmp.replace(self.path)


class Run:
    def __init__(self, svc, jid, ctl):
        self.svc, self.jid, self.ctl = svc, jid, ctl
        self.store = svc.store
        self.job = self.store.get(jid)
        self.params = self.job['params']
        self.dir = self.store.dir(jid)
        self.work = self.dir / 'work'
        self.out = self.dir / 'out'
        self.input = self.dir / self.job['input']
        self.user = {'uid': self.job['owner'], 'local': self.job['owner'] == 'local'}
        self.make_voice = bool(self.params.get('make_voice'))
        self.make_subs = bool(self.params.get('make_subs'))
        self.speed = V.clamp_speed(self.params.get('speed', V.DEFAULT_SPEED))
        self.voice = V.resolve(self.params.get('voice') or V.DEFAULT_VOICE) or V.resolve(V.DEFAULT_VOICE)
        self.style = P.normalize_style(self.params.get('style'))
        self.story = P.is_story(self.style)                       # V22: the whole text goes to the AI, which tells the story
        self.ai = 'Gemini'                                        # the one AI (V22.2: Claude and Groq were removed; an older job that
                                                                  # names another provider in its params simply runs on Gemini)
        self.ctx_n = 3                                            # how many already written lines each batch gets as context
        self.parts_done, self.parts_total = 0, 0                  # story: parts of the film told so far
        self.abort = threading.Event()
        self.lock = threading.RLock()
        # filled while running
        self.segs, self.lang, self.model = [], 'unknown', ''
        self.chunks_done, self.chunks_total = 0, 0
        self.done_asr = False
        self.cache = None
        self.cal = T.Calibration()
        self.clips = None
        self.client = None                                        # the Gemini client of this run (the page shows its model / retries)
        self.pool = None
        self.futs = {}
        self.dur, self.clip_path, self.failed = {}, {}, {}
        self.tts_done = 0
        self.stats = {'lines': 0, 'spoken': 0, 'shortened': 0, 'sped_up': 0, 'delayed': 0, 'tts_failed': 0,
                      'warnings': [], 'model': '', 'gemini_requests': 0, 'fallbacks': {}}
        self.t0 = time.time()
        # review: phase 1 writes the text and stops; phase 2 (the person pressed "continue") makes the voice, mixes and renders
        self.review = bool(self.params.get('review'))
        self.saved = review.load(self.dir) if self.review else None
        self.back = bool(self.saved and self.saved.get('done'))
        self.defer_voice = self.review and not self.back          # no voice before the person has seen the text
        self.locked = set()                                       # lines the person edited: never shortened by the AI
        self.moved = 0                                            # lines the person moved in time on the review page (V21.2)
        if self.back:
            plan = [('prep', 1), ('write', 40 if self.make_voice else 1)]
        else:
            plan = [('prep', 3), ('write', 62 if self.make_voice else 70)]
            if self.review:
                plan.append(('preview', 3))
        if self.make_voice:
            plan.append(('mix', 3))
        plan.append(('render', 22 if self.make_subs else 4))
        if self.drive_on():
            plan.append(('deliver', 5))
        self.progress = Progress(self.store, jid, plan)

    # ---- small helpers
    def check(self):
        self.ctl.check()
        if self.abort.is_set():
            raise JobCancelled()

    def drive_on(self):
        d = self.svc.drive
        if d is None:
            return False
        try:
            with d.use_dir(self._drive_dir()):
                return d.is_connected()
        except Exception:
            return False

    def _drive_dir(self):
        return None if self.user['local'] else self.svc.users.dir(self.user['uid'])

    def heavy(self, what):
        def waiting(pos):
            self.store.update(self.jid, detail=f'{what} — CPU အတွက် စောင့်နေပါတယ် (အစီအစဉ် {pos + 1})')
        return self.svc.heavy.hold(on_wait=waiting, check=self.check)

    # ---- stage: prepare
    def extract_audio(self):
        src = self.work / 'source.wav'
        try:
            if src.exists() and src.stat().st_size > 1000:
                return src
        except OSError:
            pass
        tmp = self.work / 'source.tmp.wav'
        try:
            media.extract_audio_wav(self.input, tmp, 16000)         # V22.2: sample 0 = the first PICTURE (see media.extract_audio_wav)
        except RuntimeError as e:
            text = str(e)
            if media.audio_track() is not None and 'matches no streams' in text:
                raise RuntimeError(f'.env ထဲက AUDIO_TRACK={media.audio_track()} ဒီ video မှာ မရှိပါဘူး (audio track အရေအတွက် နည်းနေတယ်)။ AUDIO_TRACK ကို ဖျက်ပါ၊ ဒါမှမဟုတ် ၀ ကနေ စပြီး မှန်တဲ့ နံပါတ်ထည့်ပါ။')
            if 'does not contain any stream' in text or 'matches no streams' in text or 'no audio' in text.lower():
                raise RuntimeError('ဒီ video မှာ အသံ (audio track) မပါပါဘူး။ အသံပါတဲ့ video ကို သုံးပါ။')
            raise
        tmp.replace(src)
        return src

    def make_client(self):
        """The Gemini client of this job (the saved key + model of the website, or the .env ones)."""
        key = self.svc.users.get_key(self.user)
        if not key:
            raise RuntimeError('Gemini API key မထည့်ရသေးပါ။ Gemini API card မှာ ကိုယ့်ရဲ့ key ထည့်ပြီး Save လုပ်ပါ။')
        model = self.svc.users.get_model(self.user)
        available = None
        try:                                              # free call: only the model names this key can see
            available = [m['name'] for m in G.list_models(key) if not m['methods'] or 'generateContent' in m['methods']]
        except G.GeminiError:
            pass                                          # a bad key shows up at the first real request (which asks for a new key)
        return G.GeminiClient(key, model, G.fallback_models(), hooks=self.ctl, available=available)

    def make_clips(self, client):
        if self.voice['engine'] == 'gemini':
            engine = V.GeminiTTS(client)
            workers = int(os.getenv('GEMINI_TTS_CONCURRENCY') or 3)
        else:
            engine = self.svc.edge
            workers = engine.concurrency + 2
        self.clips = V.ClipMaker(media.FFMPEG, engine, self.voice, self.speed, self.work / 'tts', hooks=self.ctl)
        self.pool = ThreadPoolExecutor(max_workers=max(2, workers), thread_name_prefix='tts')

    def calibrate(self):
        """How fast does THIS voice really speak? (syllables per second). Learnt from three short sentences the first time,
        remembered for the next jobs, and refined by every line that is spoken."""
        stored = self.svc.calibration.get(self.voice, self.speed)
        if stored:
            self.cal = T.Calibration(prior_sps=stored[0], prior_weight=10.0)
            return
        futs = [self.pool.submit(self.clips.make, s) for s in V.CAL_SENTENCES]
        for s, f in zip(V.CAL_SENTENCES, futs):
            try:
                _, secs = f.result()
                self.cal.update(s, secs)
            except JobCancelled:
                raise
            except Exception as e:
                print(f'[calibration] skipped: {e}', flush=True)
                break

    # ---- stage: Whisper (in its own thread) -> queue
    def start_whisper(self, source):
        q = queue.Queue()
        want_spans = self.make_subs and not self.make_voice

        def work():
            try:
                for item in asr.transcribe_chunks(source, self.work, check=self.check, slot=lambda: self.heavy('Whisper'),
                                                  want_spans=want_spans):
                    q.put(('chunk',) + tuple(item))
                q.put(('done',))
            except BaseException as e:
                q.put(('error', e))
        threading.Thread(target=work, name='whisper', daemon=True).start()
        return q

    def take(self, msg):
        kind = msg[0]
        if kind == 'chunk':
            _, i, n, segs, lang, used = msg
            self.segs.extend(segs)
            self.lang = lang or self.lang
            self.model = used or self.model
            self.chunks_done, self.chunks_total = i + 1, n
        elif kind == 'done':
            self.done_asr = True
        elif kind == 'error':
            raise msg[1]

    # ---- stage: rewrite + voice
    def ai_bits(self):
        """V22.2: the model Gemini is answering with right now and how many requests had to be repeated (shown in the job's detail line)."""
        c = self.client
        if c is None:
            return []
        bit = f'Gemini model: {c.active_model}'
        retries = int(c.stats.get('retries') or 0)
        return [bit + (f' (ပြန်စမ်းမှု {retries})' if retries else '')]

    def report_story(self):
        """Progress of the story style: Whisper (all of it), the story (part by part), then the voice."""
        w = 1.0 if self.done_asr else (self.chunks_done / max(1, self.chunks_total) if self.chunks_total else 0.0)
        s = self.parts_done / self.parts_total if self.parts_total else 0.0
        voice = self.make_voice and not self.defer_voice
        t = (self.tts_done / max(1, len(self.futs))) if (voice and self.futs) else 0.0
        frac = (0.40 * w + 0.40 * s + 0.20 * t) if voice else (0.50 * w + 0.50 * s)
        bits = [f'Whisper {self.chunks_done}/{self.chunks_total or "?"}']
        if self.parts_total:
            bits.append(f'ဇာတ်လမ်း {self.parts_done}/{self.parts_total} ပိုင်း')
        if voice and self.futs:
            bits.append(f'အသံ {self.tts_done}/{len(self.futs)}')
        bits.extend(self.ai_bits())
        if not self.done_asr:
            stage = 'စာမှတ်တမ်းယူနေပါတယ် (စာအားလုံး အရင်ထုတ်မယ်)'
        elif self.parts_total and self.parts_done < self.parts_total:
            stage = f'ဇာတ်လမ်းပြောပြသလို {self.ai} နဲ့ ရေးနေပါတယ်'
        else:
            stage = 'ဇာတ်လမ်းရေးပြီး' + (' → အသံထုတ်' if voice else '')
        self.progress.set('write', min(0.9, frac) if voice else min(0.98, frac), stage=stage, detail=' • '.join(bits))

    def report(self, note=None):
        if self.story and not self.back:
            return self.report_story()
        known = max(1, len(self.segs))
        w = self.chunks_done / max(1, self.chunks_total) if self.chunks_total else 0.0
        r = (len(self.cache.lines) / known) if self.cache is not None else 0.0
        if not self.done_asr:
            r *= w if w < 1 else 1
        t = 0.0
        if self.make_voice and self.futs:
            t = r * (self.tts_done / max(1, len(self.futs)))
        voice = self.make_voice and not self.defer_voice
        frac = 0.45 * w + 0.35 * r + (0.20 * t if voice else 0.20 * r)
        bits = [f'Whisper {self.chunks_done}/{self.chunks_total or "?"}', f'မြန်မာစာ {len(self.cache.lines) if self.cache else 0}/{len(self.segs)}']
        if voice:
            bits.append(f'အသံ {self.tts_done}/{len(self.futs)}')
        bits.extend(self.ai_bits())
        self.progress.set('write', min(0.9, frac) if voice else min(0.98, frac),
                          stage=('ပြင်ပြီးတဲ့စာကနေ မြန်မာအသံထုတ်' if self.back else 'စာမှတ်တမ်းယူ → မြန်မာစာရေး' + (' → အသံထုတ်' if voice else '')),
                          detail=' • '.join(bits))

    def speak(self, i, text):
        self.check()
        try:
            path, secs = self.clips.make(text)
        except JobCancelled:
            raise
        except Exception as e:
            if isinstance(e, (G.GeminiNeedKey,)):
                raise
            with self.lock:
                self.failed[i] = f'{e.__class__.__name__}: {e}'
                self.tts_done += 1
            print(f'[tts] line {i} failed: {e}', flush=True)
            return None
        with self.lock:
            self.cal.update(text, secs)
            self.dur[i] = secs
            self.clip_path[i] = path
            self.failed.pop(i, None)
            self.tts_done += 1
        self.report()
        return secs

    def submit_speech(self, i, text):
        if self.make_voice and not self.defer_voice and text.strip() and T.has_speech(text):
            self.futs[i] = self.pool.submit(self.speak, i, text)

    def rewrite_range(self, client, system, a, n, video_total):
        segs, cache = self.segs, self.cache
        idx = list(range(a, a + n))
        for i in idx:                                    # cached lines must still belong to the same source lines
            if i < len(cache.lines) and cache.src[i] != segs[i]['text']:
                cache.truncate(i)
                break
        todo = [i for i in idx if i >= len(cache.lines)]
        if todo:
            look = min(len(segs) - 1, todo[-1] + 1)
            sub = list(range(todo[0], look + 1))
            budgets = T.slot_budgets([segs[j]['start'] for j in sub], [segs[j]['end'] for j in sub], video_total)
            if self.make_voice:
                items = [R.timed_item(segs[i]['text'], self.cal.max_syllables(budgets[k])) for k, i in enumerate(todo)]
            else:
                items = [segs[i]['text'] for i in todo]
            ctx = [c for c in cache.lines[-self.ctx_n:] if c]
            state = {'at': 0, 'prev': next((c for c in reversed(cache.lines) if c), '')}

            def keep(texts):
                """Every piece of the answer is saved to rewrite.json THE MOMENT it is complete (V22.2): a batch that is split because
                of a timeout saves its left half before the right half is asked, so a stop / restart in between never makes the
                left half be written twice. The lines are always a prefix of the film, in order, each exactly once."""
                for raw in texts:
                    if state['at'] >= len(todo):
                        break                                  # (never more lines than were asked for)
                    i = todo[state['at']]
                    text = media.clean_repeated_text(raw, state['prev'])
                    cache.lines.append(text)
                    cache.src.append(segs[i]['text'])
                    if text:
                        state['prev'] = text
                    state['at'] += 1
                cache.save()

            new = R.rewrite_batch(client, system, items, self.lang, ctx, note=self.ctl.note, sink=keep)
            if state['at'] < len(todo):
                keep(new[state['at']:])                        # (a rewrite_batch that did not use the sink)
        for i in idx:
            self.submit_speech(i, cache.lines[i])
        self.report()

    def cache_sig(self):
        # A job that V21.x started with the "translate" style (= what is now "direct": its prompt is identical) keeps its old
        # signature, so the lines it already wrote are still found when it is resumed after the update to V22.
        if str(self.params.get('style') or '').strip().lower() == 'translate':
            return hashlib.sha1(json.dumps(['translate', self.make_voice, 'v21']).encode()).hexdigest()[:12]
        return hashlib.sha1(json.dumps([self.style, self.make_voice, 'v22']).encode()).hexdigest()[:12]

    # ---- style "story": all the text first, then ONE request (or a few parts) that tells the story
    def story_sig(self):
        rows = [[round(float(s.get('start') or 0.0), 2), s.get('text', '')] for s in self.segs]
        return hashlib.sha1(json.dumps([self.lang, self.make_voice, rows, 'story2'], ensure_ascii=False).encode('utf-8')).hexdigest()[:16]

    def load_story(self, sig):
        """work/story.json = {'sig', 'notes', 'items'}: the pieces of the story written so far (and the story notes). It only counts
        for the very same transcript (sig); a job that is resumed continues after the last piece instead of asking again."""
        state = {'sig': sig, 'notes': None, 'items': []}
        try:
            d = json.loads((self.work / 'story.json').read_text(encoding='utf-8'))
            items = d.get('items')
            if d.get('sig') == sig and isinstance(items, list):
                ok = all(isinstance(x, dict) and isinstance(x.get('from'), int) and isinstance(x.get('to'), int)
                         and x['from'] <= x['to'] and isinstance(x.get('text'), str) for x in items)
                ok = ok and all(b['from'] > a['to'] for a, b in zip(items, items[1:]))
                if ok:
                    state['items'] = items
                    state['notes'] = [str(n) for n in d['notes']] if isinstance(d.get('notes'), list) else None
        except Exception:
            pass
        return state

    def save_story(self, state):
        tmp = (self.work / 'story.json').with_suffix('.tmp')
        tmp.write_text(json.dumps(state, ensure_ascii=False), encoding='utf-8')
        tmp.replace(self.work / 'story.json')

    def story_pass(self, client, video_total):
        """The whole transcript is there. Its rows (in time order) go to the AI, which tells the story -> the pieces of the story
        ([{'from', 'to', 'text'}], every row of the film covered). A film that fits into one request is ONE request; a longer one
        is told in parts, after ONE short request that reads the whole
        film and returns notes (who is who, the Burmese spelling of the names) so that all parts agree."""
        state = self.load_story(self.story_sig())
        rows = R.story_rows(self.segs)
        if not rows:
            raise RuntimeError('No speech was detected.')
        limits = R.story_limits()
        pace = round(self.cal.sps * 0.93, 1) if self.make_voice else 5.0
        span = R.window_seconds(limits, pace)
        every = R.story_windows(rows, limits['chars'], span)
        last_done = state['items'][-1]['to'] if state['items'] else -1
        todo = R.story_windows([r for r in rows if r['i'] > last_done], limits['chars'], span)
        self.parts_done, self.parts_total = 0, len(todo)
        self.stats['story_parts'] = len(every)
        if not todo:
            self.parts_done = self.parts_total = 1
            return state['items']
        if len(every) > 1 and state['notes'] is None:
            self.progress.set('write', 0.45, stage='ဇာတ်လမ်းတစ်ခုလုံးကို အရင်ဖတ်နေပါတယ်',
                              detail=f'{self.ai} က ဇာတ်ကောင်၊ နာမည်စာလုံးပေါင်းကို မှတ်စုထုတ်နေပါတယ် (အပိုင်း {len(every)} ပိုင်းခွဲရေးမှာမို့ တစ်ကြိမ်ပဲ)')
            state['notes'] = R.story_notes(client, self.segs, self.lang, cap=limits['chars'], note=self.ctl.note, timeout=limits['timeout'])
            self.save_story(state)
        notes = R.format_story_notes(state['notes'] or [])
        self.stats['story_notes'] = len(state['notes'] or [])
        system = P.build_story_prompt(self.make_voice, pace, notes)
        self.report()
        self.ctl.note(f'{self.ai} ဆီ စာ {len(rows)} ကြောင်းလုံး ပို့ပြီး ဇာတ်လမ်းရေးခိုင်းနေပါတယ်'
                      + (f' (အပိုင်း {len(todo)} ပိုင်း)' if len(todo) > 1 else ' (တစ်ခါတည်း)'))

        def finished(k, n, items):
            self.parts_done = k
            state['items'] = items
            self.save_story(state)
            self.report()
            if n > 1:
                self.ctl.note(f'ဇာတ်လမ်း အပိုင်း {k}/{n} ပြီးပါပြီ')

        return R.tell_story(client, system, rows, self.lang, video_total, limits, pace, done=state['items'], note=self.ctl.note,
                            check=self.check, progress=finished)

    def fit_story(self, client, video_total):
        """Voice only: before anything is spoken, the pieces that are clearly too long for the time they have are shortened (all of
        them in ONE request), so the voice is made once instead of twice. The lines that are only a little too long are left to the
        shorten pass, which works with the real length of the spoken clips."""
        if not self.make_voice:
            return
        segs, lines = self.segs, self.cache.lines
        budgets = T.slot_budgets([s['start'] for s in segs], [s['end'] for s in segs], video_total)
        over = []
        for i, text in enumerate(lines):
            if not text.strip():
                continue
            top, syl = self.cal.max_syllables(budgets[i]), T.syllables(text)
            if syl > top * 1.2 + 2:
                over.append({'i': i, 'text': text, 'syllables': syl, 'max_syllables': top})
        if not over:
            return
        self.progress.set('write', 0.85, detail=f'အချိန်မလောက်တဲ့ ဇာတ်လမ်းအပိုင်း {len(over)} ခုကို ချုံ့နေပါတယ်')
        changed = 0
        for k in range(0, len(over), R.SHORTEN_BATCH):
            part = over[k:k + R.SHORTEN_BATCH]
            for it, new in zip(part, R.shorten_lines(client, part, note=self.ctl.note)):
                if new:
                    lines[it['i']] = new
                    changed += 1
        if changed:
            self.cache.save()
        self.stats['fitted'] = changed

    def story_stage(self, client, source, video_total):
        """Style "story": Whisper to the very end -> the AI tells the story from ALL the text -> what it wrote replaces the Whisper
        lines (one line per piece of the story) -> the voice of every piece. Returns the new lines."""
        self.cache = RewriteCache(self.work / 'rewrite.json', self.cache_sig())
        q = self.start_whisper(source)
        if self.make_voice:
            self.calibrate()
        while not self.done_asr:                                  # 1. all the text first (nothing is sent to the AI before that)
            self.check()
            try:
                self.take(q.get(timeout=0.5))
            except queue.Empty:
                pass
            self.report()
        if not self.segs:
            raise RuntimeError('No speech was detected.')
        self.segs.sort(key=lambda s: (float(s['start']), float(s['end'])))      # 2. in time order
        self.stats['source_lines'] = len(self.segs)
        items = self.story_pass(client, video_total)                           # 3. the AI tells the story
        segs, lines, src = R.story_segments(self.segs, items)
        if not segs:
            raise RuntimeError(f'{self.ai} က ဇာတ်လမ်း တစ်ကြောင်းမှ မရေးပေးပါဘူး။ Model / API key ကို စစ်ပြီး ပြန်စမ်းပါ။')
        prev = ''
        for k, raw in enumerate(lines):
            lines[k] = media.clean_repeated_text(raw, prev)
            if lines[k]:
                prev = lines[k]
        self.segs = segs
        self.cache.lines, self.cache.src = lines, src
        self.cache.save()
        self.stats['lines'] = len(segs)
        self.fit_story(client, video_total)                                     # 4. the pieces fit their time, then the voice
        for i, text in enumerate(self.cache.lines):
            self.submit_speech(i, text)
        self.report()
        for i, f in list(self.futs.items()):
            self.check()
            f.result()
        return self.segs

    # ---- style "direct": line by line while Whisper is still working
    def write_stage(self, client, source, video_total):
        self.cache = RewriteCache(self.work / 'rewrite.json', self.cache_sig())
        system = P.build_system_prompt(self.style, self.make_voice, timed=True)
        q = self.start_whisper(source)
        if self.make_voice:
            self.calibrate()
        next_i = 0
        batch = R.batch_size()                                          # REWRITE_BATCH in .env (15 by default)
        while True:
            self.check()
            try:
                while True:
                    self.take(q.get_nowait())
            except queue.Empty:
                pass
            ready = len(self.segs) - next_i
            if ready >= batch + 1 or (self.done_asr and ready > 0):
                n = min(batch, ready)
                self.rewrite_range(client, system, next_i, n, video_total)
                next_i += n
                continue
            if self.done_asr and ready == 0:
                break
            try:
                self.take(q.get(timeout=0.5))
            except queue.Empty:
                pass
        if not self.segs:
            raise RuntimeError('No speech was detected.')
        self.stats['lines'] = len(self.segs)
        # all lines are written: wait for the voice of every line
        for i, f in list(self.futs.items()):
            self.check()
            f.result()
        return self.segs

    # ---- stage: shorten what is still too long
    def shorten_pass(self, client, rooms, budgets, passes=2):
        for p in range(passes):
            self.check()
            lines = self.cache.lines
            over = [i for i, t in enumerate(lines) if t.strip() and i in self.dur and self.dur[i] > rooms[i] + 0.15 and i not in self.locked]
            if not over:
                return
            self.progress.set('write', 0.9 + 0.08 * p / passes, detail=f'အရှည်လွန်တဲ့ စာကြောင်း {len(over)} ကြောင်းကို ချုံ့နေပါတယ် (အကြိမ် {p + 1}/{passes})')
            changed = []
            for k in range(0, len(over), R.SHORTEN_BATCH):
                part = over[k:k + R.SHORTEN_BATCH]
                items = [{'i': i, 'text': lines[i], 'syllables': T.syllables(lines[i]),
                          'max_syllables': self.cal.max_syllables(min(budgets[i], rooms[i] * 0.9))} for i in part]
                for i, new in zip(part, R.shorten_lines(client, items, note=self.ctl.note)):
                    if new:
                        lines[i] = new
                        changed.append(i)
            if not changed:
                return
            self.cache.save()
            self.stats['shortened'] += len(changed)
            futs = {}
            for i in changed:
                self.dur.pop(i, None)
                futs[i] = self.pool.submit(self.speak, i, lines[i])
            for f in futs.values():
                self.check()
                f.result()

    # ---- stage: timeline, mix, render
    def build_timeline(self, video_total):
        segs, lines = self.segs, self.cache.lines
        n = len(segs)
        anchors = [s['start'] for s in segs]
        durs = [self.dur.get(i, 0.0) if lines[i].strip() else 0.0 for i in range(n)]
        sched = T.schedule(durs, anchors, video_total)
        sped = [i for i, s in enumerate(sched) if s and s[2] > 1.005]
        lag = [i for i, s in enumerate(sched) if s and s[0] - anchors[i] > 0.5]
        self.stats.update(spoken=sum(1 for s in sched if s), sped_up=len(sped), delayed=len(lag))
        return sched

    def mix_narration(self, sched, video_total):
        self.progress.set('mix', 0.0, stage='Building synchronized narration', detail='မြန်မာအသံကို video timeline ပေါ် စီနေပါတယ်။')
        placements = [(s[0], s[1], i) for i, s in enumerate(sched) if s]

        def load(i):
            x = T.read_wav(self.clip_path[i])[0]
            sp = sched[i][2]
            return T.time_stretch(media.FFMPEG, x, T.SR, sp) if sp > 1.005 else x
        path = self.work / 'burmese_narration.wav'
        T.mix_to_wav(path, video_total, placements, load)
        self.progress.set('mix', 1.0)
        return path

    def final_segments(self, sched, video_total):
        segs, lines = self.segs, self.cache.lines
        out = []
        for i, s in enumerate(segs):
            text = lines[i].strip()
            if not text:
                continue
            seg = dict(s)
            if sched is not None and sched[i]:
                seg['start'], seg['end'] = sched[i][0], min(video_total, sched[i][1] + 0.10)
            elif sched is not None:                                   # a line whose voice failed: keep its subtitle anyway
                seg['start'] = s['start']
                seg['end'] = min(video_total, s['start'] + max(1.0, T.Calibration().seconds(text)))
            seg['burmese'] = text
            out.append(seg)
        for cur, nxt in zip(out, out[1:]):                           # two subtitles never overlap on screen
            if cur['end'] > nxt['start'] - 0.02:
                cur['end'] = max(cur['start'] + 0.1, nxt['start'] - 0.02)
        return out

    # ---- review (phase 1 ends here, phase 2 starts with restore)
    def prepare_preview(self, video_total):
        """How the review page will play the video: 'original' (a browser can play the upload as it is), 'copy' (a small MP4 made
        just for the preview) or 'none' (not possible - the text can still be edited)."""
        if media.browser_playable(self.input):
            return 'original'
        self.progress.set('preview', 0.0, stage='Preview video ပြင်ဆင်နေပါတယ်', detail='ဒီ video ကို browser မှာ တိုက်ရိုက်ဖွင့်လို့မရလို့ preview အတွက် ကော်ပီသေးသေးလေး ပြုလုပ်နေပါတယ်။')
        stop = lambda: self.ctl.cancel_event.is_set() or self.abort.is_set()
        try:
            with self.heavy('Preview'):
                ok = media.make_preview_copy(self.input, self.work / 'preview.mp4', video_total,
                                             lambda r: self.progress.set('preview', r, detail=f'Preview video ပြင်ဆင်နေပါတယ် — {int(r * 100)}%'), stop)
        except media.Stopped:
            raise JobCancelled()
        except RuntimeError as e:
            print(f'[review] no preview copy: {e}', flush=True)
            ok = False
        return 'copy' if ok and (self.work / 'preview.mp4').is_file() else 'none'

    def hand_over(self, client, video_total):
        """End of phase 1: save what the review page needs and WAIT (this thread ends; nothing runs until the person continues)."""
        preview = self.prepare_preview(video_total)
        s = client.stats
        state = {'v': 1, 'segs': self.segs, 'lang': self.lang, 'model': self.model, 'duration': video_total,
                 'size': list(media.video_size(self.input)), 'preview': preview,
                 'sps': round(self.cal.sps, 3) if self.make_voice else None,
                 'stats': {'model': client.active_model, 'gemini_requests': s['requests'], 'fallbacks': dict(s['fallback']),
                           'seconds': int(time.time() - self.t0)},
                 'settings': review.default_settings(self.params), 'edited': [], 'done': False,
                 'ai': list(self.cache.lines)}            # the text exactly as the AI wrote it (the page can offer "back to the AI text")
        review.save(self.dir, state)
        self.store.update(self.jid, status='review', stage='Review', progress=int(max(1, min(99, self.progress.last))), wait=None, pause=None,
                          error='', stats=self.stats, _force=True,
                          detail='မြန်မာစာ ရေးပြီးပါပြီ — ဖတ်ကြည့်ပြီး ပြင်ချင်တာပြင်ပါ၊ ပြီးရင် အောက်က ခလုတ်ကို နှိပ်ပါ။ (နှိပ်တဲ့အထိ ဘာမှ မလုပ်ဘဲ စောင့်နေပါတယ်)')

    def restore(self, video_total):
        """Phase 2: take the finished text back from disk (nothing is transcribed or written again). Lines the person moved in
        time on the review page start (and end) at their new time: the voice, the room each line has and the subtitle all follow."""
        saved = self.saved
        self.segs = review.shifted_segments(saved['segs'], saved.get('shifts'), video_total)
        self.moved = sum(1 for a, b in zip(saved['segs'], self.segs) if a is not b)
        self.lang = saved.get('lang') or 'unknown'
        self.model = saved.get('model') or ''
        self.chunks_done = self.chunks_total = 1
        self.done_asr = True
        self.cache = RewriteCache(self.work / 'rewrite.json', self.cache_sig())
        if len(self.cache.lines) != len(self.segs):
            raise RuntimeError('မြန်မာစာ ဖိုင် မပြည့်စုံတော့ပါဘူး — Job ကို Cancel လုပ်ပြီး video ကို ပြန်တင်ပါ။')
        self.locked = {int(i) for i in saved.get('edited') or []}
        self.stats['lines'] = len(self.segs)

    def speak_all(self):
        """Phase 2: the voice of every line, from the (edited) text."""
        for i, text in enumerate(self.cache.lines):
            self.submit_speech(i, text)
        self.report()
        for i, f in list(self.futs.items()):
            self.check()
            f.result()

    # ---- everything
    def execute(self):
        st = self.store
        self.work.mkdir(parents=True, exist_ok=True)
        self.out.mkdir(parents=True, exist_ok=True)
        if not (self.make_voice or self.make_subs):
            raise RuntimeError('Choose at least one output: subtitles or Burmese voice.')
        self.progress.set('prep', 0.0, stage='Extracting audio', detail='Video audio ကို extract လုပ်နေပါတယ်။')
        video_total = media.picture_duration(self.input)             # V22.2: the PICTURE's length - the narration and subtitles end where it ends
        source = None if self.back else self.extract_audio()
        self.check()
        client = None if (self.back and not self.make_voice) else self.make_client()     # a subtitles-only render after the review needs no AI
        self.client = client
        if self.make_voice:
            self.make_clips(client)
        self.progress.set('prep', 1.0)
        if self.back:
            self.restore(video_total)
            if self.make_voice:
                self.calibrate()
                self.progress.set('write', 0.0, stage='ပြင်ပြီးတဲ့စာကနေ မြန်မာအသံထုတ်', detail=f'စာကြောင်း {len(self.segs)} ကြောင်း (ပြင်ထားတာ {len(self.locked)})')
                self.speak_all()
        else:
            self.progress.set('write', 0.0, stage='စာမှတ်တမ်းယူ → မြန်မာစာရေး',
                              detail=f'Style: {P.STYLE_PRESETS[self.style]["name"]} | {self.ai} model: {client.active_model}')
            if self.story:
                self.story_stage(client, source, video_total)             # all the text first, then the AI tells the story
            else:
                self.write_stage(client, source, video_total)             # line by line, while Whisper is still working
            if self.review:
                return self.hand_over(client, video_total)
        segs = self.segs

        sched = None
        narrated = None
        if self.make_voice:
            budgets = T.slot_budgets([s['start'] for s in segs], [s['end'] for s in segs], video_total)
            rooms = T.slot_rooms([s['start'] for s in segs], video_total)
            self.shorten_pass(client, rooms, budgets)
            if self.failed:
                limit = max(2, int(0.02 * max(1, len(self.futs))))
                self.stats['tts_failed'] = len(self.failed)
                if len(self.failed) > limit:
                    first = next(iter(self.failed.values()))
                    raise RuntimeError(f'အသံထုတ်လို့ မရတဲ့ စာကြောင်း {len(self.failed)} ကြောင်း ရှိပါတယ် — {first}')
                self.stats['warnings'].append(f'အသံထုတ်လို့ မရတဲ့ စာကြောင်း {len(self.failed)} ကြောင်းကို ကျော်ထားပါတယ်။')
            self.svc.calibration.put(self.voice, self.speed, self.cal.sps, self.cal.n)
            sched = self.build_timeline(video_total)
            narrated = self.mix_narration(sched, video_total)
            final = self.final_segments(sched, video_total)
        else:
            for s, t in zip(segs, self.cache.lines):
                s['burmese'] = t
            final = media.prepare_subtitle_segments([dict(s) for s in segs if s.get('burmese', '').strip()], video_total)
        look = self.params.get('look')
        if look and self.make_subs:                                  # the person moved the subtitles earlier / later on the review page
            final = media.shift_segments(final, media.clean_look(look)['offset'], video_total)
        if not final:
            raise RuntimeError(f'{self.ai} က မြန်မာစာ တစ်ကြောင်းမှ မပေးပါဘူး။ Model / API key ကို စစ်ပြီး ပြန်စမ်းပါ။')
        self.check()

        (self.out / 'transcript.txt').write_text('\n'.join(s['text'] for s in segs), encoding='utf-8')
        (self.out / 'burmese.txt').write_text('\n'.join(x['burmese'] for x in final), encoding='utf-8')
        (self.out / 'segments.json').write_text(json.dumps(final, ensure_ascii=False, indent=1), encoding='utf-8')
        if self.make_subs:
            media.write_subtitle_files(self.out, final)

        out = self.out / 'final_burmese.mp4'
        blur = self.params.get('blur')
        drive_on = self.drive_on()

        def rprog(r):
            self.progress.set('render', r, detail=f'Burmese subtitle ကို video ထဲ ထည့်နေပါတယ် — {int(r * 100)}%' if self.make_subs
                              else f'Burmese narration နဲ့ final MP4 ပြုလုပ်နေပါတယ် — {int(r * 100)}%')
        self.progress.set('render', 0.0, stage='Rendering final MP4' + (' (burning subtitles)' if self.make_subs else ''),
                          detail='Final MP4 render လုပ်နေပါတယ်။')
        stop = lambda: self.ctl.cancel_event.is_set() or self.abort.is_set()
        try:
            if self.make_subs:
                with self.heavy('Render'):
                    media.render_with_subtitles(self.work, self.input, final, narrated, out, video_total, blur, rprog, stop,
                                                self.params.get('render_preset'), look=look)
            else:
                media.mux_narration(self.input, narrated, out, video_total, rprog, stop)
        except media.Stopped:
            raise JobCancelled()
        self.progress.set('render', 1.0)

        source_text = '\n'.join(s['text'] for s in segs)
        burmese_text = '\n'.join(x['burmese'] for x in final)
        style_name = P.STYLE_PRESETS[self.style]['name']
        done = f'ပြီးပါပြီ။ Whisper={self.model} | Style={style_name}'
        if self.make_voice:
            done += f' | Voice={self.voice["name"]} ({V.speed_to_rate(self.speed)})'
        if self.make_subs:
            done += ' | Burmese subtitles (yellow' + (', original text blurred' if blur else '') + ')'
        done += f' | AI={self.ai}'
        if self.stats['shortened'] or self.stats.get('fitted'):
            done += f' | အရှည်လွန်လို့ ချုံ့ထားတဲ့ စာကြောင်း {self.stats["shortened"] + int(self.stats.get("fitted") or 0)}'
        if self.stats['sped_up']:
            done += f' | အနည်းငယ်သာ မြန်ထားတဲ့ စာကြောင်း {self.stats["sped_up"]}'
        if self.moved:
            done += f' | အချိန်ညှိထားတဲ့ စာကြောင်း {self.moved}'
        before = (self.saved or {}).get('stats') or {}               # what phase 1 (before the review) already used
        s = client.stats if client else {'requests': 0, 'fallback': {}}
        fallbacks = dict(before.get('fallbacks') or {})
        for model, n in s['fallback'].items():
            fallbacks[model] = fallbacks.get(model, 0) + n
        self.stats.update(model=client.active_model if client else before.get('model', ''),
                          gemini_requests=s['requests'] + int(before.get('gemini_requests') or 0), fallbacks=fallbacks,
                          seconds=int(time.time() - self.t0) + int(before.get('seconds') or 0))

        files = {'output_url': f'/api/files/{self.jid}/final_burmese.mp4'}
        if self.make_subs:
            files.update(srt_url=f'/api/files/{self.jid}/burmese.srt', vtt_url=f'/api/files/{self.jid}/burmese.vtt')
        drive, drive_error = None, ''
        if drive_on:
            try:
                drive = self.deliver_to_drive(out)
            except JobCancelled:
                raise
            except Exception as e:
                # Upload or check failed: nothing was deleted, the local file is still served below.
                drive_error = str(e) or e.__class__.__name__
                print(f'[drive] upload failed, keeping the local file: {drive_error}', flush=True)
        if drive:
            done += ' | Google Drive ✔' + (' | server storage ကနေ ဖျက်ပြီး' if drive['server_cleaned'] else ' | (server ဖိုင်အချို့ ဖျက်လို့မရသေးပါ)')
            files = {'drive': drive, 'stream_url': f'/api/drive/stream/{self.jid}'}
        elif drive_error:
            files['drive_error'] = drive_error
            done += ' | ⚠ Google Drive ကို မတင်နိုင်ခဲ့ပါ — ဖိုင်ကို server ပေါ်မှာ ထားထားပါတယ်'
        self.cleanup_after_success(keep_out=not drive)
        st.update(self.jid, status='completed', stage='Complete', progress=100, detail=done, source_text=source_text,
                  burmese_text=burmese_text, stats=self.stats, error='', pause=None, wait=None, _force=True, **files)

    # ---- Google Drive
    def deliver_to_drive(self, out):
        # Uploads the finished files to Google Drive and checks them (size + MD5). Only when EVERYTHING is verified
        # are the server copies deleted. Any failure leaves all local files untouched and raises, so the caller falls
        # back to serving the local file (nothing is ever lost). The small subtitle files go first, the big video last,
        # so a problem shows up early and cheaply.
        d = self.svc.drive
        stem = safe_stem(self.job.get('orig_name'))
        stamp = time.strftime('%Y%m%d-%H%M')
        plan = []
        if self.make_subs:
            plan += [('srt', self.out / 'burmese.srt', 'application/x-subrip', f'{stem}_burmese_{stamp}.srt'),
                     ('vtt', self.out / 'burmese.vtt', 'text/vtt', f'{stem}_burmese_{stamp}.vtt')]
        plan.append(('video', Path(out), 'video/mp4', f'{stem}_burmese_{stamp}.mp4'))
        sizes = [p.stat().st_size for _, p, _, _ in plan]
        total = max(1, sum(sizes))
        self.progress.set('deliver', 0.0, stage='Uploading to Google Drive', detail='Google Drive ကို ချိတ်ဆက်နေပါတယ်။')
        with d.use_dir(self._drive_dir()):
            folder = d.ensure_folder()
            share = d.read_settings()['share_anyone']
            uploaded, result, share_error, done = [], {}, '', 0
            try:
                for (key, path, mime, name), size in zip(plan, sizes):
                    self.check()
                    md5 = d.md5_file(path)

                    def prog(sent, _size, base=done, label=name):
                        frac = (base + sent) / total
                        self.progress.set('deliver', frac, detail=f'Google Drive ကို တင်နေပါတယ် — {label} — {int(frac * 100)}% '
                                                               f'({(base + sent) / 1048576:.0f}/{total / 1048576:.0f} MB)')
                    meta = d.upload_file(path, name, mime, folder, prog)
                    uploaded.append(meta.get('id'))
                    d.verify(meta, size, md5)
                    if share:
                        try:
                            d.make_public(meta['id'])
                        except d.DriveError as e:
                            share_error = str(e)
                    result[key] = {'id': meta['id'], 'name': meta.get('name', name), 'size': size,
                                   'view_url': d.view_url(meta), 'download_url': d.download_url(meta)}
                    done += size
            except BaseException:
                for fid in uploaded:                    # do not leave half a delivery in the person's Drive
                    if fid:
                        d.delete_remote(fid)
                raise
            result['folder_url'] = d.folder_url(folder)
        result['shared'] = bool(share and not share_error)
        result['share_error'] = share_error
        # Everything is in Drive and verified: now (and only now) free the server's disk.
        self.progress.set('deliver', 1.0, stage='Cleaning server storage', detail='Drive ပေါ်ရောက်ပြီ — server storage ထဲက ဖိုင်တွေကို ဖျက်နေပါတယ်။')
        gone_out = rm_tree(self.out)
        gone_work = rm_tree(self.work)
        gone_input = rm_file(self.input)
        result['server_cleaned'] = bool(gone_out and gone_work and gone_input)
        return result

    def cleanup_after_success(self, keep_out):
        """The caches are only for resuming; a finished job does not need them (nor the uploaded original)."""
        rm_tree(self.work)
        rm_file(self.input)
        if not keep_out:
            rm_tree(self.out)


# ------------------------------------------------------------------------------------------------ helpers
def safe_stem(name):
    import re
    stem = Path(name or '').stem
    stem = re.sub(r'[\\/:*?"<>|\x00-\x1f]+', '_', stem).strip(' ._')
    return stem[:80] or 'recap'


def rm_tree(path):
    # Delete a folder. Returns True when it is really gone (Windows sometimes needs a second try).
    for attempt in range(3):
        shutil.rmtree(path, ignore_errors=True)
        if not Path(path).exists():
            return True
        time.sleep(0.5 * (attempt + 1))
    return False


def rm_file(path):
    for attempt in range(3):
        try:
            Path(path).unlink()
            return True
        except FileNotFoundError:
            return True
        except OSError:
            time.sleep(0.5 * (attempt + 1))
    return False


def discard_files(job_dir):
    """Throw away everything a job produced or cached (the small job.json stays so the list can still show "cancelled")."""
    d = Path(job_dir)
    rm_tree(d / 'work')
    rm_tree(d / 'out')
    for f in d.glob('input.*'):
        rm_file(f)


def friendly_error(e):
    """The text the person sees when a job stops with an error (it can be resumed)."""
    text = str(e) or e.__class__.__name__
    if isinstance(e, (G.GeminiError, V.TtsError)):
        return text + ' — "ဆက်လုပ်မယ်" ကို နှိပ်ရင် လုပ်ပြီးသားအပိုင်းတွေကို ပြန်မလုပ်ဘဲ ဆက်သွားပါမယ်။'
    return text


def run_job(svc, jid, ctl):
    """Entry point of the worker thread. Sets the final status itself. Cancel -> discard everything; any other error -> the
    job stops as "failed" with all finished work kept on disk, so "resume" continues from there."""
    run = None
    try:
        run = Run(svc, jid, ctl)
        run.execute()
    except JobCancelled:
        if run is not None:
            run.abort.set()
        try:
            discard_files(svc.store.dir(jid))
        finally:
            raise
    except BaseException as e:                       # includes errors raised by helper threads
        traceback.print_exc()
        if run is not None:
            run.abort.set()
        svc.store.update(jid, status='failed', stage='Failed', error=friendly_error(e), pause=None, wait=None, _force=True)
    finally:
        if run is not None and run.pool is not None:
            run.pool.shutdown(wait=False, cancel_futures=True)
