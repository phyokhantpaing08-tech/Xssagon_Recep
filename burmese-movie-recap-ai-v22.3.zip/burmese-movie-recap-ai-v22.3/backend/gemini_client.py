"""Gemini REST client (V21; V22.2: the ONLY AI client - Claude and Groq were removed).

Everything that talks to Google Gemini goes through ONE class, GeminiClient, so every part of the app gets the same
protection:

* HTTP 503 "This model is currently experiencing high demand" (and 500 / 502 / 504) is NOT fatal. The client hops AT ONCE to the
  next model of the chain (each model is its own capacity pool at Google) and marks the busy one as "cooling" for
  GEMINI_COOLDOWN seconds. When EVERY model is cooling it sleeps exactly until the earliest cooldown ends (no blind back-off
  cycles) and tells the page which model it will try next and when. Only when all models stayed unavailable for
  GEMINI_OVERLOAD_PATIENCE (default 10 minutes) does it ask the person what to do - it never throws away the work done so far.
* V22.2, a request that cannot be reached or times out ("Read timed out") gets ONE quick repeat on the same model; after 2 such
  failures in a row the model is treated like an overloaded one and the client hops to the next model. It never sticks to one
  model for minutes. A request that was asked to be splittable (chat(split=True)) raises GeminiTimeout after
  `SPLIT_AFTER` read timeouts so that the caller can send two halves instead of one big request.
* Every request is logged: model, label, number of lines, latency, outcome (ok / network / overloaded / rate / notfound ...) and
  the retry number (see GeminiClient.req_log).
* HTTP 429 per-minute limits wait exactly as long as Gemini says (retryDelay).
* Daily quota / prepaid credit used up, or a key that is invalid / expired / blocked: the client PAUSES and asks for a
  new key through `hooks.ask(...)`. When a new key arrives the SAME request is repeated and the job carries on from
  where it stopped. Nothing before that point is redone.
* Key test without spending credit: check_key() only calls models.get + countTokens (no text is generated).

`hooks` is any object with (all optional): check(), note(text), sleep(seconds, why, **info), ask(kind, message, **info).
check() / sleep() / ask() may raise an exception to cancel the work - the client simply lets it propagate.
"""
import base64
import collections
import inspect
import io
import json
import os
import random
import re
import threading
import time
import wave

import requests

DEFAULT_BASE_URL = 'https://generativelanguage.googleapis.com/v1beta'
DEFAULT_MODEL = 'gemini-flash-latest'
# Tried (in this order) when the chosen model is overloaded. Each model is a separate capacity pool at Google, so a
# 503 on one usually does not hit the others. Names a key cannot see are skipped automatically.
DEFAULT_FALLBACKS = ['gemini-3.8-flash', 'gemini-3.6-flash', 'gemini-3.5-flash-lite', 'gemini-3.1-flash-lite', 'gemini-2.5-flash']

# Films contain fights, blood and adult talk. Without this the default filters may refuse a batch of lines;
# Google's own non-adjustable protections stay active either way.
SAFETY = [{'category': c, 'threshold': 'BLOCK_NONE'} for c in (
    'HARM_CATEGORY_HARASSMENT', 'HARM_CATEGORY_HATE_SPEECH',
    'HARM_CATEGORY_SEXUALLY_EXPLICIT', 'HARM_CATEGORY_DANGEROUS_CONTENT')]

# "Thinking" only costs time and tokens for this job (rewriting short lines). Try to switch it off; a model that does not
# accept a variant answers HTTP 400 mentioning "thinking" and the next variant is used (remembered per model).
THINK_VARIANTS = [{'thinkingBudget': 0}, {'thinkingLevel': 'minimal'}, None]

BACKOFF = [2, 4, 8, 15, 25, 40, 60]          # seconds, multiplied by a random 0.8 - 1.25 factor


# ------------------------------------------------------------------------------------------------ errors
class GeminiError(RuntimeError):
    """A Gemini request failed for good (bad request, unsupported region ...)."""


class GeminiTruncated(GeminiError):
    """The model ran out of output tokens in the middle of its answer (finishReason == MAX_TOKENS)."""


class GeminiBlocked(GeminiError):
    """Gemini refused to answer this input (safety / recitation / empty). Retrying the same text will not help."""


class GeminiTooLarge(GeminiError):
    """The request itself is too big for the model / the account (HTTP 413). Sending the same text again cannot work; the caller
    splits it into smaller requests."""


class GeminiTimeout(GeminiError):
    """V22.2: a request that was asked to be splittable timed out again and again, even after the client hopped to another model.
    Waiting longer will not help; the caller sends two smaller requests (each half is asked once, no line is lost or doubled)."""


class PartialText(str):
    """V22: an answer that was cut off by the output-token limit but still holds useful text (see chat(partial=True)).
    `truncated` is True for such an answer; the caller keeps what is complete and asks for the rest."""
    truncated = True


class GeminiNeedKey(GeminiError):
    """The daily quota / prepaid credit is used up, or the key is not accepted, and nobody can supply a new one."""

    def __init__(self, msg, kind='quota'):
        super().__init__(msg)
        self.kind = kind


class _NetText(str):
    """The text of a 'network' failure; `timeout` is True when it was a read / connect timeout (not a refused connection)."""
    timeout = False


class NullHooks:
    """No person to ask (scripts, tests): sleeps for real, never pauses."""

    def check(self):
        pass

    def note(self, text):
        pass

    def sleep(self, seconds, why='', **info):
        time.sleep(seconds)

    def ask(self, kind, message, **info):
        raise GeminiNeedKey(message, kind)


# ------------------------------------------------------------------------------------------------ helpers
def clean_model(name):
    name = (name or '').strip()
    return name[7:] if name.startswith('models/') else name      # the model list shows "models/gemini-..."


def parse_models(text, default=None):
    """'a, b ; c' -> ['a', 'b', 'c'] (cleaned, de-duplicated, order kept)."""
    out = []
    for part in re.split(r'[,;\s]+', text or ''):
        m = clean_model(part)
        if m and m not in out:
            out.append(m)
    return out or list(default or [])


def default_model():
    """The model of a request that names none: GEMINI_MODEL in .env, else gemini-flash-latest."""
    return (os.getenv('GEMINI_MODEL') or '').strip() or DEFAULT_MODEL


def fallback_models():
    """The models tried (in this order) when the chosen one is overloaded or unreachable: GEMINI_FALLBACK_MODELS in .env, else
    DEFAULT_FALLBACKS (the chain is NOT changed by V22.2)."""
    return parse_models(os.getenv('GEMINI_FALLBACK_MODELS') or '', DEFAULT_FALLBACKS)


def proxies_from_env():
    # Optional GEMINI_PROXY (for example http://127.0.0.1:7890, the local proxy port of a VPN program):
    # only the Gemini requests use it. Without it the normal system / VPN connection is used.
    p = (os.getenv('GEMINI_PROXY') or '').strip()
    return {'http': p, 'https': p} if p else None


def base_url():
    return (os.getenv('GEMINI_BASE_URL') or DEFAULT_BASE_URL).rstrip('/')


def extract_json_array(text):
    text = (text or '').strip()
    text = re.sub(r'^```(?:json)?\s*', '', text, flags=re.I)
    text = re.sub(r'\s*```$', '', text, flags=re.I).strip()
    try:
        return json.loads(text)
    except json.JSONDecodeError:
        start, end = text.find('['), text.rfind(']')
        if start >= 0 and end > start:
            try:
                return json.loads(text[start:end + 1])
            except json.JSONDecodeError:
                return None
        return None


def hint(status, message):
    # A short Burmese explanation for the errors people really meet.
    m = (message or '').lower()
    shown = re.match(r'\s*gemini api (\d{3})', m)
    if shown:
        status = int(shown.group(1))              # "Gemini API 401: ..." - the status of the answer that was really received
    if 'location is not supported' in m:
        return ''          # keep it plain: Gemini's own short message is shown as it is
    if 'api key' in m and ('not valid' in m or 'invalid' in m or 'expired' in m or 'not found' in m):
        return ' — API key မှားနေပါတယ်။ Google AI Studio က key ကို ပြန်ကူးပြီး Save API လုပ်ပါ။'
    if status == 401 or 'access_token_type_unsupported' in m or 'invalid authentication credentials' in m:
        return (' — Google က ဒီ key ကို လက်မခံပါဘူး (401)။ စစ်ကြည့်ပါ: (၁) key ကို အပြည့်အစုံ ကူးထားလား (ရှေ့နောက်မှာ space / " မပါစေနဲ့)၊ '
                '(၂) aistudio.google.com/apikey မှာ key အသစ်ထုတ်ပြီး ထည့်ကြည့်ပါ — `AQ.` နဲ့ စတဲ့ key က ပုံမှန်ပါပဲ (AI Studio က အခု အဲဒီပုံစံကိုပဲ ထုတ်ပေးတယ်)၊ '
                '(၃) model ကို `gemini-flash-latest` (သို့) `gemini-3.8-flash` လို လက်ရှိ model နဲ့ ပြောင်းစမ်းကြည့်ပါ။')
    if status == 404 or 'is not found' in m or 'not supported for generatecontent' in m:
        return ' — Model နာမည် မှားနေပါတယ် (ဥပမာ gemini-flash-latest)။ text ထုတ်နိုင်တဲ့ gemini model ကို ထည့်ပါ။'
    if status == 403 and ('permission' in m or 'denied' in m):
        return ' — ဒီ key နဲ့ Gemini API ကို သုံးခွင့်မရှိပါ။ AI Studio မှာ key အသစ်ထုတ်ပါ။'
    return ''


_EXHAUSTED_RE = re.compile(
    r'prepay\w*\s+credit|credits?\s+(?:are|is|have been|has been)\s+(?:depleted|exhausted|used up)|out of credits?|'
    r'insufficient\s+(?:credit|fund|balance)|spend(?:ing)?\s+(?:cap|limit)|monthly\s+(?:spend|spending)|'
    r'billing\s+(?:account\s+)?(?:is\s+)?(?:disabled|closed|not enabled)|'
    r'credit\s+balance\s+is\s+too\s+low|exceeded\s+your\s+(?:monthly|workspace)\s+(?:spend|usage)|'
    r'(?:tokens|requests)\s+per\s+day|\((?:tpd|rpd)\)', re.I)


def _details(detail):
    if not isinstance(detail, dict):
        return []
    err = detail.get('error')
    return (err.get('details') or []) if isinstance(err, dict) else []


_TRY_AGAIN_RE = re.compile(r'(?:try again|retry) in\s+((?:\d+(?:\.\d+)?\s*(?:ms|h|m|s)\s*)+)', re.I)


def _seconds_in_text(message):
    """"retry in 7.88s" / "Please try again in 14m24.768s" -> seconds (some error messages carry the wait in their text)."""
    m = _TRY_AGAIN_RE.search(message or '')
    if not m:
        return None
    total = 0.0
    for num, unit in re.findall(r'(\d+(?:\.\d+)?)\s*(ms|h|m|s)', m.group(1), re.I):
        total += float(num) * {'ms': 0.001, 's': 1.0, 'm': 60.0, 'h': 3600.0}[unit.lower()]
    return total


def retry_delay(r, detail):
    # Seconds the API asks us to wait after HTTP 429 ("retryDelay": "34s", a Retry-After header, or the words
    # "retry in 7.88s" in the message).
    try:
        for d in _details(detail):
            v = d.get('retryDelay') if isinstance(d, dict) else None
            if v:
                return float(str(v).rstrip('s'))
    except (TypeError, ValueError):
        pass
    try:
        return float(r.headers.get('Retry-After'))
    except (TypeError, ValueError, AttributeError):
        pass
    err = detail.get('error') if isinstance(detail, dict) else None
    return _seconds_in_text(err.get('message') if isinstance(err, dict) else '')


def _quota_ids(detail):
    out = []
    for d in _details(detail):
        if not isinstance(d, dict):
            continue
        for v in (d.get('violations') or []):
            if isinstance(v, dict):
                out.append(str(v.get('quotaId') or '') + ' ' + str(v.get('quotaMetric') or ''))
    return ' '.join(out).lower()


def classify(status, detail, message, delay=None):
    """What kind of failure is this?  -> one of
    'overloaded'  503 / 500 / 502 / 504: Gemini is busy, try again / use another model
    'rate'        429 per-minute limit: wait `delay` seconds
    'exhausted'   429 daily quota or prepaid credit used up for this model: waiting minutes will not help
    'key'         key invalid / expired / blocked / no permission: a new key is needed
    'region'      "User location is not supported" (VPN / server region)
    'notfound'    404: this model name does not exist (for this key)
    'thinking'    400 about the thinking settings (try the next variant)
    'toolarge'    413: this request is too big - it has to be split
    'bad'         any other client error
    """
    m = (message or '').lower()
    if 'location is not supported' in m:
        return 'region'
    if status == 413:
        return 'toolarge'
    if status == 429:
        qid = _quota_ids(detail).replace(' ', '')
        if 'perday' in qid or 'daily' in qid or _EXHAUSTED_RE.search(message or '') or (delay is not None and delay > 300):
            return 'exhausted'
        return 'rate'
    if status in (400, 402, 403) and _EXHAUSTED_RE.search(message or ''):
        return 'exhausted'                                   # (a billing message that comes with HTTP 400 / 402 / 403)
    if status >= 500 or status == 408 or 'overloaded' in m or 'high demand' in m:
        return 'overloaded'
    if status == 401:
        return 'key'
    if status in (400, 403) and ('api key' in m or 'api_key' in m):
        if status == 403 or any(w in m for w in ('not valid', 'invalid', 'expired', 'not found', 'api_key_invalid')):
            return 'key'
        return 'bad'
    if status == 403:
        return 'key'
    if status == 404 or 'is not found' in m or 'not supported for generatecontent' in m:
        return 'notfound'
    if status == 400 and 'thinking' in m:
        return 'thinking'
    return 'bad'


def _error_message(r):
    try:
        detail = r.json()
    except ValueError:
        detail = {}
    if isinstance(detail, list) and detail and isinstance(detail[0], dict):
        detail = detail[0]                              # some Google endpoints wrap the error in a list
    err = detail.get('error') if isinstance(detail, dict) else None
    msg = err.get('message') if isinstance(err, dict) else None
    return detail, (msg or (r.text or '')[:500] or f'HTTP {r.status_code}')


def gemini_text(data, partial=False):
    # The answer text of a generateContent response, or None for an empty answer.
    # partial=True (V22): an answer that hit the output-token limit is returned as a PartialText instead of raising
    # GeminiTruncated, so the caller can keep the complete part of it.
    cands = data.get('candidates') or []
    if not cands:
        reason = (data.get('promptFeedback') or {}).get('blockReason') or 'no candidates'
        raise GeminiBlocked(f'Gemini did not answer ({reason}).')
    cand = cands[0]
    parts = (cand.get('content') or {}).get('parts') or []
    text = ''.join(p.get('text', '') for p in parts if isinstance(p, dict) and not p.get('thought'))
    finish = str(cand.get('finishReason') or '')
    if finish == 'MAX_TOKENS':
        if partial and text.strip():
            return PartialText(text)
        raise GeminiTruncated('Gemini answer was cut off (output token limit reached).')
    if not text.strip():
        if finish and finish != 'STOP':
            raise GeminiBlocked(f'Gemini returned no text ({finish}).')
        return None
    return text


def _find_audio(node):
    """First base64 audio payload anywhere in a Gemini response -> (bytes, mime). Handles both the generateContent
    layout (candidates[].content.parts[].inlineData) and the Interactions layout (steps[].content[].data)."""
    stack = [node]
    while stack:
        cur = stack.pop()
        if isinstance(cur, dict):
            blob = cur.get('data')
            mime = str(cur.get('mimeType') or cur.get('mime_type') or '')
            if isinstance(blob, str) and len(blob) > 64 and (str(cur.get('type') or '') == 'audio' or mime.startswith('audio')):
                try:
                    return base64.b64decode(blob), mime
                except Exception:
                    pass
            stack.extend(cur.values())
        elif isinstance(cur, list):
            stack.extend(reversed(cur))
    return None, ''


def pcm_from_audio(raw, mime):
    """(bytes, mime) -> (little-endian 16-bit mono PCM bytes, sample_rate)."""
    if raw[:4] == b'RIFF' or 'wav' in mime.lower():
        with wave.open(io.BytesIO(raw), 'rb') as w:
            frames, rate, ch = w.readframes(w.getnframes()), w.getframerate(), w.getnchannels()
        if ch == 2:                                    # average the channels (never expected, but cheap to handle)
            import numpy as np
            a = np.frombuffer(frames, dtype='<i2').reshape(-1, 2).astype('float32').mean(axis=1)
            frames = a.astype('<i2').tobytes()
        return frames, rate
    m = re.search(r'rate=(\d+)', mime)
    return raw, int(m.group(1)) if m else 24000


# ------------------------------------------------------------------------------------------------ the client
class GeminiClient:
    NAME = 'gemini'
    TITLE = 'Gemini'                # how the AI is called in messages and errors
    NET_HOP_AFTER = 2               # V22.2: failures to connect / read timeouts IN A ROW on one model before the client hops to the next
    NET_RETRY_PAUSE = 2.0           # V22.2: seconds before the ONE repeat on the same model (it grows with every failure, 5 s at most)
    SPLIT_AFTER = 4                 # V22.2: read timeouts of one splittable request (2 on the first model + 2 more after the hop) -> GeminiTimeout

    def __init__(self, key, model=DEFAULT_MODEL, fallbacks=None, hooks=None, timeout=120, available=None):
        self.key = (key or '').strip()
        self.hooks = hooks or NullHooks()
        self.timeout = timeout
        self.session = requests.Session()
        self._lock = threading.RLock()
        self._ask_lock = threading.Lock()
        self._gen = 0                       # increases whenever a new key arrives (or "retry" was chosen)
        self._cool = {}                     # model -> time until which it counts as "recently overloaded"
        self._exhausted = {}                # model -> time until which its quota is considered used up
        self._dead = set()                  # models that do not exist for this key
        self._think = {}                    # model -> index into THINK_VARIANTS that works
        self._tts_mode = None               # 'classic' | 'interactions' (Gemini TTS, learnt on first use)
        self._sleep_info = None             # does hooks.sleep() take (model=, retry=)? learnt on the first sleep
        self.cooldown = float(os.getenv('GEMINI_COOLDOWN') or 90)
        self.patience = float(os.getenv('GEMINI_OVERLOAD_PATIENCE') or 600)
        self.min_interval = float(os.getenv('GEMINI_MIN_INTERVAL') or 0)
        self._pace_lock = threading.Lock()
        self._last = 0.0
        self.stats = {'requests': 0, 'ok': 0, 'tokens': 0, 'retries': 0, 'fallback': {}, 'outcomes': {}}
        self.req_log = collections.deque(maxlen=500)   # V22.2: one entry per request that was sent (see _log)
        self.models = [DEFAULT_MODEL]
        self.active_model = DEFAULT_MODEL
        self.set_models(model, DEFAULT_FALLBACKS if fallbacks is None else fallbacks, available)

    # ---- configuration
    def set_models(self, model, fallbacks=None, available=None):
        primary = clean_model(model) or DEFAULT_MODEL
        chain = [primary]
        for m in (fallbacks or []):
            m = clean_model(m)
            if m and m not in chain:
                chain.append(m)
        if available:
            av = {clean_model(a) for a in available}
            chain = [chain[0]] + [m for m in chain[1:] if m in av]
        self.models = chain
        self.active_model = chain[0]

    def set_key(self, key, model=None, fallbacks=None):
        with self._lock:
            if key:
                self.key = key.strip()
            if model or fallbacks is not None:
                self.set_models(model or self.models[0], self.models[1:] if fallbacks is None else fallbacks)
            self._gen += 1
            self._cool.clear()
            self._exhausted.clear()
            self._dead.clear()

    # ---- plumbing
    def _tokens(self, data):
        try:
            return int((data.get('usageMetadata') or {}).get('totalTokenCount') or 0)
        except (TypeError, ValueError, AttributeError):
            return 0

    def _note(self, text):
        try:
            self.hooks.note(text)
        except Exception:
            pass
        print(f'[{self.NAME}] {text}', flush=True)

    def _sleep(self, seconds, why, **info):
        """Sleep through the hooks (which can be cancelled). `info` (model, retry ...) tells the page what is going on; a hooks object
        that does not take it is called the old way."""
        if self._sleep_info is None:
            try:
                params = inspect.signature(self.hooks.sleep).parameters.values()
                self._sleep_info = any(p.kind is p.VAR_KEYWORD or p.name == 'model' for p in params)
            except (TypeError, ValueError, AttributeError):
                self._sleep_info = False
        if self._sleep_info:
            self.hooks.sleep(max(0.0, seconds), why, **info)
        else:
            self.hooks.sleep(max(0.0, seconds), why)

    def _log(self, model, label, lines, secs, outcome, retry, note=''):
        """V22.2: ONE line per request that was sent - model, label, how many lines it carried, latency, outcome
        (ok / network / overloaded / rate / notfound / ...) and which retry of the same logical request it was (0 = the first)."""
        entry = {'model': model, 'label': label, 'lines': lines, 'latency': round(secs, 2), 'outcome': outcome, 'retry': retry}
        self.req_log.append(entry)
        out = self.stats['outcomes']
        out[outcome] = out.get(outcome, 0) + 1
        print(f'[{self.NAME}] request model={model} label={label} lines={"-" if lines is None else lines} '
              f'latency={secs:.1f}s outcome={outcome} retry={retry}' + (f' ({note})' if note else ''), flush=True)

    def _live(self, models=None):
        return [m for m in (models or self.models) if m not in self._dead]

    def _next_ready(self, models=None):
        """-> (the model to try next, seconds until it may be tried). 0 seconds = a model is ready now; otherwise every usable model is
        "cooling" and the answer is the one whose cooldown ends first (V22.2: the client sleeps exactly that long)."""
        now = time.time()
        usable = [m for m in self._live(models) if self._exhausted.get(m, 0) <= now]
        if not usable:
            return None, 0.0
        ready = [m for m in usable if self._cool.get(m, 0) <= now]
        if ready:
            return ready[0], 0.0
        first = min(usable, key=lambda m: self._cool.get(m, 0))
        return first, max(0.0, self._cool[first] - now)

    def _pace(self):
        # Optional: GEMINI_MIN_INTERVAL=12 keeps at least 12 s between two requests (free keys allow few per minute).
        if self.min_interval <= 0:
            return
        with self._pace_lock:
            wait = self._last + self.min_interval - time.time()
            if wait > 0:
                self._sleep(wait, 'pace')
            self._last = time.time()

    def _chain(self, models=None):
        """(models to try now, any model exists, every existing model is out of quota)."""
        now = time.time()
        live = [m for m in (models or self.models) if m not in self._dead]
        usable = [m for m in live if self._exhausted.get(m, 0) <= now]
        fresh = [m for m in usable if self._cool.get(m, 0) <= now]
        return fresh + [m for m in usable if m not in fresh], bool(live), bool(live) and not usable

    @staticmethod
    def _text_variants():
        raw = (os.getenv('GEMINI_THINKING_BUDGET') or '').strip().lower()
        if raw.lstrip('-').isdigit():
            return [{'thinkingBudget': int(raw)}]
        if raw in ('auto', 'default', 'model'):
            return [None]
        return THINK_VARIANTS

    def _post(self, url, payload, timeout):
        self.stats['requests'] += 1
        headers = {'x-goog-api-key': self.key, 'Content-Type': 'application/json'}
        return self.session.post(url, headers=headers, json=payload, timeout=(15, timeout), proxies=proxies_from_env())

    def _try_model(self, model, make, parse, timeout, variants, label='request', lines=None, retry=0):
        """One request to one model. Returns (kind, value): ('ok', result) or (failure kind, text / (delay, text)). Every request that
        is sent is logged (see _log)."""
        for _ in range(len(variants) + 1):
            idx = min(self._think.get(model, 0), len(variants) - 1)
            url, payload = make(model, variants[idx])
            self._pace()
            t0 = time.time()
            try:
                r = self._post(url, payload, timeout)
            except (requests.Timeout, requests.ConnectionError) as e:
                self._log(model, label, lines, time.time() - t0, 'network', retry, 'timeout' if isinstance(e, requests.Timeout) else 'connection')
                text = _NetText(f'{self.TITLE} network error: {e}')
                text.timeout = isinstance(e, requests.Timeout)
                return 'network', text
            except requests.RequestException as e:
                self._log(model, label, lines, time.time() - t0, 'network', retry, 'request error')
                return 'network', _NetText(f'{self.TITLE} request error: {e}')
            secs = time.time() - t0
            if r.ok:
                try:
                    data = r.json()
                except ValueError:
                    self._log(model, label, lines, secs, 'bad', retry, 'not JSON')
                    raise GeminiError(f'{self.TITLE} returned an unexpected response: {r.text[:500]}')
                self.stats['tokens'] += self._tokens(data)
                value = parse(data)
                if value is None:
                    self._log(model, label, lines, secs, 'empty', retry)
                    return 'empty', f'{self.TITLE} returned an empty answer'
                self.stats['ok'] += 1
                self._log(model, label, lines, secs, 'ok', retry)
                return 'ok', value
            detail, message = _error_message(r)
            delay = retry_delay(r, detail)
            kind = classify(r.status_code, detail, message, delay)
            text = f'{self.TITLE} API {r.status_code}: {message}'
            self._log(model, label, lines, secs, kind, retry, f'HTTP {r.status_code}')
            if kind == 'thinking':
                if idx + 1 < len(variants):
                    self._think[model] = idx + 1        # this model does not accept that thinking setting: next one
                    continue
                return 'bad', text
            if kind == 'rate':
                return 'rate', (delay if delay is not None else 20.0, text)
            return kind, text
        return 'bad', f'{self.TITLE} rejected every thinking setting'

    def _attempt(self, model, make, parse, timeout, variants, label, lines, tally, split_after=0):
        """One model, with ONE quick repeat when the connection fails: after NET_HOP_AFTER (2) failures in a row the caller hops to the
        next model, exactly as it does for 'overloaded' (V22.2). `tally` counts the requests / read timeouts of the logical request;
        a splittable request (split_after > 0) raises GeminiTimeout once it has timed out that many times."""
        fails = 0
        while True:
            kind, val = self._try_model(model, make, parse, timeout, variants, label=label, lines=lines, retry=tally['sent'])
            tally['sent'] += 1
            if kind != 'network':
                return kind, val
            fails += 1
            if getattr(val, 'timeout', False):
                tally['timeouts'] += 1
            if split_after and tally['timeouts'] >= split_after:
                with self._lock:
                    self._cool[model] = time.time() + self.cooldown
                raise GeminiTimeout(f'{self.TITLE} timed out {tally["timeouts"]} times in a row (also on another model) — {str(val)[:160]}')
            if fails >= self.NET_HOP_AFTER:
                return kind, val
            self.stats['retries'] += 1
            pause = min(5.0, self.NET_RETRY_PAUSE * fails)
            self._note(f'{model} ချိတ်ဆက်မှု ပြဿနာ ({fails}/{self.NET_HOP_AFTER}) — {pause:.0f} စက္ကန့်နောက် တစ်ကြိမ်ထပ်စမ်းမယ် — {str(val)[:100]}')
            self._sleep(pause, 'network', model=model, retry=tally['sent'])
            self.hooks.check()

    def _call(self, make, parse, timeout=None, label='request', models=None, variants=None, lines=None, split_after=0):
        """Send one logical request and do not come back until it worked, the person cancelled, or it can never work."""
        timeout = timeout or self.timeout
        variants = variants or self._text_variants()
        primary = (models or self.models)[0]
        t_wait, rounds, empties, last = None, 0, 0, ''
        tally = {'sent': 0, 'timeouts': 0}      # requests sent / read timeouts so far for THIS logical request ("retry" in the log)
        failed = set()                          # models that were busy or unreachable since the waiting began
        while True:
            self.hooks.check()
            gen = self._gen
            round_start = time.time()
            chain, any_live, all_spent = self._chain(models)
            if not any_live:
                raise GeminiError(f'Model not found: {", ".join(models or self.models)} — {last}' + hint(404, last))
            if all_spent:
                self._ask(gen, 'quota', last or f'{self.TITLE} quota / credit is used up.')
                t_wait, rounds = None, 0
                failed.clear()
                continue
            wait, need_key, spent = None, None, False
            for pos, model in enumerate(chain):
                self.hooks.check()
                kind, val = self._attempt(model, make, parse, timeout, variants, label, lines, tally, split_after)
                if kind == 'ok':
                    with self._lock:
                        self._cool.pop(model, None)
                    if model != primary:
                        self.stats['fallback'][model] = self.stats['fallback'].get(model, 0) + 1
                    if not models and model != self.active_model:
                        self.active_model = model
                        self._note(f'{self.TITLE} model: {model}')
                    return val
                self.stats['retries'] += 1
                rest = chain[pos + 1:]
                # A failure that belongs to a request sent with the OLD key must not mark anything once a new key has
                # arrived meanwhile (another thread may have answered the "new key" question while this one was in flight).
                stale = self._gen != gen
                if kind == 'overloaded':
                    last, wait = val, ('overloaded', None)
                    with self._lock:
                        if not stale:
                            self._cool[model] = time.time() + self.cooldown
                            failed.add(model)
                    self._note(f'{model} ကျပ်နေပါတယ် (503) — ' + (f'{rest[0]} ကို ပြောင်းစမ်းနေပါတယ်' if rest else 'ခဏစောင့်ပြီး ပြန်စမ်းမယ်'))
                elif kind == 'network':
                    # V22.2: the same hop as for 'overloaded'. _attempt already repeated the request once on this model.
                    last, wait = val, ('network', None)
                    with self._lock:
                        if not stale:
                            self._cool[model] = time.time() + self.cooldown
                            failed.add(model)
                    self._note(f'{model} ဆက်တိုက် {self.NET_HOP_AFTER} ကြိမ် ချိတ်ဆက်မရ/ကြာလွန်း — '
                               + (f'{rest[0]} ကို ပြောင်းစမ်းနေပါတယ်' if rest else 'model အားလုံး စမ်းပြီးပါပြီ'))
                elif kind == 'exhausted':
                    last, spent = val, True
                    project_wide = bool(_EXHAUSTED_RE.search(val))      # prepaid credit / billing: every model is affected
                    with self._lock:
                        if not stale:
                            until = time.time() + 3600
                            for m in (chain if project_wide else [model]):
                                self._exhausted[m] = until
                    self._note(f'{model} ရဲ့ quota / credit ကုန်နေပါတယ်' + (f' — {rest[0]} ကို စမ်းမယ်' if rest and not project_wide else ''))
                    if project_wide:
                        break                                   # no point asking the other models, they share the credit
                elif kind == 'notfound':
                    last = val
                    with self._lock:
                        if not stale:
                            self._dead.add(model)
                    self._note(f'{model} ဆိုတဲ့ model မရှိပါ — ကျော်လိုက်ပါတယ်')
                elif kind == 'key':
                    need_key = val + hint(401, val)
                    break
                elif kind == 'toolarge':
                    raise GeminiTooLarge(val)               # the caller splits the request
                elif kind == 'rate':
                    last, wait = val[1], ('rate', val[0])
                    break                               # same model again after waiting (do not hop models for this)
                elif kind == 'empty':
                    empties += 1
                    if empties >= 3:
                        raise GeminiBlocked(f'{self.TITLE} returned an empty answer 3 times.')
                    last, wait = val, ('empty', 2.0)
                    break
                else:                                   # 'region' / 'bad'
                    raise GeminiError(val + hint(400, val))
            if need_key:
                self._ask(gen, 'key', need_key)
                t_wait, rounds = None, 0
                failed.clear()
                continue
            if wait is None:
                if spent:                               # every model ran out of quota in this round
                    self._ask(gen, 'quota', last)
                    t_wait, rounds = None, 0
                    failed.clear()
                continue                                # (only dead models left: the top of the loop raises)
            why, secs = wait
            t_wait = t_wait or round_start
            if why in ('overloaded', 'network'):
                # Pause (ask the person) only when EVERY model has failed and the patience is used up. Until then: sleep exactly until
                # the model whose cooldown ends first may be tried again - no blind back-off cycles.
                if time.time() - t_wait > self.patience and all(m in failed for m in self._live(models)):
                    self._ask(gen, 'overloaded', last or f'{self.TITLE} is busy.')
                    t_wait, rounds = None, 0
                    failed.clear()
                    continue
                nxt, secs = self._next_ready(models)
                secs = max(1.0, secs)
                tag = 'model အားလုံး ကျပ်နေပါတယ်' if why == 'overloaded' else 'ချိတ်ဆက်မှု ပြဿနာ'
                self._note(f'{tag} — {nxt} ကို {secs:.0f} စက္ကန့်နောက် ပြန်စမ်းမယ် (အကြိမ် {rounds + 1}, request {tally["sent"]}) — {str(last)[:100]}')
                rounds += 1
                self._sleep(secs, why, model=nxt, retry=rounds)
                continue
            if why == 'rate':
                if time.time() - t_wait > max(self.patience, 900):
                    self._ask(gen, 'overloaded', last or f'{self.TITLE} is busy.')
                    t_wait, rounds = None, 0
                    failed.clear()
                    continue
                secs = min(120.0, float(secs) + 1.0)
                self._note(f'{self.TITLE} rate limit — {secs:.0f} စက္ကန့် စောင့်နေပါတယ်')
                self._sleep(secs, why, model=self.active_model)
                continue
            self._sleep(secs, why)                      # 'empty': ask again after a moment

    @staticmethod
    def _backoff(n):
        return BACKOFF[min(n, len(BACKOFF) - 1)] * random.uniform(0.8, 1.25)

    def _ask(self, gen, kind, message):
        """Pause and ask the person (once, even if several threads fail together). Returns after the answer was applied."""
        with self._ask_lock:
            if self._gen != gen:
                return                                  # somebody else already supplied a new key while we waited
            answer = self.hooks.ask(kind, message, model=self.active_model, models=list(self.models)) or {}
            if answer.get('key') or answer.get('model') or answer.get('fallbacks') is not None:
                self.set_key(answer.get('key'), answer.get('model'), answer.get('fallbacks'))
            else:                                       # "try again with the same key"
                with self._lock:
                    self._exhausted.clear()
                    self._cool.clear()
                    self._dead.clear()
                    self._gen += 1

    # ---- public calls
    def chat(self, system, user, max_tokens=8192, timeout=None, json_mode=True, label='chat', partial=False, lines=None, split=False):
        """One text request -> the answer text. partial=True: an answer cut off by the output-token limit comes back as a PartialText
        (its `truncated` is True) instead of raising GeminiTruncated. `lines` = how many lines the request carries (only for the log).
        split=True (V22.2): after SPLIT_AFTER read timeouts - also on another model - raise GeminiTimeout instead of waiting
        on; the caller then sends two halves."""
        floor = int(os.getenv('GEMINI_MAX_OUTPUT_TOKENS') or 0)

        def make(model, think):
            gen = {'maxOutputTokens': max(int(max_tokens), floor)}
            if json_mode:
                gen['responseMimeType'] = 'application/json'
            if think is not None:
                gen['thinkingConfig'] = think
            payload = {'contents': [{'role': 'user', 'parts': [{'text': user}]}], 'generationConfig': gen,
                       'safetySettings': SAFETY}
            if system:
                payload['systemInstruction'] = {'parts': [{'text': system}]}
            return f'{base_url()}/models/{model}:generateContent', payload

        return self._call(make, (lambda data: gemini_text(data, True)) if partial else gemini_text, timeout, label,
                          lines=lines, split_after=self.SPLIT_AFTER if split else 0)

    def tts(self, text, voice_name, models, timeout=None):
        """Gemini text-to-speech. Returns (pcm16_mono_bytes, sample_rate). `models` = TTS model names to try, best first.
        NOTE: this cannot be verified without a real key; both request layouts Google documents are supported and the one
        that the API accepts is remembered."""
        tts_models = [clean_model(m) for m in models if clean_model(m)]
        if not tts_models:
            raise GeminiError('No Gemini TTS model configured.')

        def make(model, think):
            if self._tts_mode == 'interactions':
                payload = {'model': model, 'input': [{'type': 'user_input', 'content': [{'type': 'text', 'text': text}]}],
                           'response_format': {'type': 'audio'},
                           'generation_config': {'speech_config': [{'voice': voice_name}]}}
                return f'{base_url()}/interactions', payload
            payload = {'contents': [{'parts': [{'text': text}]}],
                       'generationConfig': {'responseModalities': ['AUDIO'], 'speechConfig': {
                           'voiceConfig': {'prebuiltVoiceConfig': {'voiceName': voice_name}}}}}
            return f'{base_url()}/models/{model}:generateContent', payload

        def parse(data):
            raw, mime = _find_audio(data)
            if raw is None:
                cands = data.get('candidates') or []
                if cands and str(cands[0].get('finishReason') or '') not in ('', 'STOP'):
                    raise GeminiBlocked(f'Gemini TTS returned no audio ({cands[0].get("finishReason")}).')
                return None
            return pcm_from_audio(raw, mime)

        try:
            return self._call(make, parse, timeout or 180, 'tts', models=tts_models, variants=[None])
        except GeminiError as e:
            msg = str(e).lower()
            if self._tts_mode is None and not isinstance(e, (GeminiBlocked, GeminiNeedKey)) and (
                    'interaction' in msg or 'not supported' in msg or 'modalit' in msg or 'not found' in msg):
                self._tts_mode = 'interactions'         # the other documented layout
                with self._lock:
                    for m in tts_models:
                        self._dead.discard(m)
                return self._call(make, parse, timeout or 180, 'tts', models=tts_models, variants=[None])
            raise


# ------------------------------------------------------------------------------------------------ free key test
def _get(url, key, timeout=20):
    return requests.get(url, headers={'x-goog-api-key': key}, timeout=(15, timeout), proxies=proxies_from_env())


def list_models(key, timeout=20):
    """Models this key can see -> [{'name': 'gemini-...', 'methods': [...]}]. Free (no tokens). Raises GeminiError."""
    out, token = [], ''
    for _ in range(6):
        url = f'{base_url()}/models?pageSize=200' + (f'&pageToken={token}' if token else '')
        try:
            r = _get(url, key, timeout)
        except requests.RequestException as e:
            raise GeminiError(f'Gemini network error: {e}')
        if not r.ok:
            detail, message = _error_message(r)
            raise GeminiError(f'Gemini API {r.status_code}: {message}' + hint(r.status_code, message))
        j = r.json()
        for m in j.get('models') or []:
            out.append({'name': clean_model(m.get('name')), 'methods': m.get('supportedGenerationMethods') or []})
        token = j.get('nextPageToken') or ''
        if not token:
            break
    return out


def check_key(key, model, timeout=20):
    """Does this key + model + connection work?  It costs NOTHING: models.get and countTokens never generate text,
    so no output tokens and no generation quota are used. Returns a dict; raises GeminiError with a readable reason."""
    key = (key or '').strip()
    if not key:
        raise GeminiError('Gemini API key မထည့်ရသေးပါ။')
    model = clean_model(model) or DEFAULT_MODEL
    t0 = time.time()
    try:
        r = _get(f'{base_url()}/models/{model}', key, timeout)
    except requests.RequestException as e:
        raise GeminiError(f'Gemini ကို ချိတ်ဆက်လို့မရပါ: {e}')
    if not r.ok:
        detail, message = _error_message(r)
        raise GeminiError(f'Gemini API {r.status_code}: {message}' + hint(r.status_code, message))
    info = r.json()
    methods = info.get('supportedGenerationMethods') or []
    if methods and 'generateContent' not in methods:
        raise GeminiError(f'{model} က text ထုတ်လို့မရတဲ့ model ပါ (generateContent မပါ)။ gemini-flash-latest လို model ကို သုံးပါ။')
    tokens = None
    try:
        r2 = requests.post(f'{base_url()}/models/{model}:countTokens', headers={'x-goog-api-key': key, 'Content-Type': 'application/json'},
                           json={'contents': [{'parts': [{'text': 'ok'}]}]}, timeout=(15, timeout), proxies=proxies_from_env())
        if r2.ok:
            tokens = r2.json().get('totalTokens')
        elif r2.status_code in (400, 401, 403):
            detail, message = _error_message(r2)
            raise GeminiError(f'Gemini API {r2.status_code}: {message}' + hint(r2.status_code, message))
    except requests.RequestException:
        pass                                            # models.get already proved key + model + region
    return {'ok': True, 'model': model, 'display': info.get('displayName') or model, 'methods': methods,
            'input_limit': info.get('inputTokenLimit'), 'output_limit': info.get('outputTokenLimit'),
            'count_ok': tokens is not None, 'seconds': round(time.time() - t0, 2)}
