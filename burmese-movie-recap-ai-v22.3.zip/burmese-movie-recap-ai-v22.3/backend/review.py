"""The review stage (V21.1): after the Burmese text is written, a job can WAIT for the person.

While it waits there is no worker thread and no CPU use - only files on disk and the status "review":

    work/rewrite.json   the Burmese lines (the file the pipeline always uses); an edit simply replaces a line in it
    work/review.json    everything else the review page needs: the Whisper lines (times + original text), the video facts,
                        the subtitle look chosen so far, which lines the person changed, the lines the person MOVED in time
                        (V21.2: "shifts"), and "done" once the person pressed "continue" (then the job runs again: voice from
                        the edited text -> mix -> render)
    work/preview.mp4    only when a browser cannot play the uploaded file as it is: a small copy for the preview

Nothing here talks to Gemini, to the voice engine or to ffmpeg's encoder, so it is cheap and easy to test.
"""
import json
import math
import re
from pathlib import Path

import media

FILE = 'review.json'
MAX_LINE = 600                                   # characters of one Burmese line (a subtitle is a few seconds, not a page)
MAX_SHIFT = 5.0                                  # V21.2: seconds one line may be moved earlier / later (the look's "offset" moves ALL lines)
MIN_GAP = 0.1                                    # seconds that must stay between the START of two neighbouring lines
END_ROOM = 0.3                                   # the last line may not start later than this many seconds before the video ends


# ------------------------------------------------------------------------------------------------ files
def _state_path(job_dir):
    return Path(job_dir) / 'work' / FILE


def _lines_path(job_dir):
    return Path(job_dir) / 'work' / 'rewrite.json'


def _write(path, doc):
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix('.tmp')
    tmp.write_text(json.dumps(doc, ensure_ascii=False), encoding='utf-8')
    tmp.replace(path)


def load(job_dir):
    """The review state of a job, or None when the job has not reached the review stage."""
    try:
        d = json.loads(_state_path(job_dir).read_text(encoding='utf-8'))
    except (OSError, ValueError):
        return None
    return d if isinstance(d, dict) and isinstance(d.get('segs'), list) else None


def save(job_dir, state):
    _write(_state_path(job_dir), state)


def read_lines(job_dir):
    """(lines, whole rewrite.json document). The lines are always one per Whisper line, in order."""
    try:
        doc = json.loads(_lines_path(job_dir).read_text(encoding='utf-8'))
        lines, src = list(doc.get('lines', [])), list(doc.get('src', []))
        if len(lines) == len(src):
            return [str(x) for x in lines], doc
    except (OSError, ValueError, AttributeError):
        pass
    return [], {}


def write_lines(job_dir, doc, lines):
    doc = dict(doc)
    doc['lines'] = list(lines)
    _write(_lines_path(job_dir), doc)


# ------------------------------------------------------------------------------------------------ what the person may change
def clean_line(text):
    """One edited Burmese line: no control characters, one space between words, not absurdly long."""
    text = re.sub(r'[\x00-\x1f\x7f]+', ' ', str(text if text is not None else ''))
    return re.sub(r'\s+', ' ', text).strip()[:MAX_LINE]


def _flag(v):
    return str(v).strip().lower() in ('1', 'true', 'on', 'yes', 'y')


def default_settings(params):
    """The look the review page starts with: what the person chose when the video was uploaded."""
    blur = params.get('blur')
    shown = media.clean_blur(blur) if blur else media.clean_blur({})
    shown['on'] = bool(blur) or not params.get('make_subs')        # a voice-only job has no blur yet: switching subtitles on starts with it
    return {'subs': bool(params.get('make_subs')), 'blur': shown, 'look': media.clean_look(params.get('look') or {})}


def clean_settings(raw, params):
    """Whatever the browser sent -> validated settings (missing parts keep the job's current values)."""
    raw = raw if isinstance(raw, dict) else {}
    base = default_settings(params)
    b = raw.get('blur') if isinstance(raw.get('blur'), dict) else {}
    blur = media.clean_blur({**base['blur'], **b})
    blur['on'] = _flag(b.get('on', base['blur']['on']))
    look = raw.get('look') if isinstance(raw.get('look'), dict) else {}
    return {'subs': _flag(raw.get('subs', base['subs'])), 'blur': blur, 'look': media.clean_look({**base['look'], **look})}


def job_params(params, settings):
    """The job's parameters after the review: subtitles on/off, the blur band, the look."""
    p = dict(params)
    p['make_subs'] = bool(settings['subs'])
    p['blur'] = {k: settings['blur'][k] for k in ('top', 'height', 'strength', 'dark')} if settings['subs'] and settings['blur']['on'] else None
    p['look'] = dict(settings['look'])
    return p


# ------------------------------------------------------------------------------------------------ V21.2: moving single lines in time
def clean_shifts(raw, count):
    """What the page sends about moved lines ({line number: seconds}, + = later) -> {int: float}: only real lines of this video,
    only numbers, nothing that is zero, never more than MAX_SHIFT. (Whether a move fits between the neighbours: effective_shifts().)"""
    out = {}
    if not isinstance(raw, dict):
        return out
    for key, val in raw.items():
        try:
            i, v = int(key), float(val)
        except (TypeError, ValueError, OverflowError):
            continue
        if not 0 <= i < count or v != v:                       # not a line of this video / not a number
            continue
        v = round(max(-MAX_SHIFT, min(MAX_SHIFT, v)), 2)
        if abs(v) >= 0.005:
            out[i] = v
    return out


def _up(x):                                                    # round UP to 0.01, so that a limit is never overstepped by the rounding
    return math.ceil(x * 100.0 - 1e-9) / 100.0


def _down(x):
    return math.floor(x * 100.0 + 1e-9) / 100.0


def effective_shifts(starts, raw, total):
    """The moves that can really be made: {line number: seconds}. A line may not start before the START of the line before it
    (+ MIN_GAP) nor after the start of the line after it (- MIN_GAP), and the last line stays inside the video. A move that does
    not fit is shortened to what fits; a line that was not moved is never touched. The review page uses the very same rule, so
    what the person sees is what the server does - this is the safety net for anything that does not come from that page."""
    n = len(starts)
    d = [0.0] * n
    for i, v in clean_shifts(raw, n).items():
        d[i] = v
    end = (float(total) - END_ROOM) if total and float(total) > 0 else 1e9
    for _ in range(8):
        changed = False
        for i in range(n):
            if not d[i]:
                continue
            a0 = float(starts[i])
            lo = (float(starts[i - 1]) + d[i - 1] + MIN_GAP) if i else 0.0
            hi = (float(starts[i + 1]) + d[i + 1] - MIN_GAP) if i + 1 < n else end
            lo, hi = min(lo, a0), max(hi, a0)                  # staying exactly where it is is always allowed
            want = d[i]
            if a0 + want < lo:
                want = _up(lo - a0)
            elif a0 + want > hi:
                want = _down(hi - a0)
            if abs(want) < 0.005:
                want = 0.0
            if want != d[i]:
                d[i], changed = want, True
        if not changed:
            break
    return {i: v for i, v in enumerate(d) if v}


def shifted_segments(segs, raw, total):
    """The Whisper lines with the moved ones moved: start, end and (when there are any) speech_start / speech_end change by the
    same number of seconds. A line that was not moved is the very same dict as before, so a job without moves works exactly as it
    always did. The voice (its start) and the subtitle (its time) both follow these lines."""
    moves = effective_shifts([s['start'] for s in segs], raw, total)
    if not moves:
        return segs
    limit = float(total) if total and float(total) > 0 else None
    out = []
    for i, s in enumerate(segs):
        d = moves.get(i)
        if not d:
            out.append(s)
            continue
        t = dict(s)
        for key in ('start', 'end', 'speech_start', 'speech_end'):
            if key in t:
                t[key] = round(float(t[key]) + d, 3)
        if limit is not None:
            for key in ('end', 'speech_end'):
                if key in t:
                    t[key] = min(t[key], limit)
        out.append(t)
    return out


def apply_edits(job_dir, edits):
    """Replace the edited Burmese lines in work/rewrite.json. edits = {line number: new text}. Returns the numbers of the lines
    that really changed. A line that was edited stays "edited" (the pipeline will not shorten it behind the person's back)."""
    state = load(job_dir)
    lines, doc = read_lines(job_dir)
    if state is None or not lines:
        raise ValueError('not in review')
    changed = []
    for key, text in (edits or {}).items():
        try:
            i = int(key)
        except (TypeError, ValueError):
            continue
        if 0 <= i < len(lines):
            new = clean_line(text)
            if new != lines[i]:
                lines[i] = new
                changed.append(i)
    if changed:
        write_lines(job_dir, doc, lines)
        state['edited'] = sorted(set(state.get('edited') or []) | set(changed))
        save(job_dir, state)
    return sorted(changed)


def remember(job_dir, settings, done=False, shifts=None):
    """Keep the look the person chose (and, with done=True, the fact that "continue" was pressed). shifts = {line number: seconds}
    the person moved lines by (V21.2); None = the page said nothing about them, so what is saved stays."""
    state = load(job_dir)
    if state is None:
        raise ValueError('not in review')
    state['settings'] = settings
    if shifts is not None:
        segs = state['segs']
        moves = effective_shifts([s['start'] for s in segs], shifts, float(state.get('duration') or 0.0))
        state['shifts'] = {str(i): v for i, v in moves.items()}
    if done:
        state['done'] = True
    save(job_dir, state)


# ------------------------------------------------------------------------------------------------ what the page gets
def _r(x):
    return round(float(x), 2)


def payload(job_dir, params):
    """Everything the review page needs to draw itself."""
    state = load(job_dir)
    if state is None:
        return None
    lines, _doc = read_lines(job_dir)
    segs = state['segs']
    total = float(state.get('duration') or 0.0)
    moves = effective_shifts([s['start'] for s in segs], state.get('shifts'), total)
    rows = []
    for i, s in enumerate(segs):
        nxt = segs[i + 1]['start'] if i + 1 < len(segs) else total
        row = {'i': i, 'a': _r(s['start']), 'b': _r(s['end']), 'nx': _r(max(nxt, s['start'])), 'src': s.get('text', ''),
               'my': lines[i] if i < len(lines) else ''}
        if 'speech_start' in s:
            row['ss'], row['se'] = _r(s['speech_start']), _r(s.get('speech_end', s['end']))
        if i in moves:
            row['sh'] = moves[i]                              # seconds this line was moved by (only moved lines carry it)
        rows.append(row)
    ai = state.get('ai') or []
    for i, row in enumerate(rows):                # only the lines that differ from what the AI wrote carry the AI text
        if i < len(ai) and ai[i] != row['my']:
            row['ai'] = ai[i]
    saved = state.get('settings')
    return {'lines': rows, 'settings': clean_settings(saved, params) if saved else default_settings(params),
            'edited': list(state.get('edited') or []), 'duration': _r(total), 'size': state.get('size'),
            'preview': state.get('preview'), 'sps': state.get('sps'), 'lang': state.get('lang'),
            'make_voice': bool(params.get('make_voice')), 'subs_ok': not media.subtitle_problem(),
            'shift': {'max': MAX_SHIFT, 'gap': MIN_GAP, 'room': END_ROOM}}      # the page uses the server's limits, not its own copy
