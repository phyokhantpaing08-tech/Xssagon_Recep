"""Access protection and the saved Gemini key (V21, single user, no sign-in).

The website has NO login: whoever can open its address (http://<server-ip>:<port>) can use it, exactly like V20. Two simple
ways to keep strangers out - use one or both:

  1) let only YOUR IP address reach the port (AWS Security Group -> Custom TCP 8000 -> Source "My IP"). Best, needs no code.
  2) APP_PASSWORD in .env - the browser asks for a password once (HTTP Basic; any user name works). Over plain http the
     password travels unencrypted, so this keeps out strangers and bots, not somebody who watches your network.

This module also holds
  * origin_ok(): the cross-site check for POST / PUT / DELETE (a page of another website cannot make your browser change things),
  * password_ok(): the APP_PASSWORD check,
  * UserStore: where the Gemini key and model are saved (data/users/local/settings.json). The key is encrypted when the optional
    "cryptography" package is installed; without it the key is only hidden (base64) in a file that is private to the server
    user (chmod 600) - the same protection as V20's data/settings.json.
"""
import base64
import hashlib
import hmac
import json
import os
import re
import secrets
import threading
from pathlib import Path
from urllib.parse import urlparse

LOCAL_USER = {'uid': 'local', 'email': '', 'name': '', 'picture': '', 'local': True}


def flag(v):
    return str(v or '').strip().lower() in ('1', 'true', 'on', 'yes', 'y')


def _b64e(b):
    return base64.urlsafe_b64encode(b).rstrip(b'=').decode('ascii')


def _b64d(s):
    return base64.urlsafe_b64decode(s + '=' * (-len(s) % 4))


def origin_ok(origin, referer, host, public_url=''):
    """CSRF guard for POST / PUT / DELETE: when the browser says where the request came from, it must be this site."""
    sources = [s for s in (origin, referer) if s]
    if not sources:
        return True                              # not a browser (curl, scripts)
    if origin and not urlparse(origin).netloc:
        return False                             # "Origin: null" = sandboxed frame / file:// page: never this website
    allowed = set()
    if host:
        allowed.add(host.lower())
    if public_url:
        allowed.add(urlparse(public_url).netloc.lower())
    for s in sources:
        netloc = urlparse(s).netloc.lower()
        if netloc and netloc not in allowed:
            return False
    return True


def password_ok(authorization, password):
    """APP_PASSWORD check (HTTP Basic: any user name, the password must match). An empty password = protection is off."""
    if not password:
        return True
    value = (authorization or '').strip()
    if value[:6].lower() != 'basic ':
        return False
    try:
        given = base64.b64decode(value[6:].strip(), validate=True).decode('utf-8').partition(':')[2]
    except Exception:                            # noqa: BLE001  (bad base64 / bad utf-8)
        return False
    return hmac.compare_digest(given.encode('utf-8'), password.encode('utf-8'))


# ------------------------------------------------------------------------------------------------ the saved key
class SecretBox:
    """Encrypts the saved Gemini key (Fernet = AES-128-CBC + HMAC) when the optional "cryptography" package is installed; the
    secret is created once in data/secret.key. Without the package the key is only base64-hidden. Anybody who can read the
    server's files can read the key either way - this protects against copies of data/ files and backups."""

    def __init__(self, data_dir):
        self._f = None
        try:
            from cryptography.fernet import Fernet
        except ImportError:
            return
        secret = self._secret(Path(data_dir))
        self._f = Fernet(_b64e(hashlib.sha256(secret + b'|keybox').digest()).encode('ascii') + b'=')

    @staticmethod
    def _secret(data_dir):
        p = data_dir / 'secret.key'
        try:
            if p.exists():
                raw = p.read_text(encoding='ascii').strip()
                if len(raw) >= 32:
                    return hashlib.sha256(('file|' + raw).encode('utf-8')).digest()
        except OSError:
            pass
        raw = secrets.token_hex(32)
        try:
            data_dir.mkdir(parents=True, exist_ok=True)
            p.write_text(raw, encoding='ascii')
            os.chmod(p, 0o600)
        except OSError:
            pass
        return hashlib.sha256(('file|' + raw).encode('utf-8')).digest()

    def encrypt(self, text):
        if self._f is None:
            return 'plain:' + _b64e(text.encode('utf-8'))
        return 'fernet:' + self._f.encrypt(text.encode('utf-8')).decode('ascii')

    def decrypt(self, blob):
        try:
            if blob.startswith('plain:'):
                return _b64d(blob[6:]).decode('utf-8')
            if blob.startswith('fernet:') and self._f is not None:
                return self._f.decrypt(blob[7:].encode('ascii')).decode('utf-8')
        except Exception:                        # noqa: BLE001
            pass
        return ''


ENV_KEYS = ('GEMINI_API_KEY', 'GOOGLE_API_KEY')
REMOVED_FIELDS = ('claude_key_enc', 'groq_key_enc', 'claude_model', 'groq_model', 'provider')   # V22.1 settings of the removed AIs


class UserStore:
    """The Gemini key and model of the one user ("local"). The folder per user id is kept so that the job / Drive code, which asks
    for "the folder of the job's owner", needs no special case.

    V22.2: Gemini is the only AI (Claude and Groq were removed). The fields in settings.json are the same as in V21 / V22
    (`gemini_key_enc`, `gemini_model`); `purge_removed()` deletes what V22.1 saved for Claude and Groq."""
    DEFAULT_MODEL = 'gemini-flash-latest'

    def __init__(self, data_dir, box=None):
        self.data_dir = Path(data_dir)
        self.box = box or SecretBox(self.data_dir)
        self._lock = threading.RLock()           # read-modify-write of settings.json is never interleaved

    def dir(self, uid):
        if not re.fullmatch(r'[A-Za-z0-9_]{1,40}', uid or ''):
            raise ValueError('bad user id')
        p = self.data_dir / 'users' / uid
        p.mkdir(parents=True, exist_ok=True)
        return p

    def _path(self, uid):
        return self.dir(uid) / 'settings.json'

    def read(self, uid):
        try:
            p = self._path(uid)
            return json.loads(p.read_text(encoding='utf-8')) if p.exists() else {}
        except Exception:                        # noqa: BLE001
            return {}

    def write(self, uid, data):
        p = self._path(uid)
        tmp = p.with_suffix('.tmp')
        tmp.write_text(json.dumps(data, ensure_ascii=False, indent=1), encoding='utf-8')
        try:
            os.chmod(tmp, 0o600)
        except OSError:
            pass
        tmp.replace(p)

    def purge_removed(self, user=None):
        """Delete the saved Claude / Groq keys, models and the provider choice of V22.1. Returns the names of the fields that were removed
        (an empty list = nothing to do). Called once at start-up; the Gemini key and model are not touched."""
        user = user or LOCAL_USER
        with self._lock:
            data = self.read(user['uid'])
            gone = [k for k in REMOVED_FIELDS if k in data]
            if gone:
                for k in gone:
                    data.pop(k, None)
                self.write(user['uid'], data)
            return gone

    # ---- the key
    def _legacy(self):
        try:
            return json.loads((self.data_dir / 'settings.json').read_text(encoding='utf-8'))      # V20's file
        except Exception:                        # noqa: BLE001
            return {}

    def _saved_key(self, user):
        blob = self.read(user['uid']).get('gemini_key_enc')
        return self.box.decrypt(blob) if blob else ''

    @staticmethod
    def _env_key():
        for name in ENV_KEYS:
            v = (os.getenv(name) or '').strip()
            if v:
                return v
        return ''

    def get_key(self, user):
        """The Gemini key ('' = none yet). A key typed on the website always wins over the .env one: that is how a key whose credit
        ran out is replaced."""
        return self._saved_key(user) or self._env_key() or (self._legacy().get('gemini_api_key') or '').strip()

    def key_source(self, user):
        if self._saved_key(user):
            return 'saved'
        if self._env_key():
            return 'env'
        return 'saved' if self.get_key(user) else ''

    def set_key(self, user, key):
        with self._lock:
            data = self.read(user['uid'])
            data['gemini_key_enc'] = self.box.encrypt(key.strip())
            self.write(user['uid'], data)

    def clear_key(self, user):
        with self._lock:
            data = self.read(user['uid'])
            data.pop('gemini_key_enc', None)
            self.write(user['uid'], data)
            legacy = self._legacy()
            if legacy.pop('gemini_api_key', None) is not None:                # V20 kept it in data/settings.json
                (self.data_dir / 'settings.json').write_text(json.dumps(legacy, ensure_ascii=False, indent=2), encoding='utf-8')

    # ---- the model
    def get_model(self, user):
        saved = (self.read(user['uid']).get('gemini_model') or '').strip()
        if saved:
            return saved
        env = (os.getenv('GEMINI_MODEL') or '').strip()
        return (env or self._legacy().get('gemini_model') or self.DEFAULT_MODEL).strip()

    def set_model(self, user, model):
        with self._lock:
            data = self.read(user['uid'])
            data['gemini_model'] = (model or self.DEFAULT_MODEL).strip()
            self.write(user['uid'], data)


def mask(key):
    key = key or ''
    return '••••••' + key[-4:] if len(key) > 4 else ('••••' if key else '')
