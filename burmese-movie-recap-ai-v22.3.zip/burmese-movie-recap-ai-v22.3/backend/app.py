"""Burmese Movie Recap AI V22.3 - the web layer (FastAPI).

The work itself lives in the other modules of this folder:

    pipeline.py      one job from upload to finished video (Whisper -> AI writes the Burmese -> Burmese voice -> mix -> render -> Drive)
    gemini_client.py every AI request (503 / 429 / quota / key / timeout problems are handled here, never fatal) - Gemini is the only AI
    jobs.py          job files on disk, pause / resume / cancel, the CPU queue
    auth.py          optional APP_PASSWORD, the cross-site check, the saved Gemini key + model
    drive_store.py   Google Drive delivery (optional)
    voices.py, timing.py, rewrite.py, asr.py, media.py, presets.py

One user, no sign-in (like V20): open http://<server-ip>:<port>. See auth.py for how to keep strangers out.
"""
import contextlib
import html as _html
import os
import re
import shutil
import subprocess
import sys
import tempfile
import threading
import time
import uuid
from pathlib import Path
from urllib.parse import quote

os.environ.setdefault('TOKENIZERS_PARALLELISM', 'false')
# (V20 forced OMP_NUM_THREADS=1 here, which made Whisper run on ONE core. V21 lets it use every core.)

BASE = Path(__file__).resolve().parent
ROOT = BASE.parent
if str(BASE) not in sys.path:                    # the modules of this folder import each other by plain name
    sys.path.insert(0, str(BASE))

try:
    from dotenv import load_dotenv
    load_dotenv(ROOT / '.env')
except ImportError:                              # python-dotenv is optional
    pass

import requests                                  # noqa: E402
from fastapi import Body, Depends, FastAPI, File, Form, HTTPException, Request, UploadFile   # noqa: E402
from fastapi.responses import FileResponse, HTMLResponse, JSONResponse, RedirectResponse, Response, StreamingResponse  # noqa: E402
from fastapi.staticfiles import StaticFiles      # noqa: E402
from starlette.background import BackgroundTask  # noqa: E402

import asr                                       # noqa: E402
import auth                                      # noqa: E402
import drive_store                               # noqa: E402
import gemini_client as G                        # noqa: E402
import jobs as J                                 # noqa: E402
import media                                     # noqa: E402
import pipeline                                  # noqa: E402
import presets as P                              # noqa: E402
import review                                    # noqa: E402
import timing as T                               # noqa: E402
import voices as V                               # noqa: E402

VERSION = 'V22.3'
VIDEO_EXTS = {'.mp4', '.mov', '.mkv', '.webm', '.avi', '.m4v'}
DOWNLOADABLE = {'final_burmese.mp4': 'video/mp4', 'burmese.srt': 'application/x-subrip', 'burmese.vtt': 'text/vtt',
                'transcript.txt': 'text/plain; charset=utf-8', 'burmese.txt': 'text/plain; charset=utf-8'}

# ------------------------------------------------------------------------------------------------ setup
DATA = Path(os.getenv('DATA_DIR') or (ROOT / 'data')).resolve()
DATA.mkdir(parents=True, exist_ok=True)
drive_store.DATA = DATA                          # the Drive login lives next to everything else
TMP = DATA / 'tmp'
TMP.mkdir(exist_ok=True)
tempfile.tempdir = str(TMP)                      # uploads are spooled here, not into a (possibly tiny) system /tmp
SAMPLES = DATA / 'samples'

USERS = auth.UserStore(DATA)
APP_PASSWORD = (os.getenv('APP_PASSWORD') or '').strip()            # '' = no password (see auth.py)
STORE = J.JobStore(DATA / 'jobs')
STORE.load_existing()
RUNNER = J.Runner(STORE)
HEAVY = J.FifoSlots(int(os.getenv('HEAVY_SLOTS') or 1))
SERVICES = pipeline.Services(STORE, DATA, HEAVY, USERS, drive=drive_store)


def _num(name, default):
    try:
        return float(os.getenv(name) or default)
    except ValueError:
        return float(default)


MAX_UPLOAD_MB = int(_num('MAX_UPLOAD_MB', 0))                    # 0 = no limit
RETENTION_HOURS = _num('RETENTION_HOURS', 0)                     # finished jobs are deleted after this many hours; 0 = keep forever
MAX_JOBS_PER_USER = int(_num('MAX_JOBS_PER_USER', 6))            # unfinished jobs at the same time (uploads that are still arriving count)


@contextlib.asynccontextmanager
async def lifespan(_app):
    start_background_threads()
    purge_removed_ai()
    resume_after_restart()
    yield


app = FastAPI(title=f'Burmese Movie Recap AI {VERSION}', docs_url=None, redoc_url=None, openapi_url=None, lifespan=lifespan)
app.mount('/static', StaticFiles(directory=str(ROOT / 'frontend')), name='static')


class Guard:
    """Pure ASGI middleware (it does not buffer the big video downloads). BEFORE anything is read from a request body it

      * (APP_PASSWORD set) answers 401 + the browser's password prompt to a request without the right password,
      * refuses a cross-site POST / PUT / DELETE,
      * answers 413 to a body that is bigger than allowed: at once when Content-Length already says so, and by counting the
        bytes for chunked uploads that do not say it,
      * counts uploads that are still arriving against the job limit (a job exists only after its upload has arrived, so
        without this ten parallel uploads would all pass the limit and fill the disk).

    It also adds a few safe response headers."""

    UNSAFE = {'POST', 'PUT', 'DELETE', 'PATCH'}
    NO_STORE_EXCEPT = ('/api/files/', '/api/drive/stream/', '/api/voice-sample/', '/api/review-font')
    SMALL_BODY = 1 << 20                         # every form except the video upload is tiny

    def __init__(self, inner):
        self.inner = inner
        self.extra = [(b'x-content-type-options', b'nosniff'), (b'referrer-policy', b'same-origin'), (b'x-frame-options', b'DENY'),
                      (b'content-security-policy', b"frame-ancestors 'none'; base-uri 'none'; object-src 'none'; form-action 'self'")]

    @classmethod
    def body_limit(cls, path):
        if path == '/api/jobs':                  # the video upload, plus a little room for the form fields
            return MAX_UPLOAD_MB * 1048576 + (2 << 20) if MAX_UPLOAD_MB > 0 else None
        return cls.SMALL_BODY

    @staticmethod
    def too_big(path):
        if path == '/api/jobs' and MAX_UPLOAD_MB > 0:
            return f'ဖိုင်က ကြီးလွန်းပါတယ် (အများဆုံး {MAX_UPLOAD_MB} MB)။'
        return 'Request is too large.'

    async def __call__(self, scope, receive, send):
        if scope['type'] != 'http':
            return await self.inner(scope, receive, send)
        headers = {k.decode('latin-1').lower(): v.decode('latin-1') for k, v in scope.get('headers', [])}
        path = scope.get('path', '')
        extra = list(self.extra)
        if path.startswith('/api/') and not path.startswith(self.NO_STORE_EXCEPT):
            extra.append((b'cache-control', b'no-store'))

        async def send_with_headers(message):
            if message['type'] == 'http.response.start':
                message = dict(message, headers=list(message.get('headers') or []) + extra)
            await send(message)

        def refuse(status, detail, **more):
            return JSONResponse({'detail': detail}, status_code=status, headers=dict({'Connection': 'close'}, **more))(scope, receive, send_with_headers)

        if APP_PASSWORD and not auth.password_ok(headers.get('authorization'), APP_PASSWORD):
            return await refuse(401, 'Password လိုပါတယ်။', **{'WWW-Authenticate': 'Basic realm="Burmese Movie Recap AI", charset="UTF-8"'})
        if scope['method'] in self.UNSAFE:
            if not auth.origin_ok(headers.get('origin'), headers.get('referer'), headers.get('host')):
                return await refuse(403, 'Cross-site request refused.')
            limit = self.body_limit(path)
            if limit:
                declared = headers.get('content-length', '')
                if declared.isdigit() and int(declared) > limit:
                    return await refuse(413, self.too_big(path))
                inner_receive, seen = receive, 0

                async def counted():             # chunked uploads: stop reading as soon as the limit is passed
                    nonlocal seen
                    message = await inner_receive()
                    if message['type'] == 'http.request':
                        seen += len(message.get('body') or b'')
                        if seen > limit:
                            raise HTTPException(413, self.too_big(path), headers={'Connection': 'close'})
                    return message
                receive = counted
            if scope['method'] == 'POST' and path == '/api/jobs':
                uid = auth.LOCAL_USER['uid']
                try:
                    begin_upload(uid)
                except HTTPException as e:
                    return await refuse(e.status_code, e.detail)
                try:
                    return await self.inner(scope, receive, send_with_headers)
                finally:
                    end_upload(uid)
        await self.inner(scope, receive, send_with_headers)


app.add_middleware(Guard)


# ------------------------------------------------------------------------------------------------ helpers
def current_user():
    """There is no sign-in: everybody who can open the website is the one user "local" (see auth.py)."""
    return dict(auth.LOCAL_USER)


def user_dir(user):
    return None if user.get('local') else USERS.dir(user['uid'])


def base_of(request: Request):
    return str(request.base_url).rstrip('/')


def page(title, body, status=400):
    return HTMLResponse('<!doctype html><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">'
                        '<body style="font-family:system-ui,sans-serif;background:#05020e;color:#f6f2ff;max-width:640px;margin:12vh auto;padding:0 20px">'
                        f'<h2>{_html.escape(title)}</h2><p style="white-space:pre-wrap">{_html.escape(body)}</p>'
                        '<p><a style="color:#c4b5fd" href="/">← Back to the app</a></p></body>', status_code=status)


def flag(v):
    return str(v or '').strip().lower() in ('1', 'true', 'on', 'yes', 'y')


def own_job(jid, user):
    job = STORE.get(jid) if re.fullmatch(r'[0-9a-f]{32}', jid or '') else None
    if not job or job.get('owner') != user['uid']:
        raise HTTPException(404, 'Job not found')
    return job


def input_exists(job):
    try:
        return (STORE.dir(job['id']) / job['input']).is_file()
    except (ValueError, KeyError, OSError):
        return False


def view(job, full=True):
    d = {k: v for k, v in job.items() if k not in ('owner', 'input')}
    running = RUNNER.running(job['id'])
    d['running'] = running
    d['can_resume'] = bool(job.get('status') in J.RESUMABLE and not running and input_exists(job))
    d['can_cancel'] = bool(running or job.get('status') in J.RESUMABLE or job.get('status') == J.REVIEW)
    d['now'] = time.time()                       # server clock: lets the page count down "retry in N seconds" correctly
    if not full:
        d.pop('source_text', None)
        d.pop('burmese_text', None)
    return d


KEY_URL = 'https://aistudio.google.com/apikey'
KEY_SITE = 'Google AI Studio'


def key_info(user):
    """What the website needs to know about the Gemini key (never the key itself)."""
    key = USERS.get_key(user)
    return {'configured': bool(key), 'masked': auth.mask(key), 'model': USERS.get_model(user), 'source': USERS.key_source(user),
            'default_model': G.default_model(), 'key_url': KEY_URL, 'key_site': KEY_SITE}


def start_job(jid):
    return RUNNER.start(jid, lambda ctl: pipeline.run_job(SERVICES, jid, ctl))


def tidy_key(raw):
    key = (raw or '').strip().strip('"\'')
    if key and (len(key) < 5 or len(key) > 400 or re.search(r'\s', key)):
        raise HTTPException(400, f'API key ပုံစံ မမှန်ပါ — {KEY_SITE} က key တစ်ခုလုံးကို space မပါဘဲ ကူးထည့်ပါ။')
    return key


_MODEL_PLAIN = re.compile(r'[A-Za-z0-9][A-Za-z0-9._-]{0,79}')


def tidy_model(raw):
    """A model name from the website ("models/" in front is fine). It goes into the request address, so only plain model-name
    characters are accepted (a slash is never valid in a Gemini model name)."""
    model = G.clean_model(raw)
    if model and (not _MODEL_PLAIN.fullmatch(model) or '..' in model):
        raise HTTPException(400, 'Model နာမည် မမှန်ပါ — ဥပမာ gemini-flash-latest (စာလုံး၊ ဂဏန်း၊ - . _ ပဲ ရပါတယ်)။')
    return model


MISSING_KEY = 'Gemini API key မထည့်ရသေးပါ — "Gemini API" card မှာ ကိုယ့်ရဲ့ key ကို ထည့်ပြီး Save လုပ်ပါ။'


# ------------------------------------------------------------------------------------------------ the page
@app.get('/', response_class=HTMLResponse)
def home():
    return HTMLResponse((ROOT / 'frontend' / 'index.html').read_text(encoding='utf-8'), headers={'Cache-Control': 'no-store'})


@app.get('/favicon.ico')
def favicon():
    return HTMLResponse('', status_code=204)


# ------------------------------------------------------------------------------------------------ about this server
BOOT_ID = uuid.uuid4().hex[:12]                  # changes every time the server (re)starts: the page tells "server restarted" from "network broke"


@app.get('/api/about')
def about():
    return {'version': VERSION, 'max_upload_mb': MAX_UPLOAD_MB, 'retention_hours': RETENTION_HOURS, 'max_jobs': MAX_JOBS_PER_USER,
            'password_protected': bool(APP_PASSWORD), 'boot': BOOT_ID}


# ------------------------------------------------------------------------------------------------ the Gemini key
@app.get('/api/settings')
def get_settings(user=Depends(current_user)):
    return key_info(user)


@app.post('/api/settings')
def save_settings(gemini_api_key: str = Form(''), gemini_model: str = Form(''), user=Depends(current_user)):
    """Save the Gemini key and / or model (the key is stored encrypted, see auth.py)."""
    key = tidy_key(gemini_api_key)
    model = tidy_model(gemini_model)
    if not (key or USERS.get_key(user)):
        raise HTTPException(400, 'Gemini API key ထည့်ပါ။')
    if key:
        USERS.set_key(user, key)
    if model:
        USERS.set_model(user, model)
    return dict(key_info(user), ok=True)


@app.delete('/api/settings')
def clear_settings(user=Depends(current_user)):
    USERS.clear_key(user)
    return dict(key_info(user), ok=True)


@app.post('/api/settings/test')
def test_settings(gemini_api_key: str = Form(''), gemini_model: str = Form(''), user=Depends(current_user)):
    """Does the key work? It costs NOTHING: no text is generated (models.get + countTokens), so no output tokens and no generation
    quota or credit is used. A key typed in the box but not saved yet can be tested too."""
    key = tidy_key(gemini_api_key) or USERS.get_key(user)
    model = tidy_model(gemini_model) or USERS.get_model(user)
    if not key:
        return {'ok': False, 'error': 'Gemini API key မထည့်ရသေးပါ။'}
    try:
        info = G.check_key(key, model)
    except G.GeminiError as e:
        return {'ok': False, 'error': str(e)[:900]}
    return dict(info, ok=True, free=True)


@app.post('/api/settings/models')
def list_ai_models(gemini_api_key: str = Form(''), user=Depends(current_user)):
    """The models this key can use (a free call). Fills the model box on the website."""
    key = tidy_key(gemini_api_key) or USERS.get_key(user)
    if not key:
        return {'ok': False, 'error': 'Gemini API key မထည့်ရသေးပါ။', 'models': []}
    try:
        found = G.list_models(key)
    except G.GeminiError as e:
        return {'ok': False, 'error': str(e)[:900], 'models': []}
    names = sorted({m['name'] for m in found if m['name'].startswith('gemini') and (not m['methods'] or 'generateContent' in m['methods'])
                    and 'tts' not in m['name'] and 'image' not in m['name'] and 'embedding' not in m['name']})
    return {'ok': True, 'models': names}


# ------------------------------------------------------------------------------------------------ options + voice samples
@app.get('/api/options')
def options(user=Depends(current_user)):
    problem = media.subtitle_problem()
    return {
        'voices': V.public_list(V.edge_live_cached()), 'groups': V.GROUPS,
        'styles': [{'id': k, 'name': v['name'], 'label': v['label'], 'desc': v['desc'], 'new': bool(v.get('new')), 'mode': v.get('mode', 'line')}
                   for k, v in P.STYLE_PRESETS.items()],
        'default_voice': V.DEFAULT_VOICE, 'default_style': P.DEFAULT_STYLE, 'recommended_style': P.RECOMMENDED_STYLE,
        'default_speed': V.DEFAULT_SPEED, 'speed_min': V.MIN_SPEED, 'speed_max': V.MAX_SPEED,
        'render_presets': list(media.RENDER_PRESETS), 'default_render': media.render_preset(),
        'subtitle_ready': not problem, 'subtitle_problem': problem,
        'max_upload_mb': MAX_UPLOAD_MB,
    }


@app.get('/api/voice-sample/{vid}')
def voice_sample(vid: str, speed: int = V.DEFAULT_SPEED, user=Depends(current_user)):
    """A short example sentence in the chosen voice (at the chosen speed) so the person can listen before choosing. The answer
    headers say whether the sample really sounds like Burmese speech (a voice that cannot read Burmese gives silence or a
    clip of the wrong length): X-Sample-Ok = 1 / 0, X-Sample-Message = the reason."""
    voice = V.resolve(vid)
    if not voice:
        raise HTTPException(404, 'Unknown voice')
    sp = V.clamp_speed(int(round(speed / 5.0)) * 5)
    try:
        if voice['engine'] == 'gemini':
            key = USERS.get_key(user)
            if not key:
                raise HTTPException(400, 'Gemini အသံကို နားထောင်ဖို့ ကိုယ့် Gemini API key ကို အရင်ထည့်ပါ။')
            client = G.GeminiClient(key, USERS.get_model(user), [])
            client.patience = 60
            engine = V.GeminiTTS(client)
        else:
            engine = SERVICES.edge
        path, _secs = V.ClipMaker(media.FFMPEG, engine, voice, sp, SAMPLES).make(voice['sample'])
    except HTTPException:
        raise
    except G.GeminiNeedKey as e:
        raise HTTPException(400, str(e))
    except (V.TtsError, G.GeminiError) as e:
        raise HTTPException(502, f'Voice sample could not be generated: {e}')
    except Exception as e:
        raise HTTPException(502, f'Voice sample could not be generated: {e.__class__.__name__}: {e}')
    ok, message = V.check_sample(voice['sample'], T.read_wav(path)[0])
    return FileResponse(path, media_type='audio/wav', headers={
        'X-Sample-Ok': '1' if ok else '0', 'X-Sample-Message': quote(message), 'Cache-Control': 'private, max-age=600',
        'Access-Control-Expose-Headers': 'X-Sample-Ok, X-Sample-Message'})


# ------------------------------------------------------------------------------------------------ jobs
_UPLOADING = {}                                  # uid -> uploads that are still arriving (they are not jobs yet)
_UPLOADING_LOCK = threading.Lock()


def begin_upload(uid):
    """Called by Guard BEFORE the body of POST /api/jobs is read. A person may have MAX_JOBS_PER_USER unfinished jobs; uploads that
    are still arriving count too, otherwise ten parallel uploads would all pass the check (a job exists only after the upload has
    arrived completely) and ten huge files would fill the disk."""
    with _UPLOADING_LOCK:
        if STORE.count_active(uid) + _UPLOADING.get(uid, 0) >= MAX_JOBS_PER_USER:
            raise HTTPException(429, f'တစ်ပြိုင်နက် job {MAX_JOBS_PER_USER} ခုထက် မပိုရပါ။ တစ်ခုခု ပြီးမှ (သို့) Cancel လုပ်ပြီးမှ ထပ်တင်ပါ။')
        _UPLOADING[uid] = _UPLOADING.get(uid, 0) + 1


def end_upload(uid):
    with _UPLOADING_LOCK:
        left = _UPLOADING.get(uid, 0) - 1
        if left > 0:
            _UPLOADING[uid] = left
        else:
            _UPLOADING.pop(uid, None)


@app.post('/api/jobs')
def create_job(video: UploadFile = File(...), voice: str = Form(V.DEFAULT_VOICE), style: str = Form(P.DEFAULT_STYLE),
               make_voice: str = Form('1'), make_subtitles: str = Form('0'),
               blur_original: str = Form('1'), blur_height: float = Form(18), blur_top: float = Form(-1),
               speed: float = Form(V.DEFAULT_SPEED), render_speed: str = Form(''), review_first: str = Form('0', alias='review'), user=Depends(current_user)):
    v = V.resolve(voice)
    if not v:
        raise HTTPException(400, 'Unsupported voice')
    if style not in P.STYLE_PRESETS:
        raise HTTPException(400, 'Unsupported style')
    mv, ms = flag(make_voice), flag(make_subtitles)
    if not (mv or ms):
        raise HTTPException(400, 'စာတန်းထိုးမည် သို့မဟုတ် မြန်မာသံပြောင်းမည် — အနည်းဆုံး တစ်ခု ရွေးပါ။')
    if not USERS.get_key(user):
        raise HTTPException(400, MISSING_KEY)
    if ms:
        problem = media.subtitle_problem()
        if problem:
            raise HTTPException(400, problem)
    suffix = Path(video.filename or 'video.mp4').suffix.lower()
    if suffix not in VIDEO_EXTS:
        raise HTTPException(400, 'Unsupported video format')
    if STORE.count_active(user['uid']) >= MAX_JOBS_PER_USER:
        raise HTTPException(429, f'တစ်ပြိုင်နက် job {MAX_JOBS_PER_USER} ခုထက် မပိုရပါ။ တစ်ခုခု ပြီးမှ (သို့) Cancel လုပ်ပြီးမှ ထပ်တင်ပါ။')
    # The upload goes to a temporary file first, and becomes a job only when it arrived completely.
    part = TMP / f'{uuid.uuid4().hex}.upload'
    limit, written, job = MAX_UPLOAD_MB * 1048576, 0, None
    try:
        with open(part, 'wb') as out:
            while True:
                chunk = video.file.read(1 << 20)
                if not chunk:
                    break
                written += len(chunk)
                if limit and written > limit:
                    raise HTTPException(413, f'ဖိုင်က ကြီးလွန်းပါတယ် (အများဆုံး {MAX_UPLOAD_MB} MB)။')
                out.write(chunk)
        if written <= 0:
            raise HTTPException(400, 'Video ဖိုင် အလွတ်ဖြစ်နေပါတယ်။')
        if not media.looks_like_video(part):
            raise HTTPException(400, 'ဒီဖိုင်က video ဖိုင် အစစ် မဟုတ်ပါဘူး (mp4 / mov / m4v / mkv / webm / avi ပဲ ရပါတယ်)။')
        free = shutil.disk_usage(DATA).free
        if free < written * 2 + (400 << 20):
            raise HTTPException(507, 'Server ရဲ့ disk နေရာ မလောက်ပါဘူး။ နောက်မှ ပြန်စမ်းပါ (သို့) Owner ကို ပြောပါ။')
        blur = None
        if ms and flag(blur_original):
            bh = max(4.0, min(60.0, float(blur_height)))
            bt = None if float(blur_top) < 0 else max(0.0, min(100.0 - bh, float(blur_top)))
            blur = {'top': bt, 'height': bh}
        render = (render_speed or '').strip().lower()
        params = {'voice': v['id'], 'style': style, 'make_voice': mv, 'make_subs': ms, 'speed': V.clamp_speed(speed),
                  'blur': blur, 'render_preset': render if render in media.RENDER_PRESETS else media.render_preset(),
                  'review': flag(review_first)}
        job = STORE.create(user['uid'], params, Path(video.filename or 'video').name[:200], suffix)
        part.replace(STORE.dir(job['id']) / f'input{suffix}')
    except BaseException:
        try:
            part.unlink()
        except OSError:
            pass
        if job:
            STORE.remove(job['id'])
        raise
    start_job(job['id'])
    return {'id': job['id']}


@app.get('/api/jobs')
def list_jobs(user=Depends(current_user)):
    out = []
    for j in STORE.list_for(user['uid']):
        running = RUNNER.running(j['id'])
        d = {k: v for k, v in j.items() if k != 'input'}
        d['running'] = running
        d['can_resume'] = bool(j.get('status') in J.RESUMABLE and not running and input_exists(j))
        d['can_cancel'] = bool(running or j.get('status') in J.RESUMABLE or j.get('status') == J.REVIEW)
        out.append(d)
    return {'jobs': out}


@app.get('/api/jobs/{jid}')
def get_job(jid: str, user=Depends(current_user)):
    return view(own_job(jid, user))


@app.post('/api/jobs/{jid}/resume')
def resume_job(jid: str, gemini_api_key: str = Form(''), gemini_model: str = Form(''), api_key: str = Form(''), model: str = Form(''),
               user=Depends(current_user)):
    """Continue a paused job (credit used up / key refused / the AI busy) with a NEW key or the same one, or continue a job
    that stopped (error, server restart). Everything finished so far stays on disk, so nothing starts again from the beginning.
    The key / model are the Gemini ones (api_key / model = what the page sends; gemini_api_key / gemini_model = V21 names)."""
    job = own_job(jid, user)
    key = tidy_key(api_key or gemini_api_key)
    model = tidy_model(model or gemini_model)
    running = RUNNER.running(jid)
    if running and job['status'] != 'paused':
        raise HTTPException(409, 'ဒီ job က အလုပ်လုပ်နေဆဲပါ။')
    if not running and job['status'] not in J.RESUMABLE:
        raise HTTPException(409, 'ဒီ job ကို ဆက်လုပ်လို့ မရပါ။')
    if key:                                      # the new key is checked FIRST (free call), a bad one never wakes the job
        try:
            G.check_key(key, model or USERS.get_model(user))
        except G.GeminiError as e:
            raise HTTPException(400, f'ဒီ key နဲ့ မရသေးပါ — {e}')
        USERS.set_key(user, key)
    if model:
        USERS.set_model(user, model)
    if running:
        if not RUNNER.answer(jid, {'key': key or None, 'model': model or None}):
            raise HTTPException(409, 'Job က အခု စောင့်နေတဲ့ အနေအထား မဟုတ်တော့ပါဘူး။ Page ကို refresh လုပ်ကြည့်ပါ။')
    else:
        if not input_exists(job):
            raise HTTPException(409, 'မူရင်း video ဖိုင် ဖျက်ပြီးသွားပါပြီ။ Video ကို ပြန်တင်ပါ။')
        if not USERS.get_key(user):
            raise HTTPException(400, 'Gemini API key မထည့်ရသေးပါ။')
        if STORE.count_active(user['uid']) >= MAX_JOBS_PER_USER:
            raise HTTPException(429, 'တစ်ပြိုင်နက် job အရေအတွက် ပြည့်နေပါတယ်။ တစ်ခုခု ပြီးမှ ဆက်လုပ်ပါ။')
        try:
            start_job(jid)
        except RuntimeError:
            raise HTTPException(409, 'ဒီ job က အလုပ်လုပ်နေဆဲပါ။')
    return {'ok': True, 'job': view(STORE.get(jid))}


@app.post('/api/jobs/{jid}/cancel')
def cancel_job(jid: str, user=Depends(current_user)):
    """Stop for good: the files of the job are deleted. (A paused job is NOT cancelled by anything else - it waits.)"""
    job = own_job(jid, user)
    if RUNNER.running(jid):
        RUNNER.cancel(jid)
    elif job['status'] in J.RESUMABLE or job['status'] in J.UNFINISHED:
        pipeline.discard_files(STORE.dir(jid))
        STORE.update(jid, status='cancelled', stage='Cancelled', detail='ပယ်ဖျက်လိုက်ပါတယ်။', pause=None, wait=None, error='', _force=True)
    return {'ok': True, 'job': view(STORE.get(jid))}


@app.delete('/api/jobs/{jid}')
def delete_job(jid: str, user=Depends(current_user)):
    own_job(jid, user)
    if RUNNER.running(jid):
        raise HTTPException(409, 'အလုပ်လုပ်နေတဲ့ job ကို အရင် Cancel လုပ်ပါ။')
    STORE.remove(jid)
    return {'ok': True}


# ------------------------------------------------------------------------------------------------ review (V21.1)
# A job started with "review" stops after the Burmese text is written (status "review") and waits for the person: they watch the
# video with the subtitles on top, edit the lines, set the look of the subtitles and of the blur, and then press "continue".
REVIEW_LOCK = threading.Lock()                   # one edit / continue at a time (they rewrite the same small files)
FRAME_LOCK = threading.Semaphore(1)              # one "real picture" at a time (each one starts ffmpeg)
VIDEO_TYPES = {'.mp4': 'video/mp4', '.m4v': 'video/mp4', '.mov': 'video/quicktime', '.webm': 'video/webm',
               '.mkv': 'video/x-matroska', '.avi': 'video/x-msvideo'}
_FONT_SCALE = {}


def review_job(jid, user):
    job = own_job(jid, user)
    if job['status'] != J.REVIEW or RUNNER.running(jid):
        raise HTTPException(409, 'ဒီ job က စာပြင်တဲ့ အဆင့်မှာ မရှိပါဘူး။ Page ကို refresh လုပ်ကြည့်ပါ။')
    return job


def review_body(body):
    if not isinstance(body, dict):
        raise HTTPException(400, 'Request မမှန်ပါ။')
    edits = body.get('edits')
    if edits is not None and not isinstance(edits, dict):
        raise HTTPException(400, 'Request မမှန်ပါ။')
    return edits or {}, body.get('settings')


def review_shifts(body):
    """V21.2: the lines the person moved in time ({line number: seconds}); None = the page said nothing about them (what is saved stays)."""
    shifts = body.get('shifts') if isinstance(body, dict) else None
    if shifts is not None and not isinstance(shifts, dict):
        raise HTTPException(400, 'Request မမှန်ပါ။')
    return shifts


def ranged_file(request, path, media_type):
    """A file answered with HTTP Range support: a browser needs it to play a video and to jump around in it."""
    size = path.stat().st_size
    start, end, status = 0, size - 1, 200
    m = re.fullmatch(r'bytes=(\d*)-(\d*)', (request.headers.get('range') or '').strip())
    if m and (m.group(1) or m.group(2)):
        if m.group(1):
            start = int(m.group(1))
            if m.group(2):
                end = min(end, int(m.group(2)))
        else:
            start = max(0, size - int(m.group(2)))
        if start > end or start >= size:
            return Response(status_code=416, headers={'Content-Range': f'bytes */{size}'})
        status = 206
    length = max(0, end - start + 1)

    def chunks():
        with open(path, 'rb') as f:
            f.seek(start)
            left = length
            while left > 0:
                block = f.read(min(1 << 20, left))
                if not block:
                    break
                left -= len(block)
                yield block
    headers = {'Accept-Ranges': 'bytes', 'Content-Length': str(length), 'Cache-Control': 'private, max-age=600'}
    if status == 206:
        headers['Content-Range'] = f'bytes {start}-{end}/{size}'
    return StreamingResponse(chunks(), status_code=status, media_type=media_type, headers=headers)


@app.get('/api/files/{jid}/review-video')
def review_video(jid: str, request: Request, user=Depends(current_user)):
    """The video for the preview on the review page: the upload itself when a browser can play it, otherwise the small copy."""
    job = review_job(jid, user)
    state = review.load(STORE.dir(jid)) or {}
    if state.get('preview') == 'copy':
        path, kind = STORE.dir(jid) / 'work' / 'preview.mp4', 'video/mp4'
    elif state.get('preview') == 'original':
        path = STORE.dir(jid) / job['input']
        kind = VIDEO_TYPES.get(path.suffix.lower(), 'video/mp4')
    else:
        raise HTTPException(404, 'Preview video မရှိပါဘူး။')
    if not path.is_file():
        raise HTTPException(404, 'Preview video မရှိပါဘူး။')
    return ranged_file(request, path, kind)


@app.get('/api/review-font')
def review_font():
    """The font the subtitles are burned with, so the preview on the page draws the same letters."""
    path, _name = media.find_burmese_font()
    if not path or path.suffix.lower() not in ('.ttf', '.otf'):
        raise HTTPException(404, 'No font')
    return FileResponse(path, media_type='font/otf' if path.suffix.lower() == '.otf' else 'font/ttf',
                        headers={'Cache-Control': 'public, max-age=86400'})


def font_info():
    path, name = media.find_burmese_font()
    if not path or path.suffix.lower() not in ('.ttf', '.otf'):
        return None
    if str(path) not in _FONT_SCALE:
        _FONT_SCALE[str(path)] = media.font_metric_scale(path)
    return {'url': '/api/review-font', 'family': name, 'scale': _FONT_SCALE[str(path)]}


@app.get('/api/jobs/{jid}/review')
def get_review(jid: str, user=Depends(current_user)):
    job = review_job(jid, user)
    data = review.payload(STORE.dir(jid), job['params'])
    if data is None:
        raise HTTPException(409, 'ဒီ job ရဲ့ စာ ဖိုင်တွေ မတွေ့တော့ပါဘူး — Cancel လုပ်ပြီး video ကို ပြန်တင်ပါ။')
    voice = V.resolve(job['params'].get('voice') or '')
    data.update(voice_name=voice['name'] if voice else '', font=font_info(), orig_name=job.get('orig_name', ''),
                video_url=f'/api/files/{jid}/review-video' if data.get('preview') in ('original', 'copy') else None)
    return data


@app.post('/api/jobs/{jid}/review')
def save_review(jid: str, body: dict = Body(...), user=Depends(current_user)):
    """Keep the edited lines and the chosen look (the page does this by itself every few seconds, so nothing is lost)."""
    job = review_job(jid, user)
    edits, raw = review_body(body)
    shifts = review_shifts(body)
    try:
        with REVIEW_LOCK:
            changed = review.apply_edits(STORE.dir(jid), edits)
            review.remember(STORE.dir(jid), review.clean_settings(raw, job['params']), shifts=shifts)
    except ValueError:
        raise HTTPException(409, 'ဒီ job ရဲ့ စာ ဖိုင်တွေ မတွေ့တော့ပါဘူး။')
    return {'ok': True, 'changed': changed}


@app.post('/api/jobs/{jid}/review/continue')
def continue_review(jid: str, body: dict = Body(...), user=Depends(current_user)):
    """The person is happy with the text and the look: keep everything and let the job go on (voice from the EDITED text, mix, render)."""
    job = review_job(jid, user)
    edits, raw = review_body(body)
    shifts = review_shifts(body)
    params = job['params']
    if not input_exists(job):
        raise HTTPException(409, 'မူရင်း video ဖိုင် ဖျက်ပြီးသွားပါပြီ။ Video ကို ပြန်တင်ပါ။')
    settings = review.clean_settings(raw, params)
    if not (settings['subs'] or params.get('make_voice')):
        raise HTTPException(400, 'စာတန်းထိုးမည် သို့မဟုတ် မြန်မာသံပြောင်းမည် — အနည်းဆုံး တစ်ခု ရွေးပါ။')
    if params.get('make_voice') and not USERS.get_key(user):
        raise HTTPException(400, MISSING_KEY)
    if settings['subs']:
        problem = media.subtitle_problem()
        if problem:
            raise HTTPException(400, problem)
    try:
        with REVIEW_LOCK:
            review.apply_edits(STORE.dir(jid), edits)
            lines, _doc = review.read_lines(STORE.dir(jid))
            if not any(T.has_speech(x) for x in lines):
                raise HTTPException(400, 'မြန်မာစာ တစ်ကြောင်းမှ မကျန်တော့ပါဘူး — အနည်းဆုံး တစ်ကြောင်း ရှိရပါမယ်။')
            review.remember(STORE.dir(jid), settings, done=True, shifts=shifts)
            STORE.update(jid, params=review.job_params(params, settings), _force=True)
    except ValueError:
        raise HTTPException(409, 'ဒီ job ရဲ့ စာ ဖိုင်တွေ မတွေ့တော့ပါဘူး။')
    try:
        start_job(jid)
    except RuntimeError:
        raise HTTPException(409, 'ဒီ job က အလုပ်လုပ်နေဆဲပါ။')
    return {'ok': True, 'job': view(STORE.get(jid))}


@app.post('/api/jobs/{jid}/review/frame')
def review_frame(jid: str, body: dict = Body(...), user=Depends(current_user)):
    """ONE picture of the finished look (the real ASS file and the real blur filter) at a moment of the video, for the "real picture" button."""
    job = review_job(jid, user)
    state = review.load(STORE.dir(jid)) or {}
    if not isinstance(body, dict):
        raise HTTPException(400, 'Request မမှန်ပါ။')
    try:
        at = float(body.get('t', 0))
    except (TypeError, ValueError):
        at = 0.0
    at = max(0.0, min(at if at == at else 0.0, max(0.0, float(state.get('duration') or 0.0) - 0.1)))
    text = review.clean_line(body.get('text')) or 'မြန်မာစာတန်း ဒီနေရာမှာ ပေါ်ပါမယ်'
    settings = review.clean_settings(body.get('settings'), job['params'])
    problem = media.subtitle_problem()
    if problem:
        raise HTTPException(400, problem)
    if not FRAME_LOCK.acquire(timeout=20):
        raise HTTPException(429, 'ပုံထုတ်နေဆဲပါ — ခဏနေမှ ထပ်နှိပ်ပါ။')
    shot = STORE.dir(jid) / 'work' / 'frame' / f'{uuid.uuid4().hex}.jpg'
    try:
        shot.parent.mkdir(parents=True, exist_ok=True)
        media.render_frame(STORE.dir(jid) / job['input'], STORE.dir(jid) / 'work', at, text,
                           {k: settings['blur'][k] for k in ('top', 'height', 'strength', 'dark')} if settings['subs'] and settings['blur']['on'] else None,
                           settings['look'], shot, size=tuple(state['size']) if state.get('size') else None)
        data = shot.read_bytes()
    except (RuntimeError, OSError, subprocess.SubprocessError) as e:
        raise HTTPException(502, f'ပုံ ထုတ်လို့မရပါ — {str(e)[-300:]}')
    finally:
        FRAME_LOCK.release()
        try:
            shot.unlink()
        except OSError:
            pass
    return Response(content=data, media_type='image/jpeg')


@app.get('/api/files/{jid}/{name}')
def get_file(jid: str, name: str, download: int = 0, user=Depends(current_user)):
    job = own_job(jid, user)
    if name not in DOWNLOADABLE:
        raise HTTPException(404, 'File not found')
    path = STORE.dir(jid) / 'out' / name
    if not path.is_file():
        raise HTTPException(404, 'File not found')
    if download:
        stem = pipeline.safe_stem(job.get('orig_name'))
        return FileResponse(path, media_type=DOWNLOADABLE[name], filename=f'{stem}_{name}')
    return FileResponse(path, media_type=DOWNLOADABLE[name])


# ------------------------------------------------------------------------------------------------ Google Drive (optional)
def drive_redirect_uri(request):
    return (os.getenv('DRIVE_REDIRECT_URI') or '').strip() or base_of(request) + '/api/drive/callback'


@app.get('/api/drive/status')
def drive_status(request: Request, user=Depends(current_user)):
    with drive_store.use_dir(user_dir(user)):
        st = drive_store.status()
    st['redirect_uri'] = drive_redirect_uri(request)
    return st


@app.get('/api/drive/connect')
def drive_connect(request: Request, user=Depends(current_user)):
    # Opens Google's consent page. Google sends the browser back to /api/drive/callback afterwards.
    try:
        with drive_store.use_dir(user_dir(user)):
            return RedirectResponse(drive_store.auth_url(drive_redirect_uri(request)))
    except drive_store.DriveError as e:
        return page('Google Drive', str(e))


@app.get('/api/drive/callback')
def drive_callback(code: str = '', state: str = '', error: str = '', user=Depends(current_user)):
    if error:
        return page('Google Drive မချိတ်ဖြစ်ပါ', f'Google က: {error}')
    try:
        with drive_store.use_dir(user_dir(user)):
            drive_store.finish_auth(state, code)
    except drive_store.DriveError as e:
        return page('Google Drive မချိတ်ဖြစ်ပါ', str(e))
    return RedirectResponse('/?drive=connected')


@app.post('/api/drive/disconnect')
def drive_disconnect(user=Depends(current_user)):
    with drive_store.use_dir(user_dir(user)):
        drive_store.disconnect()
        return drive_store.status(check=False)


@app.post('/api/drive/settings')
def drive_settings(share_anyone: str = Form(''), folder_name: str = Form(''), user=Depends(current_user)):
    # share_anyone: '1' = anyone with the link may view/download the uploaded files, '0' = only you (default).
    changes = {}
    if share_anyone.strip() != '':
        changes['share_anyone'] = flag(share_anyone)
    name = re.sub(r'[\x00-\x1f]+', ' ', folder_name).strip()[:100]
    if name:
        changes['folder_name'] = name
    with drive_store.use_dir(user_dir(user)):
        if changes:
            drive_store.save_settings(**changes)
        return drive_store.status(check=False)


@app.get('/api/drive/stream/{jid}')
def drive_stream(jid: str, request: Request, user=Depends(current_user)):
    # Plays the finished video straight from the person's Google Drive (with Range support so the player can seek).
    # The server only relays the bytes; nothing is stored on its disk.
    job = own_job(jid, user)
    fid = ((job.get('drive') or {}).get('video') or {}).get('id')
    if not fid:
        raise HTTPException(404, 'No Google Drive video for this job')
    try:
        with drive_store.use_dir(user_dir(user)):
            up = drive_store.open_stream(fid, request.headers.get('range'))
    except drive_store.DriveError as e:
        raise HTTPException(502, str(e))
    except requests.RequestException as e:
        raise HTTPException(502, f'Google Drive could not be reached: {e}')
    if up.status_code not in (200, 206, 416):
        code = up.status_code
        up.close()
        raise HTTPException(502, f'Google Drive answered HTTP {code}')
    headers = {'Accept-Ranges': 'bytes'}
    for k in ('Content-Length', 'Content-Range'):
        if up.headers.get(k):
            headers[k] = up.headers[k]
    return StreamingResponse(up.iter_content(1 << 20), status_code=up.status_code, media_type='video/mp4',
                             headers=headers, background=BackgroundTask(up.close))


# ------------------------------------------------------------------------------------------------ health + background work
@app.get('/api/health')
def health():
    try:
        import edge_tts
        edge = getattr(edge_tts, '__version__', 'installed')
    except ImportError:
        edge = 'missing'
    try:
        wh = asr.settings()                       # V22.3: what Whisper will really use (WHISPER_MODEL=auto is resolved to the model of this machine)
    except Exception:
        wh = {}
    return {'ok': True, 'version': VERSION, 'ffmpeg': bool(media.FFMPEG), 'edge_tts': edge,
            'whisper_model': wh.get('model') or os.getenv('WHISPER_MODEL') or 'auto', 'whisper_device': wh.get('device'),
            'whisper_words': wh.get('words'), 'whisper_threads': asr.cpu_threads(),
            'running_jobs': len(RUNNER.controls), 'waiting_for_cpu': HEAVY.waiting()}


def janitor():
    """Every few minutes: delete jobs nobody needs any more (finished downloads, abandoned half-done jobs) and stray upload
    files, so the server's disk does not fill up."""
    while True:
        time.sleep(600)
        try:
            if RETENTION_HOURS > 0:
                gone = STORE.cleanup(RUNNER.controls, finished_hours=RETENTION_HOURS, stale_hours=max(72.0, RETENTION_HOURS * 1.5))
                if gone:
                    print(f'[cleanup] removed {len(gone)} old job(s)', flush=True)
            now = time.time()
            for f in TMP.glob('*'):
                try:
                    if f.is_file() and now - f.stat().st_mtime > 6 * 3600:
                        f.unlink()
                except OSError:
                    pass
        except Exception as e:
            print(f'[cleanup] {e}', flush=True)


def warm_up():
    """Things that would otherwise delay the first person: the Edge voice list and the Whisper model (its first download)."""
    try:
        V.edge_live_names()
    except Exception as e:
        print(f'[startup] voice list: {e}', flush=True)
    try:
        model, name = asr.whisper_model()
        cfg = asr.settings()
        print(f'[startup] Whisper "{name}" ready ({cfg["device"]}, {cfg["compute"]}, beam {cfg["beam"]}, {asr.cpu_threads()} CPU threads)', flush=True)
    except Exception as e:
        print(f'[startup] Whisper not preloaded: {e}', flush=True)


def purge_removed_ai():
    """V22.2: Claude and Groq were removed. What V22.1 saved for them (their keys, models and the "chosen provider") is deleted at start-up;
    the Gemini key and model are not touched."""
    try:
        gone = USERS.purge_removed(auth.LOCAL_USER)
        if gone:
            print(f'[startup] removed the saved Claude / Groq settings: {", ".join(gone)}', flush=True)
    except Exception as e:                           # (never let this stop the server from starting)
        print(f'[startup] could not clean the old settings: {e}', flush=True)


def resume_after_restart():
    """V22.1: the jobs that were working when the server stopped (a crash, a reboot, a deploy) go on by themselves from the work that is
    saved on the disk - nobody has to come back and press "continue". Needs the video and the Gemini key; a job that keeps
    stopping the server is given up after J.AUTO_RESUME_TRIES tries."""
    for jid in STORE.auto_resumable():
        job = STORE.get(jid)
        try:
            if not job or not input_exists(job) or not USERS.get_key(auth.LOCAL_USER):
                STORE.update(jid, auto_resume=False, _force=True)
                continue
            STORE.update(jid, auto_resume=False, auto_tries=int(job.get('auto_tries') or 0) + 1, _force=True)
            start_job(jid)
            print(f'[startup] job {jid[:6]} was working when the server stopped: continuing it by itself', flush=True)
        except Exception as e:                       # (never let one job stop the server from starting)
            print(f'[startup] could not continue job {jid[:6]}: {e}', flush=True)


def start_background_threads():
    threading.Thread(target=janitor, name='janitor', daemon=True).start()
    if not flag(os.getenv('RECAP_NO_WARMUP')):
        threading.Thread(target=warm_up, name='warmup', daemon=True).start()
    host, port = os.getenv('HOST', '0.0.0.0'), os.getenv('PORT', '8000')
    print(f'[startup] Burmese Movie Recap AI {VERSION} — open http://<this-computer-or-server-address>:{port}', flush=True)
    if APP_PASSWORD:
        print('[startup] password protection is ON (APP_PASSWORD): the browser asks for it once', flush=True)
    elif host not in ('127.0.0.1', 'localhost', '::1'):
        print('[startup] ⚠ no password: everybody who can reach this port can use the website AND your saved API keys. '
              'Let only your own IP reach the port (AWS Security Group -> source "My IP") and/or set APP_PASSWORD in .env', flush=True)


if __name__ == '__main__':
    import uvicorn
    # timeout_keep_alive: uvicorn closes an idle connection after 5 s by default, exactly when the page asks for the job list again,
    # and a browser that starts an upload on such a half-closed connection sees "server cannot be reached". 75 s is what nginx uses.
    uvicorn.run(app, host=os.getenv('HOST', '0.0.0.0'), port=int(os.getenv('PORT', '8000')),
                timeout_keep_alive=int(_num('KEEP_ALIVE_SECONDS', 75)))
