"""Jobs (V21): bookkeeping that survives restarts, pause / resume / cancel, and a fair queue for the CPU.

* Every job lives in  data/jobs/<id>/  with a small job.json (status, settings, result) next to its files. When the server
  restarts, jobs that were running are marked "interrupted" and can be resumed: the pipeline keeps its finished work on disk
  (Whisper chunks, rewritten text, synthesised lines), so resuming never starts from the beginning.
* JobControl is the "hooks" object handed to the Gemini client: when Gemini's quota / credit is used up the client calls
  ask(); the job goes to status "paused" and waits - for hours if needed - until the person supplies a new key (answer()) or
  cancels (cancel()).
* FifoSlots limits how many heavy CPU stages (Whisper, rendering) run at once, first come first served.
"""
import json
import os
import shutil
import threading
import time
import uuid
from collections import deque
from contextlib import contextmanager
from pathlib import Path


class JobCancelled(Exception):
    """The person pressed Cancel (raised inside the worker thread to unwind quickly)."""


ACTIVE = ('queued', 'processing', 'paused')
FINISHED = ('completed', 'failed', 'cancelled')
RESUMABLE = ('interrupted', 'failed')
# "review": the Burmese text is written and the job WAITS for the person (no thread, survives a restart as it is). It still
# counts as an unfinished job (its files are on the disk) and can be cancelled.
REVIEW = 'review'
# V22.1: after a server restart (crash, out of memory, deploy, reboot) a job that was working goes on BY ITSELF, from the work that is
# saved on the disk. A job that keeps killing the server is given up after this many automatic restarts (then a person decides).
AUTO_RESUME_TRIES = 3
UNFINISHED = ACTIVE + (REVIEW,)
# What the list view needs (the transcript texts of finished jobs can be large).
LIST_KEYS = ('id', 'status', 'stage', 'progress', 'detail', 'orig_name', 'created', 'updated', 'error', 'params', 'pause', 'wait',
             'output_url', 'srt_url', 'vtt_url', 'stream_url', 'drive', 'drive_error', 'stats', 'input')


class JobStore:
    def __init__(self, root):
        self.root = Path(root)
        self.root.mkdir(parents=True, exist_ok=True)
        self._jobs = {}
        self._lock = threading.RLock()
        self._written = {}

    # ---- paths
    def dir(self, jid):
        if not jid or Path(jid).name != jid or not all(c.isalnum() for c in jid):
            raise ValueError('bad job id')
        return self.root / jid

    # ---- persistence
    def _persist(self, jid, force=False):
        job = self._jobs.get(jid)
        if job is None:
            return
        now = time.time()
        if not force and now - self._written.get(jid, 0) < 1.0:
            return
        self._written[jid] = now
        p = self.dir(jid) / 'job.json'
        try:
            p.parent.mkdir(parents=True, exist_ok=True)
            tmp = p.with_suffix('.tmp')
            tmp.write_text(json.dumps(job, ensure_ascii=False), encoding='utf-8')
            tmp.replace(p)
        except OSError:
            pass

    def load_existing(self):
        """At start-up: read every job.json; whatever was running is now "interrupted" (its thread is gone)."""
        with self._lock:
            for d in sorted(self.root.iterdir()) if self.root.exists() else []:
                try:
                    job = json.loads((d / 'job.json').read_text(encoding='utf-8'))
                    if not isinstance(job, dict) or job.get('id') != d.name:
                        continue
                except Exception:
                    continue
                if job.get('status') in ACTIVE:
                    # V22.1: a job that was WORKING (queued / processing) when the server stopped is continued by the server itself
                    # (see auto_resumable); a paused one waits for a person (new key / credit), so it is not.
                    if job.get('status') in ('queued', 'processing') and int(job.get('auto_tries') or 0) < AUTO_RESUME_TRIES:
                        job['auto_resume'] = True
                    job.update(status='interrupted', pause=None, wait=None,
                               detail='Server ပြန်စတင်ခဲ့လို့ ရပ်သွားပါတယ်။ "ဆက်လုပ်မယ်" ကို နှိပ်ရင် လုပ်ပြီးသားအပိုင်းတွေကို ပြန်မလုပ်ဘဲ ဆက်သွားပါမယ်။')
                self._jobs[d.name] = job
                self._persist(d.name, force=True)

    def auto_resumable(self):
        """Ids of the jobs that were working when the server stopped and have not used up their automatic restarts yet."""
        with self._lock:
            return [jid for jid, j in self._jobs.items() if j.get('auto_resume') and j.get('status') == 'interrupted'
                    and int(j.get('auto_tries') or 0) < AUTO_RESUME_TRIES]

    # ---- API
    def create(self, owner, params, orig_name, suffix):
        jid = uuid.uuid4().hex
        now = time.time()
        job = {'id': jid, 'owner': owner, 'status': 'queued', 'stage': 'Queued', 'progress': 1, 'detail': '', 'error': '',
               'params': params, 'orig_name': orig_name or '', 'input': f'input{suffix}', 'created': now, 'updated': now,
               'pause': None, 'wait': None}
        with self._lock:
            self.dir(jid).mkdir(parents=True, exist_ok=True)
            self._jobs[jid] = job
            self._persist(jid, force=True)
        return dict(job)

    def get(self, jid):
        with self._lock:
            job = self._jobs.get(jid)
            return json.loads(json.dumps(job)) if job else None

    def update(self, jid, **kw):
        with self._lock:
            job = self._jobs.get(jid)
            if job is None:
                return
            force = bool(kw.pop('_force', False))
            important = force or ('status' in kw and kw['status'] != job.get('status')) \
                or ('stage' in kw and kw['stage'] != job.get('stage'))
            job.update(kw)
            job['updated'] = time.time()
            self._persist(jid, force=important)

    def list_for(self, owner, limit=40):
        with self._lock:
            mine = [j for j in self._jobs.values() if j.get('owner') == owner]
            mine.sort(key=lambda j: j.get('created', 0), reverse=True)
            return [{k: j.get(k) for k in LIST_KEYS} for j in mine[:limit]]

    def count_active(self, owner):
        with self._lock:
            return sum(1 for j in self._jobs.values() if j.get('owner') == owner and j.get('status') in UNFINISHED)

    def owner_of(self, jid):
        with self._lock:
            j = self._jobs.get(jid)
            return j.get('owner') if j else None

    def remove(self, jid):
        with self._lock:
            self._jobs.pop(jid, None)
            self._written.pop(jid, None)
        shutil.rmtree(self.dir(jid), ignore_errors=True)

    def cleanup(self, controls, finished_hours=48.0, stale_hours=72.0):
        """Delete old jobs from disk. finished = completed / cancelled, stale = failed / interrupted that nobody resumed."""
        now = time.time()
        gone = []
        with self._lock:
            for jid, j in list(self._jobs.items()):
                if jid in controls:
                    continue
                age = (now - float(j.get('updated') or 0)) / 3600.0
                st = j.get('status')
                if (st in ('completed', 'cancelled') and age > finished_hours) or (st in ('failed', 'interrupted', 'queued', 'processing', 'paused', REVIEW) and age > stale_hours):
                    gone.append(jid)
        for jid in gone:
            self.remove(jid)
        return gone


class JobControl:
    """The hooks object of ONE running job (also what the Gemini client talks to)."""

    def __init__(self, store, jid):
        self.store = store
        self.jid = jid
        self.cancel_event = threading.Event()
        self.cv = threading.Condition()
        self._answer = None
        self.paused = False

    # ---- called from the worker thread(s)
    def check(self):
        if self.cancel_event.is_set():
            raise JobCancelled()

    def note(self, text):
        self.store.update(self.jid, detail=str(text)[:400])

    def sleep(self, seconds, why='', model=None, retry=None, **_info):
        """Wait `seconds` (the page counts them down). V22.2: `model` = the Gemini model that will be tried next and `retry` = which
        waiting round this is - the page shows both."""
        end = time.time() + max(0.0, float(seconds))
        self.store.update(self.jid, wait={'until': end, 'why': why, 'model': model, 'retry': retry})
        try:
            while True:
                left = end - time.time()
                if left <= 0 or self.cancel_event.wait(min(left, 0.5)):
                    break
        finally:
            self.store.update(self.jid, wait=None)
        self.check()

    def ask(self, kind, message, **info):
        """Pause the job and wait for the person. Returns the answer dict ({'key': ..., 'model': ...} or {} = "try again")."""
        pause = {'kind': kind, 'message': str(message)[:700], 'since': time.time(),
                 'model': info.get('model'), 'models': info.get('models')}
        with self.cv:
            self._answer = None
            self.paused = True
        self.store.update(self.jid, status='paused', pause=pause, wait=None, _force=True,
                          detail='ရပ်ထားပါတယ် — လုပ်ပြီးသားအပိုင်းတွေ သိမ်းထားပါတယ်၊ ဆက်လုပ်တဲ့အခါ အစကနေ ပြန်မစပါဘူး။')
        try:
            with self.cv:
                while self._answer is None and not self.cancel_event.is_set():
                    self.cv.wait(1.0)
                if self.cancel_event.is_set():
                    raise JobCancelled()
                answer = self._answer
                self._answer = None
        finally:
            with self.cv:
                self.paused = False
        self.store.update(self.jid, status='processing', pause=None, _force=True)
        return answer

    # ---- called from the web request threads
    def answer(self, data):
        with self.cv:
            if not self.paused:
                return False
            self._answer = dict(data or {})
            self.cv.notify_all()
            return True

    def cancel(self):
        self.cancel_event.set()
        with self.cv:
            self.cv.notify_all()

    @contextmanager
    def quiet(self):
        yield


class FifoSlots:
    """At most `n` holders at a time, granted strictly in arrival order (so nobody starves)."""

    def __init__(self, n):
        self.n = max(1, int(n))
        self.used = 0
        self.cv = threading.Condition()
        self.queue = deque()

    @contextmanager
    def hold(self, on_wait=None, check=None):
        ticket = object()
        with self.cv:
            self.queue.append(ticket)
            try:
                while not (self.queue[0] is ticket and self.used < self.n):
                    if on_wait:
                        try:
                            on_wait(self.queue.index(ticket))
                        except Exception:
                            pass
                    self.cv.wait(0.5)
                    if check:
                        check()
            except BaseException:
                try:
                    self.queue.remove(ticket)
                except ValueError:
                    pass
                self.cv.notify_all()
                raise
            self.queue.popleft()
            self.used += 1
            self.cv.notify_all()
        try:
            yield
        finally:
            with self.cv:
                self.used -= 1
                self.cv.notify_all()

    def waiting(self):
        with self.cv:
            return len(self.queue)


class Runner:
    """Starts / stops the worker threads of the jobs."""

    def __init__(self, store, max_jobs=None):
        self.store = store
        self.controls = {}
        self.lock = threading.Lock()
        self.slots = FifoSlots(max_jobs or int(os.getenv('MAX_CONCURRENT_JOBS') or 2))

    def running(self, jid):
        with self.lock:
            return jid in self.controls

    def start(self, jid, target):
        """target(ctl) does the work (and sets the final status itself)."""
        ctl = JobControl(self.store, jid)
        with self.lock:
            if jid in self.controls:
                raise RuntimeError('job already running')
            self.controls[jid] = ctl
        self.store.update(jid, status='queued', stage='Queued', error='', pause=None, wait=None, _force=True)
        threading.Thread(target=self._run, args=(jid, ctl, target), name=f'job-{jid[:6]}', daemon=True).start()
        return ctl

    def _run(self, jid, ctl, target):
        try:
            def waiting(pos):
                self.store.update(jid, detail=f'တခြား job တွေ ပြီးဖို့ စောင့်နေပါတယ် (အစီအစဉ် {pos + 1})')
            with self.slots.hold(on_wait=waiting, check=ctl.check):
                self.store.update(jid, status='processing', detail='')
                target(ctl)
        except JobCancelled:
            self.store.update(jid, status='cancelled', stage='Cancelled', detail='ပယ်ဖျက်လိုက်ပါတယ်။', _force=True)
        except BaseException as e:                    # the pipeline reports its own errors; this is the last safety net
            self.store.update(jid, status='failed', stage='Failed', error=str(e) or e.__class__.__name__, _force=True)
        finally:
            with self.lock:
                self.controls.pop(jid, None)

    def cancel(self, jid):
        with self.lock:
            ctl = self.controls.get(jid)
        if ctl:
            ctl.cancel()
            return True
        return False

    def answer(self, jid, data):
        with self.lock:
            ctl = self.controls.get(jid)
        return bool(ctl and ctl.answer(data))
