"""Burmese text with Gemini (V22.2): the line-by-line rewrite, the "shorten" step and the story-telling step.

* rewrite_batch()   - style "direct": one request for a batch of lines (REWRITE_BATCH in .env, 15 by default). In voice mode every
                      input item carries `max_syllables`, the time budget of that line, so the AI condenses instead of the audio
                      being sped up later. A batch whose answer is cut off, wrongly counted, too big or that TIMES OUT again and
                      again (even after the client hopped to another model) is split in half - every line is written exactly once.
* tell_story()      - style "story": the WHOLE transcript (all rows in time order) goes to the AI, which is asked to tell the story in
                      its own words. The answer is a list of pieces {"from", "to", "text"}: a piece covers consecutive transcript
                      rows. A film too long for one request is told in several parts (story_limits(): GEMINI_STORY_* in .env).
* story_segments()  - the pieces -> the "lines" the rest of the pipeline works with (voice, timing, review, subtitles).
* shorten_lines()   - ONE request for all lines that still turned out too long (both styles).
* story_notes()     - ONE request that reads the whole transcript first and returns short notes (story, tone, who is who, the Burmese
                      spelling of every name). Used only when the story has to be told in several parts, so that all parts agree.

All requests go through gemini_client.GeminiClient (one retry / fallback / hop engine for everything).
"""
import bisect
import json
import os
import re

import gemini_client as G
import presets as P
import timing as T

BATCH = 15                      # lines per request of the "direct" style (V22.2: 30 -> 15; REWRITE_BATCH in .env changes it)
SHORTEN_BATCH = 40
REWRITE_TIMEOUT = 300           # seconds a rewrite / shorten request may take to ANSWER (GEMINI_REWRITE_TIMEOUT in .env); the 15 s connect
                                # timeout of the client is not changed
STORY_NOTES_CAP = 150000        # most characters of transcript the story notes read (a longer film is thinned out evenly)
STORY_LINE_CHARS = 400          # one transcript row is cut at this length
STORY_CONTEXT = 4               # how many pieces of the story told so far a following request gets (continuity only)
STORY_ABSORB = 3                # a stretch of at most this many rows that no piece covers is joined to the piece before it
TOKENS_PER_SYLLABLE = 2.5       # (a cautious guess for Burmese) used to keep one request's answer inside the output limit
NOTES_MAX_CHARS = 3500          # all notes together
NOTE_MAX_CHARS = 700            # one note


def _env_number(name, default, low, high):
    try:
        raw = (os.getenv(name) or '').strip()
        value = float(raw) if raw else float(default)
    except ValueError:
        value = float(default)
    return max(low, min(high, value))


def batch_size():
    """Lines per request of the "direct" style. Read from the environment every time it is asked (REWRITE_BATCH, 1 - 100)."""
    return int(_env_number('REWRITE_BATCH', BATCH, 1, 100))


def rewrite_timeout():
    """Seconds one rewrite / shorten request may take to answer (GEMINI_REWRITE_TIMEOUT, 30 - 3600; the default 300 replaces the
    old fixed 120 s, which cut off long answers and then repeated the same request over and over)."""
    return _env_number('GEMINI_REWRITE_TIMEOUT', REWRITE_TIMEOUT, 30, 3600)


def story_limits():
    """How much one "write the whole story" request may carry (see pipeline.story_pass): characters of source transcript, tokens of
    answer, seconds to wait for it. GEMINI_STORY_CHARS / GEMINI_STORY_TOKENS / GEMINI_STORY_TIMEOUT in .env change them."""
    return {'chars': int(_env_number('GEMINI_STORY_CHARS', 150000, 1500, 10 ** 7)),
            'tokens': int(_env_number('GEMINI_STORY_TOKENS', 65000, 1024, 10 ** 6)),
            'timeout': int(_env_number('GEMINI_STORY_TIMEOUT', 900, 60, 7200))}


def _title(client):
    return getattr(client, 'TITLE', None) or 'AI'


def _text_of(x):
    if isinstance(x, dict):                       # the model sometimes echoes {"text": ...} objects
        x = x.get('text', x.get('burmese', ''))
    return re.sub(r'\s+', ' ', str(x if x is not None else '')).strip()


def clean(xs):
    return [_text_of(x) for x in xs]


# ------------------------------------------------------------------------------------------------ style "direct": line by line
def build_user_prompt(items, source_lang, extra='', context_lines=None):
    expected = len(items)
    prompt = f'Source language: {source_lang}\nREQUIRED OUTPUT COUNT: {expected}\n\n'
    if context_lines:
        # The last few lines already narrated, so the story keeps flowing across batch borders.
        prompt += ('PREVIOUS NARRATION (already told; context for continuity only. '
                   'Do NOT repeat it and do NOT include it in your output):\n'
                   + json.dumps(context_lines, ensure_ascii=False) + '\n\n')
    prompt += 'INPUT JSON ARRAY:\n' + json.dumps(items, ensure_ascii=False)
    if extra:
        prompt += '\n\n' + extra
    return prompt


def _ask(client, system, items, source_lang, extra='', context=None, label='rewrite'):
    # Burmese script uses MANY tokens (and some models also count their hidden "thinking" in the same limit), so leave plenty of
    # headroom. A cut-off answer is detected (GeminiTruncated) and the batch is split. split=True: a batch of several lines that keeps
    # timing out - on one model and on the next - raises GeminiTimeout instead of waiting on, and is split as well.
    content = client.chat(system, build_user_prompt(items, source_lang, extra, context), max_tokens=8192, timeout=rewrite_timeout(),
                          label=label, lines=len(items), split=len(items) > 1)
    return G.extract_json_array(content)


def rewrite_batch(client, system, items, source_lang, context=None, note=None, sink=None):
    """Rewrite one batch -> list of Burmese strings, exactly one per item.

    If the model returns the wrong number of lines, one stricter retry follows. If it is still wrong (or its answer was cut
    off / blocked / too big, or the request timed out again and again), the batch is split in half so one bad reply cannot fail or
    stall the whole job. One single line that the AI refuses is skipped (left empty).

    `sink(texts)` (optional) is called with every piece of the answer THE MOMENT it is complete - the left half before the right
    half is even asked - so the caller can save it: a job that is stopped later never writes those lines again. Over the whole
    batch the sink receives every line exactly once, in order."""
    expected = len(items)
    result = None
    name = _title(client)
    try:
        result = _ask(client, system, items, source_lang, context=context)
        if not isinstance(result, list) or len(result) != expected:
            got = len(result) if isinstance(result, list) else 'an invalid JSON response'
            retry = (f'Your previous response was invalid. It contained {got} outputs, but exactly {expected} outputs are required.\n'
                     f'Return EXACTLY {expected} strings now.\n'
                     'One input line = one output string. Do not merge, split, add, remove, number, explain, or format anything '
                     'outside the JSON array.')
            result = _ask(client, system, items, source_lang, retry, context)
    except G.GeminiTruncated:
        if expected == 1:
            raise G.GeminiError(f'{name} answer was cut off even for a single line. Raise GEMINI_MAX_OUTPUT_TOKENS in .env '
                                '(or use another model).')
        result = None
    except G.GeminiTimeout:
        result = None                                  # (only raised for a batch of several lines)
        if note:
            note(f'{name} ဆီက အဖြေ အချိန်ကြာလွန်းလို့ batch ({expected} lines) ကို နှစ်ပိုင်းခွဲပါမယ်')
    except G.GeminiTooLarge:
        if expected == 1:
            raise
        result = None
    except G.GeminiBlocked as e:
        if expected == 1:
            print(f'[{name.lower()}] one line skipped: {e}', flush=True)
            if note:
                note(f'{name} က စာကြောင်းတစ်ကြောင်းကို မဖြေပေးလို့ ကျော်လိုက်ပါတယ်။')
            return _delivered([''], sink)
        result = None
    if isinstance(result, list) and len(result) == expected:
        return _delivered(clean(result), sink)
    if expected > 1:
        if note:
            note(f'Batch ကို နှစ်ပိုင်းခွဲပြီး ပြန်စမ်းနေပါတယ် ({expected} lines)')
        mid = expected // 2
        keep = max(3, len(context or []))
        left = rewrite_batch(client, system, items[:mid], source_lang, context, note, sink)
        right = rewrite_batch(client, system, items[mid:], source_lang, [c for c in ((context or []) + left)[-keep:] if c], note, sink)
        return left + right
    if isinstance(result, list) and result:
        # One input line answered with several strings: keep them together as that one line.
        return _delivered(clean([' '.join(_text_of(x) for x in result)]), sink)
    actual = len(result) if isinstance(result, list) else 'invalid JSON'
    raise G.GeminiError(f'{name} returned an invalid response for a single line: expected 1, received {actual}.')


def _delivered(texts, sink):
    if sink is not None:
        sink(list(texts))
    return texts


def timed_item(text, max_syllables):
    return {'text': str(text).strip(), 'max_syllables': int(max_syllables)}


# ------------------------------------------------------------------------------------------------ shorten (both styles)
def shorten_lines(client, items, note=None):
    """items = [{'i', 'text', 'syllables', 'max_syllables'}] -> list (same order) with the shortened text, or None where
    nothing usable came back (empty, or not shorter than before). One request for the whole list."""
    expected = len(items)
    if not expected:
        return []
    arr = None
    try:
        content = client.chat(P.SHORTEN_SYSTEM, 'INPUT JSON ARRAY:\n' + json.dumps(items, ensure_ascii=False),
                              max_tokens=8192, timeout=rewrite_timeout(), label='shorten', lines=expected, split=expected > 1)
        arr = G.extract_json_array(content)
    except (G.GeminiTruncated, G.GeminiBlocked, G.GeminiTooLarge, G.GeminiTimeout):
        arr = None
    if isinstance(arr, list) and len(arr) == expected:
        out = []
        for it, new in zip(items, clean(arr)):
            out.append(new if new and T.syllables(new) < T.syllables(it['text']) else None)
        return out
    if expected > 1:
        mid = expected // 2
        return shorten_lines(client, items[:mid], note) + shorten_lines(client, items[mid:], note)
    return [None]


# ------------------------------------------------------------------------------------------------ style "story": the rows
def fmt_clock(seconds):
    try:
        t = int(max(0.0, float(seconds)))
    except (TypeError, ValueError):
        t = 0
    h, rest = divmod(t, 3600)
    return f'{h}:{rest // 60:02d}:{rest % 60:02d}' if h else f'{rest // 60}:{rest % 60:02d}'


def story_rows(segs):
    """The transcript as rows in TIME ORDER: [{'i': number of the line in `segs`, 'a': start, 'b': end, 'text'}]. Lines without any
    text are left out. The number `i` is what the AI uses to say which rows a piece of the story covers."""
    rows = []
    for i, seg in enumerate(segs):
        text = re.sub(r'\s+', ' ', str(seg.get('text') or '')).strip()
        if not text:
            continue
        try:
            a = max(0.0, float(seg.get('start') or 0.0))
            b = max(a, float(seg.get('end') or a))
        except (TypeError, ValueError):
            a = b = 0.0
        rows.append({'i': i, 'a': a, 'b': b, 'text': text.replace('|', '/')[:STORY_LINE_CHARS]})
    rows.sort(key=lambda r: (r['a'], r['i']))                     # (Whisper's lines already are in order; this is the guarantee)
    return rows


def row_line(r):
    return f"{r['i']}|{r['a']:.1f}-{r['b']:.1f}|{r['text']}"


def window_seconds(limits, pace):
    """About how many seconds of film one request can tell without its answer hitting the output-token limit (a cautious guess:
    if the answer is cut off anyway, the part that arrived is kept and the rest is asked for again)."""
    sps = max(3.0, float(pace or 5.0))
    return max(60.0, 0.8 * float(limits['tokens']) / (sps * TOKENS_PER_SYLLABLE))


def _cut_point(rows):
    """Where to cut a window that is full: preferably at the longest pause among its last rows (a scene border)."""
    n = len(rows)
    lo = max(1, n - max(1, n // 7))
    best, best_gap = n, 1.0
    for k in range(lo, n):
        gap = rows[k]['a'] - rows[k - 1]['b']
        if gap >= best_gap:
            best, best_gap = k, gap
    return best


def story_windows(rows, max_chars, max_seconds):
    """Cuts the rows into parts: each part has at most `max_chars` characters of transcript and `max_seconds` seconds of film.
    A film that fits is ONE part (= one request)."""
    windows, cur, chars = [], [], 0
    for r in rows:
        n = len(row_line(r)) + 1
        if cur and (chars + n > max_chars or r['b'] - cur[0]['a'] > max_seconds):
            k = _cut_point(cur)
            windows.append(cur[:k])
            cur = cur[k:]
            chars = sum(len(row_line(x)) + 1 for x in cur)
        cur.append(r)
        chars += n
    if cur:
        windows.append(cur)
    return windows


def story_user_prompt(rows, lang, total, first=True, last=True, context=None, extra=''):
    a, b = rows[0]['i'], rows[-1]['i']
    p = f'Source language: {lang}\nLength of the whole film: {fmt_clock(total)}\n'
    if first and last:
        p += 'The transcript below is the WHOLE film: tell the whole story from its beginning to its end.\n'
    elif first:
        p += f'The transcript below is the BEGINNING of a longer film (rows {a}-{b}). Tell only this part; the story goes on afterwards.\n'
    elif last:
        p += f'The transcript below is the END of a longer film (rows {a}-{b}). The earlier part was already told; carry on and bring the story to its end.\n'
    else:
        p += f'The transcript below is a MIDDLE part of a longer film (rows {a}-{b}). The earlier part was already told and the story goes on afterwards. Tell only this part.\n'
    if context:
        p += ('\nSTORY SO FAR (the last pieces you already told; context only, so that your story continues smoothly and the names '
              'stay the same. Do NOT repeat them and do NOT include them in your output):\n'
              + json.dumps(list(context), ensure_ascii=False) + '\n')
    p += f'\nTRANSCRIPT (number|start-end in seconds|text), {len(rows)} rows, numbers {a} to {b}:\n'
    p += '\n'.join(row_line(r) for r in rows)
    p += (f'\n\nNow tell the story of these rows. Return ONLY the JSON array of {{"from", "to", "text"}} elements that covers every '
          f'row from {a} to {b}.')
    if extra:
        p += '\n\n' + extra
    return p


# ------------------------------------------------------------------------------------------------ style "story": the answer
def parse_story_items(text):
    """What the AI answered -> (list of the {...} pieces that could be read, complete).

    complete is False when the answer was broken or cut off in the middle: the pieces that are whole are still returned, so
    nothing that arrived is lost. An answer that wraps the array in an object ({"story": [...]}) is understood too."""
    s = str(text or '').strip()
    s = re.sub(r'^```(?:json)?\s*', '', s, flags=re.I)
    s = re.sub(r'\s*```\s*$', '', s).strip()
    try:
        data = json.loads(s)
    except ValueError:
        data = None
    if isinstance(data, dict):
        data = next((v for v in data.values() if isinstance(v, list)), None)
    if isinstance(data, list):
        return [x for x in data if isinstance(x, dict)], True
    start = s.find('[')
    if start < 0:
        return [], False
    dec, pos, items = json.JSONDecoder(), start + 1, []
    while pos < len(s):
        while pos < len(s) and s[pos] in ' \t\r\n,':
            pos += 1
        if pos >= len(s) or s[pos] != '{':
            break
        try:
            obj, pos = dec.raw_decode(s, pos)
        except ValueError:
            break
        if isinstance(obj, dict):
            items.append(obj)
    return items, False


def _num(x):
    try:
        return int(float(str(x).strip()))
    except (TypeError, ValueError, OverflowError):
        return None


def normalize_story_items(raw, rows):
    """The pieces the AI wrote -> (items, covered).

    items   = [{'from': row number, 'to': row number, 'text': str}] in time order, nothing overlapping, each piece directly after
              the one before (a small stretch of rows no piece covered is joined to the piece before it).
    covered = how many of `rows` (from the first one on) the items cover. Everything after that is NOT told yet: the answer may have
              been cut off, the AI may have stopped early or skipped a large stretch - the caller asks for the rest again.
    Row numbers outside the given rows are clamped, a piece that goes back in time is trimmed, a piece with no usable numbers is
    dropped."""
    nums = [r['i'] for r in rows]
    spans = []
    for it in raw:
        if not isinstance(it, dict):
            continue
        a = _num(it.get('from', it.get('start', it.get('first'))))
        b = _num(it.get('to', it.get('end', it.get('last'))))
        if a is None and b is None:
            continue
        a = b if a is None else a
        b = a if b is None else b
        if b < a:
            a, b = b, a
        k1, k2 = bisect.bisect_left(nums, a), bisect.bisect_right(nums, b) - 1
        if k1 >= len(nums) or k2 < 0:
            continue
        spans.append([k1, max(k1, k2), _text_of(it.get('text', it.get('burmese', '')))])
    spans.sort(key=lambda s: (s[0], s[1]))
    out, pos = [], 0
    for k1, k2, text in spans:
        k1 = max(k1, pos)
        if k2 < k1:
            continue                                   # lies inside what an earlier piece already covers
        gap = k1 - pos
        if gap > STORY_ABSORB:
            break
        if gap and out:
            out[-1]['to'] = nums[k1 - 1]
        elif gap:
            k1 = pos                                   # nothing before it: the first piece starts at the first row
        out.append({'from': nums[k1], 'to': nums[k2], 'text': text})
        pos = k2 + 1
    return out, pos


def burmese_text(items):
    return ' '.join(it['text'] for it in items if it.get('text'))


def story_attempt(client, system, rows, lang, total, first, last, context, limits, strict=False):
    """ONE request: tell the story of `rows`. -> (items, covered). Raises the client's errors (GeminiNeedKey, GeminiTooLarge,
    GeminiTruncated / GeminiBlocked for an answer without anything usable ...)."""
    extra = ''
    if strict:
        extra = (f'Your previous answer could not be used. Return ONLY a JSON array of objects {{"from": <row number>, "to": <row number>, '
                 f'"text": "<Burmese>"}}. Use the row numbers EXACTLY as they are written at the start of the rows ({rows[0]["i"]} to '
                 f'{rows[-1]["i"]}), start with row {rows[0]["i"]}, cover every row in order and write the text in Burmese.')
    user = story_user_prompt(rows, lang, total, first, last, context, extra)
    answer = client.chat(system, user, max_tokens=limits['tokens'], timeout=limits['timeout'], label='story', partial=True)
    raw, _complete = parse_story_items(answer)
    items, covered = normalize_story_items(raw, rows)
    if covered and not burmese_text(items) and sum(len(r['text']) for r in rows[:covered]) > 40:
        return [], 0                                   # pieces without any words: not an answer
    return items, covered


def tell_rows(client, system, rows, lang, total, context=None, first=True, last=True, limits=None, note=None, check=None):
    """Tells the story of ALL the given rows -> items that cover every one of them. A request that fails (answer cut off, not
    usable, too big, refused) is repeated once, strictly; after that the rows are split in two and each half is told on its own. An
    answer that covers only the first rows of the request (cut off, or stopped early) keeps what arrived and asks again for the
    rest. A single row that cannot be told at all is skipped (empty text), so nothing can stall the film."""
    out, ctx, remaining, fails = [], list(context or []), list(rows), 0
    name = _title(client)
    while remaining:
        if check:
            check()
        items, covered, split = [], 0, False
        try:
            items, covered = story_attempt(client, system, remaining, lang, total, first and not out, last, ctx, limits, strict=fails > 0)
        except G.GeminiNeedKey:
            raise
        except (G.GeminiTooLarge, G.GeminiTruncated, G.GeminiBlocked) as e:
            print(f'[{name.lower()}] story request failed ({e.__class__.__name__}): {e}', flush=True)
            split = True
        if covered:
            out.extend(items)
            ctx = [x for x in (ctx + [it['text'] for it in items]) if x][-STORY_CONTEXT:]
            remaining = remaining[covered:]
            fails = 0
            continue
        if not split:
            fails += 1
            if fails < 2:
                if note:
                    note(f'{name} ရဲ့ အဖြေကို သုံးလို့မရလို့ တစ်ခါပြန်မေးနေပါတယ် ({len(remaining)} rows)')
                continue
        if len(remaining) == 1:
            r = remaining[0]
            print(f'[{name.lower()}] story: row {r["i"]} skipped (no usable answer)', flush=True)
            if note:
                note(f'{name} က စာကြောင်းတစ်ကြောင်းကို မဖြေပေးလို့ ကျော်လိုက်ပါတယ်။')
            out.append({'from': r['i'], 'to': r['i'], 'text': ''})
            remaining, fails = [], 0
            continue
        if note:
            note(f'ဇာတ်လမ်းအပိုင်းကို နှစ်ပိုင်းခွဲပြီး ပြန်စမ်းနေပါတယ် ({len(remaining)} rows)')
        half = max(1, len(remaining) // 2)
        head = tell_rows(client, system, remaining[:half], lang, total, ctx, first and not out, False, limits, note, check)
        out.extend(head)
        ctx = [x for x in (ctx + [it['text'] for it in head]) if x][-STORY_CONTEXT:]
        remaining, fails = remaining[half:], 0
    return out


def tell_story(client, system, rows, lang, total, limits, pace, done=None, note=None, check=None, progress=None):
    """The whole story. rows = every row of the film (story_rows), `done` = the pieces already written by an earlier run of this job
    (they are kept; the story goes on after their last row). progress(parts_done, parts_total, items) is called after every part (the
    pipeline saves them, so a job that is stopped or paused continues from the last finished part).
    -> items covering every row, in time order."""
    items = [dict(x) for x in (done or [])]
    last_done = items[-1]['to'] if items else -1
    rest = [r for r in rows if r['i'] > last_done]
    windows = story_windows(rest, limits['chars'], window_seconds(limits, pace))
    for k, w in enumerate(windows):
        if check:
            check()
        ctx = [it['text'] for it in items if it.get('text')][-STORY_CONTEXT:]
        first = not items and w[0] is rows[0]
        last = w[-1] is rows[-1]
        items.extend(tell_rows(client, system, w, lang, total, ctx, first, last, limits, note, check))
        if progress:
            progress(k + 1, len(windows), items)
    return items


def story_segments(segs, items):
    """The pieces of the story -> (new_segs, lines, src): one line per piece. A piece starts when its first row starts and ends when its
    last row ends; `src` is the original text of its rows (the review page shows it next to the story), `lines` the Burmese story.
    These lists take the place of the Whisper lines for everything that follows (voice, timing, subtitles, review)."""
    new, lines, src = [], [], []
    for it in items:
        group = [segs[k] for k in range(max(0, it['from']), min(len(segs) - 1, it['to']) + 1)]
        if not group:
            continue
        text = ' '.join(t for t in (re.sub(r'\s+', ' ', str(g.get('text') or '')).strip() for g in group) if t)
        seg = {'start': float(group[0]['start']), 'end': max(float(g['end']) for g in group), 'text': text}
        if 'speech_start' in group[0]:
            seg['speech_start'] = float(group[0]['speech_start'])
            seg['speech_end'] = max(float(g.get('speech_end', g['end'])) for g in group)
        new.append(seg)
        lines.append(_text_of(it.get('text')))
        src.append(text)
    return new, lines, src


# ------------------------------------------------------------------------------------------------ story notes (several parts)
def story_transcript(segs, cap=STORY_NOTES_CAP):
    """The whole transcript as rows "number|m:ss|text" for the story notes. A film so long that it does not fit into `cap`
    characters is thinned out evenly (every 2nd, 3rd ... line), so the notes still cover the film from start to end."""
    rows = []
    for i, seg in enumerate(segs):
        text = re.sub(r'\s+', ' ', str(seg.get('text') or '')).strip()
        if not text:
            continue
        try:
            t = int(max(0.0, float(seg.get('start') or 0.0)))
        except (TypeError, ValueError):
            t = 0
        rows.append(f'{i}|{t // 60}:{t % 60:02d}|{text[:STORY_LINE_CHARS]}')
    total = sum(len(r) + 1 for r in rows)
    if total > cap and rows:
        stride = -(-total // cap)                                       # ceil
        rows = [r for k, r in enumerate(rows) if k % stride == 0 or k == len(rows) - 1]
    return '\n'.join(rows)


def clean_notes(arr):
    """What the model answered -> a short list of note strings (an object or nested lists are flattened, empty and over-long
    notes are dropped / cut, everything together stays under NOTES_MAX_CHARS)."""
    if isinstance(arr, dict):
        arr = [f'{k}: {v}' for k, v in arr.items()]
    out, used = [], 0
    for x in arr if isinstance(arr, list) else []:
        if isinstance(x, dict):
            x = ' | '.join(str(v) for v in x.values())
        elif isinstance(x, list):
            x = ' | '.join(str(v) for v in x)
        s = re.sub(r'\s+', ' ', str(x if x is not None else '')).strip()[:NOTE_MAX_CHARS]
        if not s:
            continue
        if used + len(s) > NOTES_MAX_CHARS:
            break
        out.append(s)
        used += len(s)
    return out


def story_notes(client, segs, source_lang, cap=STORY_NOTES_CAP, note=None, timeout=180):
    """ONE request that reads the whole transcript -> list of short note strings ([] when nothing usable came back). A key / quota
    problem is raised as usual (the job waits for a key); anything else (answer blocked or cut off, a model that cannot do it) only
    means the story is written without notes - never a failed job."""
    text = story_transcript(segs, cap)
    if not text:
        return []
    user = f'Source language: {source_lang}\nTRANSCRIPT (number|time|text), {len(segs)} lines:\n{text}'
    try:
        content = client.chat(P.STORY_NOTES_SYSTEM, user, max_tokens=4096, timeout=timeout, label='story-notes')
        arr = G.extract_json_array(content)
    except G.GeminiNeedKey:
        raise
    except G.GeminiError as e:
        print(f'[{_title(client).lower()}] story notes skipped: {e}', flush=True)
        if note:
            note('ဇာတ်လမ်းမှတ်စု မရလို့ မှတ်စုမပါဘဲ ဆက်ရေးပါမယ်။')
        return []
    return clean_notes(arr)


def format_story_notes(notes):
    """The notes as one block for the system prompt ('' when there are none)."""
    notes = [str(n).strip() for n in (notes or []) if str(n).strip()]
    if not notes:
        return ''
    return P.STORY_NOTES_HEADER + '\n' + '\n'.join('- ' + n for n in notes)
