"""Timing helpers (V21).

The old versions fitted every Burmese line into its time slot by SPEEDING UP the audio line by line (so some lines were
fast, some slow) and by silencing whatever stuck out of the slot (so some lines were cut off). V21 does it the other way:

1. The narrator always speaks at ONE steady pace (the speed the person picked).
2. Every line gets a time budget; Gemini is asked to say less where the time is short (condense, never rush).
3. Real audio lengths are measured; a line that is still too long is shortened again (see app.py).
4. The clips are placed on the video timeline. A clip may start a little late when the one before it ran over, but it is
   never cut off, and it is only sped up slightly (at most +18 %) in the rare case that it would otherwise fall far behind.
5. Everything is mixed in memory with numpy: no giant ffmpeg command with one input per line.
"""
import math
import os
import re
import subprocess
import wave

import numpy as np

SR = 24000                      # sample rate of the narration clips and of the mixed narration track
COMMA_PAUSE = 0.18              # seconds a "၊" (or ",") adds to the speaking time
STOP_PAUSE = 0.30               # seconds a "။" (or ". ! ?") adds
GAP = 0.12                      # breathing space kept between two clips
MAX_END_LAG = 0.8               # a clip may end this long after the next line has started before it is sped up
MAX_SPEEDUP = 1.18              # the most any clip is ever sped up (rare last resort)


# ------------------------------------------------------------------------------------------------ syllables
_CONSONANTS = frozenset([chr(c) for c in range(0x1000, 0x1022)] + list('ဣဤဥဦဧဩဪဿ'))
_VIRAMA = '္'
_ASAT = '်'


def syllables(text):
    """Rough number of spoken syllables of a Burmese text.

    Every Burmese consonant / independent vowel that is not a *final* consonant (the one followed by asat ် or by the
    stacking sign ္) starts a syllable.  မင်္ဂလာပါ = 4, ကျွန်တော် = 2, ပြောပြမယ် = 3, ဗုဒ္ဓ = 2.
    Digits and Latin words (rare, Gemini is asked to spell them in Burmese) are counted roughly.
    """
    s = str(text or '')
    n = 0
    for i, ch in enumerate(s):
        if ch in _CONSONANTS:
            nxt = s[i + 1] if i + 1 < len(s) else ''
            if nxt != _ASAT and nxt != _VIRAMA:
                n += 1
    for word in re.findall(r'[A-Za-z]+', s):
        n += max(1, math.ceil(len(word) / 3))
    n += int(round(1.5 * len(re.findall(r'[0-9၀-၉]', s))))
    return n


def pause_seconds(text):
    s = str(text or '')
    commas = len(re.findall(r'[၊,;:]', s))
    stops = len(re.findall(r'[။.!?]', s))
    return commas * COMMA_PAUSE + stops * STOP_PAUSE


def has_speech(text):
    return bool(re.search(r'[က-ဪဿ၀-၉A-Za-z0-9]', str(text or '')))


class Calibration:
    """Learns how many syllables per second the chosen voice really speaks (at the chosen speed) from the clips that were
    actually synthesised, so estimates and budgets get more accurate as the job goes on."""

    def __init__(self, prior_sps=5.0, prior_weight=4.0):
        self.prior = float(prior_sps)
        self.weight = float(prior_weight)
        self._syl = 0.0
        self._sec = 0.0
        self.n = 0
        self.sps = float(prior_sps)

    def update(self, text, seconds):
        syl = syllables(text)
        eff = float(seconds) - pause_seconds(text)
        if syl < 5 or eff < 0.5:
            return
        self._syl += syl
        self._sec += eff
        self.n += 1
        self.sps = (self._syl + self.weight * self.prior) / (self._sec + self.weight)

    def seconds(self, text):
        """Estimated speaking time of a text."""
        return syllables(text) / self.sps + pause_seconds(text)

    def max_syllables(self, budget_seconds, safety=0.93):
        """How many syllables fit into `budget_seconds` (with a safety margin for pauses and estimation error)."""
        return max(2, int((float(budget_seconds) - 0.15) * self.sps * safety))


# ------------------------------------------------------------------------------------------------ time slots
def slot_budgets(anchors, ends, video_total, gap=GAP):
    """How many seconds each line may speak.

    anchors[i] = when the original line starts, ends[i] = when it stops. The Burmese narration starts at the anchor and may
    use the whole room up to the next line (minus a small gap): the pause after the original speech is free time, but it
    is capped so the narrator does not ramble through a long silence (at most 1.8x the original or +3 s).
    """
    n = len(anchors)
    out = []
    for i in range(n):
        orig = max(0.3, float(ends[i]) - float(anchors[i]))
        nxt = float(anchors[i + 1]) if i + 1 < n else float(video_total)
        room = max(0.0, nxt - float(anchors[i]) - gap)
        cap = max(orig * 1.8, orig + 3.0)
        budget = max(0.6, min(room, cap))
        budget = min(budget, max(0.6, float(video_total) - float(anchors[i]) - 0.05))
        out.append(budget)
    return out


def slot_rooms(anchors, video_total, gap=GAP):
    """The whole room each line has before the next line starts (no cap): a clip longer than this runs into the next one."""
    n = len(anchors)
    out = []
    for i in range(n):
        if i + 1 < n:
            room = float(anchors[i + 1]) - float(anchors[i]) - gap
        else:
            room = float(video_total) - float(anchors[i]) - 0.05
        out.append(max(0.5, room))
    return out


def schedule(durations, anchors, video_total=None, gap=GAP, max_end_lag=MAX_END_LAG, max_speedup=MAX_SPEEDUP):
    """Place the clips on the timeline.

    durations[i] = length of clip i in seconds (0 / None = no clip).  Returns a list (same length) of None or
    (start, end, speed).  A clip starts at its anchor, or right after the previous clip if that one ran over. It is never
    cut off. Only when it would end more than `max_end_lag` after the next line starts (the lag would keep growing) is it
    sped up, by at most `max_speedup`.
    """
    n = len(durations)
    out = [None] * n
    prev_end = -1e9
    for i in range(n):
        d = float(durations[i] or 0.0)
        if d <= 0:
            continue
        start = max(float(anchors[i]), prev_end + gap)
        nxt = next((float(anchors[j]) for j in range(i + 1, n) if durations[j]), None)
        if nxt is None and video_total is not None:
            nxt = float(video_total)
        speed = 1.0
        if nxt is not None:
            limit = nxt + max_end_lag
            if start + d > limit:
                room = max(0.3, limit - start)
                speed = min(max_speedup, d / room)
        end = start + d / speed
        out[i] = (start, end, speed)
        prev_end = end
    return out


# ------------------------------------------------------------------------------------------------ audio helpers
def pcm16_to_float(raw):
    return np.frombuffer(raw, dtype='<i2').astype(np.float32) / 32768.0


def float_to_pcm16(x):
    return (np.clip(x, -1.0, 1.0) * 32767.0).astype('<i2').tobytes()


def resample(x, sr_from, sr_to=SR):
    if int(sr_from) == int(sr_to) or len(x) == 0:
        return x
    n = int(round(len(x) * float(sr_to) / float(sr_from)))
    return np.interp(np.linspace(0, len(x) - 1, n), np.arange(len(x)), x).astype(np.float32)


def decode_audio(ffmpeg, path, sr=SR):
    """Any audio file (mp3 / wav ...) -> mono float32 samples at `sr` (ffmpeg writes raw PCM to a pipe)."""
    p = subprocess.run([ffmpeg, '-v', 'error', '-i', str(path), '-f', 's16le', '-ac', '1', '-ar', str(sr), '-'],
                       stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    if p.returncode or not p.stdout:
        raise RuntimeError('Could not decode audio: ' + p.stderr.decode('utf-8', 'replace')[-300:])
    return pcm16_to_float(p.stdout)


def read_wav(path):
    with wave.open(str(path), 'rb') as w:
        rate, ch, width = w.getframerate(), w.getnchannels(), w.getsampwidth()
        raw = w.readframes(w.getnframes())
    if width != 2:
        raise RuntimeError(f'{path}: only 16-bit WAV is supported')
    x = pcm16_to_float(raw)
    if ch > 1:
        x = x[:len(x) - len(x) % ch].reshape(-1, ch).mean(axis=1)
    return x, rate


def write_wav(path, x, sr=SR):
    with wave.open(str(path), 'wb') as w:
        w.setnchannels(1)
        w.setsampwidth(2)
        w.setframerate(int(sr))
        w.writeframes(float_to_pcm16(x))


def wav_seconds(path):
    """Length of a WAV file from its header (the samples are not read)."""
    with wave.open(str(path), 'rb') as w:
        return w.getnframes() / float(w.getframerate())


def trim_silence(x, sr=SR, lead=0.03, tail=0.06):
    """Cut the silence TTS engines put before and after the speech (so the real length is measured and clips butt up
    against each other naturally). Keeps a few milliseconds around the speech so nothing is clipped."""
    if len(x) == 0:
        return x
    env = np.abs(x)
    win = max(1, int(sr * 0.01))
    if len(env) > win:
        env = np.convolve(env, np.ones(win, dtype=np.float32) / win, mode='same')
    thr = max(0.002, 0.02 * float(env.max()))
    idx = np.flatnonzero(env > thr)
    if len(idx) == 0:
        return x[:0]
    a = max(0, int(idx[0]) - int(lead * sr))
    b = min(len(x), int(idx[-1]) + int(tail * sr))
    return x[a:b].copy()


def fade(x, sr=SR, fin=0.008, fout=0.030):
    """Short fades so a clip never clicks; they only touch the first / last few milliseconds."""
    n = len(x)
    if n == 0:
        return x
    x = x.copy()
    a, b = min(n // 2, int(fin * sr)), min(n // 2, int(fout * sr))
    if a > 1:
        x[:a] *= np.linspace(0.0, 1.0, a, dtype=np.float32)
    if b > 1:
        x[n - b:] *= np.linspace(1.0, 0.0, b, dtype=np.float32)
    return x


def normalize_rms(x, target=0.1, lo=0.5, hi=3.0):
    """Bring a clip to a common loudness (RMS of its speech part) so every line sounds equally loud."""
    if len(x) == 0:
        return x
    active = x[np.abs(x) > 0.01 * max(1e-6, float(np.abs(x).max()))]
    rms = float(np.sqrt(np.mean(np.square(active)))) if len(active) else 0.0
    if rms < 1e-5:
        return x
    gain = min(hi, max(lo, target / rms))
    y = x * gain
    peak = float(np.abs(y).max())
    if peak > 0.95:
        y = y * (0.95 / peak)
    return y.astype(np.float32)


def _atempo_chain(f):
    vals, x = [], float(f)
    while x > 2.0:
        vals.append(2.0)
        x /= 2.0
    while x < 0.5:
        vals.append(0.5)
        x /= 0.5
    vals.append(x)
    return ','.join(f'atempo={v:.6f}' for v in vals)


def time_stretch(ffmpeg, x, sr, factor):
    """Pitch-preserving speed change through ffmpeg's atempo (factor > 1 = faster). Used only for the rare last-resort
    speed-up and to even out the pace of engines that cannot hold a fixed speed."""
    if abs(factor - 1.0) < 0.005 or len(x) == 0:
        return x
    p = subprocess.run([ffmpeg, '-v', 'error', '-f', 's16le', '-ar', str(sr), '-ac', '1', '-i', 'pipe:0',
                        '-filter:a', _atempo_chain(factor), '-f', 's16le', '-ar', str(sr), '-ac', '1', 'pipe:1'],
                       input=float_to_pcm16(x), stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    if p.returncode or not p.stdout:
        return x
    # atempo's output length is only approximately len/factor (measured: up to +-160 samples = 7 ms at 24 kHz), so the clip is
    # cut / padded to EXACTLY the number of samples the schedule counted on (a sped-up clip never runs into the next one).
    return fit_samples(pcm16_to_float(p.stdout), int(round(len(x) / float(factor))))


def fit_samples(x, n):
    """Exactly `n` samples: cut the end, or pad it with silence."""
    n = max(0, int(n))
    if len(x) == n:
        return x
    if len(x) > n:
        return x[:n].copy()
    return np.concatenate([x, np.zeros(n - len(x), dtype=x.dtype)])


def fit_wav(path, seconds, chunk_seconds=60.0):
    """Make a 16-bit WAV exactly `seconds` long AT SAMPLE LEVEL: the end is cut, or padded with silence. The sound is streamed
    chunk by chunk (a 2 hour narration is 350 MB), and nothing is rewritten when the length is already right. Returns
    (samples_before, samples_after). V22.2: the narration must end exactly where the picture ends - neither `-shortest` chopping
    the picture nor a long narration pushing the file past the last frame."""
    path = str(path)
    with wave.open(path, 'rb') as r:
        rate, ch, width, have = r.getframerate(), r.getnchannels(), r.getsampwidth(), r.getnframes()
        want = max(0, int(round(float(seconds) * rate)))
        if have == want:
            return have, want
        tmp = path + '.fit.wav'
        step = max(1, int(chunk_seconds * rate))
        with wave.open(tmp, 'wb') as w:
            w.setnchannels(ch)
            w.setsampwidth(width)
            w.setframerate(rate)
            keep, copied = min(have, want), 0
            while copied < keep:
                frames = r.readframes(min(step, keep - copied))
                if not frames:
                    break
                w.writeframes(frames)
                copied += len(frames) // (ch * width)
            silence = b'\x00' * (ch * width)                         # shorter than asked: silence for the rest
            left = want - copied
            while left > 0:
                k = min(step, left)
                w.writeframes(silence * k)
                left -= k
    os.replace(tmp, path)
    return have, want


def mix(items, total_seconds, sr=SR):
    """items = [(samples, start_seconds)] -> one float32 track at least `total_seconds` long (clips never overlap in a
    normal run; if they ever do they simply add up)."""
    end = int(round(float(total_seconds) * sr))
    for x, start in items:
        end = max(end, int(round(start * sr)) + len(x))
    out = np.zeros(end, dtype=np.float32)
    for x, start in items:
        i = int(round(start * sr))
        out[i:i + len(x)] += x
    np.clip(out, -0.98, 0.98, out=out)
    return out


def mix_to_wav(path, total_seconds, placements, load, sr=SR, window_seconds=120.0):
    """Mix a whole film's narration into a 16-bit mono WAV without ever holding the whole track in memory (a 2 hour film
    would be 700 MB of float32). `placements` = [(start_seconds, end_seconds, key)]; `load(key)` returns the clip's samples
    (already sped up when the schedule asked for it). The track is produced window by window; a clip that straddles a
    window border is added to both windows. The file is exactly `total_seconds` long."""
    total = int(round(float(total_seconds) * sr))
    win = max(sr, int(window_seconds * sr))
    order = sorted(placements, key=lambda p: p[0])
    with wave.open(str(path), 'wb') as w:
        w.setnchannels(1)
        w.setsampwidth(2)
        w.setframerate(int(sr))
        for w0 in range(0, total, win):
            n = min(win, total - w0)
            buf = np.zeros(n, dtype=np.float32)
            for start, end, key in order:
                a = int(round(start * sr))
                if a >= w0 + n:
                    break                                   # sorted by start: nothing later can touch this window
                if int(round(end * sr)) + sr < w0:          # (1 s of margin: the real clip may be a little longer)
                    continue
                x = load(key)
                lo, hi = max(a, w0), min(a + len(x), w0 + n)
                if hi > lo:
                    buf[lo - w0:hi - w0] += x[lo - a:hi - a]
            np.clip(buf, -0.98, 0.98, out=buf)
            w.writeframes(float_to_pcm16(buf))
        if total == 0:
            w.writeframes(b'')
    return total / float(sr)
