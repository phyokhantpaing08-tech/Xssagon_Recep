"""Voices and speech synthesis (V21).

Voice list
----------
* ``native``  - Nilar (female) and Thiha (male): the only two Burmese voices Microsoft Edge TTS (free) really has.
                ONE Nilar and ONE Thiha. (V20 offered "deep / soft / energetic" variants of the same two voices; they are gone.)
* ``edge``    - "multilingual" Edge voices (Ava, Andrew, Emma, Brian, William, ...). Microsoft documents Burmese (my-MM) as a
                supported language of these voices in Azure Speech. Whether the FREE Edge endpoint reads Burmese with them
                could not be tested when this version was written, so they are marked EXPERIMENTAL: listen to the sample
                first (the sample check warns when a voice does not really speak Burmese).
* ``gemini``  - the 30 prebuilt Gemini voices (Kore, Puck, Charon ...). They use the person's own Gemini credit. Every
                narration line is one request, so a long film needs a paid key. Also unverified (needs a real key).

A voice is identified by a short id ("nilar", "thiha", "x_ava", "g_kore"). Older ids ("thiha-deep", "my-MM-ThihaNeural" ...)
still work and map to the base voice.

The narrator always speaks at ONE steady speed (the `speed` percent chosen on the website) - see timing.py.
"""
import asyncio
import hashlib
import json
import os
import re
import threading
import time
from pathlib import Path

import numpy as np

import timing as T

DEFAULT_VOICE = 'thiha'
DEFAULT_SPEED = 10          # percent faster than the engine's normal pace (applied to EVERY line the same way)
MIN_SPEED, MAX_SPEED = -20, 60     # V21.3: up to +60 % (the Burmese TikTok recaps that the "dub" style follows speak about 1.7x faster than the engine's normal pace)

# Old V17-V20 ids -> the single voice they were built on.
LEGACY_VOICE_IDS = {
    'my-MM-ThihaNeural': 'thiha', 'my-MM-NilarNeural': 'nilar',
    'thiha-deep': 'thiha', 'thiha-bright': 'thiha', 'nilar-soft': 'nilar', 'nilar-bright': 'nilar',
}

# What the clips are synthesised with, whatever the voice (the website's speed slider changes `rate`).
EDGE_PITCH = '+0Hz'

VOICES = {}


def _add(vid, **kw):
    kw['id'] = vid
    VOICES[vid] = kw


# ------------------------------------------------------------------------------------------------ native Burmese voices
_add('nilar', engine='edge', voice='my-MM-NilarNeural', name='Nilar', label='👩 နီလာ', gender='female', group='native',
     desc='မအသံ — မြန်မာ မူရင်းအသံ', experimental=False, credit=False,
     sample='မင်္ဂလာပါ၊ ကျွန်မနာမည် နီလာပါ။ ဒီနေ့ ရုပ်ရှင်ဇာတ်လမ်းလေး ပြောပြပေးမယ်နော်။')
_add('thiha', engine='edge', voice='my-MM-ThihaNeural', name='Thiha', label='👨 သီဟ', gender='male', group='native',
     desc='ကျားအသံ — မြန်မာ မူရင်းအသံ', experimental=False, credit=False,
     sample='မင်္ဂလာပါ၊ ကျွန်တော့်နာမည် သီဟပါ။ ဒီနေ့ ရုပ်ရှင်ဇာတ်လမ်းလေး ပြောပြပေးမယ်နော်။')

# ------------------------------------------------------------------------------------------------ experimental Edge voices
# (ShortName, name, gender, where the voice comes from). The list is checked against Edge's live voice list when possible.
EDGE_EXTRA = [
    ('en-US-AvaMultilingualNeural', 'Ava', 'female', 'အမေရိကန်'),
    ('en-US-AndrewMultilingualNeural', 'Andrew', 'male', 'အမေရိကန်'),
    ('en-US-EmmaMultilingualNeural', 'Emma', 'female', 'အမေရိကန်'),
    ('en-US-BrianMultilingualNeural', 'Brian', 'male', 'အမေရိကန်'),
    ('en-AU-WilliamMultilingualNeural', 'William', 'male', 'ဩစတြေးလျ'),
    ('fr-FR-VivienneMultilingualNeural', 'Vivienne', 'female', 'ပြင်သစ်'),
    ('fr-FR-RemyMultilingualNeural', 'Remy', 'male', 'ပြင်သစ်'),
    ('de-DE-SeraphinaMultilingualNeural', 'Seraphina', 'female', 'ဂျာမနီ'),
    ('de-DE-FlorianMultilingualNeural', 'Florian', 'male', 'ဂျာမနီ'),
    ('es-MX-DaliaMultilingualNeural', 'Dalia', 'female', 'မက္ကဆီကို'),
    ('es-MX-JorgeMultilingualNeural', 'Jorge', 'male', 'မက္ကဆီကို'),
    ('it-IT-GiuseppeMultilingualNeural', 'Giuseppe', 'male', 'အီတလီ'),
    ('ko-KR-HyunsuMultilingualNeural', 'Hyunsu', 'male', 'ကိုရီးယား'),
    ('pt-BR-ThalitaMultilingualNeural', 'Thalita', 'female', 'ဘရာဇီး'),
    ('zh-CN-XiaoxiaoMultilingualNeural', 'Xiaoxiao', 'female', 'တရုတ်'),
    ('zh-CN-YunyiMultilingualNeural', 'Yunyi', 'male', 'တရုတ်'),
]


def _slug(s):
    return re.sub(r'[^a-z0-9]+', '', s.lower())[:24]


def _sample_for(gender):
    me = 'ကျွန်မ' if gender == 'female' else 'ကျွန်တော်'
    return f'မင်္ဂလာပါ၊ {me} ဒီနေ့ ရုပ်ရှင်ဇာတ်လမ်းလေးကို ပြောပြပေးပါမယ်။'


def _add_edge_extra(short, name, gender, note):
    vid = 'x_' + _slug(name)
    if vid in VOICES:
        return
    icon = '👩' if gender == 'female' else '👨'
    _add(vid, engine='edge', voice=short, name=name, label=f'{icon} {name}', gender=gender, group='edge',
         desc=f'{note} • စမ်းသပ်ဆဲ (နမူနာ အရင်နားထောင်ပါ)', experimental=True, credit=False, sample=_sample_for(gender))


for _s in EDGE_EXTRA:
    _add_edge_extra(*_s)


def _load_env_extras():
    """EDGE_EXTRA_VOICES="en-US-AriaNeural:Aria:female, fr-FR-DeniseNeural:Denise:female" adds more Edge voices."""
    for part in re.split(r'[,;\n]+', os.getenv('EDGE_EXTRA_VOICES') or ''):
        bits = [b.strip() for b in part.split(':')]
        if len(bits) >= 1 and re.match(r'^[a-z]{2,3}-[A-Z]{2}-[A-Za-z0-9]+Neural$', bits[0] or ''):
            name = bits[1] if len(bits) > 1 and bits[1] else bits[0].split('-')[2].replace('Neural', '')
            gender = bits[2] if len(bits) > 2 and bits[2] in ('male', 'female') else 'female'
            _add_edge_extra(bits[0], name, gender, 'သင်ထည့်ထားတဲ့ အသံ')


_load_env_extras()

# ------------------------------------------------------------------------------------------------ Gemini voices
# (name, style word from Google's voice list, gender as it sounds). Genders are a guess - listen to the sample.
GEMINI_VOICES = [
    ('Zephyr', 'Bright', 'female'), ('Puck', 'Upbeat', 'male'), ('Charon', 'Informative', 'male'), ('Kore', 'Firm', 'female'),
    ('Fenrir', 'Excitable', 'male'), ('Leda', 'Youthful', 'female'), ('Orus', 'Firm', 'male'), ('Aoede', 'Breezy', 'female'),
    ('Callirrhoe', 'Easy-going', 'female'), ('Autonoe', 'Bright', 'female'), ('Enceladus', 'Breathy', 'male'),
    ('Iapetus', 'Clear', 'male'), ('Umbriel', 'Easy-going', 'male'), ('Algieba', 'Smooth', 'male'), ('Despina', 'Smooth', 'female'),
    ('Erinome', 'Clear', 'female'), ('Algenib', 'Gravelly', 'male'), ('Rasalgethi', 'Informative', 'male'),
    ('Laomedeia', 'Upbeat', 'female'), ('Achernar', 'Soft', 'female'), ('Alnilam', 'Firm', 'male'), ('Schedar', 'Even', 'male'),
    ('Gacrux', 'Mature', 'female'), ('Pulcherrima', 'Forward', 'female'), ('Achird', 'Friendly', 'male'),
    ('Zubenelgenubi', 'Casual', 'male'), ('Vindemiatrix', 'Gentle', 'female'), ('Sadachbia', 'Lively', 'male'),
    ('Sadaltager', 'Knowledgeable', 'male'), ('Sulafat', 'Warm', 'female'),
]
for _name, _style, _gender in GEMINI_VOICES:
    _icon = '👩' if _gender == 'female' else '👨'
    _add('g_' + _name.lower(), engine='gemini', voice=_name, name=_name, label=f'{_icon} {_name}', gender=_gender, group='gemini',
         desc=f'{_style} • Gemini credit သုံးပါတယ်', experimental=True, credit=True, sample=_sample_for(_gender))

GROUPS = [
    {'id': 'native', 'title': 'မြန်မာ မူရင်းအသံ (အလကား၊ စမ်းပြီးသား)', 'note': 'Microsoft Edge မှာ တကယ်ရှိတဲ့ မြန်မာအသံ နှစ်ခုပါ — နီလာ တစ်ခု၊ သီဟ တစ်ခု။'},
    {'id': 'edge', 'title': 'တခြား character အသံများ (အလကား၊ စမ်းသပ်ဆဲ)',
     'note': 'Microsoft ရဲ့ multilingual အသံတွေက မြန်မာစာ ဖတ်နိုင်တယ်လို့ Microsoft က ဖော်ပြထားပေမယ့် အခမဲ့ Edge လမ်းကြောင်းမှာ အလုပ်လုပ်မလုပ် ကျွန်ုပ် စမ်းလို့မရခဲ့ပါ။ အရင်နမူနာနားထောင်ပြီး ရွေးပါ။'},
    {'id': 'gemini', 'title': 'Gemini အသံ ၃၀ (သင့် Gemini credit သုံးမယ်)',
     'note': 'စာကြောင်းတစ်ကြောင်းကို request တစ်ခုစီ သုံးတဲ့အတွက် ဗီဒီယိုရှည်ရင် paid key လိုပါလိမ့်မယ်။ 👩/👨 သင်္ကေတက ခန့်မှန်းချက်ပဲ ဖြစ်ပြီး မြန်မာစာကို ဘယ်လောက်ကောင်းကောင်း ဖတ်မလဲဆိုတာ စမ်းလို့မရသေးပါ — နမူနာ အရင်နားထောင်ပါ။'},
]


def resolve(vid):
    vid = (vid or '').strip()
    vid = LEGACY_VOICE_IDS.get(vid, vid)
    return VOICES.get(vid)


def public_list(edge_live=None):
    """The voices as the website needs them. `edge_live` = set of ShortNames the Edge service really offers (or None =
    unknown): extra Edge voices that it does not offer are left out."""
    out = []
    for v in VOICES.values():
        if v['engine'] == 'edge' and v['group'] == 'edge' and edge_live is not None and v['voice'] not in edge_live:
            continue
        out.append({k: v[k] for k in ('id', 'name', 'label', 'gender', 'group', 'desc', 'experimental', 'credit')})
    return out


def speed_to_rate(speed):
    """Percent -> Edge rate string, e.g. 10 -> '+10%'."""
    try:
        p = int(round(float(speed)))
    except (TypeError, ValueError):
        p = DEFAULT_SPEED
    p = max(MIN_SPEED, min(MAX_SPEED, p))
    return f'{p:+d}%'


def clamp_speed(speed):
    try:
        return max(MIN_SPEED, min(MAX_SPEED, int(round(float(speed)))))
    except (TypeError, ValueError):
        return DEFAULT_SPEED


# ------------------------------------------------------------------------------------------------ engines
class TtsError(RuntimeError):
    pass


class EdgeTTS:
    """Microsoft Edge read-aloud voices through the `edge-tts` package. One background event loop serves every thread, so
    many lines are synthesised at the same time (EDGE_TTS_CONCURRENCY, default 6)."""

    def __init__(self, module=None, concurrency=None):
        self._mod = module
        self.concurrency = int(concurrency or os.getenv('EDGE_TTS_CONCURRENCY') or 6)
        self._loop = None
        self._sem = None
        self._lock = threading.Lock()

    @property
    def mod(self):
        if self._mod is None:
            import edge_tts                      # imported late: tests and tools that never speak do not need it
            self._mod = edge_tts
        return self._mod

    def _ensure_loop(self):
        with self._lock:
            if self._loop is None:
                loop = asyncio.new_event_loop()
                threading.Thread(target=loop.run_forever, name='edge-tts-loop', daemon=True).start()
                self._loop = loop
                self._sem = asyncio.run_coroutine_threadsafe(self._make_sem(), loop).result(10)
            return self._loop

    async def _make_sem(self):
        return asyncio.Semaphore(self.concurrency)

    async def _one(self, text, voice, rate, pitch, path, timeout):
        async with self._sem:
            comm = self.mod.Communicate(text, voice, rate=rate, pitch=pitch)
            await asyncio.wait_for(comm.save(str(path)), timeout)

    def synth(self, text, voice, rate, pitch, path, hooks=None, attempts=5, timeout=60):
        """Blocking. Writes `path` (mp3). Retries the usual transient failures; raises TtsError when it cannot."""
        loop = self._ensure_loop()
        last = None
        for attempt in range(attempts):
            if hooks:
                hooks.check()
            try:
                asyncio.run_coroutine_threadsafe(self._one(text, voice, rate, pitch, path, timeout), loop).result(timeout + 15)
                if Path(path).exists() and Path(path).stat().st_size > 200:
                    return
                last = 'Edge TTS returned an empty file'
            except Exception as e:                # NoAudioReceived, websocket / network errors, timeouts ...
                last = f'{e.__class__.__name__}: {e}'
            try:
                Path(path).unlink()
            except OSError:
                pass
            delay = min(20.0, 1.5 * (2 ** attempt))
            if hooks:
                hooks.sleep(delay, 'tts')
            else:
                time.sleep(delay)
        raise TtsError(f'Edge TTS failed after {attempts} tries ({voice}): {last}')

    ext = 'mp3'


class GeminiTTS:
    """Gemini prebuilt voices through GeminiClient.tts(). Needs the person's Gemini key (and credit)."""
    ext = 'wav'

    def __init__(self, client, models=None):
        self.client = client
        self.models = models or T_models()

    def synth(self, text, voice, rate, pitch, path, hooks=None, attempts=1, timeout=180):
        import wave
        pcm, sr = self.client.tts(text, voice, self.models, timeout=timeout)
        with wave.open(str(path), 'wb') as w:
            w.setnchannels(1)
            w.setsampwidth(2)
            w.setframerate(int(sr))
            w.writeframes(pcm)


def T_models():
    from gemini_client import parse_models
    return parse_models(os.getenv('GEMINI_TTS_MODELS') or '', ['gemini-3.8-flash-tts'])


# ------------------------------------------------------------------------------------------------ clips
class ClipMaker:
    """text -> a ready narration clip (float32 mono at 24 kHz, silence trimmed, loudness equalised), cached on disk so a
    resumed job never speaks the same line twice."""

    def __init__(self, ffmpeg, engine, voice, speed, cache_dir, hooks=None):
        self.ffmpeg = ffmpeg
        self.engine = engine
        self.voice = voice
        self.speed = clamp_speed(speed)
        self.cache = Path(cache_dir)
        self.cache.mkdir(parents=True, exist_ok=True)
        self.hooks = hooks
        self.rate = speed_to_rate(self.speed)
        # Edge voices take the speed as a parameter; Gemini voices have none, so the same fixed factor is applied to
        # EVERY clip afterwards (still one uniform speed).
        self.tempo = 1.0 if voice['engine'] == 'edge' else 1.0 + self.speed / 100.0

    def key(self, text):
        raw = f"v2|{self.voice['engine']}|{self.voice['voice']}|{self.rate}|{self.tempo:.3f}|{text}"
        return hashlib.sha1(raw.encode('utf-8')).hexdigest()[:20]

    def cached(self, text):
        """(wav path, seconds) when this exact line was synthesised before, else None."""
        p = self.cache / (self.key(text) + '.wav')
        try:
            if p.exists() and p.stat().st_size > 100:
                return p, T.wav_seconds(p)
        except Exception:
            pass
        return None

    def make(self, text):
        """-> (wav path, seconds). The line is synthesised only when it is not in the cache yet; the clip on disk is
        trimmed, loudness-equalised and 24 kHz mono, ready to be placed on the timeline."""
        hit = self.cached(text)
        if hit:
            return hit
        key = self.key(text)
        # a unique name per call: two threads may (rarely) ask for the same new line at the same moment
        raw = self.cache / f'{key}.{threading.get_ident()}.{self.engine.ext}'
        self.engine.synth(text, self.voice['voice'], self.rate, EDGE_PITCH, raw, hooks=self.hooks)
        try:
            x = T.decode_audio(self.ffmpeg, raw)
        finally:
            try:
                raw.unlink()
            except OSError:
                pass
        x = T.trim_silence(x)
        if self.tempo != 1.0:
            x = T.time_stretch(self.ffmpeg, x, T.SR, self.tempo)
        x = T.fade(T.normalize_rms(x))
        final = self.cache / f'{key}.wav'
        tmp = self.cache / f'{key}.{threading.get_ident()}.part'
        T.write_wav(tmp, x)
        tmp.replace(final)
        return final, len(x) / float(T.SR)

    def audio(self, text):
        """The clip's samples (float32, 24 kHz)."""
        path, _ = self.make(text)
        return T.read_wav(path)[0]


class CalibrationStore:
    """Remembers how fast each voice really speaks (syllables / second) between jobs."""

    def __init__(self, path):
        self.path = Path(path)
        self._lock = threading.Lock()

    @staticmethod
    def key(voice, speed):
        return f"{voice['engine']}|{voice['voice']}|{clamp_speed(speed)}"

    def get(self, voice, speed):
        try:
            d = json.loads(self.path.read_text(encoding='utf-8'))
            e = d.get(self.key(voice, speed))
            if e and 2.0 < float(e.get('sps', 0)) < 12.0:
                return float(e['sps']), int(e.get('n', 0))
        except Exception:
            pass
        return None

    def put(self, voice, speed, sps, n):
        if not (2.0 < float(sps) < 12.0) or n < 3:
            return
        with self._lock:
            try:
                d = json.loads(self.path.read_text(encoding='utf-8')) if self.path.exists() else {}
            except Exception:
                d = {}
            d[self.key(voice, speed)] = {'sps': round(float(sps), 3), 'n': int(n), 'ts': int(time.time())}
            self.path.parent.mkdir(parents=True, exist_ok=True)
            tmp = self.path.with_suffix('.tmp')
            tmp.write_text(json.dumps(d, indent=1), encoding='utf-8')
            tmp.replace(self.path)


CAL_SENTENCES = [
    'သူက မနက်စောစောထပြီး လမ်းထိပ်က ဈေးကို လျှောက်သွားတယ်။',
    'အဲဒီနောက် သူတို့နှစ်ယောက် အိမ်ကို ပြန်လာပြီး ညစာစားကြတယ်။',
    'ဒါပေမယ့် ဘာမှမဖြစ်သေးဘူး၊ ဇာတ်လမ်းက အခုမှ စတာပါ။',
]


def check_sample(text, x):
    """Does a synthesised sample really sound like the Burmese text? -> (ok, message). Looks only at length and loudness
    (nothing can judge the pronunciation itself): a voice that cannot read Burmese typically returns silence, a very short
    clip or a very long one."""
    seconds = len(x) / float(T.SR)
    if len(x) == 0 or float(np.abs(x).max()) < 0.01:
        return False, 'အသံ မထွက်ပါ (တိတ်နေပါတယ်) — ဒီအသံက မြန်မာစာ မဖတ်နိုင်ပုံပါပဲ။'
    expect = T.Calibration().seconds(text)
    if seconds < expect * 0.4:
        return False, f'အသံက တိုလွန်းနေပါတယ် ({seconds:.1f}s၊ မျှော်လင့်ချက် {expect:.1f}s) — မြန်မာစာကို အပြည့် မဖတ်ပုံပါပဲ။'
    if seconds > expect * 2.6:
        return False, f'အသံက ရှည်လွန်းနေပါတယ် ({seconds:.1f}s၊ မျှော်လင့်ချက် {expect:.1f}s) — မြန်မာစာကို မှန်မှန်ကန်ကန် မဖတ်ပုံပါပဲ။'
    return True, ''


_edge_live = {'at': 0.0, 'names': None}


def edge_live_cached():
    """What edge_live_names() learnt so far (None = not known yet). Never touches the network."""
    return _edge_live['names']


def edge_live_names(force=False):
    """ShortNames of the voices the Edge service offers right now (cached for 6 hours), or None when it cannot be asked."""
    now = time.time()
    if not force and _edge_live['names'] is not None and now - _edge_live['at'] < 6 * 3600:
        return _edge_live['names']
    try:
        import edge_tts

        async def _go():
            return await edge_tts.list_voices()
        voices = asyncio.run(asyncio.wait_for(_go(), 12))
        names = {v.get('ShortName') for v in voices if isinstance(v, dict)}
        names.discard(None)
        if names:
            _edge_live.update(at=now, names=names)
            return names
    except Exception:
        pass
    return _edge_live['names']
