"""Speech recognition with faster-whisper (V21; V22.3: the model, the timing and the cutting were reworked).

V22.3 - "the subtitles / voice do not match what is said"
-------------------------------------------------------
* MODEL. `base` is the weakest model that is still usable: it mishears words and, worse, places lines loosely. The default is now
  WHISPER_MODEL=auto: **large-v3-turbo on a GPU** (float16, beam 5) and **small on a CPU** (int8). `small` is the best model a 2-4 vCPU
  server can run in a sensible time (faster-whisper's published benchmark: 13 min of audio in 1 min 42 s on 8 threads, 1.5 GB RAM);
  large-v3-turbo has the full 32-layer large-v3 encoder, which is what costs time on a CPU, so it is only chosen automatically
  where a GPU is. Any name faster-whisper knows (tiny / base / small / medium / large-v3 / large-v3-turbo / distil-large-v3 ...) can still be
  forced with WHISPER_MODEL; a model that cannot be loaded falls back to small, base, tiny (in that order).
* WORD TIMESTAMPS. Whisper's own segment times are loose (a line often starts seconds before the first word or hangs on after the last
  one), and the Burmese voice and the subtitle are placed on the segment start. Every line now takes its start from the FIRST WORD and its
  end from the LAST WORD (word_timestamps, WHISPER_WORDS=0 switches it off). A word that is stretched across a silence (the known
  failure of word timestamps) is cut back to a believable length, and hallucination_silence_threshold drops the invented lines Whisper
  likes to write over silence and music.
* CUTTING. The audio is split into 300 s chunks. V21 / V22 cut at exactly 300 s - in the middle of a word or a sentence, and ffmpeg's
  segment muxer even added 32 ms per chunk. Now the cut goes to the quietest moment within +-20 s of the 300 s mark, at an exact sample, so
  no sentence is torn in two, and the chunks always add up to the whole film (the start of a chunk = the total length of the chunks before it).
* LANGUAGE. The language is found from the first 4 pieces of speech instead of the first 30 seconds (an intro with music made Whisper
  guess wrong for the whole film); WHISPER_LANGUAGE=en (any code) fixes it when you know it.
* `python asr.py check video.mp4` prints what Whisper hears and when, on the picture's own timeline - a one-minute way to see whether
  the times fit the film on YOUR server.

Kept from V21: all cores for Whisper (WHISPER_THREADS), the language of the first chunk is reused, every chunk's result is saved to disk
(work/whisper/chunk_NNNN.json) so a cancelled / crashed / resumed job never transcribes a finished chunk again, and chunks are produced
one at a time (a generator) so the rewrite step can start on chunk 1 while Whisper is still busy with chunk 2.
"""
import inspect
import json
import os
import sys
import threading
import wave
from contextlib import nullcontext
from pathlib import Path

import media

_models = {}
_lock = threading.Lock()

CPU_DEFAULT = 'small'
GPU_DEFAULT = 'large-v3-turbo'
FALLBACKS = ('small', 'base', 'tiny')
WEAK = ('tiny', 'tiny.en', 'base', 'base.en')
MAX_WORD_SECONDS = 1.6          # one spoken word never lasts longer than this: a longer "word" is a timestamp stretched over silence
RATE = 16000


def cpu_threads():
    try:
        n = int(os.getenv('WHISPER_THREADS') or 0)
    except ValueError:
        n = 0
    return n if n > 0 else max(1, os.cpu_count() or 1)


def cuda_available():
    try:
        import ctranslate2
        return int(ctranslate2.get_cuda_device_count()) > 0
    except Exception:
        return False


def _env_float(name, default, lo, hi):
    try:
        v = float(os.getenv(name) or default)
    except ValueError:
        v = float(default)
    return max(lo, min(hi, v))


def settings():
    """What will be used: {'model', 'device', 'compute', 'beam', 'words'}. WHISPER_MODEL / WHISPER_DEVICE = auto (the default) pick the
    right model for the machine; any other value is taken as it is."""
    device = (os.getenv('WHISPER_DEVICE') or 'auto').strip().lower()
    if device in ('', 'auto'):
        device = 'cuda' if cuda_available() else 'cpu'
    model = (os.getenv('WHISPER_MODEL') or 'auto').strip().lower()
    if model in ('', 'auto'):
        model = GPU_DEFAULT if device == 'cuda' else CPU_DEFAULT
    compute = (os.getenv('WHISPER_COMPUTE_TYPE') or '').strip() or ('float16' if device == 'cuda' else 'int8')
    try:
        beam = int(os.getenv('WHISPER_BEAM') or 0)
    except ValueError:
        beam = 0
    if beam < 1:
        beam = 5 if device == 'cuda' else 1                      # greedy is several times faster than beam 5: fine on a CPU, not needed on a GPU
    words = (os.getenv('WHISPER_WORDS') or '1').strip().lower() not in ('0', 'false', 'no', 'off')
    return {'model': model, 'device': device, 'compute': compute, 'beam': min(beam, 10), 'words': words}


def whisper_model():
    from faster_whisper import WhisperModel                     # imported late (heavy; absent in the unit tests)
    cfg = settings()
    requested, device, compute = cfg['model'], cfg['device'], cfg['compute']
    key = (requested, device, compute, cpu_threads())
    with _lock:
        if key in _models:
            return _models[key]
        last = None
        for name in [requested] + [x for x in FALLBACKS if x != requested]:
            try:
                model = WhisperModel(name, device=device, compute_type=compute, cpu_threads=cpu_threads())
                _models[key] = (model, name)
                print(f'[whisper] model={name} device={device} compute={compute} beam={cfg["beam"]} word_timestamps={"on" if cfg["words"] else "off"}'
                      + (f'  (asked for {requested}: {last})' if name != requested and last else ''), flush=True)
                if name in WEAK:
                    print(f'[whisper] "{name}" is a weak model - the words and the timing are noticeably worse. Set WHISPER_MODEL=auto in .env '
                          f'(small on a CPU, large-v3-turbo on a GPU).', flush=True)
                return model, name
            except Exception as e:
                last = e
        raise RuntimeError(f'Whisper model could not be loaded: {last}')


# ------------------------------------------------------------------------------------------------ cutting the audio
def _quietest(wav, nominal, reach, total, rate=RATE):
    """The sample (near `nominal`, within +-`reach` samples) where the sound is quietest: energy in 20 ms steps, smoothed over 300 ms; among
    the nearly-as-quiet places the one closest to `nominal`. A cut lands in a pause between words / sentences rather than inside one."""
    import numpy as np
    lo = max(0, nominal - reach)
    hi = min(total, nominal + reach)
    if hi - lo < rate:
        return min(max(nominal, 0), total)
    wav.setpos(lo)
    x = np.frombuffer(wav.readframes(hi - lo), dtype='<i2').astype(np.float32) / 32768.0
    step = max(1, int(0.02 * rate))
    n = len(x) // step
    if n < 5:
        return min(max(nominal, 0), total)
    energy = (x[:n * step].reshape(n, step) ** 2).mean(axis=1)
    k = max(3, int(0.3 / 0.02))
    smooth = np.convolve(energy, np.ones(k) / k, mode='same')
    smooth[:k // 2] = np.inf                                      # (the edges of the window are not a real minimum)
    smooth[-(k // 2):] = np.inf
    best = int(np.argmin(smooth))
    # among the (nearly) equally quiet places prefer the one closest to the nominal cut
    floor = float(smooth[best]) * 1.5 + 1e-9
    near = np.flatnonzero(smooth <= floor)
    target = (nominal - lo) // step
    best = int(near[np.argmin(np.abs(near - target))]) if len(near) else best
    return lo + best * step + step // 2


def cut_points(wav, seconds, reach_seconds=20.0, min_tail=15.0):
    """Frame numbers where the file is cut (first 0, last = the length): about every `seconds`, each at the quietest moment near it."""
    rate, total = wav.getframerate(), wav.getnframes()
    min_tail = min(min_tail, seconds * 0.4)
    step = int(seconds * rate)
    reach = int(min(reach_seconds, seconds / 4.0) * rate)
    cuts, pos = [0], 0
    while step > 0 and total - (pos + step) > min_tail * rate:
        cut = _quietest(wav, pos + step, reach, total, rate)
        if cut <= pos + step // 2:                                # (never a tiny chunk)
            cut = pos + step
        if total - cut < min_tail * rate:                         # (nor a tiny last chunk: it stays part of this one)
            break
        cuts.append(cut)
        pos = cut
    cuts.append(total)
    return cuts


def _split_with_python(source, outdir, seconds):
    with wave.open(str(source), 'rb') as r:
        if r.getframerate() != RATE or r.getsampwidth() != 2 or r.getnchannels() != 1:
            return None
        cuts = cut_points(r, seconds, _env_float('WHISPER_CUT_SEARCH', 20.0, 0.0, 120.0))
        files = []
        for i in range(len(cuts) - 1):
            a, b = cuts[i], cuts[i + 1]
            path = Path(outdir) / f'chunk_{i:04d}.wav'
            r.setpos(a)
            with wave.open(str(path), 'wb') as w:
                w.setnchannels(1)
                w.setsampwidth(2)
                w.setframerate(RATE)
                left = b - a
                while left > 0:
                    block = r.readframes(min(left, RATE * 30))
                    if not block:
                        break
                    w.writeframes(block)
                    left -= len(block) // 2
            files.append(path)
        return files


def split_audio(source, outdir, seconds=300):
    outdir = Path(outdir)
    marker = outdir / 'chunks.done'
    if marker.exists():
        have = sorted(outdir.glob('chunk_*.wav'))
        if have:
            return have
    outdir.mkdir(parents=True, exist_ok=True)
    for old in list(outdir.glob('chunk_*.wav')) + [marker]:
        try:
            old.unlink()
        except OSError:
            pass
    files = None
    try:
        files = _split_with_python(source, outdir, seconds)
    except Exception as e:                                        # (no numpy / an odd file: the ffmpeg way below always works)
        print(f'[whisper] cutting at silences is not possible ({e}); cutting at fixed times', flush=True)
        files = None
    if files is None:
        for old in outdir.glob('chunk_*.wav'):
            old.unlink()
        pattern = outdir / 'chunk_%04d.wav'
        media.ffmpeg('-i', source, '-f', 'segment', '-segment_time', seconds, '-reset_timestamps', '1', '-ac', '1', '-ar', '16000',
                     '-c:a', 'pcm_s16le', pattern)
    marker.write_text('ok')
    return sorted(outdir.glob('chunk_*.wav'))


def chunk_starts(chunks, nominal=300.0):
    """Where every chunk really starts on the film's timeline = the total length of the chunks before it (read from the WAV
    headers). (V22.2: the ffmpeg segment muxer cut at a packet border, so a chunk was 300.032 s long, not 300 s, and the nominal
    `i * chunk_len` drifted by 32 ms per chunk. V22.3 cuts the chunks itself at silences, so their lengths differ anyway.)"""
    starts, at = [], 0.0
    for c in chunks:
        starts.append(at)
        try:
            with wave.open(str(c), 'rb') as w:
                at += w.getnframes() / float(w.getframerate())
        except (wave.Error, OSError, EOFError, ZeroDivisionError):
            at += float(nominal)                       # an unreadable header: fall back to the nominal length
    return starts


def load_wav_for_whisper(wav_path):
    # faster-whisper decodes a *file path* with PyAV: av.open(path, metadata_errors="ignore"). An old PyAV
    # (the `av` package) does not know `metadata_errors` and fails with
    #   "open() got an unexpected keyword argument 'metadata_errors'".
    # split_audio() already produced 16 kHz mono 16-bit WAV files, so read them here and hand Whisper a float32
    # array instead: PyAV is then never called and the PyAV version no longer matters.
    try:
        import numpy as np
        with wave.open(str(wav_path), 'rb') as w:
            rate, width, channels = w.getframerate(), w.getsampwidth(), w.getnchannels()
            raw = w.readframes(w.getnframes())
        if rate != 16000 or width != 2 or not raw:
            return str(wav_path)
        audio = np.frombuffer(raw, dtype=np.int16)
        if channels > 1:
            audio = audio[:len(audio) - len(audio) % channels].reshape(-1, channels).mean(axis=1)
        return np.ascontiguousarray(audio, dtype=np.float32) / 32768.0
    except Exception as e:
        print(f'[whisper] could not read {wav_path} directly, letting faster-whisper decode it: {e}', flush=True)
        return str(wav_path)


def speech_spans(wav_path):
    # Where is somebody REALLY speaking? Uses the Silero VAD that faster-whisper already ships (no extra
    # install). Returns [(start, end), ...] in seconds, relative to this wav file, or None when it cannot run
    # (the segment times from Whisper are then used unchanged).
    try:
        import numpy as np
        from faster_whisper.vad import get_speech_timestamps, VadOptions
        with wave.open(str(wav_path), 'rb') as w:
            rate, raw = w.getframerate(), w.readframes(w.getnframes())
        audio = np.frombuffer(raw, dtype=np.int16).astype(np.float32) / 32768.0
        # Tighter than Whisper's own VAD settings: split at pauses of 0.3 s, only 0.1 s of padding.
        opts = VadOptions(threshold=0.4, min_speech_duration_ms=100, min_silence_duration_ms=300, speech_pad_ms=100)
        return [(a['start'] / rate, a['end'] / rate) for a in get_speech_timestamps(audio, opts, sampling_rate=rate)]
    except Exception as e:
        print(f'[subtitles] speech detection unavailable, using Whisper timing: {e}', flush=True)
        return None


def trim_to_speech(start, end, spans, slack=0.6, pad=0.12):
    # Whisper segment times are loose: a line often ends seconds after the last word (so its subtitle would hang
    # on screen until the next line) or starts before the first word. Pull both ends in to the real speech, but
    # only when the extra part is clearly silence (longer than `slack`), so a missed word never cuts a line short.
    inside = [(a, b) for a, b in spans if b > start and a < end]
    if not inside:
        return start, end
    first, last = inside[0][0], inside[-1][1]
    if first - start > slack:
        start = first - pad
    if end - last > slack:
        end = last + pad
    return start, max(end, start + 0.2)


# ------------------------------------------------------------------------------------------------ word timestamps
def _word_fields(w):
    if isinstance(w, dict):
        return w.get('word', ''), w.get('start'), w.get('end')
    return getattr(w, 'word', ''), getattr(w, 'start', None), getattr(w, 'end', None)


def _believable(text, seconds):
    """How long a word of this many letters can reasonably take (a stretched timestamp is replaced by this)."""
    return min(MAX_WORD_SECONDS, 0.30 + 0.07 * len(str(text).strip()))


def word_bounds(words):
    """(start, end) of the speech in one segment from its word timestamps, or None when there are none. Whisper's word timestamps have a known
    failure: the FIRST word of a segment can be stretched back over the silence / music before it, the LAST one forward over what follows. A word
    longer than MAX_WORD_SECONDS is cut back to a believable length on its inner side, so the line starts when the first word is really said
    and ends when the last one is."""
    good = []
    for w in words or []:
        text, a, b = _word_fields(w)
        try:
            a, b = float(a), float(b)
        except (TypeError, ValueError):
            continue
        if b >= a and a == a and b == b:
            good.append((str(text), a, b))
    if not good:
        return None
    if len(good) == 1:                                        # one word: its end is the more reliable side, pull the start in
        text, a, b = good[0]
        if b - a > MAX_WORD_SECONDS:
            a = max(a, b - _believable(text, b - a))
        return a, max(b, a + 0.05)
    text, first_a, first_b = good[0]
    if first_b - first_a > MAX_WORD_SECONDS:
        first_a = max(first_a, first_b - _believable(text, first_b - first_a))
    text, last_a, last_b = good[-1]
    if last_b - last_a > MAX_WORD_SECONDS:
        last_b = min(last_b, last_a + _believable(text, last_b - last_a))
    return first_a, max(last_b, first_a + 0.05)


def _accepted(model):
    """Names transcribe() takes (None = anything: a **kwargs function). Older faster-whisper versions lack some newer options; those are
    simply not passed."""
    try:
        params = inspect.signature(model.transcribe).parameters
    except (TypeError, ValueError):
        return None
    if any(p.kind is inspect.Parameter.VAR_KEYWORD for p in params.values()):
        return None
    return set(params)


def transcribe_wav(wav_path, lang_hint=None, check=None, want_spans=True):
    """One chunk -> ([{'start','end','text', 'speech_start'?, 'speech_end'?}] relative to the chunk, language, model name,
    language probability). Replaced by a fake in the tests."""
    model, used = whisper_model()
    cfg = settings()
    kw = {'beam_size': cfg['beam'], 'vad_filter': True, 'condition_on_previous_text': False}
    if cfg['words']:
        kw['word_timestamps'] = True
        kw['hallucination_silence_threshold'] = _env_float('WHISPER_HALLUCINATION_SILENCE', 2.0, 0.5, 10.0)
    if lang_hint:
        kw['language'] = lang_hint
    else:
        kw['language_detection_segments'] = 4                       # the first 4 pieces of speech, not just the first 30 seconds
        kw['language_detection_threshold'] = 0.5
    names = _accepted(model)
    if names is not None:
        kw = {k: v for k, v in kw.items() if k in names}
    segs, info = model.transcribe(load_wav_for_whisper(wav_path), **kw)
    spans = speech_spans(wav_path) if want_spans else None
    out = []
    for s in segs:                                           # a generator: Whisper works while we iterate
        if check:
            check()
        txt = s.text.strip()
        if not txt:
            continue
        start, end = float(s.start), float(s.end)
        bounds = word_bounds(getattr(s, 'words', None)) if cfg['words'] else None
        if bounds:                                           # the line is where its words are
            start, end = bounds
        seg = {'start': start, 'end': max(end, start + 0.05), 'text': txt}
        if spans is not None:
            a, b = trim_to_speech(start, end, spans)
            seg['speech_start'], seg['speech_end'] = a, max(b, a + 0.05)
        out.append(seg)
    return out, getattr(info, 'language', None) or 'unknown', used, float(getattr(info, 'language_probability', 0) or 0)


def transcribe_chunks(source, work, check=None, slot=None, want_spans=True):
    """Generator: yields (index, total, segments (absolute times), language, model name) for every chunk in order.
    `slot` = a context-manager factory that limits how many chunks are decoded at the same time (heavy CPU stage)."""
    work = Path(work)
    chunk_len = _env_float('WHISPER_CHUNK_SECONDS', 300, 5, 3600)      # (a typo such as 300.0 or abc must not stop the job)
    chunks = split_audio(source, work / 'chunks', chunk_len)
    starts = chunk_starts(chunks, chunk_len)
    cache = work / 'whisper'
    cache.mkdir(parents=True, exist_ok=True)
    forced = (os.getenv('WHISPER_LANGUAGE') or '').strip().lower()
    forced = '' if forced in ('', 'auto') else forced
    lang, used = forced or None, ''
    for i, c in enumerate(chunks):
        if check:
            check()
        f = cache / f'chunk_{i:04d}.json'
        rel = None
        if f.exists():
            try:
                rel = json.loads(f.read_text(encoding='utf-8'))
            except Exception:
                rel = None
        if rel is None:
            with (slot() if slot else nullcontext()):
                segs, lg, used, prob = transcribe_wav(c, lang if lang and lang != 'unknown' else None, check, want_spans)
            rel = {'segs': segs, 'lang': lg, 'model': used, 'prob': prob}
            tmp = f.with_suffix('.tmp')
            tmp.write_text(json.dumps(rel, ensure_ascii=False), encoding='utf-8')
            tmp.replace(f)
        lang = lang or (rel.get('lang') if rel.get('prob', 1) >= 0.6 or not lang else lang)
        used = rel.get('model') or used
        off = starts[i]
        out = []
        for s in rel['segs']:
            seg = {'start': max(0.0, s['start'] + off), 'end': max(s['start'] + off + 0.05, s['end'] + off), 'text': s['text']}
            if 'speech_start' in s:
                seg['speech_start'] = max(0.0, s['speech_start'] + off)
                seg['speech_end'] = max(seg['speech_start'] + 0.05, s['speech_end'] + off)
            out.append(seg)
        yield i, len(chunks), out, rel.get('lang') or lang or 'unknown', used


# ------------------------------------------------------------------------------------------------ `python asr.py check video.mp4`
def _stamp(t):
    t = max(0.0, float(t))
    return f'{int(t // 60):02d}:{t % 60:06.3f}'


def check(video, seconds=90.0, out=None):
    """Print what Whisper hears in the first `seconds` of `video`, on the picture's own timeline (the one the subtitles and the voice use)."""
    import tempfile
    out = out or sys.stdout
    cfg = settings()
    print(f'Whisper: model={cfg["model"]} device={cfg["device"]} compute={cfg["compute"]} beam={cfg["beam"]} word_timestamps={cfg["words"]}', file=out)
    info = media.probe_timing(video)
    if info:
        print(f'Picture starts at {info["v_start"]:.3f}s on the file\'s clock, length {info["picture"] or 0:.2f}s, audio starts at {info["a_start"]}', file=out)
    with tempfile.TemporaryDirectory(prefix='recap_check_') as d:
        src = Path(d) / 'source.wav'
        media.extract_audio_wav(video, src, RATE)
        with wave.open(str(src), 'rb') as r:                      # only the first minute or two: cut a short file
            keep = min(r.getnframes(), int(seconds * RATE))
            head = Path(d) / 'head.wav'
            with wave.open(str(head), 'wb') as w:
                w.setnchannels(1)
                w.setsampwidth(2)
                w.setframerate(RATE)
                w.writeframes(r.readframes(keep))
        n = 0
        for _, _, segs, lang, used in transcribe_chunks(head, Path(d) / 'work', want_spans=True):
            for s in segs:
                n += 1
                spk = f'  (speech {_stamp(s["speech_start"])} -> {_stamp(s["speech_end"])})' if 'speech_start' in s else ''
                print(f'[{_stamp(s["start"])} -> {_stamp(s["end"])}] {s["text"]}{spk}', file=out)
            print(f'-- language: {lang}, model: {used}, lines: {n}', file=out)


if __name__ == '__main__':
    if len(sys.argv) >= 3 and sys.argv[1] == 'check':
        check(sys.argv[2], float(sys.argv[3]) if len(sys.argv) > 3 else 90.0)
    else:
        print('usage: python asr.py check <video file> [seconds]')
