# V22.3 ကို AWS VPS မှာ တင်နည်း — IP လိပ်စာ + port နံပါတ်ပဲ (login မလို)

V20 လိုပဲ `http://VPS-IP:8000` ကို browser မှာ ဖွင့်ရုံပါ။ **Google login မရှိပါ**၊ domain / HTTPS / Caddy လည်း မလိုပါ။

- Gemini API key (V22.2 မှာ Gemini ပဲ ရှိတော့တယ် — Claude / Groq ကို ဖျက်ပြီး) ကို website ထဲက **Gemini API** card မှာ ကိုယ်တိုင်ထည့်ပါ (သို့ `.env` မှာ ထည့်)။
- ဒီ website မှာ ဝင်တဲ့သူ အားလုံးက **တစ်ယောက်တည်း** (ကိုယ်) အဖြစ် သုံးရပါတယ် — ကိုယ့် key၊ ကိုယ့် job၊ ကိုယ့် Drive။ ဒါကြောင့် **ဘယ်သူဝင်လို့ရမလဲ** ဆိုတာကို အောက်က အဆင့် ၂ နဲ့ ၅ မှာ ကန့်သတ်ပါ။

> အချိန်: ၂၀–၃၀ မိနစ်။ ကုန်ကျစရိတ်: VPS ကလွဲရင် မရှိပါ။

---

## ⚠️ အရင်ဖတ်ပါ — "login မရှိ" ဆိုတာ ဘာကိုဆိုလိုလဲ

- `http://` (HTTPS မဟုတ်) နဲ့ သုံးတာမို့ ကြားထဲက network ကနေ **စာတွေ ကူးဖတ်လို့ရနိုင်** ပါတယ် (ဥပမာ အများသုံး Wi-Fi)။ ကိုယ့်အိမ်/ရုံး network ကနေပဲ သုံးရင် အန္တရာယ်နည်းပါတယ်။
- Port 8000 ကို ကမ္ဘာတစ်ဝန်း ဖွင့်ထားရင် IP သိတဲ့သူ ဘယ်သူမဆို **website ကို ဝင်သုံးလို့ရ** ပါတယ် — ကိုယ့်ရဲ့ ထည့်ထားတဲ့ Gemini key (ကိုယ့် credit) နဲ့ VPS ရဲ့ CPU / disk ကို သုံးပစ်နိုင်ပါတယ်။ ဒါကြောင့် **အောက်က နည်းနှစ်ခုထဲက တစ်ခုခု (နှစ်ခုလုံးဆို ပိုကောင်း) လုပ်ပါ**:
  1. **AWS Security Group** မှာ port 8000 ကို **ကိုယ့် IP ကိုပဲ** ဖွင့် (အဆင့် ၂) — code မလိုဘဲ အကောင်းဆုံး နည်း။
  2. `.env` မှာ **`APP_PASSWORD`** ထား (အဆင့် ၅) — browser က password တစ်ခါမေးမယ်။ ဒါက စိမ်းတဲ့သူ၊ bot တွေကို တားပါတယ်။ (HTTP မို့ network ကို စောင့်ကြည့်နေသူက password ကို မြင်နိုင်ပါတယ်။)

---

## လိုအပ်တာတွေ

| | |
|---|---|
| VPS | Ubuntu 22.04 / 24.04၊ **အနည်းဆုံး 2 vCPU + 4 GB RAM + disk 40 GB** (ဗီဒီယိုတွေက နေရာယူတယ်)။ Gemini က မြန်မာ IP ကို မလက်ခံလို့ **Tokyo လို ပံ့ပိုးတဲ့ နိုင်ငံ** မှာ ဖြစ်ရပါမယ် (ကိုယ့် VPS က Tokyo မှာ ရှိပြီးသား)။ |
| ကိုယ့်ကွန်ပျူတာ | `scp` / `ssh` သုံးဖို့ (Windows 10/11 မှာ PowerShell ထဲက `ssh` / `scp` ပါပြီးသား)။ |

---

## အဆင့် ၁ — အရင် V20 run နေရင် ရပ်ပါ

V20 ကို run နေတယ်ဆိုရင် (port 8000 တူလို့) အရင်ရပ်ပါ — SSH နဲ့ ဝင်ပြီး:

```bash
sudo pkill -f uvicorn        # ဒါမှမဟုတ် V20 ကို ဖွင့်ထားတဲ့ terminal / screen ထဲမှာ Ctrl+C
```

V21 ကို **folder အသစ်** မှာ တင်မှာမို့ V20 folder ကို မထိပါဘူး။

## အဆင့် ၂ — AWS Security Group (ဘယ်သူ ဝင်လို့ရမလဲ)

EC2 → Instances → ကိုယ့် VPS → **Security** tab → Security group → **Edit inbound rules**:

| Type | Port | Source |
|---|---|---|
| SSH | 22 | **My IP** |
| Custom TCP | **8000** | **My IP** ← ကိုယ့် IP ကိုပဲ |

- V20 အတွက် ဖွင့်ထားတဲ့ port 8000 rule မှာ Source က `0.0.0.0/0` (Anywhere) ဖြစ်နေရင် **My IP** အဖြစ် ပြောင်းပါ။ ဒီအဆင့်ကိုပဲ လုပ်ရင်တောင် စိမ်းတဲ့သူတွေ ဝင်လို့မရတော့ပါဘူး။
- ⚠️ ကိုယ့် IP က ပြောင်းတတ်ရင် (မြန်မာ ISP တွေက မကြာခဏ ပြောင်း) rule ကို ပြန်ပြင်ရပါမယ် — ဝင်လို့မရတော့ရင် ပထမဆုံး ဒါကို စစ်ပါ။ ဖုန်း / တခြားနေရာကနေပါ သုံးချင်ရင် Source ကို `0.0.0.0/0` ထားပြီး **`APP_PASSWORD`** ကို ထားပါ။
- တခြား port (80, 443 …) မလိုပါဘူး။

## အဆင့် ၃ — Server ပေါ်မှာ program တင်ပါ

ကိုယ့်ကွန်ပျူတာကနေ zip ကို VPS ဆီ ပို့ပါ (`key.pem` နေရာမှာ ကိုယ့် key ဖိုင်၊ `13.231.227.226` နေရာမှာ ကိုယ့် VPS IP):

```bash
scp -i key.pem burmese-movie-recap-ai-v21.3.zip ubuntu@13.231.227.226:~
ssh -i key.pem ubuntu@13.231.227.226
```

VPS ထဲမှာ:

```bash
sudo apt update
sudo apt install -y python3-venv python3-pip ffmpeg unzip
cd ~
unzip burmese-movie-recap-ai-v21.3.zip      # ဖြေလိုက်ရင် folder နာမည် burmese-movie-recap-ai-v21 နဲ့ ထွက်လာပါတယ် (zip နာမည်ပဲ .3 ပါတာ)
cd burmese-movie-recap-ai-v21
python3 -m venv venv
venv/bin/pip install -r backend/requirements.txt
cp .env.example .env
```

- မြန်မာစာတန်း ဖောင့် (Padauk) က `fonts/` ထဲမှာ ပါပြီးသားပါ — ထပ်သွင်းစရာ မလိုပါဘူး။
- **V20 ရဲ့ key / Drive login ကို ဆက်သုံးချင်ရင်:** V20 folder ထဲက `data/settings.json`၊ `data/drive_token.json`၊ `data/drive_settings.json`၊ `data/credentials.json` (ရှိတာတွေ) ကို V21 ရဲ့ `data/` ထဲ ကူးထည့်ပါ (ဖိုင်နာမည်၊ နေရာ အတူတူပါ)။ V20 ရဲ့ `data/jobs` အဟောင်းတွေကိုတော့ မကူးပါနဲ့။
  ```bash
  cp ~/burmese-movie-recap-ai-v20/data/settings.json ~/burmese-movie-recap-ai-v21/data/ 2>/dev/null
  cp ~/burmese-movie-recap-ai-v20/data/drive_*.json ~/burmese-movie-recap-ai-v20/data/credentials.json ~/burmese-movie-recap-ai-v21/data/ 2>/dev/null
  ```
  (V20 folder နာမည်က ကွဲနေရင် ကိုယ့်ဟာနဲ့ ပြင်ပါ။ ဒီအဆင့်က မဖြစ်မနေ မဟုတ်ပါ — key ကို website မှာ ပြန်ထည့်လည်းရ။)

## အဆင့် ၄ — အရင်စမ်းပါ

```bash
cd ~/burmese-movie-recap-ai-v21
venv/bin/python backend/app.py
```

`[startup] …` စာတွေပေါ်ပြီး error မရှိရင် ကိုယ့်ကွန်ပျူတာ browser မှာ **`http://13.231.227.226:8000`** ဖွင့်ကြည့်ပါ (ကိုယ့် VPS IP နဲ့)။ Page ပေါ်ရင် အောင်ပါပြီ — Terminal မှာ **Ctrl+C** နဲ့ ရပ်ပြီး အဆင့် ၅ ကို ဆက်ပါ။

> V20 လိုပဲ `venv/bin/python -m uvicorn backend.app:app --host 0.0.0.0 --port 8000` နဲ့လည်း စလို့ရပါတယ် (စမ်းထားတယ်)။

## အဆင့် ၅ — `.env` ဖိုင် (ကိုယ့်ကြိုက်သလို)

```bash
nano ~/burmese-movie-recap-ai-v21/.env
```

ဘာမှ မပြင်လည်း run ပါတယ်။ ပြင်ချင်ရင်သာ (`#` ကို ဖျက်ပါ):

```ini
# Website ကို ဝင်ဖို့ password တစ်ခု (browser က တစ်ခါမေးမယ်၊ user name ကို ဘာရိုက်ရိုက်ရ)
APP_PASSWORD=ကိုယ့်password

# Gemini key ကို .env မှာ ထည့်ချင်ရင် (မဟုတ်ရင် website မှာ ထည့်။ Website မှာ ထည့်တဲ့ key က .env ထဲက key ကို အစားထိုးတယ်)
GEMINI_API_KEY=ကိုယ့်-Gemini-key        # AI Studio က ပေးတဲ့ key အတိုင်း (AQ. နဲ့စတာ ဖြစ်ဖြစ်၊ AIza နဲ့စတာ ဖြစ်ဖြစ်)
```

- `HOST` (default `0.0.0.0` = အပြင်ကနေ ဝင်လို့ရ) နဲ့ `PORT` (default `8000`) ကို ပြောင်းလို့ရတယ်။ `HOST=127.0.0.1` ထားရင် SSH tunnel ကနေပဲ ဝင်လို့ရမယ် (အောက်က "ပိုလုံခြုံချင်ရင်" ကြည့်ပါ)။
- ဗီဒီယို အကြီးဆုံး (`MAX_UPLOAD_MB`)၊ ပြီးတဲ့ဖိုင်တွေကို အလိုအလျောက်ဖျက်ချိန် (`RETENTION_HOURS`)၊ တပြိုင်နက် job အရေအတွက် (`MAX_JOBS_PER_USER`) တို့ကို `.env.example` ထဲမှာ ရှင်းပြထားပါတယ် — default က ကန့်သတ်ချက်မရှိ (V20 လိုပဲ)။

## အဆင့် ၆ — systemd service (server ပြန်ဖွင့်လည်း အလိုအလျောက် စ)

```bash
cd ~/burmese-movie-recap-ai-v21
sudo cp deploy/recap.service /etc/systemd/system/recap.service
sudo nano /etc/systemd/system/recap.service      # User=ubuntu နဲ့ လမ်းကြောင်း ၂ ခုကို ကိုယ့်ဟာနဲ့ တိုက်စစ်ပါ
sudo systemctl daemon-reload
sudo systemctl enable --now recap
sudo systemctl status recap --no-pager           # "active (running)" ဖြစ်ရမယ်
journalctl -u recap -f                           # live log (Ctrl+C နဲ့ ထွက်)
```

> App ကို **တစ်ခုတည်း** (`--workers` မသုံးပါနဲ့) run ပါ — လုပ်နေတဲ့ job တွေက အဲဒီ process ထဲမှာ ရှိတာမို့ပါ။

> **V22.1 — Browser ပိတ်လည်း၊ server ပြန်စလည်း job ဆက်လုပ်:** Job တွေက server ပေါ်မှာ run တာမို့ browser ပိတ်လည်း မရပ်ပါ (upload ပြီးတာနဲ့ page ပိတ်လို့ရပြီ)။ Server ပြန်စသွားရင် (`Restart=always` က ၅ စက္ကန့်နဲ့ ပြန်တင်) အလုပ်လုပ်နေတဲ့ job ကို app က **သူ့ဟာသူ ဆက်လုပ်** ပါတယ် (log မှာ `continuing it by itself` ပေါ်)။
>
> **RAM နည်းရင် swap ထည့်ပါ** (Whisper + ffmpeg က memory များပြီး ကုန်ရင် Linux က app ကို ရပ်ပစ်ပါတယ် — "server ချိတ်ဆက်မရ" ဖြစ်ရတဲ့ အကြောင်းရင်း တစ်ခု ဖြစ်နိုင်):
> ```bash
> free -m                                   # Swap က 0 ဆိုရင် ထည့်သင့်
> sudo fallocate -l 4G /swapfile && sudo chmod 600 /swapfile && sudo mkswap /swapfile && sudo swapon /swapfile
> echo '/swapfile none swap sw 0 0' | sudo tee -a /etc/fstab
> sudo journalctl -u recap -n 100 --no-pager   # ရပ်သွားတဲ့အကြောင်း ("Killed" / "Out of memory") ကြည့်
> ```

## အဆင့် ၇ — စမ်းကြည့်ပါ

1. ကိုယ့်ကွန်ပျူတာမှာ: `curl http://13.231.227.226:8000/api/health` → `{"ok":true,"version":"V22.3",…}` (`APP_PASSWORD` ထားရင် `curl -u x:ကိုယ့်password …` လို့ ရိုက်ပါ)။
2. Browser မှာ `http://13.231.227.226:8000` ဖွင့်ပါ (password ထားရင် မေးပါလိမ့်မယ်)။
3. **Gemini API** card မှာ key ထည့် (<https://aistudio.google.com/apikey>) → **Save** → **Test (အလကား)** → ✅ ပေါ်ရင် အဆင်သင့်။ (Test က စာမထုတ်ပါဘူး၊ credit မကုန်ပါဘူး။) AI Studio က အခု `AQ.` နဲ့စတဲ့ key ကိုပဲ ထုတ်ပေးပါတယ် — ပုံမှန်ပါပဲ။ 401 ပေါ်ရင် page ပေါ်က စာအတိုင်း စစ်ပါ (key အပြည့်အစုံ ကူးထားလား၊ key အသစ်ထပ်ထုတ်၊ model ကို `gemini-flash-latest` / `gemini-3.8-flash` ပြောင်းစမ်း)။
4. ဗီဒီယို အတို (၁–၂ မိနစ်) တစ်ခုနဲ့ အစမ်းလုပ်ကြည့်ပါ။ Job စတာနဲ့ page မှာ အဆင့်တွေ ဖြတ်သွားတာ မြင်ရမယ်။
5. **V22 — 📖 ဇာတ်လမ်းပြောဟန် စမ်းချင်ရင်:** စာသားပုံစံမှာ **📖 ဇာတ်လမ်းပြောဟန်** ကို ရွေး၊ "✍️ စာကို အရင်ပြင်မယ်" ကို ✔ ထားပါ။ ဒီပုံစံက Whisper ပြီးတဲ့အထိ စောင့်ပြီး စာအားလုံးကို အချိန်အလိုက်စီကာ Gemini ဆီ ပို့ပြီး "ဇာတ်လမ်းပြောပြနေသလို ရေးပါ" လို့ ခိုင်းမှ အသံ / စာတန်း ဆက်လုပ်တာမို့ ပထမစာ မပေါ်ခင် အရင်ထက် ကြာပါတယ်။ **၁–၂ မိနစ် ဗီဒီယိုအတိုနဲ့ အရင်စမ်းပြီး review page မှာ ဖတ်ကြည့်ပါ** (အသေးစိတ် — README ရဲ့ "V22" အပိုင်း)။

---

## Google Drive ချိတ်ချင်ရင် (မလိုအပ်ပါ)

Google က OAuth redirect လိပ်စာကို `https://` (သို့) `localhost` ပဲ လက်ခံလို့ `http://13.231.227.226:8000` ကနေ **Connect Google Drive** ကို နှိပ်လို့ မရပါဘူး။ V20 မှာလိုပဲ **တစ်ခါတည်း SSH tunnel** နဲ့ ချိတ်ပါ:

1. Google Cloud Console မှာ **Desktop app** OAuth client လုပ် (README က "Google Drive" အပိုင်း) → JSON ကို VPS ရဲ့ `~/burmese-movie-recap-ai-v21/data/credentials.json` အဖြစ် ထား (သို့ `.env` မှာ `GOOGLE_CLIENT_ID` / `GOOGLE_CLIENT_SECRET`)၊ ပြီးရင် `sudo systemctl restart recap`။
2. **ကိုယ့်ကွန်ပျူတာမှာ** (VPS ထဲမှာ မဟုတ်ပါ):
   ```bash
   ssh -i key.pem -L 8000:127.0.0.1:8000 ubuntu@13.231.227.226
   ```
   အဲဒီ terminal ကို ဖွင့်ထားပြီး ကိုယ့်ကွန်ပျူတာ browser မှာ **`http://127.0.0.1:8000`** ကို ဖွင့် → Drive card မှာ **Connect Google Drive** နှိပ် → Google မှာ ခွင့်ပြု။
   (ကိုယ့်ကွန်ပျူတာမှာ port 8000 ကို တခြား program သုံးနေရင် `-L 8080:127.0.0.1:8000` လို့ရိုက်ပြီး `http://127.0.0.1:8080` ကို ဖွင့်ပါ။)
3. ချိတ်ပြီးရင် token က **server ပေါ်မှာ** (`data/drive_token.json`) သိမ်းလို့ ပြီးနောက်ပိုင်း `http://13.231.227.226:8000` ကနေ တင်တဲ့ job တွေကိုလည်း Drive ထဲ အလိုအလျောက် တင်ပေးပါတယ်။ Tunnel ကို ပြန်ပိတ်လို့ရပါပြီ။
4. Google Cloud မှာ OAuth consent screen ကို **In production** လုပ်ထားပါ (Testing ဆို Drive login က ၇ ရက်နဲ့ ကုန်တယ်)။

> ⚠️ ဒီ Drive ချိတ်နည်းကို Google ရဲ့ တကယ့် server နဲ့ မစမ်းနိုင်ခဲ့ပါ (V20 ရဲ့ နည်းအတိုင်းပါ)။ အဆင်မပြေရင် Drive ကို မသုံးဘဲ ပြီးတဲ့ ဗီဒီယိုကို website ကနေ တိုက်ရိုက် download ယူပါ။

## ပိုလုံခြုံချင်ရင် — port ကို လုံးဝ မဖွင့်ဘဲ SSH tunnel နဲ့ပဲ သုံးခြင်း

`.env` မှာ `HOST=127.0.0.1` ထား၊ Security Group ကနေ port 8000 rule ကို **ဖျက်** (SSH 22 ပဲ ကျန်)၊ ပြီးတော့ သုံးချင်တိုင်း ကိုယ့်ကွန်ပျူတာမှာ `ssh -i key.pem -L 8000:127.0.0.1:8000 ubuntu@13.231.227.226` ဖွင့်ပြီး `http://127.0.0.1:8000` ကို သုံးပါ။ ဒီနည်းက traffic ကို SSH နဲ့ encrypt လုပ်ပေးတာမို့ HTTP ရဲ့ အားနည်းချက် မရှိတော့ပါဘူး။

---

## ပြဿနာ ဖြေရှင်းနည်း

| ပြဿနာ | အဖြေ |
|---|---|
| Browser မှာ ဖွင့်လို့မရ၊ "ကြာလွန်းလို့ timeout" | (၁) Security Group မှာ port 8000 rule ရှိလား၊ Source က **ကိုယ့်ရဲ့ လက်ရှိ IP** လား (IP ပြောင်းသွားတတ်) — <https://checkip.amazonaws.com> မှာ ကိုယ့် IP ကြည့်ပြီး ပြန်ညှိ။ (၂) App run နေလား: `sudo systemctl status recap`။ (၃) `HOST=127.0.0.1` ထားထားလား။ |
| "Connection refused" | App မပွင့်သေး / ရပ်နေ: `journalctl -u recap -n 80 --no-pager` |
| Password မေးပြီး ထပ်ထပ်မေးနေ | `APP_PASSWORD` မမှန်ဘူး (စာလုံးအကြီးအသေး၊ space)။ User name ကတော့ ဘာရိုက်ရိုက်ရ။ |
| `User location is not supported for the API use` | VPS က Gemini မပံ့ပိုးတဲ့ နိုင်ငံမှာ ရှိနေတာ။ Tokyo / Singapore / US စတာ သုံးပါ။ |
| ဗီဒီယို upload လုပ်ရင် ပြတ်သွား | `.env` မှာ `MAX_UPLOAD_MB` ထားထားရင် ကျော်တာ၊ ဒါမှမဟုတ် disk ပြည့်တာ: `df -h`။ |
| စာတန်းထည့်တဲ့အခါ "libass မပါဘူး" | `sudo apt install -y ffmpeg` ပြီးရင် `.env` ထဲ `FFMPEG_PATH=/usr/bin/ffmpeg` ထည့်ပါ။ |
| Disk ပြည့်လာ | `.env` မှာ `RETENTION_HOURS=48` ထည့်ပါ (ပြီးတဲ့ဖိုင်တွေ ၄၈ နာရီမှာ အလိုအလျောက်ဖျက်)။ ဖိုင်တွေကို `~/burmese-movie-recap-ai-v21/data/jobs/` မှာ သိမ်းပါတယ်။ |
| Drive ချိတ်လို့မရ | အပေါ်က "Google Drive ချိတ်ချင်ရင်" ကို SSH tunnel နဲ့ လုပ်ပါ။ `redirect_uri_mismatch` ဆိုရင် OAuth client က **Desktop app** မဟုတ်လို့ ဖြစ်နိုင်။ |

---

## သိထားရမယ့် လုံခြုံရေးအချက်များ

- Gemini key ကို `data/users/local/settings.json` ထဲမှာ (V20 ရဲ့ `data/settings.json` လို) သိမ်းပါတယ် — ဖိုင်ကို server user တစ်ယောက်ပဲ ဖတ်လို့ရအောင် (`chmod 600`) ထားပြီး စာသားအတိုင်း မဖတ်ရအောင် လျှို့ဝှက်ထားပါတယ် (`cryptography` ကို `venv/bin/pip install cryptography` နဲ့ သွင်းထားရင် ပိုခိုင်မာတဲ့ encryption သုံးတယ်)။ ဒါပေမယ့် VPS ကို ဝင်လို့ရသူ (ကိုယ်၊ AWS account ပိုင်ရှင်) ကတော့ ဖတ်နိုင်ပါတယ်။ `data/` folder ကို တခြားသူနဲ့ မမျှဝေပါနဲ့။
- ဒီ website မှာ ဝင်သူတိုင်းက ကိုယ်နဲ့ **တူညီတဲ့ အခွင့်အရေး** ရပါတယ် (key ပြောင်းခြင်း၊ job ဖျက်ခြင်း၊ ပြီးတဲ့ဗီဒီယို download လုပ်ခြင်း အပါအဝင်)။ ဒါကြောင့် အဆင့် ၂ (Security Group) / `APP_PASSWORD` ကို မဖြစ်မနေ သုံးပါ။
- တခြား website တစ်ခုက ကိုယ့် browser ကနေ ဒီ website ကို ခိုးခိုင်းလို့ မရအောင် (Origin စစ်၊ iframe ပိတ်) ကာကွယ်ထားပါတယ်။
- တင်တဲ့ ဗီဒီယိုက **ကိုယ်ပိုင် / လိုင်စင်ရ** ဖြစ်ရပါမယ် — တာဝန်က ကိုယ့်မှာပါ။
- AWS က **ထွက်သွားတဲ့ data (egress)** ကို ကောက်ခံတတ်ပါတယ် — ဗီဒီယိုကြီးတွေ အကြိမ်များစွာ download လုပ်ရင် ဘေလ်တက်နိုင်လို့ AWS Billing alert ထားပါ။

## Update လုပ်နည်း (V21 / V21.1 / V21.2 / V21.3 / V22 / V22.1 / V22.2 ကနေ V22.3 သို့၊ ဒါမှမဟုတ် နောက်ပိုင်း version အသစ်ထွက်ရင်)

V21 (ဒါမှမဟုတ် V21.1 / V21.2 / V21.3) ကို တင်ပြီးသားဆိုရင် **`.env` နဲ့ `data/` (ကိုယ့် key၊ job တွေ) ကို မထိဘဲ** code ကိုပဲ အစားထိုးပါ။ zip အသစ်ကို VPS ပေါ် `scp` နဲ့ ပို့ပြီး (အဆင့် ၃ လိုပဲ) VPS ထဲမှာ:

```bash
sudo systemctl stop recap
cd ~
rm -rf new_code && mkdir new_code && cd new_code
unzip ../burmese-movie-recap-ai-v22.3.zip
cd ..
# code ကိုပဲ အစားထိုး (.env၊ data/၊ venv/ ကို မထိပါ)
cp -r new_code/burmese-movie-recap-ai-v22.3/backend new_code/burmese-movie-recap-ai-v22.3/frontend new_code/burmese-movie-recap-ai-v22.3/fonts new_code/burmese-movie-recap-ai-v22.3/deploy new_code/burmese-movie-recap-ai-v22.3/README.md ~/burmese-movie-recap-ai-v21/
cd ~/burmese-movie-recap-ai-v21
# V22.3 — Whisper model: .env ထဲမှာ WHISPER_MODEL=base (V21 - V22.2 က ကူးထားတာ) ရှိရင် code အသစ်က အဲဒါကို ဆက်လိုက်မယ်၊ auto ပြောင်းပါ
grep -n "^WHISPER" .env || true
sed -i 's/^WHISPER_MODEL=.*/WHISPER_MODEL=auto/; s/^WHISPER_DEVICE=.*/WHISPER_DEVICE=auto/' .env
venv/bin/pip install -r backend/requirements.txt      # V22 မှာ package အသစ် မထပ်တိုးပါ၊ ပြီးသားဆိုရင် မြန်မြန်ပြီးမယ်
sudo systemctl start recap
curl http://13.231.227.226:8000/api/health             # "version":"V22.3" ပေါ်ရမယ် (APP_PASSWORD ထားရင် curl -u x:ကိုယ့်password …)
rm -rf ~/new_code
```

- Browser မှာ page ကို **refresh** လုပ်ပါ (ဖုန်းမှာ tab ကို ပိတ်ပြီး ပြန်ဖွင့်တာ အသေချာဆုံး) — page အသစ်မှာ (V21 ကလာတာဆိုရင် "✍️ စာကို အရင်ပြင်မယ်" checkbox၊ V21.1 ကလာတာဆိုရင် စာပြင်တဲ့ စာကြောင်းတိုင်းမှာ "⏱ အချိန်ဘား") ပေါ်လာပါလိမ့်မယ်။
- V21 နဲ့ စပြီး ပြီးသားဖြစ်တဲ့ job တွေ၊ ရပ်နေတဲ့ job တွေ ပျက်စီးမှု မရှိပါ။ ရပ်သွားတဲ့ job တွေက "server ပြန်စလို့ ရပ်သွား" လို့ ပေါ်ပြီး **ဆက်လုပ်မယ်** နှိပ်ရင် လုပ်ပြီးသားအပိုင်းတွေ မပြန်လုပ်ဘဲ ဆက်သွားပါတယ်။
- **V21.2 ရဲ့ အချိန်ဘား** — စာပြင်တဲ့ page မှာ စာကြောင်းတိုင်းရဲ့ ဘေးနား (ဖုန်းမှာ box အောက်) က ဘားနဲ့ စာတန်း / အသံကို ဘယ်စက္ကန့်မှာ စမလဲ တစ်ကြောင်းချင်း ညှိလို့ရပါတယ်။ အပ်ဒိတ်လုပ်ချိန်မှာ စာပြင်ဖို့ စောင့်နေတဲ့ job ရှိရင် မပျက်ပါ — ဘာမှ မရွှေ့ရသေးတဲ့ အနေအထားကနေ စပြီး ဘားတွေ ပါလာပါလိမ့်မယ်။
- **V22.3 ရဲ့ ပြောင်းလဲမှု** — "အသံနဲ့ စာမညီ" ပြဿနာ: (၁) Whisper model `base` အစား **`auto`** (CPU → `small`၊ GPU → `large-v3-turbo`) — ⚠️ အပေါ်က `sed` နဲ့ `.env` ကို ပြောင်းမှ အသက်ဝင်မယ်၊ ပထမကြိမ် model download (~၅၀၀ MB) ကြောင့် စတင်ချိန်နည်းနည်းကြာမယ်၊ `base` ထက် ပိုနှေးနိုင်တယ် (တိုင်းမထား)။ (၂) စာကြောင်းအချိန်ကို **စကားလုံးအချိန်** နဲ့ ယူ၊ (၃) အသံကို **တိတ်ဆိတ်တဲ့နေရာမှာ** ဖြတ်၊ (၄) ဘာသာစကားကို စကားပြော ၄ ပိုင်းကနေ ခန့်မှန်း (`WHISPER_LANGUAGE=en` နဲ့ ကိုယ်တိုင်သတ်မှတ်လို့ရ)၊ (၅) `AUDIO_TRACK=1` — track များတဲ့ ကားအတွက်။ ကိုယ့်ကားနဲ့ စစ်ကြည့်ဖို့: `cd ~/burmese-movie-recap-ai-v21/backend && ../venv/bin/python asr.py check ~/film.mp4 90`။ Job ပြေးနေရင် update မလုပ်ခင် ပြီးအောင်စောင့်ပါ။
- **V22.2 ရဲ့ ပြောင်းလဲမှု** — (၁) **Claude / Groq ကို ဖျက်ပြီး — Gemini ပဲ ကျန်** (V22.1 က သိမ်းထားတဲ့ Claude / Groq key၊ model၊ ရွေးချယ်မှုကို server စတက်ချိန်မှာ အလိုအလျောက် ဖျက်ပါတယ်၊ Gemini key က ကျန်)။ (၂) **Gemini ကြာရင် စောင့်ပုံ ပြင်ထား** — `.env` မှာ `GEMINI_REWRITE_TIMEOUT=300`၊ `REWRITE_BATCH=15` (default တွေပါ၊ ဘာမှ မထည့်လည်းရ)။ (၃) **ffmpeg ဖြတ်တာ တိကျ** — `-shortest` ဖယ်၊ အသံနဲ့ပုံ ညီ၊ ဖိုင်က ပုံနဲ့ တူတူ ဆုံး။ **V22 ရဲ့ ပြောင်းလဲမှု (သမိုင်း)** — (၁) API ၃ နေရာ (V22.2 မှာ ဖျက်ပြီး) (၂) စာသားပုံစံ **၂ မျိုးပဲ** ကျန် — အရင်ပုံစံ (Dub၊ ရုပ်ရှင် Recap …) တွေ ကို ဖျက်ပြီးပါပြီ၊ browser မှာ သိမ်းထားတာက `တိုက်ရိုက်စာတန်းထိုးဟန်` ပြန်ဖြစ်ပါမယ်။ **အရင် version က ရပ်နေတဲ့ / စာပြင်ဖို့ စောင့်နေတဲ့ job** — အရင် "ဘာသာပြန်" ပုံစံနဲ့ စခဲ့တာ (အခု တိုက်ရိုက်စာတန်းထိုးဟန် နဲ့ prompt တူ) ဆိုရင် ရေးပြီးသား မြန်မာစာကို ပြန်တွေ့ပြီး ဆက်သွားပါမယ်။ တခြားပုံစံအဟောင်း (Dub၊ ရုပ်ရှင် Recap …) နဲ့ စခဲ့တာတွေက အဲဒီပုံစံ မရှိတော့လို့ `တိုက်ရိုက်စာတန်းထိုးဟန်` နဲ့ **မြန်မာစာကို ပြန်ရေး** ပါမယ် (Whisper စာမှတ်တမ်းက မပျက်)၊ စာပြင်ဖို့ စောင့်နေတဲ့ အဲဒီ job ဆိုရင်တော့ "မြန်မာစာ ဖိုင် မပြည့်စုံတော့ပါဘူး — Cancel လုပ်ပြီး ပြန်တင်ပါ" လို့ ပေါ်မယ် — update မလုပ်ခင် ပြီးအောင် လုပ်ထားတာ အကောင်းဆုံးပါ။ (၃) `.env` ထဲ ဘာမှ ထပ်ထည့်စရာ မလိုပါ (`.env.example` မှာ အသစ်တွေ ကြည့်ပါ)။
- **စာပြင်ဖို့ စောင့်နေတဲ့ job** (V21.1 ကစပြီး) က server ပြန်စတာကို ခံပါတယ် — "ကိုယ့် Job တွေ" ထဲက **✍️ ပြင်မယ်** နဲ့ ပြန်ဝင်ပြီး ပြင်ထားတာတွေ ကျန်နေတာ တွေ့ရပါမယ်။ ၃ ရက် ပြန်မလာရင်တော့ disk မပြည့်အောင် အလိုအလျောက် ဖျက်ပါတယ်။
