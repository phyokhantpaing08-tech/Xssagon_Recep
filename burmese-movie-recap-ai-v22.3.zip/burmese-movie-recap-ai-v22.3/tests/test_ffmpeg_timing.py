"""V22.2 (task 2): ffmpeg cuts / joins at exactly the right position - PROVEN BY MEASURING.

A small test film is generated (tests/ffmpeg_fixtures.py): every picture carries its frame number as a barcode and the sound has a
1 kHz beep every 2 s starting at 0. The same film is made as MP4, as MKV starting at 2 s and at 3600 s, as MPEG-TS (starts at ~1.4 s),
with the sound starting 0.3 s after the picture, and with the picture starting 0.5 s after the sound - what real downloads look
like. The finished files are then read back and measured:

* the Burmese narration (beeps at 0, 3, 7.5 s) must start at the first picture: offset <= 20 ms (measured: <= 1 ms),
* no picture is lost or repeated (frame numbers run 0..n-1) and the file ends within one frame of the picture's end,
* the same for a narration that is shorter / longer than the picture (the old `-shortest` chopped the picture),
* subtitles appear and disappear within one frame of their times, the original sound keeps its distance from the picture,
* a thumbnail at second X shows the frame at X (no key-frame snapping), the extracted sound starts at the first picture, the
  Whisper chunks start where they really start, time_stretch keeps its exact length, SRT / VTT keep millisecond precision.
"""
import os
import shutil
import subprocess
import sys
import tempfile
import unittest
import wave
from pathlib import Path

import numpy as np

HERE = os.path.dirname(__file__)
sys.path.insert(0, HERE)
sys.path.insert(0, os.path.join(HERE, '..', 'backend'))


def _find_font():
    cands = [os.getenv('TEST_BURMESE_FONT') or '', os.path.join(HERE, '..', 'fonts', 'Padauk-Regular.ttf'),
             '/usr/share/fonts/truetype/noto/NotoSansMyanmar-Regular.ttf', '/usr/share/fonts/truetype/padauk/Padauk-Regular.ttf']
    return next((c for c in cands if c and os.path.isfile(c)), '')


FONT = _find_font()
if FONT:
    os.environ['SUBTITLE_FONT'] = FONT

import ffmpeg_fixtures as F   # noqa: E402
import media                  # noqa: E402
import timing as T            # noqa: E402

HAVE = bool(shutil.which('ffmpeg') and shutil.which('ffprobe'))
SECONDS = 10.0
FRAME = 1.0 / F.FPS
BEEPS = [0.0, 3.0, 7.5]
VARIANTS = {
    'mp4': dict(),
    'mkv+2s': dict(container='mkv', ts_offset=2.0),
    'mkv+3600s': dict(container='mkv', ts_offset=3600.0),
    'ts': dict(container='ts'),
    'audio-late': dict(container='mkv', audio_delay=0.3),
    'video-late': dict(container='mkv', video_delay=0.5),
}
SUBS = [{'start': 2.0, 'end': 3.5, 'burmese': 'မင်္ဂလာပါ'}, {'start': 6.0, 'end': 7.0, 'burmese': 'ကျေးဇူးတင်ပါတယ်'}]


def barcode_of_image(path):
    raw = subprocess.run([F.FFMPEG, '-v', 'error', '-i', str(path), '-vf', f'crop={F.BITS * F.BLOCK}:{F.BLOCK}:0:0', '-f', 'rawvideo', '-pix_fmt', 'gray', '-'],
                         stdout=subprocess.PIPE, stderr=subprocess.PIPE, check=True).stdout
    f = np.frombuffer(raw, dtype=np.uint8).reshape(F.BLOCK, F.BITS * F.BLOCK)
    centres = f[F.BLOCK // 2, F.BLOCK // 2::F.BLOCK][:F.BITS]
    return int(sum((1 << k) for k, v in enumerate(centres) if v > 125))


def wav_onsets(path):
    with wave.open(str(path)) as w:
        rate, raw = w.getframerate(), w.readframes(w.getnframes())
    x = np.frombuffer(raw, dtype='<i2').astype(np.float32) / 32768.0
    return [float(t) for t in F.onsets(x, rate)], len(x) / float(rate)


@unittest.skipUnless(HAVE, 'ffmpeg and ffprobe are needed')
class Base(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.dir = Path(tempfile.mkdtemp(prefix='recap_timing_'))
        cls.films, cls.cache = {}, {}
        for name, kw in VARIANTS.items():
            ext = '.ts' if kw.get('container') == 'ts' else '.mkv' if kw.get('container') == 'mkv' else '.mp4'
            cls.films[name] = F.make_film(cls.dir / (name.replace('+', '_') + ext), seconds=SECONDS, **kw)

    @classmethod
    def tearDownClass(cls):
        shutil.rmtree(cls.dir, True)

    def narration(self, seconds):
        key = ('narr', seconds)
        if key not in self.cache:
            self.cache[key] = F.make_narration(self.dir / f'narr_{seconds}.wav', BEEPS, seconds)
        return self.cache[key]

    def made(self, kind, name, narr=SECONDS):
        """The finished file of one path (kind = mux / render / orig), made once and reused by every test."""
        key = (kind, name, narr)
        if key in self.cache:
            return self.cache[key]
        src = self.films[name]
        total = media.picture_duration(src)
        out = self.dir / f'{kind}_{name.replace("+", "_")}_{narr}.mp4'
        if kind == 'mux':
            work = self.dir / f'narr_copy_{name}_{narr}.wav'
            shutil.copy(self.narration(narr), work)                  # fit_wav changes the file it is given: give it a copy
            media.mux_narration(str(src), str(work), str(out), total)
        else:
            work_dir = self.dir / f'w_{kind}_{name}_{narr}'.replace('+', '_')
            work_dir.mkdir()
            narrated = None
            if kind == 'render':
                narrated = self.dir / f'narr_copy_r_{name}_{narr}.wav'
                shutil.copy(self.narration(narr), narrated)
            media.render_with_subtitles(work_dir, str(src), [] if kind != 'sub' else SUBS, str(narrated) if narrated else None, str(out), total, preset='ultrafast')
        self.cache[key] = out
        return out

    # ---- instruments
    def measure(self, src, out):
        a, b = F.video_frames(src), F.video_frames(out)
        info = F.probe(out)
        first = b[0][1]
        return {'frames_in': len(a), 'frames_out': len(b), 'idx': [i for i, _ in b], 'first_t': first, 'duration': info['format']['duration'],
                'video_duration': info['video']['duration'],
                'onsets': [o - first for o in F.audio_onsets_on_the_timeline(out)]}


class ProbeTests(Base):
    def test_every_variant_reports_where_the_picture_starts_and_how_long_it_is(self):
        want_start = {'mp4': 0.0, 'mkv+2s': 2.0, 'mkv+3600s': 3600.0, 'ts': 1.48, 'audio-late': 0.0, 'video-late': 0.52}
        for name, src in self.films.items():
            with self.subTest(name):
                info = media.probe_timing(src)
                self.assertAlmostEqual(info['v_start'], want_start[name], delta=0.03)
                self.assertAlmostEqual(info['picture'], SECONDS, delta=FRAME)          # the PICTURE's length, not the container's
                self.assertAlmostEqual(info['fps'], F.FPS, delta=0.01)
                self.assertAlmostEqual(media.picture_duration(src), SECONDS, delta=FRAME)
                self.assertGreaterEqual(info['offset'], -0.0001)

    def test_unreadable_file_is_none_and_duration_falls_back(self):
        bad = self.dir / 'bad.mp4'
        bad.write_bytes(b'not a video')
        self.assertIsNone(media.probe_timing(bad))
        self.assertIsNone(media.probe_timing(self.dir / 'missing.mp4'))


class MuxTests(Base):
    def check(self, name, kind, narr=SECONDS):
        m = self.measure(self.films[name], self.made(kind, name, narr))
        self.assertEqual(m['frames_out'], m['frames_in'], 'a picture was lost or repeated')
        self.assertEqual(m['idx'], list(range(m['frames_in'])), 'frame numbers must run 0..n-1')
        self.assertAlmostEqual(m['duration'], SECONDS, delta=FRAME, msg=f'file length {m["duration"]}')
        self.assertAlmostEqual(m['video_duration'], SECONDS, delta=FRAME)
        got = m['onsets'][:len(BEEPS)]
        self.assertEqual(len(got), len(BEEPS), m['onsets'])
        for want, have in zip(BEEPS, got):
            self.assertLessEqual(abs(have - want), 0.020, f'{name}/{kind}: narration beep {want}s heard at {have:+.3f}s (limit 20 ms)')
        return m

    def test_mux_copy_path_all_variants(self):
        for name in VARIANTS:
            with self.subTest(name):
                self.check(name, 'mux')

    def test_render_path_all_variants(self):
        for name in VARIANTS:
            with self.subTest(name):
                m = self.check(name, 'render')
                self.assertAlmostEqual(m['first_t'], 0.0, delta=0.001)              # the re-encoded picture starts at 0

    def test_narration_shorter_than_the_picture_does_not_cut_the_picture(self):
        for name in ('mp4', 'video-late'):
            for kind in ('mux', 'render'):
                with self.subTest(f'{name}/{kind}'):
                    self.check(name, kind, 7.9)           # (the old -shortest produced a 7.9 s film out of a 10 s one)

    def test_narration_longer_than_the_picture_ends_with_the_picture(self):
        for name in ('mp4', 'mkv+2s'):
            for kind in ('mux', 'render'):
                with self.subTest(f'{name}/{kind}'):
                    self.check(name, kind, 13.0)

    def test_the_narration_file_is_cut_or_padded_to_the_picture_at_sample_level(self):
        self.made('mux', 'mp4', 7.9)
        self.made('mux', 'mp4', 13.0)
        for L in (7.9, 13.0):
            with wave.open(str(self.dir / f'narr_copy_mp4_{L}.wav')) as w:
                self.assertEqual(w.getnframes(), int(round(SECONDS * w.getframerate())))

    def test_original_sound_keeps_its_distance_from_the_picture(self):
        for name, src in self.films.items():
            with self.subTest(name):
                v0 = media.probe_timing(src)['v_start']
                want = [t - v0 for t in F.audio_onsets_on_the_timeline(src)]
                want = [t for t in want if t >= -0.005]                              # sound before the first picture is dropped
                m = self.measure(src, self.made('orig', name))
                self.assertEqual(m['frames_out'], m['frames_in'])
                self.assertEqual(m['idx'], list(range(m['frames_in'])))
                self.assertEqual(len(m['onsets']), len(want), (m['onsets'], want))
                for w, h in zip(want, m['onsets']):
                    self.assertLessEqual(abs(w - h), 0.020, (name, want, m['onsets']))


class ExtractTests(Base):
    def test_extracted_sound_starts_at_the_first_picture(self):
        for name, src in self.films.items():
            with self.subTest(name):
                wav = self.dir / f'x_{name.replace("+", "_")}.wav'
                media.extract_audio_wav(str(src), str(wav))
                v0 = media.probe_timing(src)['v_start']
                want = [t for t in (o - v0 for o in F.audio_onsets_on_the_timeline(src)) if t >= -0.005]
                got, _ = wav_onsets(wav)
                self.assertEqual(len(got), len(want), (got, want))
                for w, h in zip(want, got):
                    self.assertLessEqual(abs(w - h), 0.020, (name, want, got))

    def test_a_film_without_sound_says_so(self):
        silent = F.make_film(self.dir / 'silent.mp4', seconds=2.0, audio=False)
        with self.assertRaises(RuntimeError) as cm:
            media.extract_audio_wav(str(silent), str(self.dir / 'silent.wav'))
        text = str(cm.exception)
        self.assertTrue('does not contain any stream' in text or 'matches no streams' in text or 'no audio' in text.lower(), text)


@unittest.skipUnless(FONT, 'a Burmese font is needed to burn subtitles')
class SubtitleTimingTests(Base):
    def test_subtitles_appear_and_disappear_within_one_frame(self):
        for name in ('mp4', 'mkv+2s', 'ts', 'video-late'):
            with self.subTest(name):
                out = self.made('sub', name)
                frames = F.video_frames(out)
                bright = F.band_brightness(out)
                self.assertEqual(len(bright), len(frames))
                t0 = frames[0][1]
                shown = [t - t0 for (_, t), b in zip(frames, bright) if b > 90]
                self.assertTrue(shown, 'no subtitle was drawn')
                runs, start, prev = [], shown[0], shown[0]
                for t in shown[1:]:
                    if t - prev > 1.5 * FRAME:
                        runs.append((start, prev + FRAME))
                        start = t
                    prev = t
                runs.append((start, prev + FRAME))
                self.assertEqual(len(runs), len(SUBS), runs)
                for (a, b), seg in zip(runs, SUBS):
                    self.assertLessEqual(abs(a - seg['start']), FRAME + 0.001, (name, runs))
                    self.assertLessEqual(abs(b - seg['end']), FRAME + 0.001, (name, runs))

    def test_every_picture_is_kept_when_subtitles_are_burned(self):
        m = self.measure(self.films['mkv+2s'], self.made('sub', 'mkv+2s'))
        self.assertEqual(m['idx'], list(range(m['frames_in'])))
        self.assertAlmostEqual(m['duration'], SECONDS, delta=FRAME)


@unittest.skipUnless(FONT, 'a Burmese font is needed to burn subtitles')
class ThumbnailTests(Base):
    def test_the_picture_shown_is_the_one_at_the_asked_second(self):
        for name in ('mp4', 'mkv+2s', 'ts', 'video-late'):
            for at in (0.0, 3.01, 5.5, 9.3):                    # (the key-frame is at 0 only: gop 250 - every other second is a "cut in the middle")
                with self.subTest(f'{name} @ {at}'):
                    out = self.dir / f'thumb_{name.replace("+", "_")}_{at}.jpg'
                    media.render_frame(self.films[name], self.dir / 'thumbwork', at, 'မင်္ဂလာပါ', None, {}, out)
                    got = barcode_of_image(out)
                    self.assertLessEqual(abs(got - round(at * F.FPS)), 1, f'asked {at}s (frame {round(at * F.FPS)}), got frame {got}')


@unittest.skipUnless(HAVE, 'ffmpeg is needed')
class AudioMathTests(unittest.TestCase):
    def test_time_stretch_keeps_the_exact_length(self):
        sr = T.SR
        for n in (int(3.7 * sr), int(0.43 * sr), int(12.0 * sr) + 13):
            x = (0.3 * np.sin(2 * np.pi * 440 * np.arange(n) / sr)).astype(np.float32)
            for factor in (1.02, 1.1, 1.25, 1.5, 2.0, 2.7):
                with self.subTest(f'{n} x{factor}'):
                    self.assertEqual(len(T.time_stretch(media.FFMPEG, x, sr, factor)), int(round(n / factor)))

    def test_fit_samples(self):
        x = np.ones(5, dtype=np.float32)
        self.assertEqual(T.fit_samples(x, 5).tolist(), [1] * 5)
        self.assertEqual(T.fit_samples(x, 3).tolist(), [1] * 3)
        self.assertEqual(T.fit_samples(x, 8).tolist(), [1] * 5 + [0] * 3)
        self.assertEqual(len(T.fit_samples(x, 0)), 0)

    def test_fit_wav_cuts_pads_and_leaves_an_exact_file_alone(self):
        d = Path(tempfile.mkdtemp())
        self.addCleanup(shutil.rmtree, d, True)
        p = d / 'a.wav'
        for have, secs in ((120000, 3.0), (120000, 8.25), (120000, 5.0), (1000, 0.0), (3120007, 125.5)):
            T.write_wav(p, np.full(have, 0.2, dtype=np.float32), 24000)
            before = p.stat().st_mtime_ns
            got = T.fit_wav(p, secs)
            with wave.open(str(p)) as w:
                self.assertEqual(w.getnframes(), int(round(secs * 24000)))
            x, _ = T.read_wav(p)
            if len(x) and have > int(round(secs * 24000)) - 1:
                self.assertAlmostEqual(float(x[0]), 0.2, places=3)
            if have == int(round(secs * 24000)):
                self.assertEqual(p.stat().st_mtime_ns, before, 'an exact file must not be rewritten')
            self.assertEqual(got, (have, int(round(secs * 24000))))

    def test_mix_to_wav_is_exactly_as_long_as_asked(self):
        d = Path(tempfile.mkdtemp())
        self.addCleanup(shutil.rmtree, d, True)
        p = d / 'mix.wav'
        T.mix_to_wav(p, 10.0, [(1.0, 2.0, 0)], lambda k: np.full(24000, 0.1, dtype=np.float32))
        self.assertAlmostEqual(T.wav_seconds(p), 10.0, delta=1.0 / 24000)


@unittest.skipUnless(HAVE, 'ffmpeg is needed')
class ChunkTests(unittest.TestCase):
    def test_whisper_chunks_start_where_they_really_start(self):
        import asr
        d = Path(tempfile.mkdtemp())
        self.addCleanup(shutil.rmtree, d, True)
        sr, total = 16000, 85
        x = np.zeros(total * sr, dtype=np.float32)
        for k in range(total):                                   # a 5 ms click at every whole second
            x[k * sr:k * sr + 80] = 0.8
        src = d / 'src.wav'
        T.write_wav(src, x, sr)
        chunks = asr.split_audio(src, d / 'chunks', 20)
        self.assertGreaterEqual(len(chunks), 4)
        starts = asr.chunk_starts(chunks, 20)
        for i, c in enumerate(chunks):
            y, rate = T.read_wav(c)
            first = float(np.flatnonzero(np.abs(y) > 0.4)[0]) / rate
            absolute = starts[i] + first                          # where that click really is on the film's timeline
            self.assertLessEqual(abs(absolute - round(absolute)), 0.001, f'chunk {i} starts at {starts[i]} but its click is at {absolute}')

    def test_unreadable_chunk_falls_back_to_the_nominal_length(self):
        import asr
        d = Path(tempfile.mkdtemp())
        self.addCleanup(shutil.rmtree, d, True)
        good = d / 'a.wav'
        T.write_wav(good, np.zeros(16000 * 3, dtype=np.float32), 16000)
        bad = d / 'b.wav'
        bad.write_bytes(b'junk')
        self.assertEqual(asr.chunk_starts([good, bad, good], 20), [0.0, 3.0, 23.0])


class SubtitleFileTests(unittest.TestCase):
    def test_srt_and_vtt_keep_millisecond_precision(self):
        d = Path(tempfile.mkdtemp())
        self.addCleanup(shutil.rmtree, d, True)
        segs = [{'start': 61.2345, 'end': 62.0, 'burmese': 'a'}, {'start': 3599.9996, 'end': 3600.0504, 'burmese': 'b'},
                {'start': 0.0, 'end': 0.001, 'burmese': 'c'}]
        media.write_subtitle_files(d, segs)
        srt = (d / 'burmese.srt').read_text(encoding='utf-8')
        vtt = (d / 'burmese.vtt').read_text(encoding='utf-8')
        self.assertRegex(srt, r'00:01:01,23[45] --> 00:01:02,000')
        self.assertIn('01:00:00,000 --> 01:00:00,050', srt)         # 3599.9996 s rounds UP to the next second, not to 59,1000
        self.assertIn('00:00:00,000 --> 00:00:00,001', srt)
        self.assertIn('01:00:00.000 --> 01:00:00.050', vtt)
        self.assertTrue(vtt.startswith('WEBVTT'))

    def test_ass_time_is_within_5_ms(self):
        for t in (0.0, 1.004, 2.0, 59.995, 3599.999, 7384.567):
            h, m, rest = media.ass_time(t).split(':')
            s = float(h) * 3600 + float(m) * 60 + float(rest)
            self.assertLessEqual(abs(s - t), 0.0051, (t, media.ass_time(t)))


if __name__ == '__main__':
    unittest.main()
