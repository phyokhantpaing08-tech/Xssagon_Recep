"""V22.2: Gemini timeouts and waiting - no real API, a fake HTTP server (mock_gemini.py) that can stall like a slow / overloaded Gemini.

  (a) 2 network failures (read timeouts / refused connections) in a row on one model -> hop to the next model, like 'overloaded'
  (b) a batch that keeps timing out - on one model and on the next - is split in half; every line is written exactly once
  (c) the read timeout (GEMINI_REWRITE_TIMEOUT) and the batch size (REWRITE_BATCH) come from the environment
  (d) only when EVERY model failed (and the patience is over) the job pauses - with the finished work saved on the disk
  plus: the wait ends exactly when the earliest cooldown ends, the page is told the next model and the retry round, every request is logged.
"""
import json
import os
import socket
import sys
import tempfile
import threading
import time
import types
import unittest
import unittest.mock as mock
from unittest.mock import patch

HERE = os.path.dirname(__file__)
sys.path.insert(0, os.path.join(HERE, '..', 'backend'))
sys.path.insert(0, HERE)

import requests                      # noqa: E402

import gemini_client as G            # noqa: E402
import jobs as J                     # noqa: E402
import mock_gemini as M              # noqa: E402
import pipeline                      # noqa: E402
import rewrite as R                  # noqa: E402
from test_pipeline import PipelineBase, TOTAL_LINES, burmese_digits, line_index   # noqa: E402

os.environ.setdefault('GEMINI_THINKING_BUDGET', '')

A, B, C = 'gemini-flash-latest', 'gemini-3.6-flash', 'gemini-3.5-flash-lite'
FIVE = [A, 'gemini-3.6-flash', 'gemini-3.5-flash-lite', 'gemini-3.1-flash-lite', 'gemini-2.5-flash']


class Hooks:
    """Records what the client tells the person; sleeps only a little."""

    def __init__(self, answer=None):
        self.sleeps, self.notes, self.asks = [], [], []
        self.answer = answer
        self.client = None

    def check(self):
        pass

    def note(self, text):
        self.notes.append(text)

    def sleep(self, seconds, why='', **info):
        self.sleeps.append((round(seconds, 2), why, info))
        time.sleep(min(seconds, 0.02))

    def ask(self, kind, message, **info):
        self.asks.append({'kind': kind, 'message': message, 'info': info, 'log': list(self.client.req_log) if self.client else []})
        if self.answer is None:
            raise G.GeminiNeedKey(message, kind)
        return self.answer(self) or {}


def make(hooks, models=(A, B), timeout=0.15, patience=600.0, cooldown=30.0):
    c = G.GeminiClient('KEY', models[0], list(models[1:]), hooks=hooks, timeout=timeout)
    c.patience, c.cooldown = patience, cooldown
    hooks.client = c
    return c


def ask(c, **kw):
    return c.chat('sys', 'INPUT JSON ARRAY:\n["a"]', **kw)


def n_items(payload):
    return len(M._parse_input(payload['contents'][0]['parts'][0]['text']))


def outcomes(c, model=None):
    return [e['outcome'] for e in c.req_log if model is None or e['model'] == model]


# ====================================================================================================== (a) the hop
class HopTests(unittest.TestCase):
    def test_two_timeouts_in_a_row_hop_to_the_next_model(self):
        with M.MockGemini() as mg:
            mg.state.stall = lambda model, payload: 0.5 if model == A else 0           # model A never answers in time
            h = Hooks()
            c = make(h)
            out = ask(c, label='rewrite', lines=3)
        self.assertIn('[', out)
        self.assertEqual((mg.state.count(model=A, action='generateContent'), mg.state.count(model=B, action='generateContent')), (2, 1))
        self.assertEqual(c.active_model, B)
        self.assertEqual([(e['model'], e['outcome'], e['retry']) for e in c.req_log], [(A, 'network', 0), (A, 'network', 1), (B, 'ok', 2)])
        self.assertEqual(c.stats['outcomes'], {'network': 2, 'ok': 1})
        self.assertGreater(c._cool[A], time.time())                                    # A is cooling now, B was not marked
        self.assertNotIn(B, c._cool)
        self.assertEqual([w for _, w, _ in h.sleeps], ['network'])                     # ONE quick pause between the two tries on A
        self.assertEqual(h.sleeps[0][2]['model'], A)
        self.assertTrue(any(f'{A} ဆက်တိုက် 2 ကြိမ်' in n and B in n for n in h.notes), h.notes)   # "hopping to B" is said on the page

    def test_one_timeout_is_not_enough_to_hop(self):
        with M.MockGemini() as mg:
            seen = {'n': 0}

            def stall(model, payload):
                seen['n'] += 1
                return 0.5 if seen['n'] == 1 else 0                                    # only the very first request is slow
            mg.state.stall = stall
            h = Hooks()
            c = make(h)
            ask(c)
        self.assertEqual((mg.state.count(model=A, action='generateContent'), mg.state.count(model=B, action='generateContent')), (2, 0))
        self.assertEqual(c.active_model, A)
        self.assertEqual(outcomes(c), ['network', 'ok'])

    def test_every_request_is_logged_with_model_label_lines_latency_outcome_and_retry(self):
        with M.MockGemini() as mg:
            mg.state.push(M.e503(), model=A, times=1)
            mg.state.push(M.e429_minute('1s'), model=B, times=1)
            h = Hooks()
            c = make(h)
            with patch('builtins.print') as pr:
                ask(c, label='rewrite', lines=15)
        self.assertEqual(len(c.req_log), 3)
        first = c.req_log[0]
        self.assertEqual((first['model'], first['label'], first['lines'], first['outcome'], first['retry']), (A, 'rewrite', 15, 'overloaded', 0))
        self.assertIsInstance(first['latency'], float)
        self.assertEqual([e['outcome'] for e in c.req_log], ['overloaded', 'rate', 'ok'])
        self.assertEqual([e['retry'] for e in c.req_log], [0, 1, 2])
        printed = ' '.join(str(a) for call in pr.call_args_list for a in call.args)
        self.assertIn('label=rewrite lines=15', printed)
        self.assertIn('outcome=overloaded retry=0', printed)

    def test_a_refused_connection_hops_too_but_it_is_not_a_timeout_so_nothing_is_split(self):
        s = socket.socket()
        s.bind(('127.0.0.1', 0))
        port = s.getsockname()[1]
        s.close()                                                                      # nobody listens there: "connection refused"
        with patch.dict(os.environ, {'GEMINI_BASE_URL': f'http://127.0.0.1:{port}/v1beta'}):
            h = Hooks()
            c = make(h, patience=0.2)
            with self.assertRaises(G.GeminiNeedKey):                                   # (no answer given: the person is asked)
                ask(c, split=True)                                                     # GeminiTimeout is NOT raised for a refused connection
        self.assertEqual(h.asks[0]['kind'], 'overloaded')
        before = [e['model'] for e in h.asks[0]['log']]
        self.assertGreaterEqual(before.count(A), 2)
        self.assertGreaterEqual(before.count(B), 2)                                    # both models were tried twice before the person was asked

    def test_overloaded_still_hops_at_once(self):
        with M.MockGemini() as mg:
            mg.state.push(M.e503(), model=A, times=99)
            h = Hooks()
            c = make(h)
            ask(c)
        self.assertEqual(outcomes(c), ['overloaded', 'ok'])
        self.assertEqual(h.sleeps, [])                                                 # no waiting at all


# ====================================================================================================== waiting + pausing
class WaitAndPauseTests(unittest.TestCase):
    def test_when_every_model_is_cooling_the_wait_ends_with_the_earliest_cooldown_and_the_page_is_told(self):
        with M.MockGemini() as mg:
            mg.state.push(M.e503(), times=2)                                           # A and B both overloaded once
            h = Hooks()
            c = make(h, cooldown=7.0)
            ask(c)
        self.assertEqual(len(h.sleeps), 1)
        secs, why, info = h.sleeps[0]
        self.assertEqual(why, 'overloaded')
        self.assertTrue(5.0 < secs <= 7.0, secs)                                       # not a blind 2 / 4 / 8 s back-off: until A may be tried again
        self.assertEqual((info['model'], info['retry']), (A, 1))                       # the page: "next model A in N seconds, round 1"
        self.assertTrue(any(A in n and 'စက္ကန့်' in n for n in h.notes), h.notes)

    def test_no_pause_while_a_model_may_recover_inside_the_patience_window(self):
        with M.MockGemini() as mg:
            seen = {'n': 0}

            def stall(model, payload):
                seen['n'] += 1
                return 0.5 if seen['n'] <= 6 else 0                                    # A, A, B, B, (wait) A, A: all slow - then it recovers
            mg.state.stall = stall
            h = Hooks()
            c = make(h, patience=600)
            ask(c)
        self.assertEqual(h.asks, [])                                                   # the person was never asked
        self.assertEqual(outcomes(c), ['network'] * 6 + ['ok'])
        self.assertTrue(any(why == 'network' and info.get('model') for _, why, info in h.sleeps))

    def test_the_person_is_asked_only_after_every_model_failed_and_the_same_request_then_goes_on(self):
        with M.MockGemini() as mg:
            mg.state.stall = lambda model, payload: 0.5

            def recovered(hooks):
                mg.state.stall = None                                                  # "try again": Gemini is fine again
                return {}
            h = Hooks(answer=recovered)
            c = make(h, models=(A, B, C), patience=0.4, cooldown=0.05)
            out = ask(c)
        self.assertIn('[', out)
        self.assertEqual(len(h.asks), 1)
        failed = [e['model'] for e in h.asks[0]['log'] if e['outcome'] == 'network']
        for m in (A, B, C):
            self.assertGreaterEqual(failed.count(m), 2, (m, failed))                   # EVERY model had failed (twice) when the person was asked
        self.assertEqual(h.asks[0]['kind'], 'overloaded')


# ====================================================================================================== (b) split on timeout
class SplitOnTimeoutTests(unittest.TestCase):
    ITEMS = [f'source line 0-{k}' for k in range(8)]

    def expected(self):
        return [M.POOL[2] + ' ' + burmese_digits(line_index(x)) for x in self.ITEMS]

    def run_batch(self, stall):
        sys_prompt = 'system'
        got, notes = [], []
        with M.MockGemini() as mg, patch.object(R, 'rewrite_timeout', lambda: 0.15), patch.object(G.GeminiClient, 'NET_RETRY_PAUSE', 0.01):
            mg.state.generate = __import__('test_pipeline').unique_generate()
            mg.state.stall = lambda model, payload: stall(model, payload, got)
            h = Hooks()
            c = make(h, models=FIVE)
            result = R.rewrite_batch(c, sys_prompt, list(self.ITEMS), 'en', None, notes.append, sink=got.extend)
        return result, got, notes, c, h, mg

    def test_a_batch_that_keeps_timing_out_is_split_and_every_line_is_written_exactly_once(self):
        result, got, notes, c, h, mg = self.run_batch(lambda model, payload, got: 0.4 if n_items(payload) > 2 else 0)
        self.assertEqual(result, self.expected())                                      # right order, nothing lost
        self.assertEqual(got, self.expected())                                         # the sink saw every line exactly once, in order
        answered = []                                                                  # the requests that were answered: their lines are disjoint and cover the batch
        for r in mg.state.requests:
            if r['action'] == 'generateContent' and n_items(r['payload']) <= 2:
                answered.extend(M._parse_input(r['payload']['contents'][0]['parts'][0]['text']))
        self.assertEqual(sorted(answered), sorted(self.ITEMS))
        self.assertEqual(len(answered), len(set(answered)))
        self.assertEqual(outcomes(c).count('network'), 12)                             # 4 timeouts for the 8, 4 for each 4 - and then it went through
        self.assertEqual(h.asks, [])                                                   # never paused
        self.assertTrue(any('နှစ်ပိုင်းခွဲ' in n for n in notes), notes)

    def test_the_left_half_is_saved_before_the_right_half_is_even_asked(self):
        seen = []

        def stall(model, payload, got):
            texts = payload['contents'][0]['parts'][0]['text']
            if n_items(payload) > 2 and 'source line 0-7' in texts:                    # the requests that contain the last line time out
                seen.append(len(got))                                                  # ... and how many lines were saved at that moment
                return 0.4
            return 0
        result, got, notes, c, h, mg = self.run_batch(stall)
        self.assertEqual(result, self.expected())
        self.assertEqual(got, self.expected())
        self.assertEqual(seen[0], 0)                                                   # the whole batch: nothing saved yet
        self.assertEqual(seen[-1], 4)                                                  # the right half: the left half (4 lines) was already saved
        self.assertEqual(len(got), len(set(got)))

    def test_a_single_line_is_never_split_it_waits_hops_and_pauses_at_the_end(self):
        with M.MockGemini() as mg, patch.object(R, 'rewrite_timeout', lambda: 0.15), patch.object(G.GeminiClient, 'NET_RETRY_PAUSE', 0.01):
            mg.state.stall = lambda model, payload: 0.4
            h = Hooks()
            c = make(h, models=(A, B), patience=0.3, cooldown=0.05)
            with self.assertRaises(G.GeminiNeedKey):                                   # (nobody answers the question)
                R.rewrite_batch(c, 'system', ['source line 0-0'], 'en')
        self.assertEqual(h.asks[0]['kind'], 'overloaded')


# ====================================================================================================== (c) environment
class EnvironmentTests(unittest.TestCase):
    def test_the_defaults(self):
        with patch.dict(os.environ):
            os.environ.pop('REWRITE_BATCH', None)
            os.environ.pop('GEMINI_REWRITE_TIMEOUT', None)
            self.assertEqual(R.batch_size(), 15)
            self.assertEqual(R.rewrite_timeout(), 300.0)

    def test_batch_and_timeout_are_read_from_the_environment_every_time(self):
        with patch.dict(os.environ, {'REWRITE_BATCH': '7', 'GEMINI_REWRITE_TIMEOUT': '450'}):
            self.assertEqual((R.batch_size(), R.rewrite_timeout()), (7, 450.0))
        with patch.dict(os.environ, {'REWRITE_BATCH': '500', 'GEMINI_REWRITE_TIMEOUT': '5'}):
            self.assertEqual((R.batch_size(), R.rewrite_timeout()), (100, 30.0))        # limits: 1 - 100 lines, 30 s and up
        with patch.dict(os.environ, {'REWRITE_BATCH': '0'}):
            self.assertEqual(R.batch_size(), 1)
        with patch.dict(os.environ, {'REWRITE_BATCH': 'many', 'GEMINI_REWRITE_TIMEOUT': 'slow'}):
            self.assertEqual((R.batch_size(), R.rewrite_timeout()), (15, 300.0))        # nonsense = the default
        with patch.dict(os.environ, {'REWRITE_BATCH': ' 9 '}):
            self.assertEqual(R.batch_size(), 9)

    def test_the_rewrite_and_shorten_requests_wait_for_the_env_timeout_and_the_connect_timeout_stays_15(self):
        seen = []
        real = requests.Session.post

        def spy(self, *a, **kw):
            seen.append(kw.get('timeout'))
            return real(self, *a, **kw)
        item = {'i': 0, 'text': M.POOL[3], 'syllables': 20, 'max_syllables': 5}
        for env, want in (({}, 300.0), ({'GEMINI_REWRITE_TIMEOUT': '450'}, 450.0)):
            seen.clear()
            with M.MockGemini(), patch.dict(os.environ, env), patch.object(requests.Session, 'post', spy):
                os.environ.pop('GEMINI_REWRITE_TIMEOUT', None) if not env else None
                c = G.GeminiClient('KEY', A, [], hooks=Hooks())
                R.rewrite_batch(c, 'system', ['source line 0-0'], 'en')
                R.shorten_lines(c, [item])
            self.assertEqual(seen, [(15, want), (15, want)], env)

    def test_the_story_limits_moved_here_and_still_follow_their_variables(self):
        with patch.dict(os.environ):
            for k in ('GEMINI_STORY_CHARS', 'GEMINI_STORY_TOKENS', 'GEMINI_STORY_TIMEOUT'):
                os.environ.pop(k, None)
            self.assertEqual(R.story_limits(), {'chars': 150000, 'tokens': 65000, 'timeout': 900})
        with patch.dict(os.environ, {'GEMINI_STORY_CHARS': '40000', 'GEMINI_STORY_TOKENS': '30000', 'GEMINI_STORY_TIMEOUT': '600'}):
            self.assertEqual(R.story_limits(), {'chars': 40000, 'tokens': 30000, 'timeout': 600})

    def test_the_model_chain_was_not_touched(self):
        self.assertEqual(G.DEFAULT_FALLBACKS, ['gemini-3.8-flash', 'gemini-3.6-flash', 'gemini-3.5-flash-lite', 'gemini-3.1-flash-lite', 'gemini-2.5-flash'])
        self.assertEqual(G.DEFAULT_MODEL, 'gemini-flash-latest')


# ====================================================================================================== what the page is told
class PageInfoTests(unittest.TestCase):
    def test_the_wait_the_page_counts_down_carries_the_next_model_and_the_round(self):
        with tempfile.TemporaryDirectory() as tmp:
            store = J.JobStore(os.path.join(tmp, 'jobs'))
            job = store.create('local', {}, 'a.mp4', '.mp4')
            ctl = J.JobControl(store, job['id'])
            t = threading.Thread(target=ctl.sleep, args=(0.8, 'overloaded'), kwargs={'model': B, 'retry': 2})
            t.start()
            time.sleep(0.3)
            wait = store.get(job['id'])['wait']
            t.join()
            self.assertEqual((wait['why'], wait['model'], wait['retry']), ('overloaded', B, 2))
            self.assertGreater(wait['until'], time.time() - 1)
            self.assertIsNone(store.get(job['id'])['wait'])                            # cleared when the wait is over

    def test_the_job_notes_show_the_model_and_the_retries(self):
        run = types.SimpleNamespace(client=types.SimpleNamespace(active_model=B, stats={'retries': 3}))
        self.assertEqual(pipeline.Run.ai_bits(run), [f'Gemini model: {B} (ပြန်စမ်းမှု 3)'])
        run.client.stats['retries'] = 0
        self.assertEqual(pipeline.Run.ai_bits(run), [f'Gemini model: {B}'])
        self.assertEqual(pipeline.Run.ai_bits(types.SimpleNamespace(client=None)), [])


# ====================================================================================================== (d) the whole job
class JobTests(PipelineBase):
    def setUp(self):
        super().setUp()
        for p in (patch.object(R, 'rewrite_timeout', lambda: 0.3), patch.object(G.GeminiClient, 'NET_RETRY_PAUSE', 0.02),
                  patch.dict(os.environ, {'GEMINI_OVERLOAD_PATIENCE': '1', 'GEMINI_COOLDOWN': '0.3'})):
            p.start()
            self.addCleanup(p.stop)

    def rewrite_requests(self):
        return [r for r in self.mock.state.requests if r['action'] == 'generateContent' and 'responseModalities' not in json.dumps(r['payload'])]

    def test_all_models_failing_pauses_the_job_with_the_work_saved_and_nothing_is_written_twice(self):
        stalled = {'on': False, 'calls': 0}

        def stall(model, payload):
            stalled['calls'] += 1
            return 0.8 if (stalled['on'] or stalled['calls'] > 1) else 0               # the first batch is answered, then Gemini hangs
        self.mock.state.stall = stall
        env = self.env
        jid = env.job(self.video, make_subs=False)
        env.start(jid)
        job = env.wait(jid, ('paused', 'completed', 'failed'), timeout=180)
        self.assertEqual(job['status'], 'paused', job.get('error'))
        self.assertEqual(job['pause']['kind'], 'overloaded')                           # every model failed: the person decides
        saved = json.loads((env.store.dir(jid) / 'work' / 'rewrite.json').read_text(encoding='utf-8'))
        self.assertEqual(len(saved['lines']), 4)                                       # the first batch is safe on the disk
        time.sleep(0.5)
        self.assertEqual(env.store.get(jid)['status'], 'paused')                       # it waits, it does not give up
        mark = len(self.mock.state.requests)
        stalled['on'], stalled['calls'] = False, -10 ** 9                              # Gemini is back
        self.assertTrue(env.runner.answer(jid, {}))                                    # "try again"
        job = env.wait(jid, ('completed', 'failed'), timeout=180)
        self.assertEqual(job['status'], 'completed', job.get('error'))
        lines = (env.store.dir(jid) / 'out' / 'burmese.txt').read_text(encoding='utf-8').split('\n')
        self.assertEqual(len(lines), TOTAL_LINES)
        self.assertEqual(len(set(lines)), TOTAL_LINES)                                 # every line exactly once
        later = ' '.join(json.dumps(r['payload'], ensure_ascii=False) for r in self.mock.state.requests[mark:])
        for k in range(4):
            self.assertNotIn(f'source line 0-{k}"', later)                              # the finished lines were never asked for again

    def test_a_batch_that_times_out_is_split_and_the_job_completes_with_every_line_once(self):
        def stall(model, payload):
            text = payload['contents'][0]['parts'][0]['text']
            return 0.8 if (n_items(payload) > 2 and 'source line 0-4' in text) else 0  # the second batch only works in small pieces
        self.mock.state.stall = stall
        env = self.env
        jid = env.job(self.video, make_subs=False)
        env.start(jid)
        job = env.wait(jid, ('completed', 'failed', 'paused'), timeout=180)
        self.assertEqual(job['status'], 'completed', job.get('error'))
        out = env.store.dir(jid) / 'out'
        lines = (out / 'burmese.txt').read_text(encoding='utf-8').split('\n')
        self.assertEqual(len(lines), TOTAL_LINES)
        self.assertEqual(len(set(lines)), TOTAL_LINES)
        self.assertEqual(lines, [M.POOL[2] + ' ' + burmese_digits(i) for i in range(TOTAL_LINES)])        # in order, each source line once
        self.assertEqual((out / 'transcript.txt').read_text(encoding='utf-8').split('\n'), [f'source line {i // 5}-{i % 5}' for i in range(TOTAL_LINES)])
        answered = []
        for r in self.rewrite_requests():
            if n_items(r['payload']) <= 2:
                answered += [line_index(x) for x in M._parse_input(r['payload']['contents'][0]['parts'][0]['text'])]
        self.assertEqual(len(answered), len(set(answered)))                            # no line was answered twice by the small pieces

    def test_the_batch_size_follows_REWRITE_BATCH(self):
        with patch.dict(os.environ, {'REWRITE_BATCH': '3'}):
            env = self.env
            jid = env.job(self.video, make_subs=False)
            env.start(jid)
            job = env.wait(jid, ('completed', 'failed', 'paused'), timeout=120)
        self.assertEqual(job['status'], 'completed', job.get('error'))
        sizes = [n_items(r['payload']) for r in self.rewrite_requests()]
        self.assertEqual(max(sizes), 3)
        self.assertEqual(sum(sizes), TOTAL_LINES)

    def test_the_default_batch_is_15(self):
        with patch.object(R, 'BATCH', 15):                                             # (the harness lowers BATCH to 4 for the other tests)
            with patch.dict(os.environ):
                os.environ.pop('REWRITE_BATCH', None)
                self.assertEqual(R.batch_size(), 15)


if __name__ == '__main__':
    unittest.main()
