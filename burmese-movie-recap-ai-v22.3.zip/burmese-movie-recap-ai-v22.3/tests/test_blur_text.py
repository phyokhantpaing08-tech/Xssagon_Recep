"""V22.1: the subtitle text follows the blur box. Before, the text stayed at 5.5 % of the picture whatever the box was, so a big
blur box held a tiny text with a lot of empty space above and below it. Now the size is derived from the HEIGHT OF THE BOX
(media.band_size) and a subtitle that needs more lines is made smaller until all its lines just fit (media.fit_subtitle).

The last test draws real subtitles with ffmpeg / libass (Padauk font) and measures the pixels: the text must stay inside the box
and must fill a good part of it."""
import os
import shutil
import subprocess
import sys
import tempfile
import unittest

import numpy as np

HERE = os.path.dirname(__file__)
sys.path.insert(0, os.path.join(HERE, '..', 'backend'))

import media  # noqa: E402

SHORT = 'မင်္ဂလာပါ ဒီနေ့ ရာသီဥတု ကောင်းတယ်'
LONG = ('ဒီလိုနဲ့ သူမက အိမ်ကို ပြန်ရောက်လာပြီး အမေ့ကို အကုန်ပြောပြလိုက်တယ် ဒါပေမဲ့ အမေက မယုံဘူး၊ ဒါကြောင့် သူမက ဆက်ပြီး '
        'ရှင်းပြနေရတယ် အဲဒီနောက် အဖေလည်း ပြန်ရောက်လာတယ်')


def size_of(ass):
    return int([x for x in ass.splitlines() if x.startswith('Dialogue')][0].split('\\fs')[1].split('\\')[0])


class BandSizeTests(unittest.TestCase):
    def test_the_size_follows_the_height_of_the_box(self):
        sizes = [media.band_size(h) for h in (60, 120, 240, 480)]
        self.assertEqual(sizes, sorted(sizes))
        self.assertEqual(len(set(sizes)), 4)
        self.assertAlmostEqual(media.band_size(240) / media.band_size(120), 2.0, delta=0.05)

    def test_the_slider_scales_it_and_a_box_makes_room_for_its_padding(self):
        self.assertAlmostEqual(media.band_size(300, 50) / media.band_size(300, 100), 0.5, delta=0.02)
        self.assertLess(media.band_size(300, 100, True), media.band_size(300, 100, False))
        self.assertGreaterEqual(media.band_size(10), 14)            # never smaller than the floor

    def test_a_bigger_box_means_bigger_text_in_the_ass_file(self):
        seg = [{'start': 0, 'end': 2, 'burmese': SHORT}]
        small = size_of(media.build_ass(seg, 1280, 720, 'Padauk', media.blur_band(720, 70, 10)))
        big = size_of(media.build_ass(seg, 1280, 720, 'Padauk', media.blur_band(720, 60, 30)))
        self.assertGreater(big, small * 1.5)

    def test_the_old_5_5_percent_ceiling_is_gone(self):
        # a 18 % box on a 1080p picture used to give 59 px text (5.5 % of 1080) however big the box was
        seg = [{'start': 0, 'end': 2, 'burmese': SHORT}]
        self.assertGreater(size_of(media.build_ass(seg, 1920, 1080, 'Padauk', media.blur_band(1080, 70, 18))), 80)


class FitSubtitleTests(unittest.TestCase):
    def test_every_line_fits_into_the_box(self):
        for text in (SHORT, LONG, 'ဟုတ်ကဲ့'):
            for boxed in (False, True):
                for band_h in (60, 130, 194, 346):
                    wrapped, s = media.fit_subtitle(text, 1000, band_h, media.band_size(band_h, 100, boxed), boxed)
                    lines = wrapped.count('\n') + 1
                    pad = media.BOX_PAD if boxed else 0.0
                    self.assertTrue((lines + pad) * s <= band_h or s <= 12, (text[:6], boxed, band_h, s, lines))

    def test_it_is_the_biggest_size_that_fits_not_a_much_smaller_one(self):
        # one size bigger must NOT fit (otherwise the text is smaller than it has to be: the old "padding")
        for band_h in (130, 194, 346):
            size = media.band_size(band_h, 250)
            wrapped, s = media.fit_subtitle(LONG, 950, band_h, size)
            if s < size and s > 12:
                bigger, _ = media.fit_subtitle(LONG, 950, band_h, s + 1)
                # at s + 1 the wrap needs more lines, so the block is taller than the box
                lines = media.wrap_burmese(LONG, int(max(10, min(90, 950 / ((s + 1) * 0.42))))).count('\n') + 1
                self.assertGreater(lines * (s + 1), band_h, (band_h, s))

    def test_a_short_text_keeps_the_size_it_was_given(self):
        wrapped, s = media.fit_subtitle('ဟုတ်ကဲ့', 1000, 200, 100)
        self.assertEqual((wrapped, s), ('ဟုတ်ကဲ့', 100))

    def test_a_long_text_in_a_narrow_picture_is_not_shrunk_to_nothing(self):
        wrapped, s = media.fit_subtitle(LONG, 950, 346, media.band_size(346))
        self.assertGreater(s, 40)                                   # it was 26 px when the size jumped down too far


@unittest.skipUnless(shutil.which('ffmpeg'), 'ffmpeg is not installed')
class RenderedTextTests(unittest.TestCase):
    """Real libass output: where the yellow / white pixels really are."""

    def ink(self, w, h, band, look, text):
        font_dir = os.path.join(HERE, '..', 'fonts')
        if not os.path.exists(os.path.join(font_dir, 'Padauk-Regular.ttf')):
            self.skipTest('the bundled Padauk font is missing')
        with tempfile.TemporaryDirectory() as d:
            ass = media.build_ass([{'start': 0, 'end': 2, 'burmese': text}], w, h, 'Padauk', band=band, look=look)
            with open(os.path.join(d, 'a.ass'), 'w', encoding='utf-8') as f:
                f.write(ass)
            out = os.path.join(d, 'o.png')
            r = subprocess.run(['ffmpeg', '-y', '-loglevel', 'error', '-f', 'lavfi', '-i', f'color=c=black:s={w}x{h}:d=1',
                                '-vf', f'ass=a.ass:fontsdir={os.path.abspath(font_dir)}', '-frames:v', '1', out], cwd=d, capture_output=True)
            if r.returncode != 0 or not os.path.exists(out):
                self.skipTest('this ffmpeg cannot draw ASS subtitles (no libass)')
            try:
                from PIL import Image
            except ImportError:
                self.skipTest('Pillow is not installed')
            a = np.array(Image.open(out).convert('RGB')).astype(int)
        ys = np.where((a.sum(2) > 60).any(1))[0]
        return (int(ys.min()), int(ys.max())) if len(ys) else None

    def test_the_text_stays_inside_the_box_and_fills_a_good_part_of_it(self):
        for w, h in ((1920, 1080), (1280, 720), (1080, 1920)):
            for look in (None, {'box': True, 'box_alpha': 100}, {'font': 60}, {'font': 200}):
                for text in (SHORT, LONG):
                    band = media.blur_band(h, 72, 18)
                    got = self.ink(w, h, band, look, text)
                    self.assertIsNotNone(got)
                    y0, bh = band
                    self.assertGreaterEqual(got[0], y0, (w, h, look, text[:5]))
                    self.assertLess(got[1], y0 + bh, (w, h, look, text[:5]))

    def test_a_typical_line_is_much_bigger_than_before(self):
        w, h = 1920, 1080
        band = media.blur_band(h, 72, 18)
        a, b = self.ink(w, h, band, None, SHORT)
        self.assertGreater((b - a + 1) / band[1], 0.40)             # used to be about 0.27 (59 px text in a 194 px box)

    def test_the_text_grows_with_the_box(self):
        heights = []
        for pct in (10, 20, 30):
            band = media.blur_band(1080, 60, pct)
            a, b = self.ink(1920, 1080, band, None, SHORT)
            heights.append(b - a + 1)
        self.assertEqual(heights, sorted(heights))
        self.assertGreater(heights[2], heights[0] * 2)


if __name__ == '__main__':
    unittest.main()
