import base64
import json
import os
import sys
import tempfile
import threading
import unittest
from pathlib import Path
from unittest import mock
from urllib.parse import parse_qs, urlparse

sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', 'backend'))

import auth as A  # noqa: E402

try:
    import cryptography  # noqa: F401
    HAVE_FERNET = True
except ImportError:
    HAVE_FERNET = False


class OriginTests(unittest.TestCase):
    def test_origin_check(self):
        ok = A.origin_ok
        self.assertTrue(ok('', '', 'recap.example.com'))                       # curl / scripts
        self.assertTrue(ok('https://recap.example.com', '', 'recap.example.com'))
        self.assertTrue(ok('https://recap.example.com', 'https://recap.example.com/page', 'x', 'https://recap.example.com'))
        self.assertFalse(ok('https://evil.example', '', 'recap.example.com'))
        self.assertFalse(ok('', 'https://evil.example/a', 'recap.example.com', 'https://recap.example.com'))
        self.assertTrue(ok('http://127.0.0.1:8000', '', '127.0.0.1:8000'))
        self.assertTrue(ok('http://13.231.227.226:8000', '', '13.231.227.226:8000'))        # the VPS address with its port
        self.assertFalse(ok('http://13.231.227.226:9000', '', '13.231.227.226:8000'))       # another port is another site
        self.assertFalse(ok('null', '', 'recap.example.com'))                 # sandboxed frame / file:// page
        self.assertFalse(ok('null', 'https://recap.example.com/x', 'recap.example.com', 'https://recap.example.com'))
        self.assertFalse(ok('NULL', '', 'recap.example.com'))


class PasswordTests(unittest.TestCase):
    @staticmethod
    def basic(user, password):
        return 'Basic ' + base64.b64encode(f'{user}:{password}'.encode('utf-8')).decode('ascii')

    def test_no_password_means_no_protection(self):
        for header in (None, '', 'Basic abc', self.basic('a', 'b')):
            self.assertTrue(A.password_ok(header, ''))

    def test_http_basic_password(self):
        ok = A.password_ok
        self.assertTrue(ok(self.basic('anything', 'secret'), 'secret'))
        self.assertTrue(ok(self.basic('', 'secret'), 'secret'))                # the user name does not matter
        self.assertTrue(ok(self.basic('a', 'se:cret'), 'se:cret'))             # a colon inside the password
        self.assertTrue(ok('BASIC ' + self.basic('a', 'secret')[6:], 'secret'))                # the word "Basic" in any case
        self.assertTrue(ok(self.basic('x', 'စကားဝှက် ၁၂၃'), 'စကားဝှက် ၁၂၃'))      # not only ASCII
        for bad in (None, '', 'Basic', 'Basic ', 'Basic !!!not-base64', 'Bearer secret', self.basic('a', 'wrong'),
                    self.basic('a', ''), self.basic('a', 'secret '), self.basic('a', 'SECRET'),
                    'Basic ' + base64.b64encode(b'no-colon-at-all').decode(), 'Basic ' + base64.b64encode(b'\xff\xfe:\xff').decode()):
            self.assertFalse(ok(bad, 'secret'), bad)


class DriveLoginStateTests(unittest.TestCase):
    """The Google Drive login (an OAuth flow) keeps its one-time states in memory."""

    def setUp(self):
        import drive_store
        self.D = drive_store
        self.tmp = tempfile.TemporaryDirectory()
        self.env = mock.patch.dict(os.environ, {'GOOGLE_CLIENT_ID': 'cid', 'GOOGLE_CLIENT_SECRET': 'sec'})
        self.env.start()
        self.D._pending.clear()

    def tearDown(self):
        self.D._pending.clear()
        self.env.stop()
        self.tmp.cleanup()

    def state_of(self, who):
        with self.D.use_dir(Path(self.tmp.name) / who):
            return parse_qs(urlparse(self.D.auth_url('https://x.example/api/drive/callback')).query)['state'][0]

    def test_a_state_belongs_to_the_folder_that_asked_for_it_and_works_once(self):
        state = self.state_of('alice')
        with self.D.use_dir(Path(self.tmp.name) / 'bob'):
            with self.assertRaises(self.D.DriveError) as cm:
                self.D.finish_auth(state, 'CODE')
        self.assertIn('Connect', str(cm.exception))
        with self.D.use_dir(Path(self.tmp.name) / 'alice'):                   # ...and the state is used up
            with self.assertRaises(self.D.DriveError):
                self.D.finish_auth(state, 'CODE')
        with self.D.use_dir(Path(self.tmp.name) / 'alice'):
            with self.assertRaises(self.D.DriveError):                       # an invented state
                self.D.finish_auth('invented', 'CODE')

    def test_half_done_logins_do_not_pile_up_in_memory(self):
        for _ in range(self.D.MAX_PENDING + 150):
            self.state_of('alice')
        self.assertLessEqual(len(self.D._pending), self.D.MAX_PENDING)
        newest = self.state_of('alice')                                       # the newest ones are the ones that are kept
        self.assertIn(newest, self.D._pending)


class SecretBoxTests(unittest.TestCase):
    def test_secret_is_generated_once_and_reused(self):
        if not HAVE_FERNET:
            self.skipTest('the optional "cryptography" package is not installed')
        with tempfile.TemporaryDirectory() as d:
            a = A.SecretBox(d)
            self.assertTrue((Path(d) / 'secret.key').exists())
            blob = a.encrypt('AIza-ONE')
            self.assertTrue(blob.startswith('fernet:'))
            self.assertEqual(A.SecretBox(d).decrypt(blob), 'AIza-ONE')        # a restart can read it
            with tempfile.TemporaryDirectory() as other:
                self.assertEqual(A.SecretBox(other).decrypt(blob), '')        # another server's secret cannot

    def test_without_the_cryptography_package_the_key_is_only_hidden(self):
        with tempfile.TemporaryDirectory() as d, mock.patch.dict(sys.modules, {'cryptography': None, 'cryptography.fernet': None}):
            box = A.SecretBox(d)
            blob = box.encrypt('AIza-TWO')
            self.assertTrue(blob.startswith('plain:'))
            self.assertNotIn('AIza-TWO', blob)
            self.assertEqual(box.decrypt(blob), 'AIza-TWO')
            self.assertFalse((Path(d) / 'secret.key').exists())               # no secret file is needed
        if HAVE_FERNET:                                                       # ...and a later install can still read it
            self.assertEqual(A.SecretBox(tempfile.mkdtemp()).decrypt(blob), 'AIza-TWO')


class UserStoreTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.old = {k: os.environ.pop(k, None) for k in ('GEMINI_API_KEY', 'GOOGLE_API_KEY', 'GEMINI_MODEL', 'ANTHROPIC_API_KEY', 'CLAUDE_API_KEY',
                                                       'GROQ_API_KEY', 'AI_PROVIDER', 'CLAUDE_MODEL', 'GROQ_MODEL')}
        self.me = dict(A.LOCAL_USER)

    def tearDown(self):
        for k, v in self.old.items():
            if v is not None:
                os.environ[k] = v
            else:
                os.environ.pop(k, None)
        self.tmp.cleanup()

    def test_the_saved_key_is_not_readable_in_the_file(self):
        st = A.UserStore(self.tmp.name)
        st.set_key(self.me, 'AIza-USER-ONE-KEY')
        raw = (Path(self.tmp.name) / 'users' / 'local' / 'settings.json').read_text(encoding='utf-8')
        self.assertNotIn('AIza-USER-ONE-KEY', raw)
        self.assertRegex(raw, r'(fernet|plain):')
        self.assertEqual(st.get_key(self.me), 'AIza-USER-ONE-KEY')
        self.assertEqual(A.UserStore(self.tmp.name).get_key(self.me), 'AIza-USER-ONE-KEY')    # still there after a restart
        st.clear_key(self.me)
        self.assertEqual(st.get_key(self.me), '')

    def test_parallel_writes_do_not_lose_each_other(self):
        st = A.UserStore(self.tmp.name)
        errors = []

        def hammer(i):
            try:
                for n in range(25):
                    if i % 2:
                        st.set_key(self.me, 'AIza-STAYS')
                    else:
                        st.set_model(self.me, f'gemini-model-{i}-{n}')
            except Exception as e:                    # noqa: BLE001
                errors.append(e)
        st.set_key(self.me, 'AIza-STAYS')
        threads = [threading.Thread(target=hammer, args=(i,)) for i in range(6)]
        [t.start() for t in threads]
        [t.join() for t in threads]
        self.assertEqual(errors, [])
        self.assertEqual(st.get_key(self.me), 'AIza-STAYS')                       # no write overwrote the key with an old copy
        self.assertTrue(st.get_model(self.me).startswith('gemini-model-'))

    def test_a_key_typed_on_the_website_beats_the_env_key(self):
        os.environ['GEMINI_API_KEY'] = 'OLD-ENV-KEY'
        os.environ['GEMINI_MODEL'] = 'gemini-from-env'
        st = A.UserStore(self.tmp.name)
        self.assertEqual((st.get_key(self.me), st.key_source(self.me), st.get_model(self.me)), ('OLD-ENV-KEY', 'env', 'gemini-from-env'))
        st.set_key(self.me, 'NEW-KEY-FROM-WEBSITE')
        st.set_model(self.me, 'gemini-chosen')
        self.assertEqual((st.get_key(self.me), st.key_source(self.me), st.get_model(self.me)),
                         ('NEW-KEY-FROM-WEBSITE', 'saved', 'gemini-chosen'))
        st.clear_key(self.me)
        self.assertEqual(st.get_key(self.me), 'OLD-ENV-KEY')

    def test_the_v20_settings_file_is_still_read_and_cleared(self):
        (Path(self.tmp.name) / 'settings.json').write_text(json.dumps({'gemini_api_key': 'OLD-KEY', 'gemini_model': 'gemini-x'}), encoding='utf-8')
        st = A.UserStore(self.tmp.name)
        self.assertEqual(st.get_key(self.me), 'OLD-KEY')
        self.assertEqual(st.get_model(self.me), 'gemini-x')
        st.set_key(self.me, 'NEW-KEY')
        self.assertEqual(st.get_key(self.me), 'NEW-KEY')
        st.clear_key(self.me)
        self.assertEqual(st.get_key(self.me), '')                                 # the old plain-text key is gone too
        self.assertNotIn('OLD-KEY', (Path(self.tmp.name) / 'settings.json').read_text(encoding='utf-8'))

    def test_model_default_and_override(self):
        st = A.UserStore(self.tmp.name)
        self.assertEqual(st.get_model(self.me), 'gemini-flash-latest')
        st.set_model(self.me, 'gemini-3.6-flash')
        self.assertEqual(st.get_model(self.me), 'gemini-3.6-flash')

    # ---- V22.2: Gemini is the only AI - and what V22.1 saved for Claude / Groq is purged
    def test_the_key_is_not_readable_in_the_file_and_is_private(self):
        store = A.UserStore(self.tmp.name)
        store.set_key(self.me, 'SECRET-gemini-ABCDEF')
        raw = (Path(self.tmp.name) / 'users' / 'local' / 'settings.json').read_text(encoding='utf-8')
        self.assertNotIn('SECRET-gemini', raw)
        self.assertIn('gemini_key_enc', raw)
        self.assertEqual(os.stat(Path(self.tmp.name) / 'users' / 'local' / 'settings.json').st_mode & 0o077, 0)

    def test_clearing_the_key_keeps_the_model(self):
        store = A.UserStore(self.tmp.name)
        store.set_key(self.me, 'KEY-gemini')
        store.set_model(self.me, 'gemini-3.6-flash')
        store.clear_key(self.me)
        self.assertEqual(store.get_key(self.me), '')
        self.assertEqual(store.key_source(self.me), '')
        self.assertEqual(store.get_model(self.me), 'gemini-3.6-flash')

    def test_env_keys_and_a_typed_key_beats_them(self):
        store = A.UserStore(self.tmp.name)
        with mock.patch.dict(os.environ, {'GEMINI_API_KEY': 'ENV-G'}):
            self.assertEqual((store.get_key(self.me), store.key_source(self.me)), ('ENV-G', 'env'))
            store.set_key(self.me, 'TYPED-G')
            self.assertEqual((store.get_key(self.me), store.key_source(self.me)), ('TYPED-G', 'saved'))
        with mock.patch.dict(os.environ, {'GOOGLE_API_KEY': 'ALIAS-G'}):
            self.assertEqual(A.UserStore(tempfile.mkdtemp()).get_key(self.me), 'ALIAS-G')
        for removed in ('ANTHROPIC_API_KEY', 'CLAUDE_API_KEY', 'GROQ_API_KEY'):                  # (the keys of the removed AIs are ignored)
            with mock.patch.dict(os.environ, {removed: 'NOT-USED'}):
                self.assertEqual(A.UserStore(tempfile.mkdtemp()).get_key(self.me), '')

    def test_the_model_default_and_the_env_model(self):
        store = A.UserStore(self.tmp.name)
        self.assertEqual(store.get_model(self.me), 'gemini-flash-latest')
        with mock.patch.dict(os.environ, {'GEMINI_MODEL': 'gemini-3.8-flash'}):
            self.assertEqual(A.UserStore(tempfile.mkdtemp()).get_model(self.me), 'gemini-3.8-flash')
        store.set_model(self.me, 'gemini-3.6-flash')
        self.assertEqual(store.get_model(self.me), 'gemini-3.6-flash')
        store.set_model(self.me, '')                                                      # empty = back to the default
        self.assertEqual(store.get_model(self.me), 'gemini-flash-latest')

    def test_purge_removes_what_v22_1_saved_for_claude_and_groq(self):
        store = A.UserStore(self.tmp.name)
        store.set_key(self.me, 'G-KEY-1111')
        store.set_model(self.me, 'gemini-3.6-flash')
        data = store.read('local')
        data.update({'claude_key_enc': store.box.encrypt('C-KEY'), 'groq_key_enc': store.box.encrypt('Q-KEY'),
                     'claude_model': 'claude-haiku-5-5', 'groq_model': 'qwen/qwen3.8-27b', 'provider': 'groq'})
        store.write('local', data)
        self.assertEqual(sorted(store.purge_removed(self.me)), ['claude_key_enc', 'claude_model', 'groq_key_enc', 'groq_model', 'provider'])
        self.assertEqual(sorted(store.read('local')), ['gemini_key_enc', 'gemini_model'])
        self.assertEqual((store.get_key(self.me), store.get_model(self.me)), ('G-KEY-1111', 'gemini-3.6-flash'))
        self.assertEqual(store.purge_removed(self.me), [])                                # nothing left to do the second time
        raw = (Path(self.tmp.name) / 'users' / 'local' / 'settings.json').read_text(encoding='utf-8')
        self.assertNotIn('claude', raw)
        self.assertNotIn('groq', raw)

    def test_bad_user_ids_are_refused(self):
        st = A.UserStore(self.tmp.name)
        for bad in ('', '../x', 'a/b', 'a b', 'x' * 60):
            with self.assertRaises(ValueError):
                st.dir(bad)

    def test_mask(self):
        self.assertEqual(A.mask('AIzaSyABCD1234'), '••••••1234')
        self.assertEqual(A.mask('abc'), '••••')
        self.assertEqual(A.mask(''), '')


if __name__ == '__main__':
    unittest.main()
