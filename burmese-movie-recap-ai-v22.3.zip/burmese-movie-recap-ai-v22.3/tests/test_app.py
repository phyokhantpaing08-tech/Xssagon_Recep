"""HTTP-level tests: the real FastAPI app on a real (local) port, a fake Gemini server, fake Whisper / Edge TTS, real ffmpeg.
One user, no sign-in (like V20), in three configurations: the normal one, one with small upload / job limits, and one with
APP_PASSWORD."""
import asyncio
import base64
import importlib.util
import json
import os
import re
import shutil
import sys
import tempfile
import threading
import time
import unittest
from pathlib import Path
from unittest import mock

HERE = os.path.dirname(__file__)
BACKEND = os.path.join(HERE, '..', 'backend')
sys.path.insert(0, BACKEND)
sys.path.insert(0, HERE)

try:
    import fastapi  # noqa: F401
except ImportError:                                  # FastAPI is not installed: these HTTP tests are skipped
    vend = os.getenv('FASTAPI_VENDOR')               # (optional) a folder that holds FastAPI's source, for sandboxes without pip
    if vend:
        for sub in ('fastapi_src', 'annotated-doc_src/src', 'typing-inspection_src/src'):
            sys.path.insert(0, os.path.join(vend, sub))
    try:
        import fastapi  # noqa: F401,F811
    except ImportError:
        fastapi = None

import requests                    # noqa: E402

from test_pipeline import (FONT, TOTAL_LINES, VIDEO_SECONDS, FakeEdge, FakeWhisper, make_video, unique_generate, with_story)  # noqa: E402,F401
import asr                         # noqa: E402
import auth                        # noqa: E402
import mock_gemini as M            # noqa: E402
import presets as P                # noqa: E402
import rewrite as R                # noqa: E402
import voices as V                 # noqa: E402

MANAGED_ENV = ('APP_PASSWORD', 'MAX_UPLOAD_MB', 'RETENTION_HOURS', 'MAX_JOBS_PER_USER', 'GOOGLE_CLIENT_ID', 'GOOGLE_CLIENT_SECRET',
               'GEMINI_API_KEY', 'GEMINI_MODEL', 'DATA_DIR', 'RECAP_NO_WARMUP', 'DRIVE_REDIRECT_URI')


def load_app(name, env):
    for k in MANAGED_ENV:
        os.environ.pop(k, None)
    os.environ.update(env)
    spec = importlib.util.spec_from_file_location(name, os.path.join(BACKEND, 'app.py'))
    mod = importlib.util.module_from_spec(spec)
    sys.modules[name] = mod
    spec.loader.exec_module(mod)
    return mod


class AsgiCall:
    """Drives the ASGI app directly (no socket), the way uvicorn does, and records how much of the request body the app pulled
    before it started to answer. chunks = the pieces of the body; gate = an asyncio.Event: after the chunks the body stays
    "still arriving" until the event is set (a slow upload)."""

    def __init__(self, app, path, headers, chunks, gate=None, method='POST'):
        self.app, self.path, self.method = app, path, method
        self.headers = {k.lower(): v for k, v in headers.items()}
        self.chunks, self.gate = list(chunks), gate
        self.read, self.at_start, self.status, self.body, self.reply_headers = 0, None, None, b'', {}

    async def receive(self):
        if self.chunks:
            piece = self.chunks.pop(0)
            self.read += len(piece)
            return {'type': 'http.request', 'body': piece, 'more_body': bool(self.chunks) or self.gate is not None}
        if self.gate is not None:
            await self.gate.wait()
            self.gate = None
            return {'type': 'http.request', 'body': b'', 'more_body': False}
        await asyncio.sleep(30)                      # the app wanted more than was sent
        return {'type': 'http.disconnect'}

    async def send(self, message):
        if message['type'] == 'http.response.start':
            self.status, self.at_start = message['status'], self.read
            self.reply_headers = {k.decode('latin-1').lower(): v.decode('latin-1') for k, v in message.get('headers', [])}
        elif message['type'] == 'http.response.body':
            self.body += message.get('body', b'')

    async def run(self):
        scope = {'type': 'http', 'asgi': {'version': '3.0'}, 'http_version': '1.1', 'method': self.method, 'scheme': 'http',
                 'path': self.path, 'raw_path': self.path.encode(), 'root_path': '', 'query_string': b'',
                 'headers': [(k.encode('latin-1'), v.encode('latin-1')) for k, v in self.headers.items()],
                 'client': ('127.0.0.1', 50000), 'server': ('testserver', 80)}
        await asyncio.wait_for(self.app(scope, self.receive, self.send), 20)
        return self

    def detail(self):
        try:
            return json.loads(self.body.decode('utf-8')).get('detail', '')
        except ValueError:
            return ''


MB = b'\0' * 1048576
# the first bytes of a real multipart upload, so that the form parser keeps waiting for the rest of the "video"
FORM_START = (b'--xyz\r\nContent-Disposition: form-data; name="video"; filename="a.mp4"\r\n'
              b'Content-Type: video/mp4\r\n\r\n')


class Server:
    def __init__(self, appmod):
        import socket
        import uvicorn
        with socket.socket() as s:
            s.bind(('127.0.0.1', 0))
            self.port = s.getsockname()[1]
        self.url = f'http://127.0.0.1:{self.port}'
        self.server = uvicorn.Server(uvicorn.Config(appmod.app, host='127.0.0.1', port=self.port, log_level='error', lifespan='on'))
        self.thread = threading.Thread(target=self.server.run, daemon=True)
        self.thread.start()
        end = time.time() + 15
        while not self.server.started and time.time() < end:
            time.sleep(0.05)
        if not self.server.started:
            raise RuntimeError('server did not start')

    def stop(self):
        self.server.should_exit = True
        self.thread.join(10)


class Client:
    """A small wrapper around requests: paths are relative to the server, no redirects, and the upload / wait_job helpers."""

    def __init__(self, base):
        self.base = base
        self.http = requests.Session()

    def request(self, method, path, **kw):
        kw.setdefault('allow_redirects', False)
        kw.setdefault('timeout', 60)
        return self.http.request(method, self.base + path, **kw)

    def get(self, path, **kw):
        return self.request('GET', path, **kw)

    def post(self, path, **kw):
        return self.request('POST', path, **kw)

    def delete(self, path, **kw):
        return self.request('DELETE', path, **kw)

    def wait_job(self, jid, states, timeout=120):
        end = time.time() + timeout
        j = {}
        while time.time() < end:
            r = self.get(f'/api/jobs/{jid}')
            if r.status_code == 200:
                j = r.json()
                if j['status'] in states:
                    return j
            time.sleep(0.1)
        raise AssertionError(f'timeout waiting for {states}: {j.get("status")} {j.get("detail")} {j.get("error")}')

    def upload(self, video, **form):
        data = {'voice': 'thiha', 'make_voice': '1', 'make_subtitles': '0'}
        data.update(form)
        with open(video, 'rb') as f:
            return self.post('/api/jobs', data=data, files={'video': ('movie.mp4', f, 'video/mp4')})


@unittest.skipUnless(fastapi and shutil.which('ffmpeg'), 'FastAPI and ffmpeg are needed')
class AppTestBase(unittest.TestCase):
    ENV = {}
    NAME = 'app_x'

    @classmethod
    def setUpClass(cls):
        cls.tmp = tempfile.mkdtemp(prefix='recap_app_')
        cls.video = Path(cls.tmp) / 'video.mp4'
        make_video(cls.video)
        env = {'DATA_DIR': str(Path(cls.tmp) / 'data'), 'RECAP_NO_WARMUP': '1'}
        env.update(cls.ENV)
        cls.mock = M.MockGemini()
        cls.mock.__enter__()
        cls.app = load_app(cls.NAME, env)
        cls.app.SERVICES.edge = V.EdgeTTS(module=FakeEdge, concurrency=4)
        cls.whisper = FakeWhisper()
        cls.patchers = [mock.patch.object(asr, 'transcribe_wav', cls.whisper), mock.patch.object(R, 'BATCH', 4)]
        for p in cls.patchers:
            p.start()
        cls.server = Server(cls.app)

    @classmethod
    def tearDownClass(cls):
        for jid in list(cls.app.RUNNER.controls):
            cls.app.RUNNER.cancel(jid)
        end = time.time() + 10
        while cls.app.RUNNER.controls and time.time() < end:
            time.sleep(0.05)
        cls.server.stop()
        for p in cls.patchers:
            p.stop()
        cls.mock.__exit__(None, None, None)
        import tempfile as _t
        _t.tempdir = None
        shutil.rmtree(cls.tmp, ignore_errors=True)
        sys.modules.pop(cls.NAME, None)

    def setUp(self):
        FakeEdge.reset()
        self.whisper.calls.clear()
        self.mock.state.requests.clear()
        self.mock.state.script.clear()
        self.mock.state.valid_keys = None
        self.mock.state.generate = unique_generate()

    def exhausted_after(self, n_ok, key='KEY-A'):
        calls = {'n': 0}
        lock = threading.Lock()
        base = unique_generate()

        def gen(system, user, k):
            if k == key:
                with lock:
                    calls['n'] += 1
                    broken = calls['n'] > n_ok
                if broken:
                    return M.e429_prepay()
            return base(system, user)
        self.mock.state.generate = gen


# ====================================================================================================== local mode
class LocalModeTests(AppTestBase):
    NAME = 'app_local'
    ENV = {}

    @classmethod
    def setUpClass(cls):
        super().setUpClass()
        cls.c = Client(cls.server.url)

    def setUp(self):
        super().setUp()
        self.c.post('/api/settings', data={'gemini_api_key': 'RESET-KEY', 'gemini_model': 'gemini-flash-latest'})
        self.c.delete('/api/settings')                                                # (every test starts without a saved key)

    def test_page_and_about(self):
        r = self.c.get('/')
        self.assertEqual(r.status_code, 200)
        self.assertIn('<html', r.text.lower())
        self.assertNotIn('Sign in with Google', r.text)                             # there is no sign-in any more
        self.assertNotIn('/api/auth', r.text)
        about = self.c.get('/api/about').json()
        self.assertEqual(about['version'], 'V22.3')
        self.assertFalse(about['password_protected'])
        self.assertEqual((about['max_upload_mb'], about['retention_hours'], about['max_jobs']), (0, 0, 6))
        self.assertEqual(self.c.get('/api/auth/login').status_code, 404)           # the sign-in routes are gone
        self.assertEqual(self.c.get('/api/me').status_code, 404)

    def test_options_one_nilar_one_thiha_and_groups(self):
        o = self.c.get('/api/options').json()
        ids = [v['id'] for v in o['voices']]
        self.assertEqual([v for v in ids if v in ('nilar', 'thiha')], ['nilar', 'thiha'])
        self.assertFalse([v for v in ids if re.search(r'(soft|deep|bright|energetic)', v)])
        self.assertEqual({v['group'] for v in o['voices']}, {'native', 'edge', 'gemini'})
        self.assertEqual(len([v for v in o['voices'] if v['group'] == 'gemini']), 30)
        self.assertEqual([g['id'] for g in o['groups']], ['native', 'edge', 'gemini'])
        self.assertEqual(o['default_speed'], 10)
        self.assertIn('veryfast', o['render_presets'])
        self.assertIn('subtitle_ready', o)

    def test_options_offer_exactly_two_styles_and_no_providers(self):
        o = self.c.get('/api/options').json()
        self.assertEqual([x['id'] for x in o['styles']], ['direct', 'story'])
        self.assertEqual(o['default_style'], 'direct')
        self.assertEqual(o['recommended_style'], 'direct')
        self.assertEqual([x['label'] for x in o['styles']], ['🔤 တိုက်ရိုက်စာတန်းထိုးဟန်', '📖 ဇာတ်လမ်းပြောဟန်'])
        self.assertEqual([x['mode'] for x in o['styles']], ['line', 'story'])
        self.assertTrue(all(x['desc'] for x in o['styles']))
        self.assertNotIn('providers', o)                                                  # V22.2: Gemini is the only AI
        self.assertNotIn('provider', o)
        self.assertEqual((o['speed_min'], o['speed_max']), (-20, 60))

    def test_settings_save_clear_and_masked(self):
        s = self.c.get('/api/settings').json()
        self.assertFalse(s['configured'])
        r = self.c.post('/api/settings', data={'gemini_api_key': 'AIzaTESTKEY123456', 'gemini_model': 'models/gemini-3.6-flash'})
        self.assertEqual(r.status_code, 200, r.text)
        s = r.json()
        self.assertEqual((s['configured'], s['masked'], s['model']), (True, '••••••3456', 'gemini-3.6-flash'))
        self.assertNotIn('AIzaTESTKEY', json.dumps(self.c.get('/api/settings').json()))
        self.assertEqual(self.c.post('/api/settings', data={'gemini_api_key': 'has space inside'}).status_code, 400)
        self.assertEqual(self.c.delete('/api/settings').json()['configured'], False)
        self.assertEqual(self.c.post('/api/settings', data={'gemini_api_key': ''}).status_code, 400)

    def test_test_api_is_free_it_never_generates_text(self):
        self.c.post('/api/settings', data={'gemini_api_key': 'KEY-A'})
        r = self.c.post('/api/settings/test').json()
        self.assertTrue(r['ok'] and r['free'])
        self.assertEqual(r['model'], 'gemini-flash-latest')
        self.assertTrue(r['count_ok'])
        actions = [(q['method'], q['action']) for q in self.mock.state.requests]
        self.assertNotIn(('POST', 'generateContent'), actions)              # no generation = no credit
        self.assertEqual(sorted(set(actions)), [('GET', ''), ('POST', 'countTokens')])
        # a typed key that is not saved can be tested too
        self.mock.state.valid_keys = {'KEY-A'}
        bad = self.c.post('/api/settings/test', data={'gemini_api_key': 'NOT-A-VALID-KEY'}).json()
        self.assertFalse(bad['ok'])
        self.assertIn('API key', bad['error'])
        self.assertTrue(self.c.post('/api/settings/test', data={'gemini_api_key': 'KEY-A'}).json()['ok'])
        self.assertEqual(self.c.get('/api/settings').json()['masked'], '••••••EY-A')        # the saved key was not replaced

    def test_models_list_is_free(self):
        self.c.post('/api/settings', data={'gemini_api_key': 'KEY-A'})
        r = self.c.post('/api/settings/models').json()
        self.assertTrue(r['ok'])
        self.assertIn('gemini-flash-latest', r['models'])
        self.assertNotIn('gemini-3.8-flash-tts', r['models'])

    def test_create_job_validation(self):
        before = len(self.c.get('/api/jobs').json()['jobs'])
        self.assertEqual(self.c.upload(self.video).status_code, 400)                        # no key yet
        self.c.post('/api/settings', data={'gemini_api_key': 'KEY-A'})
        r = self.c.upload(self.video, make_voice='0', make_subtitles='0')
        self.assertEqual(r.status_code, 400)
        self.assertEqual(self.c.upload(self.video, voice='nope').status_code, 400)
        self.assertEqual(self.c.upload(self.video, style='nope').status_code, 400)
        r = self.c.post('/api/jobs', data={'voice': 'thiha'}, files={'video': ('movie.exe', b'abc', 'application/octet-stream')})
        self.assertEqual(r.status_code, 400)
        self.assertEqual(len(self.c.get('/api/jobs').json()['jobs']), before)               # nothing half-created
        self.assertEqual([p for p in Path(self.app.TMP).glob('*.upload')], [])

    def test_only_real_video_containers_are_accepted(self):
        """ffmpeg picks the demuxer by CONTENT: a playlist called movie.mp4 must never reach it."""
        self.c.post('/api/settings', data={'gemini_api_key': 'KEY-A'})
        looks = self.app.media.looks_like_video
        tmp = Path(self.tmp) / 'sniff'
        tmp.mkdir(exist_ok=True)

        def probe(raw):
            f = tmp / 'x.bin'
            f.write_bytes(raw)
            return looks(f)
        self.assertTrue(looks(self.video))                                                  # a real mp4 made by ffmpeg
        self.assertTrue(probe(b'\x00\x00\x00\x18ftypmp42\x00\x00\x00\x00mp42isom'))
        self.assertTrue(probe(b'\x00\x00\x00\x08wide\x00\x00\x10\x00mdat'))              # old QuickTime layouts
        self.assertTrue(probe(b'\x1a\x45\xdf\xa3\x9fB\x86\x81\x01B\xf7\x81\x01'))           # Matroska / WebM
        self.assertTrue(probe(b'RIFF\x10\x00\x00\x00AVI LIST\x00\x00'))
        for bad in (b'', b'#EXTM3U\n#EXT-X-VERSION:3\n#EXTINF:1,\nfile:///etc/passwd\n', b'ffconcat version 1.0\nfile /etc/passwd\n',
                    b'v=0\r\no=- 0 0 IN IP4 127.0.0.1\r\ns=x\r\n', b'\0' * 64, b'GIF89a\x01\x00\x01\x00', b'MZ\x90\x00\x03', b'<html></html>',
                    b'RIFF\x10\x00\x00\x00WAVEfmt '):
            self.assertFalse(probe(bad), bad)
        self.assertFalse(looks(tmp / 'missing.mp4'))
        before = len(self.c.get('/api/jobs').json()['jobs'])
        for name, raw in (('movie.mp4', b'#EXTM3U\n#EXTINF:1,\nfile:///etc/passwd\n'), ('clip.mkv', b'ffconcat version 1.0\nfile /etc/hosts\n'),
                          ('a.avi', b'not a video at all' * 50)):
            r = self.c.post('/api/jobs', data={'voice': 'thiha'}, files={'video': (name, raw, 'video/mp4')})
            self.assertEqual(r.status_code, 400, name)
            self.assertIn('video', r.json()['detail'])
        self.assertEqual(len(self.c.get('/api/jobs').json()['jobs']), before)               # nothing was created
        self.assertEqual([p for p in Path(self.app.TMP).glob('*.upload')], [])
        r = self.c.upload(self.video)                                                       # a real one still works
        self.assertEqual(r.status_code, 200, r.text)
        self.c.post(f"/api/jobs/{r.json()['id']}/cancel")

    def test_a_job_in_the_story_style_sends_all_the_text_at_once_and_completes(self):
        self.c.post('/api/settings', data={'gemini_api_key': 'KEY-A'})
        self.mock.state.generate = with_story(unique_generate())
        r = self.c.upload(self.video, style='story', speed='45', render_speed='ultrafast')
        self.assertEqual(r.status_code, 200, r.text)
        j = self.c.wait_job(r.json()['id'], ('completed', 'failed'))
        self.assertEqual(j['status'], 'completed', j.get('error'))
        self.assertEqual((j['params']['style'], j['params']['speed']), ('story', 45))
        self.assertNotIn('provider', j['params'])
        self.assertIn('Style=Story telling', j['detail'])
        texts = [q for q in self.mock.state.requests if q['action'] == 'generateContent' and 'systemInstruction' in q['payload']]
        self.assertEqual(len(texts), 1)                                                    # the whole film in ONE request
        self.assertIn('charismatic Burmese storyteller', texts[0]['payload']['systemInstruction']['parts'][0]['text'])
        self.assertEqual(j['stats']['source_lines'], TOTAL_LINES)
        self.assertEqual(j['stats']['lines'], TOTAL_LINES // 3)

    def test_the_old_styles_are_gone(self):
        self.c.post('/api/settings', data={'gemini_api_key': 'KEY-A'})
        for old in ('dub', 'recap', 'translate', 'suspense', 'emotional', 'comedy', 'friend'):
            self.assertEqual(self.c.upload(self.video, style=old).status_code, 400, old)

    # ---- V22.2: Gemini is the only AI (Claude and Groq were removed)
    def test_the_settings_know_only_gemini(self):
        r = self.c.post('/api/settings', data={'gemini_api_key': 'KEY-A', 'gemini_model': 'gemini-3.6-flash',
                                               'claude_api_key': 'sk-ant-KEY', 'groq_api_key': 'gsk_KEY', 'provider': 'claude'})   # (unknown fields are ignored)
        self.assertEqual(r.status_code, 200, r.text)
        s = r.json()
        self.assertEqual((s['configured'], s['masked'], s['model']), (True, '••••••EY-A', 'gemini-3.6-flash'))
        self.assertNotIn('providers', s)
        self.assertNotIn('provider', s)
        self.assertEqual(s['key_site'], 'Google AI Studio')
        self.assertEqual(sorted(self.app.USERS.read('local')), ['gemini_key_enc', 'gemini_model'])    # nothing was saved for Claude / Groq

    def test_key_and_model_are_checked_before_anything_is_saved(self):
        self.assertEqual(self.c.post('/api/settings', data={'gemini_model': 'gemini-3.6-flash'}).status_code, 400)       # a model without a key
        self.c.post('/api/settings', data={'gemini_api_key': 'KEY-A'})
        self.assertEqual(self.c.post('/api/settings', data={'gemini_api_key': 'has space'}).status_code, 400)
        for bad in ('a/b', 'qwen/qwen3.8-27b', 'a/../b', '../x'):                                 # a slash is never valid in a Gemini model name
            r = self.c.post('/api/settings', data={'gemini_model': bad})
            self.assertEqual(r.status_code, 400, bad)
        self.assertEqual(self.c.get('/api/settings').json()['model'], 'gemini-flash-latest')
        self.assertEqual(self.c.post('/api/settings', data={'gemini_model': 'models/gemini-3.6-flash'}).json()['model'], 'gemini-3.6-flash')

    def test_a_job_cannot_start_without_the_gemini_key(self):
        r = self.c.upload(self.video)
        self.assertEqual(r.status_code, 400)
        self.assertIn('Gemini', r.json()['detail'])
        self.assertEqual([q for q in self.mock.state.requests if q['action'] == 'generateContent'], [])

    def test_the_old_claude_and_groq_settings_are_deleted_at_start_up(self):
        self.c.post('/api/settings', data={'gemini_api_key': 'KEY-A', 'gemini_model': 'gemini-3.6-flash'})
        data = self.app.USERS.read('local')
        data.update({'claude_key_enc': self.app.USERS.box.encrypt('sk-ant-OLD'), 'groq_key_enc': self.app.USERS.box.encrypt('gsk_OLD'),
                     'claude_model': 'claude-haiku-5-5', 'groq_model': 'openai/gpt-oss-120b', 'provider': 'groq'})
        self.app.USERS.write('local', data)
        self.app.purge_removed_ai()
        left = self.app.USERS.read('local')
        self.assertEqual(sorted(left), ['gemini_key_enc', 'gemini_model'])
        s = self.c.get('/api/settings').json()
        self.assertEqual((s['configured'], s['model']), (True, 'gemini-3.6-flash'))               # the Gemini key and model were not touched

    def test_gemini_voices_work_and_need_only_the_gemini_key(self):
        self.assertEqual(self.c.get('/api/voice-sample/g_kore').status_code, 400)                 # no key yet
        self.c.post('/api/settings', data={'gemini_api_key': 'KEY-A'})
        r = self.c.upload(self.video, voice='g_kore', make_subtitles='0', render_speed='ultrafast')
        self.assertEqual(r.status_code, 200, r.text)
        self.c.post(f"/api/jobs/{r.json()['id']}/cancel")

    def test_test_and_models_are_free(self):
        self.c.post('/api/settings', data={'gemini_api_key': 'KEY-A'})
        r = self.c.post('/api/settings/test', data={'gemini_api_key': 'KEY-TYPED'}).json()
        self.assertEqual((r['ok'], r['free'], r['model']), (True, True, 'gemini-flash-latest'))
        r = self.c.post('/api/settings/test', data={'gemini_model': 'nope'}).json()
        self.assertFalse(r['ok'])
        r = self.c.post('/api/settings/models', data={}).json()
        self.assertTrue(r['ok'])
        self.assertIn('gemini-3.6-flash', r['models'])
        self.assertNotIn('gemini-3.8-flash-tts', r['models'])                                     # a speech model is not a text model
        self.assertEqual(self.mock.state.count(method='POST', action='generateContent'), 0)       # nothing was generated
        self.assertEqual(self.c.get('/api/settings').json()['masked'], '••••••EY-A')              # (a typed key is not saved by a test)

    def test_the_speed_limit_is_the_servers(self):
        self.c.post('/api/settings', data={'gemini_api_key': 'KEY-A'})
        r = self.c.upload(self.video, speed='500', render_speed='ultrafast')
        self.assertEqual(r.status_code, 200, r.text)
        self.assertEqual(self.c.get('/api/jobs/' + r.json()['id']).json()['params']['speed'], 60)
        self.c.post(f"/api/jobs/{r.json()['id']}/cancel")

    def test_full_job_download_range_and_list(self):
        self.c.post('/api/settings', data={'gemini_api_key': 'KEY-A'})
        r = self.c.upload(self.video, speed='15', render_speed='ultrafast')
        self.assertEqual(r.status_code, 200, r.text)
        jid = r.json()['id']
        j = self.c.wait_job(jid, ('completed', 'failed'))
        self.assertEqual(j['status'], 'completed', j.get('error'))
        self.assertNotIn('owner', j)
        self.assertEqual(j['params']['speed'], 15)
        self.assertEqual(j['params']['voice'], 'thiha')
        self.assertIn('/api/files/' + jid, j['output_url'])
        f = self.c.get(j['output_url'])
        self.assertEqual((f.status_code, f.headers['content-type']), (200, 'video/mp4'))
        size = int(f.headers['content-length'])
        part = self.c.get(j['output_url'], headers={'Range': 'bytes=0-99'})
        self.assertEqual((part.status_code, len(part.content)), (206, 100))
        self.assertTrue(part.headers['content-range'].endswith('/' + str(size)))
        dl = self.c.get(j['output_url'] + '?download=1')
        self.assertIn('attachment', dl.headers['content-disposition'])
        self.assertEqual(self.c.get(f'/api/files/{jid}/job.json').status_code, 404)           # only the result files
        self.assertEqual(self.c.get(f'/api/files/{jid}/..%2f..%2fsecret.key').status_code, 404)
        self.assertEqual(self.c.get('/api/files/' + 'a' * 32 + '/final_burmese.mp4').status_code, 404)
        jobs = self.c.get('/api/jobs').json()['jobs']
        self.assertEqual([x['id'] for x in jobs][:1], [jid])
        self.assertFalse(jobs[0]['can_resume'])
        self.assertNotIn('burmese_text', jobs[0])
        # voice speed from the website reached the speech engine
        self.assertTrue(all(c[2] == '+15%' for c in FakeEdge.calls))
        self.assertEqual(self.c.delete(f'/api/jobs/{jid}').status_code, 200)
        self.assertEqual(self.c.get(f'/api/jobs/{jid}').status_code, 404)

    def test_pause_when_credit_ends_then_new_key_continues(self):
        self.exhausted_after(1)
        self.c.post('/api/settings', data={'gemini_api_key': 'KEY-A'})
        jid = self.c.upload(self.video).json()['id']
        j = self.c.wait_job(jid, ('paused', 'completed', 'failed'))
        self.assertEqual(j['status'], 'paused', j.get('error'))
        self.assertEqual(j['pause']['kind'], 'quota')
        self.assertTrue(j['can_cancel'] and j['running'])
        # a key Gemini does not accept: refused at once, the job keeps waiting
        self.mock.state.valid_keys = {'KEY-A', 'KEY-B'}
        r = self.c.post(f'/api/jobs/{jid}/resume', data={'gemini_api_key': 'KEY-WRONG'})
        self.assertEqual(r.status_code, 400)
        self.assertIn('API key', r.json()['detail'])
        self.assertEqual(self.c.get(f'/api/jobs/{jid}').json()['status'], 'paused')
        self.assertEqual(self.c.get('/api/settings').json()['masked'], '••••••EY-A')          # the bad key was not saved
        # the new key
        r = self.c.post(f'/api/jobs/{jid}/resume', data={'gemini_api_key': 'KEY-B'})
        self.assertEqual(r.status_code, 200, r.text)
        j = self.c.wait_job(jid, ('completed', 'failed'))
        self.assertEqual(j['status'], 'completed', j.get('error'))
        self.assertEqual(self.c.get('/api/settings').json()['masked'], '••••••EY-B')          # remembered for the next jobs
        keys = [q['key'] for q in self.mock.state.requests if q['action'] == 'generateContent']
        self.assertEqual(keys.count('KEY-A'), 2)                                              # the 1 good batch + the refused one
        self.assertEqual(keys.count('KEY-B'), 3)                                              # only the 3 remaining batches
        self.assertEqual(sorted(self.whisper.calls), [0, 1, 2])

    def test_cancel_while_paused(self):
        self.exhausted_after(0)
        self.c.post('/api/settings', data={'gemini_api_key': 'KEY-A'})
        jid = self.c.upload(self.video).json()['id']
        self.assertEqual(self.c.wait_job(jid, ('paused', 'failed'))['status'], 'paused')
        r = self.c.post(f'/api/jobs/{jid}/cancel')
        self.assertEqual(r.status_code, 200)
        j = self.c.wait_job(jid, ('cancelled', 'failed'))
        self.assertEqual(j['status'], 'cancelled')
        self.assertFalse(j['can_resume'])
        jobdir = Path(self.app.STORE.dir(jid))
        end = time.time() + 5
        while time.time() < end and {p.name for p in jobdir.iterdir()} != {'job.json'}:
            time.sleep(0.05)
        self.assertEqual({p.name for p in jobdir.iterdir()}, {'job.json'})

    def test_failed_job_can_be_continued_or_discarded(self):
        base = unique_generate()
        n = {'c': 0}

        def gen(system, user):
            n['c'] += 1
            if n['c'] == 3:
                return 400, M.err(400, 'Request contains an invalid argument.', 'INVALID_ARGUMENT')
            return base(system, user)
        self.mock.state.generate = gen
        self.c.post('/api/settings', data={'gemini_api_key': 'KEY-A'})
        jid = self.c.upload(self.video).json()['id']
        j = self.c.wait_job(jid, ('failed', 'completed'))
        self.assertEqual(j['status'], 'failed')
        end = time.time() + 5
        while self.app.RUNNER.running(jid) and time.time() < end:
            time.sleep(0.05)
        j = self.c.get(f'/api/jobs/{jid}').json()
        self.assertTrue(j['can_resume'])
        self.assertEqual(self.c.post(f'/api/jobs/{jid}/resume').status_code, 200)
        j = self.c.wait_job(jid, ('completed', 'failed'))
        self.assertEqual(j['status'], 'completed', j.get('error'))
        self.assertEqual(self.c.post(f'/api/jobs/{jid}/resume').status_code, 409)             # nothing left to continue
        # and a second failed job can be thrown away
        n['c'] = 0
        jid2 = self.c.upload(self.video).json()['id']
        self.assertEqual(self.c.wait_job(jid2, ('failed', 'completed'))['status'], 'failed')
        end = time.time() + 5
        while self.app.RUNNER.running(jid2) and time.time() < end:
            time.sleep(0.05)
        self.assertEqual(self.c.post(f'/api/jobs/{jid2}/cancel').json()['job']['status'], 'cancelled')

    def test_voice_samples(self):
        self.c.post('/api/settings', data={'gemini_api_key': 'KEY-A'})
        r = self.c.get('/api/voice-sample/thiha')
        self.assertEqual((r.status_code, r.headers['content-type']), (200, 'audio/wav'))
        self.assertEqual(r.headers['x-sample-ok'], '1', r.headers.get('x-sample-message'))
        self.assertTrue(r.content[:4] == b'RIFF')
        self.assertEqual(self.c.get('/api/voice-sample/thiha-deep').status_code, 200)         # old ids still work
        self.assertEqual(self.c.get('/api/voice-sample/nobody').status_code, 404)
        g = self.c.get('/api/voice-sample/g_kore')
        self.assertEqual(g.status_code, 200, g.text)
        self.assertTrue(any('responseModalities' in json.dumps(q['payload']) for q in self.mock.state.requests))
        self.c.delete('/api/settings')
        self.assertEqual(self.c.get('/api/voice-sample/g_puck').status_code, 400)             # a Gemini voice needs the key

    def test_cross_site_post_is_refused(self):
        r = self.c.post('/api/settings', data={'gemini_api_key': 'KEY-A'}, headers={'Origin': 'http://evil.example'})
        self.assertEqual(r.status_code, 403)
        r = self.c.post('/api/settings', data={'gemini_api_key': 'KEY-A'}, headers={'Origin': self.server.url})
        self.assertEqual(r.status_code, 200)

    def test_security_headers_and_health(self):
        r = self.c.get('/api/health')
        self.assertEqual(r.headers['x-content-type-options'], 'nosniff')
        self.assertEqual(r.headers['cache-control'], 'no-store')
        h = r.json()
        self.assertTrue(h['ok'])
        self.assertIn('whisper_threads', h)
        self.assertGreaterEqual(h['whisper_threads'], 1)

    def test_hardening_headers_and_limits_in_local_mode(self):
        r = self.c.get('/')
        self.assertIn("frame-ancestors 'none'", r.headers['content-security-policy'])
        self.assertIs(self.c.get('/api/health').json()['ffmpeg'], True)            # no server path is shown
        # an "Origin: null" request (sandboxed frame, file:// page) is never this website
        r = self.c.post('/api/settings', data={'gemini_api_key': 'KEY-A'}, headers={'Origin': 'null'})
        self.assertEqual(r.status_code, 403)
        # a key is never 400 characters long
        self.assertEqual(self.c.post('/api/settings', data={'gemini_api_key': 'A' * 401}).status_code, 400)
        # a model name goes into the Gemini address: only plain model-name characters. Nothing is saved when it is refused.
        for bad in ('../../v1beta/files?x=1', 'gemini x', 'a/b', 'gemini:generate', 'g' * 100, 'models/a/b', '-x'):
            r = self.c.post('/api/settings', data={'gemini_api_key': 'KEY-A', 'gemini_model': bad})
            self.assertEqual(r.status_code, 400, bad)
        self.assertFalse(self.c.get('/api/settings').json()['configured'])
        self.assertEqual(self.c.post('/api/settings/test', data={'gemini_api_key': 'KEY-A', 'gemini_model': 'a/../b'}).status_code, 400)
        ok = self.c.post('/api/settings', data={'gemini_api_key': 'KEY-A', 'gemini_model': 'models/gemini-2.5-flash-preview-05-20'})
        self.assertEqual((ok.status_code, ok.json()['model']), (200, 'gemini-2.5-flash-preview-05-20'))
        # every form except the video upload is tiny: a bigger body is refused before it is read
        call = asyncio.run(AsgiCall(self.app.app, '/api/settings', {'content-type': 'application/x-www-form-urlencoded',
                                                                       'content-length': str(2 * 1048576)}, [MB, MB]).run())
        self.assertEqual((call.status, call.at_start), (413, 0))

    def test_drive_status_in_local_mode_and_settings(self):
        st = self.c.get('/api/drive/status').json()
        self.assertFalse(st['connected'])
        self.assertTrue(st['redirect_uri'].endswith('/api/drive/callback'))
        st = self.c.post('/api/drive/settings', data={'share_anyone': '1', 'folder_name': 'My Recaps'}).json()
        self.assertEqual((st['share_anyone'], st['folder_name']), (True, 'My Recaps'))
        self.c.post('/api/drive/settings', data={'share_anyone': '0'})


# ====================================================================================================== limits
class LimitsTests(AppTestBase):
    """Small limits (5 MB upload, ONE unfinished job): the server answers before it reads a body that will be refused."""
    NAME = 'app_limits'
    ENV = {'MAX_UPLOAD_MB': '5', 'MAX_JOBS_PER_USER': '1'}

    @classmethod
    def setUpClass(cls):
        super().setUpClass()
        cls.c = Client(cls.server.url)

    def setUp(self):
        super().setUp()
        self.c.delete('/api/settings')

    @staticmethod
    def form_headers(**extra):
        h = {'content-type': 'multipart/form-data; boundary=xyz'}
        h.update(extra)
        return h

    def test_one_unfinished_job_and_the_upload_limit(self):
        self.exhausted_after(0, key='KEY-A')
        self.c.post('/api/settings', data={'gemini_api_key': 'KEY-A'})
        first = self.c.upload(self.video).json()['id']
        self.assertEqual(self.c.wait_job(first, ('paused', 'failed'))['status'], 'paused')
        r = self.c.upload(self.video)
        self.assertEqual(r.status_code, 429)
        self.c.post(f'/api/jobs/{first}/cancel')
        self.c.wait_job(first, ('cancelled',))
        # the 5 MB limit of this test configuration (the file is a bit over the limit, the whole request still under limit + 2 MB)
        big = Path(self.tmp) / 'big.mp4'
        big.write_bytes(b'\0' * (6 * 1048576))
        r = self.c.upload(big)
        self.assertEqual(r.status_code, 413)
        self.assertEqual([p for p in Path(self.app.TMP).glob('*.upload')], [])               # no half-uploaded file is left
        self.assertEqual([j for j in self.c.get('/api/jobs').json()['jobs'] if j['status'] == 'queued'], [])
        self.assertEqual(self.app._UPLOADING, {})

    def test_too_big_uploads_are_refused_without_reading_them(self):
        # Content-Length already says it is too big (limit = 5 MB + the form fields)
        call = asyncio.run(AsgiCall(self.app.app, '/api/jobs', self.form_headers(**{'content-length': str(8 * 1048576)}), [MB] * 8).run())
        self.assertEqual((call.status, call.at_start), (413, 0))
        self.assertIn('5 MB', call.detail())
        self.assertEqual(call.reply_headers.get('connection'), 'close')
        # a chunked upload does not say how big it is: the server stops reading as soon as the limit is passed
        call = asyncio.run(AsgiCall(self.app.app, '/api/jobs', self.form_headers(), [FORM_START + MB] + [MB] * 13).run())
        self.assertEqual(call.status, 413)
        self.assertLessEqual(call.read, 8 * 1048576)
        self.assertIn('5 MB', call.detail())
        # the small forms
        call = asyncio.run(AsgiCall(self.app.app, '/api/settings', self.form_headers(**{'content-length': str(2 * 1048576)}), [MB, MB]).run())
        self.assertEqual((call.status, call.at_start), (413, 0))
        self.assertEqual(self.app._UPLOADING, {})

    def test_uploads_that_are_still_arriving_count_against_the_job_limit(self):
        async def scenario():
            gate = asyncio.Event()
            first = AsgiCall(self.app.app, '/api/jobs', self.form_headers(), [FORM_START + MB], gate=gate)
            running = asyncio.ensure_future(first.run())
            for _ in range(200):                                  # wait until the first upload is being received
                if first.read:
                    break
                await asyncio.sleep(0.02)
            counted = dict(self.app._UPLOADING)
            second = await AsgiCall(self.app.app, '/api/jobs', self.form_headers(), [MB] * 3).run()
            gate.set()
            await running
            return first, second, counted
        first, second, counted = asyncio.run(scenario())
        self.assertEqual((second.status, second.at_start), (429, 0))          # refused before its body was read
        self.assertIn('job 1', second.detail())
        self.assertEqual(counted, {'local': 1})
        self.assertIn(first.status, (400, 422))                               # (not a real video: it got as far as being parsed)
        self.assertEqual(self.app._UPLOADING, {})                             # counted out again

    def test_an_upload_that_is_cut_off_is_counted_out(self):
        async def scenario():
            gate = asyncio.Event()
            first = AsgiCall(self.app.app, '/api/jobs', self.form_headers(), [FORM_START + MB], gate=gate)
            running = asyncio.ensure_future(first.run())
            for _ in range(200):
                if first.read:
                    break
                await asyncio.sleep(0.02)
            running.cancel()                                      # the browser tab was closed: the request task is cancelled
            try:
                await running
            except (asyncio.CancelledError, Exception):           # noqa: BLE001
                pass
            return dict(self.app._UPLOADING)
        self.assertEqual(asyncio.run(scenario()), {})


# ====================================================================================================== password
class PasswordTests(AppTestBase):
    NAME = 'app_password'
    ENV = {'APP_PASSWORD': 's3cret', 'MAX_UPLOAD_MB': '5'}

    @classmethod
    def setUpClass(cls):
        super().setUpClass()
        cls.anon = Client(cls.server.url)
        cls.me = Client(cls.server.url)
        cls.me.http.auth = ('anybody', 's3cret')              # the browser's password prompt, answered once
        cls.wrong = Client(cls.server.url)
        cls.wrong.http.auth = ('anybody', 'not-it')

    def test_every_request_needs_the_password(self):
        for path in ('/', '/api/about', '/api/options', '/api/settings', '/api/jobs', '/api/health', '/api/drive/status', '/static/x'):
            for who in (self.anon, self.wrong):
                r = who.get(path)
                self.assertEqual(r.status_code, 401, path)
                self.assertIn('Basic', r.headers['www-authenticate'])                       # makes the browser ask for it
        self.assertEqual(self.anon.post('/api/settings', data={'gemini_api_key': 'KEY-A'}).status_code, 401)
        self.assertEqual(self.anon.delete('/api/settings').status_code, 401)
        r = self.me.get('/')
        self.assertEqual(r.status_code, 200)
        self.assertEqual(self.me.get('/api/about').json()['password_protected'], True)
        self.assertEqual(self.me.get('/api/jobs').status_code, 200)
        self.assertEqual(self.me.get('/api/settings').status_code, 200)

    def test_the_password_is_checked_before_a_body_is_read(self):
        hdr = {'content-type': 'multipart/form-data; boundary=xyz', 'content-length': str(4 * 1048576)}
        call = asyncio.run(AsgiCall(self.app.app, '/api/jobs', hdr, [FORM_START + MB] * 4).run())
        self.assertEqual((call.status, call.at_start), (401, 0))
        self.assertEqual(self.app._UPLOADING, {})
        hdr['authorization'] = 'Basic ' + base64.b64encode(b'x:wrong').decode()
        call = asyncio.run(AsgiCall(self.app.app, '/api/jobs', hdr, [FORM_START + MB] * 4).run())
        self.assertEqual((call.status, call.at_start), (401, 0))

    def test_a_job_runs_and_downloads_with_the_password(self):
        self.me.post('/api/settings', data={'gemini_api_key': 'KEY-A'})
        r = self.me.upload(self.video)
        self.assertEqual(r.status_code, 200, r.text)
        jid = r.json()['id']
        j = self.me.wait_job(jid, ('completed', 'failed'))
        self.assertEqual(j['status'], 'completed', j.get('error'))
        self.assertEqual(self.me.get(j['output_url']).status_code, 200)
        self.assertEqual(self.anon.get(j['output_url']).status_code, 401)                  # the result is behind the password too
        self.me.delete('/api/settings')


if __name__ == '__main__':
    unittest.main()
