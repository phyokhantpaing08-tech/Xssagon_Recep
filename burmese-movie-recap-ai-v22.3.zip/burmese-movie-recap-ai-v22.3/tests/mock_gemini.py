"""A fake Gemini API for the tests (stdlib only). It can be scripted to fail in the ways the real API fails:
503 "high demand", 429 per-minute, 429 daily quota, 429 "prepayment credits are depleted", 400 "API key not valid" ...
Everything it receives is recorded in `.requests`.
"""
import base64
import inspect
import json
import os
import re
import struct
import sys
import threading
import time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', 'backend'))
import timing as T  # noqa: E402

# Burmese phrases of growing length (used to "rewrite" and to "shorten")
POOL = [
    'ဟုတ်တယ်။',
    'သူ ပြန်လာတယ်။',
    'သူတို့ အိမ်ကို ပြန်သွားကြတယ်။',
    'ဒီနေ့ မနက်မှာ မိုးတွေ ရွာချခဲ့တယ်။',
    'သူက လမ်းထိပ်က ဈေးကို လျှောက်သွားပြီး ဝယ်စရာတွေ ဝယ်ခဲ့တယ်။',
    'ပြီးတော့ သူက လမ်းထိပ်က ဈေးကို တစ်ယောက်တည်း လျှောက်သွားပြီး မိသားစုအတွက် လိုတဲ့ ဝယ်စရာတွေ အကုန် ဝယ်ခဲ့တယ်။',
]
POOL_SYL = [T.syllables(p) for p in POOL]

# V21.3: what the fake "story analyst" answers (the system prompt of the story-notes request contains "story analyst")
STORY_NOTES = ['STORY: A little girl with a gift is adopted by a kind family.',
               'TONE: period family drama, everyday speech',
               'CHARACTER: Dodo = ဒိုဒို | girl, about six, the adopted daughter | calls the mother မေမေ']


def err(status, message, status_text='UNAVAILABLE', details=None):
    return {'error': {'code': status, 'message': message, 'status': status_text, 'details': details or []}}


def e503():
    return 503, err(503, 'This model is currently experiencing high demand. Spikes in demand are usually temporary. Please try again later.')


def e429_minute(delay='3s'):
    return 429, err(429, 'You exceeded your current quota, please check your plan and billing details.', 'RESOURCE_EXHAUSTED', [
        {'@type': 'type.googleapis.com/google.rpc.QuotaFailure', 'violations': [
            {'quotaMetric': 'generativelanguage.googleapis.com/generate_content_free_tier_requests',
             'quotaId': 'GenerateRequestsPerMinutePerProjectPerModel-FreeTier'}]},
        {'@type': 'type.googleapis.com/google.rpc.RetryInfo', 'retryDelay': delay}])


def e429_day():
    return 429, err(429, 'You exceeded your current quota, please check your plan and billing details.', 'RESOURCE_EXHAUSTED', [
        {'@type': 'type.googleapis.com/google.rpc.QuotaFailure', 'violations': [
            {'quotaMetric': 'generativelanguage.googleapis.com/generate_content_free_tier_requests',
             'quotaId': 'GenerateRequestsPerDayPerProjectPerModel-FreeTier'}]},
        {'@type': 'type.googleapis.com/google.rpc.RetryInfo', 'retryDelay': '30s'}])


def e429_prepay():
    return 429, err(429, 'Your prepayment credits are depleted. Please go to AI Studio at https://ai.studio/projects to manage your project and billing.', 'RESOURCE_EXHAUSTED')


def e400_key():
    return 400, err(400, 'API key not valid. Please pass a valid API key.', 'INVALID_ARGUMENT')


def e401_auth():
    return 401, err(401, 'API keys are not supported by this API. Expected OAuth2 access token or other authentication credentials that assert a principal.',
                    'UNAUTHENTICATED', [{'@type': 'type.googleapis.com/google.rpc.ErrorInfo', 'reason': 'ACCESS_TOKEN_TYPE_UNSUPPORTED'}])


def e400_thinking():
    return 400, err(400, 'Thinking budget is not supported for this model.', 'INVALID_ARGUMENT')


class State:
    def __init__(self):
        self.lock = threading.Lock()
        self.requests = []
        self.script = []                      # [{'model':..,'key':..,'path':.., 'times': n, 'status':.., 'body':..}]
        self.models = ['gemini-flash-latest', 'gemini-3.6-flash', 'gemini-3.5-flash-lite', 'gemini-3.1-flash-lite',
                       'gemini-2.5-flash', 'gemini-3.8-flash-tts']
        self.valid_keys = None                # None = every key is valid
        self.tts_mode = 'classic'             # which TTS layout the fake API accepts
        self.delay = 0.0                      # artificial latency of generateContent
        self.stall = None                     # V22.2: stall(model, payload) -> seconds to sleep before answering (a client with a short timeout then sees "Read timed out")

    def push(self, status_body, model=None, key=None, path=None, times=1):
        status, body = status_body
        self.script.append({'model': model, 'key': key, 'path': path, 'times': times, 'status': status, 'body': body})

    def count(self, **kw):
        n = 0
        for r in self.requests:
            if all(r.get(k) == v for k, v in kw.items()):
                n += 1
        return n


def _parse_input(user):
    m = re.search(r'INPUT JSON ARRAY:\s*', user)
    if not m:
        return []
    try:
        arr, _ = json.JSONDecoder().raw_decode(user[m.end():])
        return arr
    except ValueError:
        return []


def _choose(max_syl, seed):
    fits = [p for p, n in zip(POOL, POOL_SYL) if n <= max_syl]
    if not fits:
        return POOL[0]
    # the longest phrase that fits (rotating among equally long ones is not needed for the tests)
    return fits[-1]


STORY_ROW = re.compile(r'^(\d+)\|([\d.]+)-([\d.]+)\|(.*)$', re.M)


def story_rows(user):
    """The transcript rows of a story request: [(number, start, end, text)]."""
    return [(int(n), float(a), float(b), t) for n, a, b, t in STORY_ROW.findall(user or '')]


def story_generate(system, user, group=3):
    """The fake storyteller (V22): one piece for every `group` rows, with a short Burmese sentence."""
    rows = story_rows(user)
    digits = lambda n: ''.join('၀၁၂၃၄၅၆၇၈၉'[int(c)] for c in str(n))
    # (every piece has its own text: the pipeline blanks a line that repeats the one before it)
    return [{'from': rows[k][0], 'to': rows[min(k + group, len(rows)) - 1][0], 'text': POOL[2] + ' ' + digits(rows[k][0])}
            for k in range(0, len(rows), group)]


def default_generate(system, user):
    if 'story analyst' in (system or ''):
        return list(STORY_NOTES)
    if 'charismatic Burmese storyteller' in (system or ''):
        return story_generate(system, user)
    items = _parse_input(user)
    out = []
    shorten = 'timing editor' in (system or '')
    for k, it in enumerate(items):
        if isinstance(it, dict):
            limit = int(it.get('max_syllables') or 999)
            text = str(it.get('text') or '')
            out.append('' if not text.strip() else _choose(limit, k))
        else:
            out.append(POOL[2] if str(it).strip() else '')
    return out


class Handler(BaseHTTPRequestHandler):
    protocol_version = 'HTTP/1.1'

    def log_message(self, *a):
        pass

    def _send(self, status, body, headers=None):
        raw = json.dumps(body).encode('utf-8')
        try:
            self.send_response(status)
            self.send_header('Content-Type', 'application/json')
            self.send_header('Content-Length', str(len(raw)))
            for k, v in (headers or {}).items():
                self.send_header(k, v)
            self.end_headers()
            self.wfile.write(raw)
        except (BrokenPipeError, ConnectionResetError):          # the client gave up waiting (a timeout test): nothing to tell it any more
            self.close_connection = True

    def _scripted(self, model, key, path):
        st = self.server.state
        with st.lock:
            for item in st.script:
                if item['times'] <= 0:
                    continue
                if item['model'] and item['model'] != model:
                    continue
                if item['key'] and item['key'] != key:
                    continue
                if item['path'] and item['path'] not in path:
                    continue
                item['times'] -= 1
                return item['status'], item['body']
        return None

    def _handle(self, method):
        st = self.server.state
        path = self.path.split('?')[0]
        key = self.headers.get('x-goog-api-key', '')
        length = int(self.headers.get('Content-Length') or 0)
        payload = json.loads(self.rfile.read(length) or b'{}') if length else {}
        m = re.match(r'^/v1beta/models/([^:/]+)(?::(\w+))?$', path)
        model = m.group(1) if m else ''
        action = (m.group(2) if m else '') or ''
        if path == '/v1beta/interactions':
            model = payload.get('model', '')
            action = 'interactions'
        with st.lock:
            st.requests.append({'method': method, 'path': path, 'model': model, 'key': key, 'action': action,
                                'payload': payload, 'time': time.time()})
        if st.valid_keys is not None and key not in st.valid_keys:
            return self._send(*e400_key())
        scripted = self._scripted(model, key, path + ':' + action)
        if scripted:
            status, body = scripted
            headers = {'Retry-After': '1'} if status == 429 else {}
            return self._send(status, body, headers)
        if method == 'GET':
            if path == '/v1beta/models':
                return self._send(200, {'models': [{'name': f'models/{n}', 'supportedGenerationMethods': ['generateContent', 'countTokens']} for n in st.models]})
            if model in st.models:
                return self._send(200, {'name': f'models/{model}', 'displayName': model, 'inputTokenLimit': 1048576,
                                        'outputTokenLimit': 65536, 'supportedGenerationMethods': ['generateContent', 'countTokens']})
            return self._send(404, err(404, f'models/{model} is not found for API version v1beta, or is not supported for generateContent.', 'NOT_FOUND'))
        if model not in st.models:
            return self._send(404, err(404, f'models/{model} is not found for API version v1beta, or is not supported for generateContent.', 'NOT_FOUND'))
        if action == 'countTokens':
            return self._send(200, {'totalTokens': 1})
        if st.delay:
            time.sleep(st.delay)
        stall = st.stall(model, payload) if st.stall else 0
        if stall:
            time.sleep(stall)
        if action == 'generateContent':
            gen = payload.get('generationConfig') or {}
            if 'responseModalities' in gen:                       # Gemini TTS, classic layout
                if st.tts_mode != 'classic':
                    return self._send(400, err(400, 'This model only supports the Interactions API.', 'INVALID_ARGUMENT'))
                text = payload['contents'][0]['parts'][0]['text']
                return self._send(200, {'candidates': [{'finishReason': 'STOP', 'content': {'parts': [
                    {'inlineData': {'mimeType': 'audio/L16;codec=pcm;rate=24000', 'data': _tone_b64(text)}}]}}],
                    'usageMetadata': {'totalTokenCount': 10}})
            system = ((payload.get('systemInstruction') or {}).get('parts') or [{}])[0].get('text', '')
            user = payload['contents'][0]['parts'][0]['text']
            fn = st.generate if hasattr(st, 'generate') else default_generate
            try:
                wants_key = len(inspect.signature(fn).parameters) >= 3       # generate(system, user, key)
            except (TypeError, ValueError):
                wants_key = False
            arr = fn(system, user, key) if wants_key else fn(system, user)
            if isinstance(arr, tuple):                            # a custom generator may answer with (status, body)
                return self._send(*arr)
            return self._send(200, {'candidates': [{'finishReason': 'STOP', 'content': {'parts': [{'text': json.dumps(arr, ensure_ascii=False)}]}}],
                                    'usageMetadata': {'totalTokenCount': 100}})
        if action == 'interactions':
            text = payload['input'][0]['content'][0]['text']
            return self._send(200, {'steps': [{'type': 'model_output', 'content': [
                {'type': 'audio', 'mime_type': 'audio/l16;rate=24000', 'data': _tone_b64(text)}]}]})
        return self._send(404, err(404, 'unknown endpoint', 'NOT_FOUND'))

    def do_GET(self):
        self._handle('GET')

    def do_POST(self):
        self._handle('POST')


def _tone_b64(text, sr=24000):
    import math
    seconds = max(0.3, len(text) * 0.06)
    n = int(seconds * sr)
    samples = [int(9000 * math.sin(2 * math.pi * 200 * i / sr)) for i in range(n)]
    return base64.b64encode(struct.pack('<%dh' % n, *samples)).decode('ascii')


class MockGemini:
    def __init__(self):
        self.state = State()
        self.httpd = ThreadingHTTPServer(('127.0.0.1', 0), Handler)
        self.httpd.state = self.state
        self.port = self.httpd.server_address[1]
        self.url = f'http://127.0.0.1:{self.port}/v1beta'
        self.thread = threading.Thread(target=self.httpd.serve_forever, daemon=True)

    def __enter__(self):
        self.thread.start()
        self._old = os.environ.get('GEMINI_BASE_URL')
        os.environ['GEMINI_BASE_URL'] = self.url
        return self

    def __exit__(self, *a):
        self.httpd.shutdown()
        self.httpd.server_close()
        if self._old is None:
            os.environ.pop('GEMINI_BASE_URL', None)
        else:
            os.environ['GEMINI_BASE_URL'] = self._old
