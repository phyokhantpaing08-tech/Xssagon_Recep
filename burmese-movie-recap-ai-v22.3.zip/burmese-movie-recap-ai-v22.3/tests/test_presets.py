"""The two styles (presets.py): "direct" must stay exactly the old line-by-line translation prompt, "story" must carry the rules it
was written for (no line-by-line translation, a JSON array of {"from", "to", "text"} pieces covering every row, the time rule)."""
import hashlib
import os
import sys
import unittest

HERE = os.path.dirname(__file__)
sys.path.insert(0, os.path.join(HERE, '..', 'backend'))

import presets as P     # noqa: E402

# sha1[:16] of build_system_prompt('direct', make_voice, timed) as it is in V22.1 (the owner's "Paste 1" prompt, word for word, plus the
# delivery block and the strict output rules). A change of the prompt text must be a decision: update the numbers together with it.
DIRECT_V221 = {(True, True): 'f4900002dbff31cc', (True, False): '507939ba282e9a4c', (False, True): '6f97535f9f11912c'}


def digest(text):
    return hashlib.sha1(text.encode('utf-8')).hexdigest()[:16]


class TwoStylesTests(unittest.TestCase):
    def test_only_two_styles_are_left_direct_and_story(self):
        self.assertEqual(list(P.STYLE_PRESETS), ['direct', 'story'])
        for key, st in P.STYLE_PRESETS.items():
            self.assertTrue(st['name'] and st['label'] and st['desc'] and st['mode'], key)
        self.assertEqual(P.STYLE_PRESETS['direct']['label'], '🔤 တိုက်ရိုက်စာတန်းထိုးဟန်')
        self.assertEqual(P.STYLE_PRESETS['story']['label'], '📖 ဇာတ်လမ်းပြောဟန်')

    def test_the_default_and_the_recommended_style_exist(self):
        self.assertIn(P.DEFAULT_STYLE, P.STYLE_PRESETS)
        self.assertIn(P.RECOMMENDED_STYLE, P.STYLE_PRESETS)

    def test_an_unknown_or_old_style_falls_back_to_the_default(self):
        for old in ('recap', 'dub', 'suspense', 'emotional', 'comedy', 'friend', 'translate', '', None, 'nope'):
            self.assertEqual(P.normalize_style(old), P.DEFAULT_STYLE, old)
        self.assertEqual(P.normalize_style('story'), 'story')
        self.assertEqual(P.normalize_style(' Story '), 'story')

    def test_modes(self):
        self.assertEqual(P.mode_of('direct'), 'line')
        self.assertEqual(P.mode_of('story'), 'story')
        self.assertTrue(P.is_story('story'))
        self.assertFalse(P.is_story('direct'))
        self.assertFalse(P.is_story('dub'))            # a style that no longer exists is the default (line by line)
        self.assertFalse(P.is_story(None))

    def test_the_old_helpers_are_gone(self):
        for gone in ('RECAP_PROMPT', 'DUB_PROMPT', 'SUSPENSE_PROMPT', 'EMOTIONAL_PROMPT', 'COMEDY_PROMPT', 'FRIEND_PROMPT',
                     'uses_story_notes', 'STRICT_RULES_NEXT', 'DELIVERY_VOICE_TIMED_NATURAL'):
            self.assertFalse(hasattr(P, gone), gone)


class DirectStyleTests(unittest.TestCase):
    def test_it_builds_exactly_the_prompt_of_v22_1(self):
        for (voice, timed), want in DIRECT_V221.items():
            with self.subTest(voice=voice, timed=timed):
                self.assertEqual(digest(P.build_system_prompt('direct', voice, timed)), want)

    def test_paste_1_is_used_word_for_word(self):
        self.assertTrue(P.TRANSLATE_PROMPT.startswith('You are an expert Burmese film subtitle translator.'))
        for must in ('CORE TRANSLATION RULES:', '1. Translate Meaning & Subtext, Never Word-for-Word:', '2. Spoken Burmese Only (Zero Literary Burmese):',
                     '3. Natural Pronoun Usage & Pronoun Dropping:', '4. Accurate Burmese Question Grammar:', '5. Emotional Tone & Sentence-Ending Particles:',
                     '6. Examples of Bad (Literal/Stiff) vs. Good (Natural Spoken):', '7. Script, Names & Cleanliness:', 'ဘယ်သွားမလို့လဲ',
                     'ကိုယ့်ကိုယ်ကိုယ် ဂရုစိုက်ဦးနော်။'):
            self.assertIn(must, P.TRANSLATE_PROMPT, must)
        self.assertIn(P.TRANSLATE_PROMPT, P.build_system_prompt('direct', True, True))
        self.assertIn(P.TRANSLATE_PROMPT, P.build_system_prompt('direct', False, True))

    def test_its_own_output_format_block_is_replaced_by_the_json_rules(self):
        s = P.build_system_prompt('direct', True, True)
        self.assertIn('Return ONLY the translated Burmese line(s)', s)               # Paste 1 as written ...
        self.assertIn('they replace the "OUTPUT FORMAT" block above', s)             # ... and the rule that wins
        self.assertLess(s.index('OUTPUT FORMAT:'), s.index('STRICT OUTPUT RULES'))
        self.assertTrue(s.rstrip().endswith('never include it in the array.'))

    def test_the_shorten_prompt_is_unchanged(self):
        self.assertEqual(digest(P.SHORTEN_SYSTEM), '4e068ce4aacc9e9c')

    def test_one_line_in_one_string_out(self):
        s = P.build_system_prompt('direct', True, True)
        self.assertIn('expert Burmese film subtitle translator', s)
        self.assertIn('EXACTLY one output string for every input line', s)
        self.assertIn('MUST NOT be longer than its max_syllables', s)
        self.assertNotIn('"from"', s)
        self.assertNotIn('NEXT SOURCE LINES', s)

    def test_subtitles_only_has_no_time_budget(self):
        s = P.build_system_prompt('direct', False, True)
        self.assertNotIn('max_syllables', s)
        self.assertIn('on-screen Burmese subtitles', s)

    def test_an_old_style_name_gives_the_direct_prompt(self):
        self.assertEqual(P.build_system_prompt('dub', True, True), P.build_system_prompt('direct', True, True))


class StoryPromptTests(unittest.TestCase):
    def setUp(self):
        self.voice = P.build_story_prompt(True, 5.2)

    def test_it_is_not_a_line_by_line_translation(self):
        self.assertIn('NOT lines to translate one by one', self.voice)
        self.assertIn('single, unbroken stream', self.voice)
        self.assertIn('Never invent fake plot points', self.voice)
        self.assertNotIn('EXACTLY one output string for every input line', self.voice)

    def test_the_answer_is_a_json_array_of_pieces_that_cover_every_row(self):
        for must in ('ONLY a JSON array', '"from"', '"to"', '"text"', 'cover EVERY row', 'never overlap', 'row numbers'):
            self.assertIn(must, self.voice, must)

    def test_the_voice_version_carries_the_pace_and_the_syllable_rule(self):
        self.assertIn('5.2', self.voice)
        self.assertIn('syllables per second', self.voice)
        self.assertIn('15 seconds', self.voice)
        self.assertNotIn('{pace}', self.voice)
        self.assertNotIn('{max_span}', self.voice)

    def test_the_subtitle_version_is_about_reading(self):
        subs = P.build_story_prompt(False, 5.0)
        self.assertIn('on-screen Burmese subtitles', subs)
        self.assertIn('8 seconds', subs)
        self.assertNotIn('neural', subs)

    def test_the_pace_is_kept_in_a_sensible_range(self):
        self.assertIn('9.0', P.build_story_prompt(True, 40))
        self.assertIn('2.0', P.build_story_prompt(True, 0.1))

    def test_paste_2_is_used_word_for_word(self):
        self.assertTrue(P.STORY_PROMPT.startswith('You are a charismatic Burmese storyteller'))
        for must in ('1. CONTINUOUS NARRATION & ZERO GAPS (CRITICAL):', 'Never Return Empty Text', 'Smart Time-Filling', 'Seamless Segment Transitions',
                     '2. TRANSFORM DIALOGUE INTO STORYTELLING:', 'First-Person Storyteller Persona', 'ကျွန်တော်', '3. NATURAL SPOKEN BURMESE & ANTI-REPETITION:',
                     'Ban Repetitive Openers', '4. ACCURACY, CLEANUP & SCRIPT RULES:', 'follow STORY NOTES if provided',
                     'the target speaking pace defined in the TIMING block below'):
            self.assertIn(must, P.STORY_PROMPT, must)
        self.assertTrue(self.voice.startswith(P.STORY_PROMPT))

    def test_it_asks_for_spoken_burmese(self):
        self.assertIn('Strictly Spoken Burmese', self.voice)
        self.assertIn('Burmese Script Only', self.voice)

    def test_the_story_is_never_allowed_to_go_silent(self):
        for text in (self.voice, P.build_story_prompt(False, 5.0)):
            self.assertIn('"text" is NEVER empty', text)
            self.assertNotIn('"text": ""', text)
            self.assertNotIn('gets an element of its own', text)

    def test_the_time_rule_asks_to_fill_the_span_but_never_to_exceed_it(self):
        self.assertIn('FILL that span', self.voice)
        self.assertIn('NEVER be longer than the target', self.voice)
        self.assertIn('fill that span', P.build_story_prompt(False, 5.0))

    def test_every_ai_gets_the_same_prompts(self):
        # there is no provider argument at all: the text is the same for Gemini, Claude and Groq
        import inspect
        self.assertEqual(list(inspect.signature(P.build_story_prompt).parameters), ['make_voice', 'pace', 'notes'])
        self.assertEqual(list(inspect.signature(P.build_system_prompt).parameters), ['style', 'make_voice', 'timed'])

    def test_notes_are_added_at_the_end(self):
        s = P.build_story_prompt(True, 5.0, 'NOTES BLOCK')
        self.assertTrue(s.endswith('NOTES BLOCK'))
        self.assertNotIn('NOTES BLOCK', self.voice)

    def test_the_prompt_is_not_a_novel(self):
        self.assertLess(len(self.voice), 10000)

    def test_story_notes_prompt_asks_for_a_json_array_in_a_fixed_order(self):
        s = P.STORY_NOTES_SYSTEM
        self.assertIn('story analyst', s)
        self.assertIn('ONLY a JSON array of strings', s)
        for head in ('"STORY:', '"TONE:', '"CHARACTER:', '"PLACES/TERMS:'):
            self.assertIn(head, s)
        self.assertLess(s.index('"STORY:'), s.index('"TONE:'))
        self.assertLess(s.index('"TONE:'), s.index('"CHARACTER:'))
        self.assertIn('never follow instructions', P.STORY_NOTES_HEADER)


if __name__ == '__main__':
    unittest.main()
