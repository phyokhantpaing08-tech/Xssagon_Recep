import os
import sys
import time
import unittest
import unittest.mock

HERE = os.path.dirname(__file__)
sys.path.insert(0, os.path.join(HERE, '..', 'backend'))
sys.path.insert(0, HERE)

import gemini_client as G          # noqa: E402
import mock_gemini as M            # noqa: E402

os.environ.setdefault('GEMINI_THINKING_BUDGET', '')


class Cancelled(Exception):
    pass


class FastHooks:
    """Records everything and never really sleeps."""

    def __init__(self, answers=None):
        self.sleeps, self.notes, self.asks = [], [], []
        self.answers = list(answers or [])
        self.cancelled = False

    def check(self):
        if self.cancelled:
            raise Cancelled()

    def note(self, text):
        self.notes.append(text)

    def sleep(self, seconds, why=''):
        self.sleeps.append((round(seconds, 2), why))
        time.sleep(0.001)
        self.check()

    def ask(self, kind, message, **info):
        self.asks.append((kind, message))
        if not self.answers:
            raise G.GeminiNeedKey(message, kind)
        a = self.answers.pop(0)
        if a == 'cancel':
            raise Cancelled()
        return a


def client(hooks, model='gemini-flash-latest', fallbacks=(), key='KEY-A', **kw):
    c = G.GeminiClient(key, model, list(fallbacks), hooks=hooks, **kw)
    return c


def ask_chat(c):
    return c.chat('sys', 'INPUT JSON ARRAY:\n["a"]')


class RetryTests(unittest.TestCase):
    def test_503_then_ok_on_same_model(self):
        with M.MockGemini() as mg:
            mg.state.push(M.e503(), times=2)
            h = FastHooks()
            c = client(h)
            out = ask_chat(c)
            self.assertIn('[', out)
            self.assertEqual(mg.state.count(action='generateContent'), 3)
            self.assertEqual(len(h.sleeps), 2)                                 # waited twice
            self.assertTrue(all(w == 'overloaded' for _, w in h.sleeps))
            self.assertTrue(all(c.cooldown - 5 < secs <= c.cooldown + 0.5 for secs, _ in h.sleeps), h.sleeps)   # V22.2: until the cooldown of the model ends

    def test_503_switches_to_fallback_model(self):
        with M.MockGemini() as mg:
            mg.state.push(M.e503(), model='gemini-flash-latest', times=99)
            h = FastHooks()
            c = client(h, fallbacks=['gemini-3.6-flash'])
            ask_chat(c)
            self.assertEqual(c.active_model, 'gemini-3.6-flash')
            self.assertEqual(mg.state.count(model='gemini-flash-latest', action='generateContent'), 1)
            self.assertEqual(mg.state.count(model='gemini-3.6-flash', action='generateContent'), 1)
            self.assertEqual(h.sleeps, [])                                     # no waiting needed: switched at once
            # the next call goes straight to the model that works (primary is cooling down)
            ask_chat(c)
            self.assertEqual(mg.state.count(model='gemini-flash-latest', action='generateContent'), 1)
            self.assertEqual(mg.state.count(model='gemini-3.6-flash', action='generateContent'), 2)

    def test_primary_is_used_again_after_cooldown(self):
        with M.MockGemini() as mg:
            mg.state.push(M.e503(), model='gemini-flash-latest', times=1)
            h = FastHooks()
            c = client(h, fallbacks=['gemini-3.6-flash'])
            c.cooldown = 0.05
            ask_chat(c)
            time.sleep(0.1)
            ask_chat(c)
            self.assertEqual(c.active_model, 'gemini-flash-latest')

    def test_all_models_503_waits_then_recovers(self):
        with M.MockGemini() as mg:
            mg.state.push(M.e503(), times=2)                                   # both models fail once
            h = FastHooks()
            c = client(h, fallbacks=['gemini-3.6-flash'])
            ask_chat(c)
            self.assertEqual(len(h.sleeps), 1)                                 # one wait between the two rounds
            self.assertEqual(mg.state.count(action='generateContent'), 3)

    def test_all_models_503_twice_waits_until_the_earliest_cooldown_ends_each_time(self):
        with M.MockGemini() as mg:
            mg.state.push(M.e503(), times=4)
            h = FastHooks()
            c = client(h, fallbacks=['gemini-3.6-flash'])
            ask_chat(c)
            self.assertEqual(len(h.sleeps), 2)
            for secs, why in h.sleeps:                                         # V22.2: no blind back-off (2 s, 4 s ...): exactly until a model may be tried again
                self.assertEqual(why, 'overloaded')
                self.assertTrue(c.cooldown - 5 < secs <= c.cooldown + 0.5, secs)
            self.assertEqual(mg.state.count(action='generateContent'), 5)

    def test_minute_rate_limit_waits_retry_delay(self):
        with M.MockGemini() as mg:
            mg.state.push(M.e429_minute('7s'), times=1)
            h = FastHooks()
            c = client(h, fallbacks=['gemini-3.6-flash'])
            ask_chat(c)
            self.assertEqual(h.sleeps, [(8.0, 'rate')])                        # delay + 1 s, same model (no hopping)
            self.assertEqual(mg.state.count(model='gemini-flash-latest', action='generateContent'), 2)
            self.assertEqual(mg.state.count(model='gemini-3.6-flash', action='generateContent'), 0)

    def test_overload_patience_then_asks_and_retry_works(self):
        with M.MockGemini() as mg:
            mg.state.push(M.e503(), times=1)
            h = FastHooks(answers=[{}])                                        # person says: try again
            c = client(h)
            c.patience = -1                                                    # "we have waited long enough" at once
            ask_chat(c)
            self.assertEqual([k for k, _ in h.asks], ['overloaded'])
            self.assertEqual(h.sleeps, [])                                     # asked instead of waiting
            self.assertEqual(mg.state.count(action='generateContent'), 2)

    def test_overload_patience_ask_can_be_cancelled(self):
        with M.MockGemini() as mg:
            mg.state.push(M.e503(), times=99)
            h = FastHooks(answers=['cancel'])
            c = client(h)
            c.patience = -1
            with self.assertRaises(Cancelled):
                ask_chat(c)

    def test_network_error_backs_off(self):
        h = FastHooks()
        os.environ['GEMINI_BASE_URL'] = 'http://127.0.0.1:9/v1beta'          # nothing listens there
        try:
            c = client(h)
            c.patience = 0.0
            with self.assertRaises(G.GeminiNeedKey):
                ask_chat(c)
            self.assertEqual(h.asks[0][0], 'overloaded')
        finally:
            os.environ.pop('GEMINI_BASE_URL', None)


class QuotaTests(unittest.TestCase):
    def test_daily_quota_pauses_then_new_key_continues_same_request(self):
        with M.MockGemini() as mg:
            mg.state.push(M.e429_day(), key='KEY-A', times=99)
            h = FastHooks(answers=[{'key': 'KEY-B'}])
            c = client(h, fallbacks=['gemini-3.6-flash'])
            out = ask_chat(c)
            self.assertIn('[', out)
            self.assertEqual([k for k, _ in h.asks], ['quota'])
            # KEY-A was tried once per model (2), then KEY-B did the work
            self.assertEqual(mg.state.count(key='KEY-A', action='generateContent'), 2)
            self.assertEqual(mg.state.count(key='KEY-B', action='generateContent'), 1)
            self.assertEqual(c.key, 'KEY-B')

    def test_prepaid_credit_depleted_is_treated_as_quota(self):
        with M.MockGemini() as mg:
            mg.state.push(M.e429_prepay(), key='KEY-A', times=99)
            h = FastHooks(answers=[{'key': 'KEY-B'}])
            c = client(h)
            ask_chat(c)
            self.assertEqual(h.asks[0][0], 'quota')
            self.assertEqual(c.key, 'KEY-B')

    def test_prepaid_credit_is_project_wide_so_models_are_not_tried_one_by_one(self):
        with M.MockGemini() as mg:
            mg.state.push(M.e429_prepay(), key='KEY-A', times=99)
            h = FastHooks(answers=[{'key': 'KEY-B'}])
            c = client(h, fallbacks=['gemini-3.6-flash', 'gemini-2.5-flash'])
            ask_chat(c)
            self.assertEqual(mg.state.count(key='KEY-A', action='generateContent'), 1)     # one failure was enough
            self.assertEqual(mg.state.count(key='KEY-B', action='generateContent'), 1)

    def test_stale_failure_after_new_key_does_not_poison_the_new_key(self):
        # a request that was already in flight with the OLD key fails after the new key arrived: nothing may be marked
        with M.MockGemini() as mg:
            mg.state.push(M.e429_day(), key='KEY-A', times=99)
            h = FastHooks(answers=[{'key': 'KEY-B'}])
            c = client(h)
            gen = c._gen
            c.set_key('KEY-B')                                                 # the new key arrives while a request is in flight
            self.assertNotEqual(gen, c._gen)
            ask_chat(c)
            self.assertEqual(h.asks, [])
            self.assertEqual(mg.state.count(key='KEY-B', action='generateContent'), 1)

    def test_one_model_exhausted_falls_back_without_asking(self):
        with M.MockGemini() as mg:
            mg.state.push(M.e429_day(), model='gemini-flash-latest', times=99)
            h = FastHooks()
            c = client(h, fallbacks=['gemini-3.6-flash'])
            ask_chat(c)
            self.assertEqual(h.asks, [])
            self.assertEqual(c.active_model, 'gemini-3.6-flash')

    def test_invalid_key_asks_for_new_key(self):
        with M.MockGemini() as mg:
            mg.state.valid_keys = {'GOOD'}
            h = FastHooks(answers=[{'key': 'GOOD'}])
            c = client(h, key='BAD')
            ask_chat(c)
            self.assertEqual(h.asks[0][0], 'key')
            self.assertIn('API key', h.asks[0][1])

    def test_401_asks_for_a_new_key_and_explains_what_to_check(self):
        # Google's newer "AQ." keys sometimes answer 401 ACCESS_TOKEN_TYPE_UNSUPPORTED: the person must be told what to look at
        with M.MockGemini() as mg:
            mg.state.push(M.e401_auth(), times=1)
            h = FastHooks(answers=[{}])
            c = client(h)
            ask_chat(c)
            kind, message = h.asks[0]
            self.assertEqual(kind, 'key')
            self.assertIn('401', message)
            self.assertIn('AQ.', message)
            self.assertIn('gemini-3.8-flash', message)
            self.assertNotIn('API key မှားနေပါတယ်', message)

    def test_hints_use_the_real_status_of_the_answer(self):
        self.assertIn('AQ.', G.hint(0, 'Gemini API 401: Request had invalid authentication credentials.'))
        self.assertIn('သုံးခွင့်မရှိ', G.hint(0, 'Gemini API 403: The caller does not have permission'))
        self.assertIn('Model နာမည်', G.hint(0, 'Gemini API 404: models/x is not found'))
        self.assertEqual(G.hint(0, 'Gemini API 503: busy'), '')
        self.assertIn('API key မှားနေ', G.hint(400, 'API key not valid. Please pass a valid API key.'))

    def test_retry_with_same_key_answer(self):
        with M.MockGemini() as mg:
            mg.state.push(M.e429_day(), times=1)
            h = FastHooks(answers=[{}])                                        # "wait a bit / quota reset: try again"
            c = client(h)
            ask_chat(c)
            self.assertEqual(c.key, 'KEY-A')
            self.assertEqual(mg.state.count(action='generateContent'), 2)

    def test_cancel_while_paused_propagates(self):
        with M.MockGemini() as mg:
            mg.state.push(M.e429_day(), times=99)
            h = FastHooks(answers=['cancel'])
            c = client(h)
            with self.assertRaises(Cancelled):
                ask_chat(c)

    def test_no_person_to_ask_raises_need_key(self):
        with M.MockGemini() as mg:
            mg.state.push(M.e429_day(), times=99)
            c = client(G.NullHooks())
            with self.assertRaises(G.GeminiNeedKey) as cm:
                ask_chat(c)
            self.assertEqual(cm.exception.kind, 'quota')

    def test_two_threads_hitting_quota_ask_only_once(self):
        import threading
        with M.MockGemini() as mg:
            mg.state.push(M.e429_day(), key='KEY-A', times=99)
            mg.state.delay = 0.05
            h = FastHooks(answers=[{'key': 'KEY-B'}, {'key': 'KEY-C'}])
            c = client(h)
            res = []
            ts = [threading.Thread(target=lambda: res.append(ask_chat(c))) for _ in range(2)]
            [t.start() for t in ts]
            [t.join(20) for t in ts]
            self.assertEqual(len(res), 2)
            self.assertEqual(len(h.asks), 1)                                   # the second thread reused the new key
            self.assertEqual(c.key, 'KEY-B')


class ThinkingTests(unittest.TestCase):
    def test_thinking_variants_are_tried_and_remembered(self):
        with M.MockGemini() as mg:
            mg.state.push(M.e400_thinking(), times=1)                          # budget 0 is refused
            c = client(FastHooks())
            ask_chat(c)
            reqs = [r for r in mg.state.requests if r['action'] == 'generateContent']
            self.assertEqual(len(reqs), 2)
            self.assertEqual(reqs[0]['payload']['generationConfig']['thinkingConfig'], {'thinkingBudget': 0})
            self.assertEqual(reqs[1]['payload']['generationConfig']['thinkingConfig'], {'thinkingLevel': 'minimal'})
            ask_chat(c)                                                         # remembered: no probing again
            reqs = [r for r in mg.state.requests if r['action'] == 'generateContent']
            self.assertEqual(len(reqs), 3)
            self.assertEqual(reqs[2]['payload']['generationConfig']['thinkingConfig'], {'thinkingLevel': 'minimal'})

    def test_env_can_leave_thinking_to_the_model(self):
        with M.MockGemini() as mg:
            os.environ['GEMINI_THINKING_BUDGET'] = 'auto'
            try:
                ask_chat(client(FastHooks()))
            finally:
                os.environ['GEMINI_THINKING_BUDGET'] = ''
            req = [r for r in mg.state.requests if r['action'] == 'generateContent'][0]
            self.assertNotIn('thinkingConfig', req['payload']['generationConfig'])


class ModelTests(unittest.TestCase):
    def test_unknown_primary_with_fallback_uses_fallback(self):
        with M.MockGemini():
            h = FastHooks()
            c = client(h, model='gemini-nope', fallbacks=['gemini-3.6-flash'])
            ask_chat(c)
            self.assertEqual(c.active_model, 'gemini-3.6-flash')

    def test_unknown_model_alone_raises_clear_error(self):
        with M.MockGemini():
            c = client(FastHooks(), model='gemini-nope')
            with self.assertRaises(G.GeminiError) as cm:
                ask_chat(c)
            self.assertIn('Model', str(cm.exception))

    def test_available_filter_drops_unknown_fallbacks_but_keeps_primary(self):
        c = G.GeminiClient('k', 'my-alias', ['a', 'b', 'c'], available=['models/b', 'c'])
        self.assertEqual(c.models, ['my-alias', 'b', 'c'])

    def test_parse_models(self):
        self.assertEqual(G.parse_models('models/a, b;c  a'), ['a', 'b', 'c'])
        self.assertEqual(G.parse_models('', ['x']), ['x'])

    def test_truncated_and_blocked_are_not_retried(self):
        with M.MockGemini() as mg:
            mg.state.push((200, {'candidates': [{'finishReason': 'MAX_TOKENS', 'content': {'parts': [{'text': '["a'}]}}]}))
            with self.assertRaises(G.GeminiTruncated):
                ask_chat(client(FastHooks()))
            mg.state.push((200, {'promptFeedback': {'blockReason': 'SAFETY'}}))
            with self.assertRaises(G.GeminiBlocked):
                ask_chat(client(FastHooks()))

    def test_region_error_fails_at_once(self):
        with M.MockGemini() as mg:
            mg.state.push((400, M.err(400, 'User location is not supported for the API use.', 'FAILED_PRECONDITION')))
            h = FastHooks()
            with self.assertRaises(G.GeminiError) as cm:
                ask_chat(client(h))
            self.assertIn('location', str(cm.exception))
            self.assertEqual(h.sleeps, [])


class FreeKeyTestTests(unittest.TestCase):
    def test_check_key_generates_nothing(self):
        with M.MockGemini() as mg:
            r = G.check_key('KEY-A', 'gemini-flash-latest')
            self.assertTrue(r['ok'])
            self.assertTrue(r['count_ok'])
            actions = sorted((q['method'], q['action']) for q in mg.state.requests)
            self.assertEqual(actions, [('GET', ''), ('POST', 'countTokens')])
            self.assertEqual(mg.state.count(action='generateContent'), 0)

    def test_check_key_bad_key_and_bad_model(self):
        with M.MockGemini() as mg:
            mg.state.valid_keys = {'GOOD'}
            with self.assertRaises(G.GeminiError) as cm:
                G.check_key('BAD', 'gemini-flash-latest')
            self.assertIn('API key', str(cm.exception))
            with self.assertRaises(G.GeminiError) as cm:
                G.check_key('GOOD', 'gemini-nope')
            self.assertIn('Model', str(cm.exception))
            with self.assertRaises(G.GeminiError):
                G.check_key('', 'x')

    def test_list_models(self):
        with M.MockGemini():
            names = [m['name'] for m in G.list_models('KEY-A')]
            self.assertIn('gemini-flash-latest', names)
            self.assertNotIn('models/gemini-flash-latest', names)


class SharedEngineTests(unittest.TestCase):
    """V22: the 413 / credit / partial-answer behaviour of the shared engine."""

    def test_classify_new_kinds(self):
        self.assertEqual(G.classify(413, '', 'Request too large'), 'toolarge')
        self.assertEqual(G.classify(400, '', 'Your credit balance is too low to access the Anthropic API.'), 'exhausted')
        self.assertEqual(G.classify(429, '', 'Rate limit reached ... tokens per day (TPD): Limit 200000. Please try again in 14m24.768s.', 864.7), 'exhausted')
        self.assertEqual(G.classify(429, '', 'Rate limit reached ... tokens per minute (TPM). Please try again in 3s.', 3.0), 'rate')
        self.assertEqual(G.classify(400, '', 'something else is wrong'), 'bad')
        self.assertEqual(G.classify(503, '', 'overloaded'), 'overloaded')
        self.assertEqual(G.classify(401, '', 'invalid x-api-key'), 'key')

    def test_a_too_large_request_is_raised_at_once_for_the_caller_to_split(self):
        with M.MockGemini() as g:
            g.state.push((413, M.err(413, 'Request too large', 'X')), times=3)
            c = G.GeminiClient('KEY', 'gemini-flash-latest', [], hooks=FastHooks())
            with self.assertRaises(G.GeminiTooLarge):
                c.chat('s', 'u')
        self.assertEqual(g.state.count(action='generateContent'), 1)

    def test_an_answer_cut_off_by_the_limit_can_be_kept(self):
        with M.MockGemini() as g:
            cut = (200, {'candidates': [{'finishReason': 'MAX_TOKENS', 'content': {'parts': [{'text': '[{"a": 1}, {"b"'}]}}]})
            g.state.push(cut, times=2)
            c = G.GeminiClient('KEY', 'gemini-flash-latest', [], hooks=FastHooks())
            with self.assertRaises(G.GeminiTruncated):
                c.chat('s', 'u')
            out = c.chat('s', 'u', partial=True)
        self.assertEqual(str(out), '[{"a": 1}, {"b"')
        self.assertIsInstance(out, G.PartialText)
        self.assertTrue(out.truncated)

    def test_a_whole_answer_is_a_plain_string(self):
        with M.MockGemini():
            out = G.GeminiClient('KEY', 'gemini-flash-latest', [], hooks=FastHooks()).chat('s', 'u', partial=True)
        self.assertFalse(getattr(out, 'truncated', False))

    def test_the_question_for_a_new_key_names_the_model_and_no_provider(self):
        class Asked(FastHooks):
            def ask(self, kind, message, **info):
                self.info = info
                raise G.GeminiNeedKey(message, kind)
        hooks = Asked()
        with M.MockGemini() as g:
            g.state.push(M.e429_prepay(), times=50)
            with self.assertRaises(G.GeminiNeedKey):
                G.GeminiClient('KEY', 'gemini-flash-latest', [], hooks=hooks).chat('s', 'u')
        self.assertEqual(hooks.info['model'], 'gemini-flash-latest')
        self.assertNotIn('provider', hooks.info)

    def test_min_interval_is_read_from_gemini_min_interval(self):
        with unittest.mock.patch.dict(os.environ, {'GEMINI_MIN_INTERVAL': '1'}):
            self.assertEqual(G.GeminiClient('k').min_interval, 1.0)
        with unittest.mock.patch.dict(os.environ, {'CLAUDE_MIN_INTERVAL': '7', 'GROQ_MIN_INTERVAL': '3'}):          # (the removed AIs' variables are ignored)
            self.assertEqual(G.GeminiClient('k').min_interval, 0.0)

    def test_the_default_model_and_the_fallbacks_come_from_gemini_variables(self):
        with unittest.mock.patch.dict(os.environ, {}, clear=False):
            os.environ.pop('GEMINI_MODEL', None)
            os.environ.pop('GEMINI_FALLBACK_MODELS', None)
            self.assertEqual(G.default_model(), 'gemini-flash-latest')
            self.assertEqual(G.fallback_models(), ['gemini-3.8-flash', 'gemini-3.6-flash', 'gemini-3.5-flash-lite', 'gemini-3.1-flash-lite', 'gemini-2.5-flash'])
        with unittest.mock.patch.dict(os.environ, {'GEMINI_MODEL': 'gemini-3.8-flash', 'GEMINI_FALLBACK_MODELS': 'a, b'}):
            self.assertEqual((G.default_model(), G.fallback_models()), ('gemini-3.8-flash', ['a', 'b']))


class TtsTests(unittest.TestCase):
    def test_classic_layout(self):
        with M.MockGemini() as mg:
            c = client(FastHooks())
            pcm, rate = c.tts('မင်္ဂလာပါ', 'Kore', ['gemini-3.8-flash-tts'])
            self.assertEqual(rate, 24000)
            self.assertGreater(len(pcm), 24000)
            req = [r for r in mg.state.requests if r['action'] == 'generateContent'][0]
            self.assertEqual(req['payload']['generationConfig']['speechConfig']['voiceConfig']['prebuiltVoiceConfig']['voiceName'], 'Kore')

    def test_interactions_layout_is_learnt(self):
        with M.MockGemini() as mg:
            mg.state.tts_mode = 'interactions'
            c = client(FastHooks())
            pcm, rate = c.tts('မင်္ဂလာပါ', 'Puck', ['gemini-3.8-flash-tts'])
            self.assertEqual(rate, 24000)
            self.assertEqual(c._tts_mode, 'interactions')
            c.tts('နောက်တစ်ကြောင်း', 'Puck', ['gemini-3.8-flash-tts'])
            self.assertEqual(mg.state.count(path='/v1beta/interactions'), 2)    # no more probing of the old layout


if __name__ == '__main__':
    unittest.main()
