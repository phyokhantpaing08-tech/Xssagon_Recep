"""V22.3: Whisper finds the right words at the right time - what can be PROVEN without the real model is proven here.

faster-whisper / ctranslate2 are not needed: the model is replaced by a fake that records how it was called and returns word timings
chosen by the test. What is measured:

* the model choice (auto = small on a CPU, large-v3-turbo on a GPU; explicit names honoured; a model that cannot be loaded falls back
  to small -> base -> tiny) and that unknown options are never passed to an older faster-whisper,
* every line takes its start from the FIRST WORD and its end from the LAST WORD, a word stretched over silence is cut back,
* the audio is cut in a pause (never in the middle of a tone / word), the pieces add up to the whole file sample for sample, and every
  piece starts where `chunk_starts` says,
* with the real ffmpeg: film (MKV starting at 2 s, MPEG-TS, sound 0.3 s late, picture 0.5 s late) -> extract_audio_wav -> split_audio ->
  transcribe_chunks gives every beep at its true time on the picture's timeline (<= 20 ms) - and a FIXED cut, which is what V21 / V22
  did, tears a tone in two and puts it 100 ms off.
"""
import os
import shutil
import sys
import tempfile
import types
import unittest
import wave
from contextlib import contextmanager
from pathlib import Path
from types import SimpleNamespace as NS
from unittest import mock

import numpy as np

HERE = os.path.dirname(__file__)
sys.path.insert(0, HERE)
sys.path.insert(0, os.path.join(HERE, '..', 'backend'))

import asr                    # noqa: E402
import ffmpeg_fixtures as F   # noqa: E402
import media                  # noqa: E402
import timing as T            # noqa: E402

HAVE = bool(shutil.which('ffmpeg') and shutil.which('ffprobe'))
ENV_KEYS = ('WHISPER_MODEL', 'WHISPER_DEVICE', 'WHISPER_COMPUTE_TYPE', 'WHISPER_BEAM', 'WHISPER_WORDS', 'WHISPER_THREADS', 'WHISPER_LANGUAGE',
            'WHISPER_CHUNK_SECONDS', 'WHISPER_CUT_SEARCH', 'WHISPER_HALLUCINATION_SILENCE', 'AUDIO_TRACK')


@contextmanager
def env(**kw):
    old = {k: os.environ.get(k) for k in ENV_KEYS}
    for k in ENV_KEYS:
        os.environ.pop(k, None)
    os.environ.update({k: str(v) for k, v in kw.items()})
    try:
        yield
    finally:
        for k, v in old.items():
            if v is None:
                os.environ.pop(k, None)
            else:
                os.environ[k] = v


def W(word, a, b):
    return NS(word=word, start=a, end=b)


class SettingsTests(unittest.TestCase):
    def test_auto_on_a_cpu_is_small_int8_greedy(self):
        with env(), mock.patch.object(asr, 'cuda_available', return_value=False):
            self.assertEqual(asr.settings(), {'model': 'small', 'device': 'cpu', 'compute': 'int8', 'beam': 1, 'words': True})

    def test_auto_on_a_gpu_is_large_v3_turbo_float16_beam5(self):
        with env(), mock.patch.object(asr, 'cuda_available', return_value=True):
            self.assertEqual(asr.settings(), {'model': 'large-v3-turbo', 'device': 'cuda', 'compute': 'float16', 'beam': 5, 'words': True})

    def test_explicit_values_are_honoured(self):
        with env(WHISPER_MODEL='Medium', WHISPER_DEVICE='cpu', WHISPER_COMPUTE_TYPE='int8_float32', WHISPER_BEAM=3, WHISPER_WORDS=0), \
                mock.patch.object(asr, 'cuda_available', return_value=True):
            self.assertEqual(asr.settings(), {'model': 'medium', 'device': 'cpu', 'compute': 'int8_float32', 'beam': 3, 'words': False})

    def test_junk_values_do_not_crash(self):
        with env(WHISPER_BEAM='x', WHISPER_THREADS='y', WHISPER_HALLUCINATION_SILENCE='z'), mock.patch.object(asr, 'cuda_available', return_value=False):
            self.assertEqual(asr.settings()['beam'], 1)
            self.assertGreaterEqual(asr.cpu_threads(), 1)
            self.assertEqual(asr._env_float('WHISPER_HALLUCINATION_SILENCE', 2.0, 0.5, 10.0), 2.0)

    def test_no_ctranslate2_means_no_gpu(self):
        with mock.patch.dict(sys.modules, {'ctranslate2': None}):
            self.assertFalse(asr.cuda_available())


class ModelLoadingTests(unittest.TestCase):
    def setUp(self):
        asr._models.clear()
        self.calls = []
        calls, bad = self.calls, set()
        self.bad = bad

        class WhisperModel:
            def __init__(self, name, device='cpu', compute_type='int8', cpu_threads=0):
                calls.append((name, device, compute_type))
                if name in bad:
                    raise RuntimeError(f'cannot download {name}')
        self.stub = types.ModuleType('faster_whisper')
        self.stub.WhisperModel = WhisperModel
        self.patch = mock.patch.dict(sys.modules, {'faster_whisper': self.stub})
        self.patch.start()
        self.addCleanup(self.patch.stop)
        self.addCleanup(asr._models.clear)

    def load(self, **e):
        with env(**e), mock.patch.object(asr, 'cuda_available', return_value=False):
            return asr.whisper_model()[1]

    def test_auto_loads_small_on_a_cpu(self):
        self.assertEqual(self.load(), 'small')
        self.assertEqual(self.calls, [('small', 'cpu', 'int8')])

    def test_the_model_is_loaded_once(self):
        self.load()
        self.load()
        self.assertEqual(len(self.calls), 1)

    def test_a_model_that_cannot_be_loaded_falls_back_to_small_then_base_then_tiny(self):
        self.bad.update({'large-v3-turbo'})
        self.assertEqual(self.load(WHISPER_MODEL='large-v3-turbo'), 'small')
        asr._models.clear()
        self.bad.update({'small'})
        self.bad.update({'medium'})
        self.assertEqual(self.load(WHISPER_MODEL='medium'), 'base')
        asr._models.clear()
        self.bad.update({'base'})
        self.assertEqual(self.load(WHISPER_MODEL='medium'), 'tiny')
        asr._models.clear()
        self.bad.update({'tiny'})
        with self.assertRaises(RuntimeError):
            self.load(WHISPER_MODEL='medium')

    def test_a_weak_model_is_called_out_in_the_log(self):
        import io
        from contextlib import redirect_stdout
        buf = io.StringIO()
        with redirect_stdout(buf):
            self.load(WHISPER_MODEL='base')
        self.assertIn('weak model', buf.getvalue())
        self.assertIn('WHISPER_MODEL=auto', buf.getvalue())
        asr._models.clear()
        buf = io.StringIO()
        with redirect_stdout(buf):
            self.load()
        self.assertNotIn('weak model', buf.getvalue())
        self.assertIn('model=small', buf.getvalue())


class WordBoundsTests(unittest.TestCase):
    def test_the_line_runs_from_the_first_word_to_the_last_word(self):
        self.assertEqual(asr.word_bounds([W(' Hello', 4.20, 4.60), W(' there', 4.70, 5.10), W(' friend', 5.20, 5.90)]), (4.20, 5.90))

    def test_no_words_means_none(self):
        self.assertIsNone(asr.word_bounds(None))
        self.assertIsNone(asr.word_bounds([]))
        self.assertIsNone(asr.word_bounds([W('x', None, None), W('y', 'a', 'b'), W('z', float('nan'), 1.0)]))

    def test_a_first_word_stretched_back_over_the_silence_is_cut_back(self):
        a, b = asr.word_bounds([W(' So', 1.0, 6.0), W(' what', 6.1, 6.4), W(' now', 6.5, 6.9)])
        self.assertLess(5.0, a)                                # it was said just before 6.0, not at 1.0
        self.assertLessEqual(a, 6.0)
        self.assertEqual(b, 6.9)

    def test_a_last_word_stretched_forward_over_the_silence_is_cut_back(self):
        a, b = asr.word_bounds([W(' Go', 10.0, 10.3), W(' away', 10.4, 18.0)])
        self.assertEqual(a, 10.0)
        self.assertLess(b, 12.1)
        self.assertGreater(b, 10.4)

    def test_one_stretched_word_keeps_its_end(self):
        a, b = asr.word_bounds([W(' No', 2.0, 9.0)])
        self.assertEqual(b, 9.0)
        self.assertGreater(a, 7.0)

    def test_a_normal_long_word_is_left_alone(self):
        self.assertEqual(asr.word_bounds([W(' Unbelievable', 3.0, 4.4), W(' yes', 4.5, 4.8)]), (3.0, 4.8))

    def test_words_may_be_dicts_and_arrive_unsorted_text_is_kept_out_of_it(self):
        self.assertEqual(asr.word_bounds([{'word': 'a', 'start': 1.0, 'end': 1.2}, {'word': 'b', 'start': 1.3, 'end': 1.9}]), (1.0, 1.9))

    def test_never_zero_length(self):
        a, b = asr.word_bounds([W('a', 3.0, 3.0)])
        self.assertGreater(b, a)


class FakeResult:
    def __init__(self, segs, language='en', prob=0.97):
        self.segs, self.info = segs, NS(language=language, language_probability=prob)


class NewModel:
    """Like faster-whisper >= 1.1: knows every option."""
    def __init__(self, segs, **info):
        self.result, self.calls = FakeResult(segs, **info), []

    def transcribe(self, audio, beam_size=5, vad_filter=False, condition_on_previous_text=True, word_timestamps=False,
                   hallucination_silence_threshold=None, language=None, language_detection_segments=1, language_detection_threshold=0.5):
        self.calls.append(dict(beam_size=beam_size, vad_filter=vad_filter, condition_on_previous_text=condition_on_previous_text,
                               word_timestamps=word_timestamps, hallucination_silence_threshold=hallucination_silence_threshold, language=language,
                               language_detection_segments=language_detection_segments, language_detection_threshold=language_detection_threshold))
        return iter(self.result.segs), self.result.info


class OldModel:
    """An old faster-whisper: no language_detection_* and no hallucination_silence_threshold."""
    def __init__(self, segs):
        self.result, self.calls = FakeResult(segs), []

    def transcribe(self, audio, beam_size=5, vad_filter=False, condition_on_previous_text=True, word_timestamps=False, language=None):
        self.calls.append(dict(beam_size=beam_size, vad_filter=vad_filter, word_timestamps=word_timestamps, language=language))
        return iter(self.result.segs), self.result.info


class KwargsModel:
    def __init__(self, segs):
        self.result, self.calls = FakeResult(segs), []

    def transcribe(self, audio, **kw):
        self.calls.append(kw)
        return iter(self.result.segs), self.result.info


SEGS = [NS(start=0.0, end=6.0, text=' Hello there', words=[W(' Hello', 2.0, 2.4), W(' there', 2.5, 3.1)]),
        NS(start=6.0, end=9.0, text='   ', words=[]),
        NS(start=9.0, end=14.0, text=' No words here', words=None)]


class TranscribeWavTests(unittest.TestCase):
    def run_it(self, model, spans=None, lang=None, want_spans=True, **e):
        with env(**e), mock.patch.object(asr, 'cuda_available', return_value=False), mock.patch.object(asr, 'whisper_model', return_value=(model, 'small')), \
                mock.patch.object(asr, 'load_wav_for_whisper', return_value='x.wav'), mock.patch.object(asr, 'speech_spans', return_value=spans):
            return asr.transcribe_wav('x.wav', lang, None, want_spans)

    def test_lines_take_their_times_from_the_words(self):
        model = NewModel(SEGS)
        segs, lang, used, prob = self.run_it(model, want_spans=False)
        self.assertEqual((lang, used, prob), ('en', 'small', 0.97))
        self.assertEqual(len(segs), 2)                          # the blank line is dropped
        self.assertEqual((segs[0]['start'], segs[0]['end'], segs[0]['text']), (2.0, 3.1, 'Hello there'))   # whisper said 0.0 - 6.0
        self.assertEqual((segs[1]['start'], segs[1]['end']), (9.0, 14.0))                                   # no words: whisper's own times
        self.assertNotIn('speech_start', segs[0])

    def test_options_for_a_new_model(self):
        model = NewModel(SEGS)
        self.run_it(model)
        c = model.calls[0]
        self.assertEqual((c['beam_size'], c['vad_filter'], c['condition_on_previous_text'], c['word_timestamps']), (1, True, False, True))
        self.assertEqual(c['hallucination_silence_threshold'], 2.0)
        self.assertEqual((c['language'], c['language_detection_segments'], c['language_detection_threshold']), (None, 4, 0.5))

    def test_a_known_language_is_passed_and_not_detected_again(self):
        model = NewModel(SEGS)
        self.run_it(model, lang='my')
        self.assertEqual(model.calls[0]['language'], 'my')
        self.assertEqual(model.calls[0]['language_detection_segments'], 1)          # (the default: not sent)

    def test_options_an_old_model_does_not_know_are_not_sent(self):
        model = OldModel(SEGS)
        segs, *_ = self.run_it(model)
        self.assertEqual(model.calls[0]['word_timestamps'], True)
        self.assertNotIn('hallucination_silence_threshold', model.calls[0])
        self.assertEqual(len(segs), 2)

    def test_a_kwargs_model_gets_everything(self):
        model = KwargsModel(SEGS)
        self.run_it(model)
        self.assertEqual(set(model.calls[0]), {'beam_size', 'vad_filter', 'condition_on_previous_text', 'word_timestamps', 'hallucination_silence_threshold',
                                               'language_detection_segments', 'language_detection_threshold'})

    def test_words_can_be_switched_off(self):
        model = NewModel(SEGS)
        segs, *_ = self.run_it(model, WHISPER_WORDS=0)
        self.assertEqual(model.calls[0]['word_timestamps'], False)
        self.assertIsNone(model.calls[0]['hallucination_silence_threshold'])
        self.assertEqual((segs[0]['start'], segs[0]['end']), (0.0, 6.0))

    def test_gpu_uses_beam_five(self):
        model = NewModel(SEGS)
        with env(), mock.patch.object(asr, 'cuda_available', return_value=True), mock.patch.object(asr, 'whisper_model', return_value=(model, 'large-v3-turbo')), \
                mock.patch.object(asr, 'load_wav_for_whisper', return_value='x.wav'), mock.patch.object(asr, 'speech_spans', return_value=None):
            asr.transcribe_wav('x.wav', None, None, False)
        self.assertEqual(model.calls[0]['beam_size'], 5)

    def test_speech_spans_are_still_added_from_the_word_times(self):
        segs, *_ = self.run_it(NewModel(SEGS), spans=[(2.1, 3.0), (9.5, 13.0)])
        self.assertEqual((segs[0]['speech_start'], segs[0]['speech_end']), (2.0, 3.1))     # already tight: unchanged
        self.assertAlmostEqual(segs[1]['speech_start'], 9.5 - 0.0, delta=0.5)

    def test_check_is_called_for_every_line(self):
        seen = []
        with env(), mock.patch.object(asr, 'cuda_available', return_value=False), mock.patch.object(asr, 'whisper_model', return_value=(NewModel(SEGS), 'small')), \
                mock.patch.object(asr, 'load_wav_for_whisper', return_value='x.wav'), mock.patch.object(asr, 'speech_spans', return_value=None):
            asr.transcribe_wav('x.wav', None, lambda: seen.append(1), False)
        self.assertEqual(len(seen), 3)


def tone(x, rate, a, b, hz=400.0, amp=0.5):
    n = np.arange(int(a * rate), int(b * rate))
    x[n] = amp * np.sin(2 * np.pi * hz * n / rate)


def speechlike(seconds, rate=16000, pauses=(), seed=1):
    """Noise-like 'speech' everywhere except in `pauses` [(a, b)] where there is faint noise."""
    rng = np.random.default_rng(seed)
    x = 0.25 * rng.standard_normal(int(seconds * rate)).astype(np.float32)
    for a, b in pauses:
        x[int(a * rate):int(b * rate)] *= 0.004
    return np.clip(x, -0.99, 0.99)


class SplitterTests(unittest.TestCase):
    def setUp(self):
        self.dir = Path(tempfile.mkdtemp(prefix='recap_split_'))
        self.addCleanup(shutil.rmtree, self.dir, True)

    def split(self, x, seconds, rate=16000):
        src = self.dir / 'src.wav'
        T.write_wav(src, x, rate)
        return src, asr.split_audio(src, self.dir / 'chunks', seconds)

    def test_the_cut_goes_into_the_pause_not_into_the_speech(self):
        # talking everywhere; the nominal cut (60 s) lands in the middle of speech, the nearest pause is 6 s later
        x = speechlike(200, pauses=[(66.0, 66.8), (128.0, 129.0), (195.0, 196.0)])
        src, chunks = self.split(x, 60)
        starts = asr.chunk_starts(chunks, 60)
        self.assertGreaterEqual(len(chunks), 3)
        self.assertTrue(66.0 <= starts[1] <= 66.8, starts)
        self.assertTrue(128.0 <= starts[2] <= 129.0, starts)

    def test_the_pieces_add_up_to_the_whole_file_sample_for_sample(self):
        x = speechlike(170, pauses=[(61, 62), (122, 123)])
        src, chunks = self.split(x, 60)
        parts = []
        for c in chunks:
            with wave.open(str(c)) as w:
                parts.append(np.frombuffer(w.readframes(w.getnframes()), dtype='<i2'))
        with wave.open(str(src)) as w:
            whole = np.frombuffer(w.readframes(w.getnframes()), dtype='<i2')
        self.assertTrue(np.array_equal(np.concatenate(parts), whole))
        self.assertAlmostEqual(asr.chunk_starts(chunks, 60)[-1] + len(parts[-1]) / 16000.0, 170.0, places=6)

    def test_a_short_tail_is_not_a_chunk_of_its_own(self):
        x = speechlike(130, pauses=[(60, 61)])
        _, chunks = self.split(x, 60)
        starts = asr.chunk_starts(chunks, 60)
        lengths = [b - a for a, b in zip(starts, starts[1:] + [130.0])]
        self.assertTrue(all(n >= 24.0 for n in lengths), lengths)         # min tail = 0.4 * 60 s

    def test_a_file_shorter_than_one_chunk_is_one_chunk(self):
        _, chunks = self.split(speechlike(40), 300)
        self.assertEqual(len(chunks), 1)

    def test_a_pause_exactly_on_the_nominal_cut_is_used_as_it_is(self):
        x = speechlike(150, pauses=[(59.5, 60.5)])
        _, chunks = self.split(x, 60)
        self.assertTrue(59.5 <= asr.chunk_starts(chunks, 60)[1] <= 60.5)

    def test_the_search_never_leaves_its_reach(self):
        x = speechlike(200, pauses=[(100, 101)])                                 # a pause 40 s away from the nominal 60 s cut
        _, chunks = self.split(x, 60)
        s = asr.chunk_starts(chunks, 60)[1]
        self.assertTrue(45.0 <= s <= 75.0, s)                                    # reach = seconds / 4 = 15 s

    def test_resume_returns_the_same_files_without_cutting_again(self):
        x = speechlike(130, pauses=[(60, 61)])
        src, chunks = self.split(x, 60)
        stamp = [c.stat().st_mtime_ns for c in chunks]
        again = asr.split_audio(src, self.dir / 'chunks', 60)
        self.assertEqual(again, chunks)
        self.assertEqual([c.stat().st_mtime_ns for c in again], stamp)

    def test_numpy_missing_falls_back_to_fixed_cuts(self):
        if not HAVE:
            self.skipTest('ffmpeg needed')
        x = speechlike(130)
        src = self.dir / 'src.wav'
        T.write_wav(src, x, 16000)
        with mock.patch.object(asr, '_split_with_python', side_effect=ImportError('no numpy')):
            chunks = asr.split_audio(src, self.dir / 'fixed', 60)
        self.assertGreaterEqual(len(chunks), 2)
        self.assertTrue((self.dir / 'fixed' / 'chunks.done').exists())

    def test_a_file_that_is_not_16k_mono_is_cut_by_ffmpeg(self):
        if not HAVE:
            self.skipTest('ffmpeg needed')
        src = self.dir / 'stereo.wav'
        T.write_wav(src, speechlike(130, rate=24000), 24000)
        chunks = asr.split_audio(src, self.dir / 'other', 60)
        self.assertGreaterEqual(len(chunks), 2)
        with wave.open(str(chunks[0])) as w:
            self.assertEqual((w.getframerate(), w.getnchannels()), (16000, 1))


class FakeWhisperOnBeeps:
    """Stands in for Whisper: 'hears' a segment at every tone it finds in the chunk (energy only)."""
    def __call__(self, wav_path, lang_hint=None, check=None, want_spans=True):
        with wave.open(str(wav_path)) as w:
            rate, raw = w.getframerate(), w.readframes(w.getnframes())
        x = np.frombuffer(raw, dtype='<i2').astype(np.float32) / 32768.0
        segs = [{'start': float(t), 'end': float(t) + 0.2, 'text': 'beep'} for t in F.onsets(x, rate)]
        return segs, 'en', 'fake', 0.99


@unittest.skipUnless(HAVE, 'ffmpeg and ffprobe are needed')
class RealFilmTests(unittest.TestCase):
    SECONDS = 50.0
    VARIANTS = {'mkv+2s': dict(container='mkv', ts_offset=2.0), 'ts': dict(container='ts'), 'audio-late': dict(container='mkv', audio_delay=0.3),
                'video-late': dict(container='mkv', video_delay=0.5)}

    @classmethod
    def setUpClass(cls):
        cls.dir = Path(tempfile.mkdtemp(prefix='recap_asr_'))
        cls.films = {n: F.make_film(cls.dir / (n.replace('+', '_') + ('.ts' if kw.get('container') == 'ts' else '.mkv')), seconds=cls.SECONDS, **kw)
                     for n, kw in cls.VARIANTS.items()}

    @classmethod
    def tearDownClass(cls):
        shutil.rmtree(cls.dir, True)

    def heard(self, name, chunk_seconds, split=asr.split_audio):
        src = self.films[name]
        wav = self.dir / f'{name.replace("+", "_")}.wav'
        media.extract_audio_wav(str(src), str(wav), 16000)
        work = self.dir / f'work_{name.replace("+", "_")}_{chunk_seconds}'
        shutil.rmtree(work, True)
        out = []
        with env(WHISPER_CHUNK_SECONDS=chunk_seconds), mock.patch.object(asr, 'transcribe_wav', FakeWhisperOnBeeps()), mock.patch.object(asr, 'split_audio', split):
            for _, total, segs, lang, used in asr.transcribe_chunks(wav, work, want_spans=False):
                out += [s['start'] for s in segs]
        v0 = media.probe_timing(src)['v_start']
        want = [t for t in (o - v0 for o in F.audio_onsets_on_the_timeline(src)) if t >= -0.005]
        return out, want

    def test_every_tone_is_heard_once_at_its_true_time_on_the_pictures_timeline(self):
        for name in self.films:
            with self.subTest(name):
                got, want = self.heard(name, 12)
                self.assertEqual(len(got), len(want), (name, got, want))
                for g, w in zip(got, want):
                    self.assertLessEqual(abs(g - w), 0.020, (name, got, want))

    def test_chunks_were_really_cut_in_several_pieces(self):
        self.heard('mkv+2s', 12)
        chunks = sorted((self.dir / 'work_mkv_2s_12' / 'chunks').glob('chunk_*.wav'))
        self.assertGreaterEqual(len(chunks), 3)
        starts = asr.chunk_starts(chunks, 12)
        for s in starts[1:]:                                    # cuts are in the silence between two tones (a tone is 0.2 s every 2 s)
            self.assertGreater((s % 2.0), 0.19, starts)

    def test_a_fixed_cut_tears_a_tone_and_puts_it_off_by_a_hundred_milliseconds(self):
        def fixed(source, outdir, seconds=300):
            outdir = Path(outdir)
            outdir.mkdir(parents=True, exist_ok=True)
            media.ffmpeg('-i', source, '-f', 'segment', '-segment_time', seconds, '-reset_timestamps', '1', '-ac', '1', '-ar', '16000', '-c:a', 'pcm_s16le',
                         outdir / 'chunk_%04d.wav')
            return sorted(outdir.glob('chunk_*.wav'))
        got, want = self.heard('mkv+2s', 12.1, split=fixed)       # 12.1 s lands inside the tone that runs from 12.0 to 12.2
        worst = max(abs(g - w) for g, w in zip(got, want)) if len(got) == len(want) else 99
        self.assertGreater(worst, 0.05, 'the old fixed cut should tear this tone')
        got2, want2 = self.heard('mkv+2s', 12.1)
        self.assertEqual(len(got2), len(want2))
        self.assertLessEqual(max(abs(g - w) for g, w in zip(got2, want2)), 0.020)

    def test_audio_track_picks_the_requested_stream(self):
        two = self.dir / 'two_tracks.mkv'
        F.run('-i', self.films['mkv+2s'], '-f', 'lavfi', '-i', 'sine=frequency=300:duration=50', '-map', '0:v', '-map', '0:a', '-map', '1:a', '-c', 'copy',
              '-c:a:1', 'aac', str(two))
        a, b = self.dir / 'trk0.wav', self.dir / 'trk1.wav'
        with env():
            media.extract_audio_wav(str(two), str(a))
        with env(AUDIO_TRACK=1):
            media.extract_audio_wav(str(two), str(b))
        xa, xb = (np.frombuffer(wave.open(str(p)).readframes(10**9), dtype='<i2').astype(np.float32) / 32768 for p in (a, b))
        self.assertGreaterEqual(len(F.onsets(xa, 16000)), 20)              # track 0 = the beeps
        self.assertEqual(len(F.onsets(xb, 16000)), 1 if np.abs(xb[:16000]).max() > 0.2 else 0)   # track 1 = a steady tone, no beeps
        with env(AUDIO_TRACK=7), self.assertRaises(RuntimeError) as cm:
            media.extract_audio_wav(str(two), str(self.dir / 'trk7.wav'))
        self.assertIn('matches no streams', str(cm.exception))

    def test_the_chosen_audio_track_is_also_the_one_that_is_heard_without_narration(self):
        two = self.dir / 'two_tracks_heard.mkv'
        F.run('-i', self.films['mkv+2s'], '-f', 'lavfi', '-i', 'sine=frequency=300:duration=50', '-map', '0:v', '-map', '0:a', '-map', '1:a', '-c', 'copy',
              '-c:a:1', 'aac', str(two))
        total = media.picture_duration(two)

        def beeps(path):
            x = F.audio_samples(path, 16000)
            return len(F.onsets(x, 16000))
        for track, expect_beeps in ((None, True), (1, False)):
            with self.subTest(track=track):
                e = {} if track is None else {'AUDIO_TRACK': track}
                work = self.dir / f'wt_{track}'
                work.mkdir(exist_ok=True)
                out = self.dir / f'heard_{track}.mp4'
                prev = self.dir / f'prev_{track}.mp4'
                with env(**e):
                    media.render_with_subtitles(work, str(two), [], None, str(out), total, preset='ultrafast')
                    self.assertTrue(media.make_preview_copy(str(two), str(prev), total))
                for f in (out, prev):
                    self.assertEqual(beeps(f) >= 10, expect_beeps, (track, f.name, beeps(f)))

    def test_audio_track_values(self):
        with env():
            self.assertIsNone(media.audio_track())
        with env(AUDIO_TRACK='2'):
            self.assertEqual(media.audio_track(), 2)
        with env(AUDIO_TRACK='abc'):
            self.assertIsNone(media.audio_track())
        with env(AUDIO_TRACK='-1'):
            self.assertIsNone(media.audio_track())


class ChunkLanguageTests(unittest.TestCase):
    def setUp(self):
        self.dir = Path(tempfile.mkdtemp(prefix='recap_lang_'))
        self.addCleanup(shutil.rmtree, self.dir, True)
        T.write_wav(self.dir / 'src.wav', speechlike(130, pauses=[(60, 61)]), 16000)

    def run_chunks(self, fake, **e):
        with env(WHISPER_CHUNK_SECONDS=60, **e), mock.patch.object(asr, 'transcribe_wav', fake):
            return list(asr.transcribe_chunks(self.dir / 'src.wav', self.dir / 'work', want_spans=False))

    def test_the_language_found_in_chunk_one_is_reused(self):
        hints = []

        def fake(wav, hint=None, check=None, want_spans=True):
            hints.append(hint)
            return [{'start': 1.0, 'end': 2.0, 'text': 'x'}], 'ko', 'fake', 0.9
        out = self.run_chunks(fake)
        self.assertEqual(hints[0], None)
        self.assertTrue(all(h == 'ko' for h in hints[1:]) and len(hints) >= 2, hints)
        self.assertEqual(out[-1][3], 'ko')

    def test_a_shaky_first_guess_is_not_trusted_for_the_whole_film(self):
        hints = []
        answers = iter([('en', 0.3), ('ja', 0.95), ('ja', 0.95)])

        def fake(wav, hint=None, check=None, want_spans=True):
            hints.append(hint)
            lg, p = next(answers)
            return [{'start': 1.0, 'end': 2.0, 'text': 'x'}], lg, 'fake', p
        self.run_chunks(fake)
        self.assertEqual(hints[:2], [None, 'en'])      # the existing V21 behaviour is kept: the first answer is used for the next chunk

    def test_whisper_language_is_forced_from_the_first_chunk(self):
        hints = []

        def fake(wav, hint=None, check=None, want_spans=True):
            hints.append(hint)
            return [], 'en', 'fake', 0.99
        self.run_chunks(fake, WHISPER_LANGUAGE='Th')
        self.assertTrue(hints and all(h == 'th' for h in hints), hints)

    def test_auto_means_detect(self):
        hints = []

        def fake(wav, hint=None, check=None, want_spans=True):
            hints.append(hint)
            return [], 'en', 'fake', 0.99
        self.run_chunks(fake, WHISPER_LANGUAGE='auto')
        self.assertIsNone(hints[0])

    def test_finished_chunks_are_not_transcribed_again(self):
        n = []

        def fake(wav, hint=None, check=None, want_spans=True):
            n.append(1)
            return [{'start': 1.0, 'end': 2.0, 'text': 'x'}], 'en', 'fake', 0.9
        a = self.run_chunks(fake)
        done = len(n)
        b = self.run_chunks(fake)
        self.assertEqual(len(n), done)
        self.assertEqual([x[2] for x in a], [x[2] for x in b])

    def test_segment_times_are_absolute(self):
        def fake(wav, hint=None, check=None, want_spans=True):
            return [{'start': 1.0, 'end': 2.0, 'text': 'x', 'speech_start': 1.1, 'speech_end': 1.9}], 'en', 'fake', 0.9
        out = self.run_chunks(fake)
        starts = asr.chunk_starts(sorted((self.dir / 'work' / 'chunks').glob('chunk_*.wav')), 60)
        for (i, total, segs, lang, used), st in zip(out, starts):
            self.assertAlmostEqual(segs[0]['start'], st + 1.0, places=6)
            self.assertAlmostEqual(segs[0]['speech_start'], st + 1.1, places=6)


if __name__ == '__main__':
    unittest.main()
