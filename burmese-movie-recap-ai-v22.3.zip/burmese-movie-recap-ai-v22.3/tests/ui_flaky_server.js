// V22.1: the page when the server is flaky: boot retry, upload retry, honest messages, job reattach after a refresh.
// Run by hand (needs Node + Playwright):  node tests/ui_flaky_server.js      - every check prints PASS / FAIL, exit code 1 on a FAIL.
const { chromium } = require('playwright');
const fs = require('fs');
const path = require('path'), os = require('os');
const html = fs.readFileSync(path.join(__dirname, '..', 'frontend', 'index.html'), 'utf8');
const TMPV = path.join(os.tmpdir(), 'recap-ui-test-video.mp4');
const results = {};
(async () => {
  const browser = await chromium.launch();

  // ---- 1. the server does not answer for a while at boot: the page keeps trying, then shows the app and re-attaches the running job
  {
    const page = await browser.newPage({ viewport: { width: 1000, height: 1400 } });
    let aboutCalls = 0;
    const job = { id: 'job1', status: 'processing', stage: 'Writing Burmese', progress: 40, detail: '', orig_name: 'a.mp4', created: 1, running: true, can_resume: false, can_cancel: true, now: Date.now() / 1000, params: { provider: 'groq' }, pause: null, wait: null };
    await page.route('**/*', async route => {
      const u = new URL(route.request().url());
      const send = (obj, status = 200) => route.fulfill({ status, contentType: 'application/json', body: JSON.stringify(obj) });
      if (u.pathname === '/') return route.fulfill({ status: 200, contentType: 'text/html', body: html });
      if (!u.pathname.startsWith('/api/')) return route.fulfill({ status: 204, body: '' });
      if (u.pathname === '/api/about') { aboutCalls++; if (aboutCalls <= 2) return route.abort('connectionrefused'); return send({ version: 'V22', max_upload_mb: 0, retention_hours: 0, max_jobs: 6, boot: 'b1' }); }
      if (u.pathname === '/api/jobs/job1') return send(job);
      if (u.pathname === '/api/jobs') return send({ jobs: [job] });
      if (u.pathname === '/api/options') return send({ voices: [], groups: [], styles: [{ id: 'direct', name: 'D', label: 'D', desc: '', mode: 'line' }], default_voice: 'thiha', default_style: 'direct', recommended_style: 'direct', default_speed: 10, speed_min: -20, speed_max: 60, render_presets: ['veryfast'], default_render: 'veryfast', subtitle_ready: true, subtitle_problem: '', max_upload_mb: 0 });
      if (u.pathname === '/api/settings') return send({ configured: true, provider: 'gemini', providers: {} });
      if (u.pathname === '/api/drive/status') return send({ client_configured: false, connected: false });
      return send({});
    });
    await page.goto('http://app.local/');
    await page.waitForTimeout(300);
    results.bootMsgWhileDown = await page.$eval('#bootMsg', e => e.textContent);
    await page.waitForSelector('#app', { state: 'visible', timeout: 20000 });
    await page.waitForSelector('#job', { state: 'visible', timeout: 10000 });
    results.reattached = await page.$eval('#stage', e => e.textContent);
    results.aboutCalls = aboutCalls;
    await page.close();
  }

  // ---- 2. the upload: first connection attempts fail with nothing sent -> retried by itself and succeeds
  async function uploadCase(name, handler) {
    const page = await browser.newPage({ viewport: { width: 1000, height: 1400 } });
    const calls = { about: 0, jobs: 0 };
    const state = { boot: 'b1' };
    await page.route('**/*', async route => {
      const u = new URL(route.request().url());
      const send = (obj, status = 200) => route.fulfill({ status, contentType: 'application/json', body: JSON.stringify(obj) });
      if (u.pathname === '/') return route.fulfill({ status: 200, contentType: 'text/html', body: html });
      if (!u.pathname.startsWith('/api/')) return route.fulfill({ status: 204, body: '' });
      if (u.pathname === '/api/about') { calls.about++; return handler.about ? handler.about(calls, route, send, state) : send({ version: 'V22', max_upload_mb: 0, retention_hours: 0, max_jobs: 6, boot: state.boot }); }
      if (u.method === 'POST' || (u.pathname === '/api/jobs' && route.request().method() === 'POST')) { calls.jobs++; return handler.jobs(calls, route, send, state); }
      if (u.pathname === '/api/jobs') return send({ jobs: [] });
      if (u.pathname === '/api/options') return send({ voices: [{ id: 'thiha', label: 'သီဟ', desc: 'Edge', group: 'native' }], groups: [{ id: 'native', title: 'မူရင်း', note: 'n' }], styles: [{ id: 'direct', name: 'D', label: 'D', desc: '', mode: 'line' }], default_voice: 'thiha', default_style: 'direct', recommended_style: 'direct', default_speed: 10, speed_min: -20, speed_max: 60, render_presets: ['veryfast'], default_render: 'veryfast', subtitle_ready: true, subtitle_problem: '', max_upload_mb: 0, provider: 'gemini' });
      if (u.pathname === '/api/settings') { const o = { id: 'gemini', name: 'Gemini', configured: true, masked: 'AIza…xyz', model: 'm', source: 'user', default_model: 'm' }; return send(Object.assign({}, o, { provider: 'gemini', providers: { gemini: o, claude: Object.assign({}, o, { id: 'claude', configured: false }), groq: Object.assign({}, o, { id: 'groq', configured: false }) } })); }
      if (u.pathname === '/api/drive/status') return send({ client_configured: false, connected: false });
      if (u.pathname.startsWith('/api/jobs/')) return send({ id: 'newjob', status: 'processing', stage: 'Whisper', progress: 5, detail: '', orig_name: 'v.mp4', created: 1, now: Date.now() / 1000, params: { provider: 'gemini' } });
      return send({});
    });
    await page.goto('http://app.local/');
    await page.waitForSelector('#app', { state: 'visible' });
    await page.waitForTimeout(500);
    fs.writeFileSync(TMPV, Buffer.alloc(300000, 1));
    await page.setInputFiles('input[type=file]', TMPV);
    await page.check('#rights');
    await page.click('#start');
    await page.waitForTimeout(14000);
    const r = { startMsg: await page.$eval('#startMsg', e => e.textContent), jobVisible: await page.$eval('#job', e => getComputedStyle(e).display), calls };
    await page.close();
    return r;
  }

  results.retried = await uploadCase('retry', {
    jobs: (calls, route, send) => calls.jobs <= 2 ? route.abort('connectionreset') : send({ id: 'newjob' }),
  });
  results.serverRestarted = await uploadCase('restart', {
    about: (calls, route, send, state) => { if (calls.about > 1) state.boot = 'b2'; return send({ version: 'V22', max_upload_mb: 0, retention_hours: 0, max_jobs: 6, boot: state.boot }); },
    jobs: (calls, route) => route.abort('connectionreset'),
  });
  results.serverDown = await uploadCase('down', {
    about: (calls, route, send, state) => calls.about <= 2 ? send({ version: 'V22', max_upload_mb: 0, retention_hours: 0, max_jobs: 6, boot: 'b1' }) : route.abort('connectionrefused'),
    jobs: (calls, route) => route.abort('connectionreset'),
  });
  results.uploadBrokeServerFine = await uploadCase('fine', {
    jobs: (calls, route) => route.abort('connectionreset'),
  });
  const checks = [
    ['the page keeps trying while the server is down', /ချိတ်ဆက်နေပါတယ်/.test(results.bootMsgWhileDown)],
    ['the running job is re-attached after the server is back', results.reattached === 'Writing Burmese'],
    ['an upload that failed with nothing sent is retried by itself and succeeds', results.retried.jobVisible === 'block' && results.retried.calls.jobs === 3],
    ['a restarted server is named as such', /ပြန်စတင်သွားလို့/.test(results.serverRestarted.startMsg)],
    ['a server that is down is named as such', /မချိတ်နိုင်ပါဘူး/.test(results.serverDown.startMsg)],
    ['a broken upload with a healthy server is named as such', /Server ကတော့ ကောင်းနေပါတယ်/.test(results.uploadBrokeServerFine.startMsg)],
  ];
  let bad = 0;
  for (const [name, ok] of checks) { console.log((ok ? 'PASS ' : 'FAIL ') + name); if (!ok) bad++; }
  await browser.close();
  process.exit(bad ? 1 : 0);
})().catch(e => { console.error('FAIL', e); process.exit(1); });
