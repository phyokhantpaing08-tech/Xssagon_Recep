import json
import os
import re
import sys
import unittest

HERE = os.path.dirname(__file__)
sys.path.insert(0, os.path.join(HERE, '..', 'backend'))
sys.path.insert(0, HERE)

import gemini_client as G          # noqa: E402
import mock_gemini as M            # noqa: E402
import presets as P                # noqa: E402
import rewrite as R                # noqa: E402
import timing as T                 # noqa: E402

os.environ.setdefault('GEMINI_THINKING_BUDGET', '')


class Hooks:
    def __init__(self):
        self.notes, self.sleeps = [], []

    def check(self):
        pass

    def note(self, text):
        self.notes.append(text)

    def sleep(self, seconds, why=''):
        self.sleeps.append((seconds, why))

    def ask(self, kind, message, **info):
        raise G.GeminiNeedKey(message, kind)


def make_client(hooks=None):
    return G.GeminiClient('KEY', 'gemini-flash-latest', [], hooks=hooks or Hooks())


SYSTEM = P.build_system_prompt(P.DEFAULT_STYLE, True, timed=True)


def timed(n, limit=30):
    return [R.timed_item(f'line number {i}', limit) for i in range(n)]


def truncated_body():
    return 200, {'candidates': [{'finishReason': 'MAX_TOKENS', 'content': {'parts': [{'text': '["ဟုတ်'}]}}]}


def blocked_body():
    return 200, {'promptFeedback': {'blockReason': 'SAFETY'}}


class RewriteBatchTests(unittest.TestCase):
    def test_one_output_per_input_and_condensing_limit_is_sent(self):
        with M.MockGemini() as g:
            out = R.rewrite_batch(make_client(), SYSTEM, timed(5, 12), 'en')
        self.assertEqual(len(out), 5)
        self.assertTrue(all(out))
        for text in out:                                            # the fake model honours max_syllables
            self.assertLessEqual(T.syllables(text), 12)
        sent = g.state.requests[0]['payload']['contents'][0]['parts'][0]['text']
        self.assertIn('"max_syllables": 12', sent)
        self.assertIn('REQUIRED OUTPUT COUNT: 5', sent)

    def test_plain_string_items_for_subtitle_only_mode(self):
        with M.MockGemini():
            out = R.rewrite_batch(make_client(), SYSTEM, ['hello', '', 'world'], 'en')
        self.assertEqual(len(out), 3)
        self.assertEqual(out[1], '')

    def test_context_lines_are_passed_but_not_returned(self):
        with M.MockGemini() as g:
            out = R.rewrite_batch(make_client(), SYSTEM, timed(2), 'en', context=['အရင်စာကြောင်း'])
        self.assertEqual(len(out), 2)
        sent = g.state.requests[0]['payload']['contents'][0]['parts'][0]['text']
        self.assertIn('PREVIOUS NARRATION', sent)
        self.assertIn('အရင်စာကြောင်း', sent)

    def test_wrong_count_is_retried_once_with_a_strict_prompt(self):
        with M.MockGemini() as g:
            calls = {'n': 0}
            base = M.default_generate

            def gen(system, user):
                calls['n'] += 1
                arr = base(system, user)
                return arr[:-1] if calls['n'] == 1 else arr
            g.state.generate = gen
            out = R.rewrite_batch(make_client(), SYSTEM, timed(4), 'en')
        self.assertEqual(len(out), 4)
        self.assertEqual(calls['n'], 2)
        self.assertIn('exactly 4 outputs are required', g.state.requests[1]['payload']['contents'][0]['parts'][0]['text'])

    def test_still_wrong_count_splits_the_batch_in_half(self):
        with M.MockGemini() as g:
            base = M.default_generate

            def gen(system, user):
                arr = base(system, user)
                return arr[:-1] if len(arr) > 2 else arr           # batches of 3+ never come back right
            g.state.generate = gen
            hooks = Hooks()
            out = R.rewrite_batch(make_client(hooks), SYSTEM, timed(8), 'en', note=hooks.note)
        self.assertEqual(len(out), 8)
        self.assertTrue(all(out))
        self.assertTrue(any('နှစ်ပိုင်း' in n for n in hooks.notes))

    def test_truncated_answer_splits_the_batch(self):
        with M.MockGemini() as g:
            g.state.push(truncated_body(), times=1)
            out = R.rewrite_batch(make_client(), SYSTEM, timed(6), 'en')
        self.assertEqual(len(out), 6)
        self.assertTrue(all(out))
        self.assertEqual(g.state.count(action='generateContent'), 3)    # 1 truncated + 2 halves

    def test_a_single_line_gemini_refuses_is_skipped_not_fatal(self):
        with M.MockGemini() as g:
            g.state.push(blocked_body(), times=1)
            hooks = Hooks()
            out = R.rewrite_batch(make_client(hooks), SYSTEM, timed(1), 'en', note=hooks.note)
        self.assertEqual(out, [''])
        self.assertTrue(hooks.notes)

    def test_blocked_batch_is_split_until_the_bad_line_is_found(self):
        with M.MockGemini() as g:
            base = M.default_generate
            # Gemini refuses every request that contains the input "line number 0"
            g.state.generate = lambda s, u: blocked_body() if 'line number 0' in u else base(s, u)
            out = R.rewrite_batch(make_client(), SYSTEM, timed(4), 'en')
        self.assertEqual(len(out), 4)
        self.assertEqual(out[0], '')                                    # exactly the refused line is empty
        self.assertTrue(all(out[1:]))

    def test_dict_answers_are_flattened(self):
        with M.MockGemini() as g:
            g.state.generate = lambda s, u: [{'text': 'ဟုတ်တယ်။'}, {'burmese': 'ဟုတ်ကဲ့။'}, None]
            out = R.rewrite_batch(make_client(), SYSTEM, timed(3), 'en')
        self.assertEqual(out, ['ဟုတ်တယ်။', 'ဟုတ်ကဲ့။', ''])

    def test_503_never_reaches_the_caller(self):
        with M.MockGemini() as g:
            g.state.push(M.e503(), times=2)
            hooks = Hooks()
            out = R.rewrite_batch(make_client(hooks), SYSTEM, timed(3), 'en')
        self.assertEqual(len(out), 3)
        self.assertEqual(len(hooks.sleeps), 2)


class ShortenTests(unittest.TestCase):
    def items(self, n, limit):
        long = M.POOL[-1]
        return [{'i': i, 'text': long, 'syllables': T.syllables(long), 'max_syllables': limit} for i in range(n)]

    def test_returns_shorter_text_in_one_request(self):
        with M.MockGemini() as g:
            out = R.shorten_lines(make_client(), self.items(5, 12))
        self.assertEqual(len(out), 5)
        for text in out:
            self.assertTrue(text)
            self.assertLessEqual(T.syllables(text), 12)
        self.assertEqual(g.state.count(action='generateContent'), 1)

    def test_text_that_is_not_shorter_is_rejected(self):
        with M.MockGemini() as g:
            long = M.POOL[-1]
            g.state.generate = lambda s, u: [long, 'ဟုတ်တယ်။', '']
            out = R.shorten_lines(make_client(), self.items(3, 12))
        self.assertIsNone(out[0])                                       # the same text again = no progress
        self.assertEqual(out[1], 'ဟုတ်တယ်။')
        self.assertIsNone(out[2])                                       # empty = unusable

    def test_wrong_count_falls_back_to_smaller_requests(self):
        with M.MockGemini() as g:
            base = M.default_generate
            g.state.generate = lambda s, u: base(s, u)[:-1] if len(base(s, u)) > 1 else base(s, u)
            out = R.shorten_lines(make_client(), self.items(4, 12))
        self.assertEqual(len(out), 4)
        self.assertTrue(all(out))

    def test_empty_list_makes_no_request(self):
        with M.MockGemini() as g:
            self.assertEqual(R.shorten_lines(make_client(), []), [])
        self.assertEqual(len(g.state.requests), 0)

    def test_blocked_single_line_gives_none(self):
        with M.MockGemini() as g:
            g.state.push(blocked_body(), times=1)
            out = R.shorten_lines(make_client(), self.items(1, 12))
        self.assertEqual(out, [None])


def segs_of(n, step=3.0):
    return [{'start': i * step, 'end': i * step + 2.5, 'text': f'line number {i}'} for i in range(n)]


class StoryNotesTests(unittest.TestCase):
    """V21.3: ONE request that reads the whole transcript before any line is written."""

    def test_the_transcript_rows_are_number_time_text(self):
        text = R.story_transcript([{'start': 0, 'text': 'Hello'}, {'start': 65.4, 'text': '  two   words '}, {'start': 3723, 'text': 'late'}])
        self.assertEqual(text.split('\n'), ['0|0:00|Hello', '1|1:05|two words', '2|62:03|late'])

    def test_empty_lines_are_left_out_but_the_numbers_stay_those_of_the_film(self):
        text = R.story_transcript([{'start': 1, 'text': 'a'}, {'start': 2, 'text': '   '}, {'start': 3}, {'start': 4, 'text': 'd'}])
        self.assertEqual(text.split('\n'), ['0|0:01|a', '3|0:04|d'])

    def test_a_long_film_is_thinned_out_evenly_and_keeps_its_first_and_last_line(self):
        segs = segs_of(1000)
        full = R.story_transcript(segs, cap=10 ** 9)
        thin = R.story_transcript(segs, cap=len(full) // 3)
        rows = thin.split('\n')
        self.assertLess(len(thin), len(full) // 2)
        self.assertTrue(rows[0].startswith('0|'))
        self.assertTrue(rows[-1].startswith('999|'))
        nums = [int(r.split('|')[0]) for r in rows]
        self.assertEqual(nums, sorted(nums))
        gaps = {b - a for a, b in zip(nums[:-2], nums[1:-1])}
        self.assertEqual(len(gaps), 1)                                  # the same stride all the way through

    def test_one_very_long_line_is_cut(self):
        text = R.story_transcript([{'start': 0, 'text': 'x' * 5000}])
        self.assertLessEqual(len(text), R.STORY_LINE_CHARS + 10)

    def test_clean_notes_flattens_an_object_and_nested_lists_and_caps_the_size(self):
        self.assertEqual(R.clean_notes(['STORY: a', '', None, ' TONE:  b ']), ['STORY: a', 'TONE: b'])
        self.assertEqual(R.clean_notes({'STORY': 'a', 'TONE': 'b'}), ['STORY: a', 'TONE: b'])
        self.assertEqual(R.clean_notes([{'x': 'one', 'y': 'two'}, ['p', 'q']]), ['one | two', 'p | q'])
        self.assertEqual(R.clean_notes(None), [])
        self.assertEqual(R.clean_notes('not a list'), [])
        big = R.clean_notes(['n' * 5000] * 20)
        self.assertTrue(all(len(x) <= R.NOTE_MAX_CHARS for x in big))
        self.assertLessEqual(sum(len(x) for x in big), R.NOTES_MAX_CHARS)
        self.assertGreater(len(big), 3)

    def test_the_whole_transcript_goes_out_in_one_request_with_the_story_analyst_prompt(self):
        with M.MockGemini() as g:
            notes = R.story_notes(make_client(), segs_of(40), 'en')
        self.assertEqual(notes, M.STORY_NOTES)
        self.assertEqual(g.state.count(action='generateContent'), 1)
        payload = g.state.requests[0]['payload']
        self.assertIn('story analyst', payload['systemInstruction']['parts'][0]['text'])
        sent = payload['contents'][0]['parts'][0]['text']
        self.assertIn('Source language: en', sent)
        self.assertIn('0|0:00|line number 0', sent)
        self.assertIn('39|1:57|line number 39', sent)                   # the last line is in it too
        self.assertEqual(payload['generationConfig']['maxOutputTokens'], 4096)

    def test_no_speech_no_request(self):
        with M.MockGemini() as g:
            self.assertEqual(R.story_notes(make_client(), [{'start': 0, 'text': ' '}], 'en'), [])
        self.assertEqual(len(g.state.requests), 0)

    def test_a_refused_or_cut_off_answer_means_no_notes_never_a_failed_job(self):
        for body in (blocked_body(), truncated_body()):
            with M.MockGemini() as g:
                g.state.push(body, times=1)
                hooks = Hooks()
                self.assertEqual(R.story_notes(make_client(hooks), segs_of(5), 'en', note=hooks.note), [])
                self.assertTrue(any('မှတ်စု' in n for n in hooks.notes))

    def test_an_answer_that_is_not_a_json_array_means_no_notes(self):
        with M.MockGemini() as g:
            g.state.generate = lambda s, u: {'unexpected': 'object'}
            notes = R.story_notes(make_client(), segs_of(5), 'en')
        self.assertEqual(notes, ['unexpected: object'])                 # an object is flattened, not thrown away
        with M.MockGemini() as g:
            g.state.generate = lambda s, u: 'plain text'
            self.assertEqual(R.story_notes(make_client(), segs_of(5), 'en'), [])

    def test_a_key_or_credit_problem_is_not_swallowed(self):
        with M.MockGemini() as g:
            g.state.push(M.e429_prepay(), times=50)
            with self.assertRaises(G.GeminiNeedKey):
                R.story_notes(make_client(), segs_of(5), 'en')

    def test_the_notes_block(self):
        self.assertEqual(R.format_story_notes([]), '')
        self.assertEqual(R.format_story_notes(None), '')
        self.assertEqual(R.format_story_notes(['  ', '']), '')
        block = R.format_story_notes(['STORY: a', 'TONE: b'])
        self.assertTrue(block.startswith(P.STORY_NOTES_HEADER + '\n- STORY: a\n- TONE: b'))


class NoLookaheadTests(unittest.TestCase):
    """V22: the line-by-line style sends the batch and the previous narration only (the story style sends everything instead)."""

    def test_the_prompt_has_no_next_lines_block(self):
        prompt = R.build_user_prompt(['a', 'b'], 'en', '', ['before'])
        self.assertNotIn('NEXT SOURCE LINES', prompt)
        self.assertIn('PREVIOUS NARRATION', prompt)
        self.assertEqual(M._parse_input(prompt), ['a', 'b'])

    def test_a_split_batch_still_gives_the_right_half_the_narration_of_the_left_half(self):
        with M.MockGemini() as g:
            base = M.default_generate

            def gen(system, user):
                arr = base(system, user)
                return arr[:-1] if len(arr) > 3 else arr               # batches of 4+ never come back right -> split
            g.state.generate = gen
            out = R.rewrite_batch(make_client(), SYSTEM, timed(8), 'en')
        self.assertEqual(len(out), 8)
        for r in g.state.requests:
            if r['action'] == 'generateContent':
                self.assertNotIn('NEXT SOURCE LINES', r['payload']['contents'][0]['parts'][0]['text'])


# ------------------------------------------------------------------------------------------------ V22: the story style
class FakeAI:
    """A client without a network: chat() answers from a script (a string, an exception, or a function of the user message)."""
    TITLE = 'Fake'

    def __init__(self, script=()):
        self.script, self.calls, self.kwargs = list(script), [], []

    def chat(self, system, user, **kw):
        self.calls.append(user)
        self.kwargs.append(kw)
        item = self.script.pop(0)
        if isinstance(item, Exception):
            raise item
        return item(user) if callable(item) else item


class Cut(str):
    truncated = True


LIMITS = {'chars': 5000, 'tokens': 4096, 'timeout': 60}


def piece(a, b, text='ဟုတ်တယ်။'):
    return {'from': a, 'to': b, 'text': text}


def answer(*pieces):
    return json.dumps(list(pieces), ensure_ascii=False)


def rows_of(n, step=3.0, text='hello there'):
    return R.story_rows([{'start': i * step, 'end': i * step + 2.5, 'text': f'{text} {i}'} for i in range(n)])


def numbers(user):
    return [int(x) for x in re.findall(r'^(\d+)\|', user, re.M)]


def echo(group=2):
    """A storyteller that covers every row it sees, `group` rows per piece."""
    def gen(user):
        nums = numbers(user)
        return answer(*[piece(nums[k], nums[min(k + group, len(nums)) - 1], f'ဇာတ် {nums[k]}') for k in range(0, len(nums), group)])
    return gen


class StoryRowsTests(unittest.TestCase):
    def test_rows_are_in_time_order_with_the_number_of_the_line(self):
        segs = [{'start': 5, 'end': 6, 'text': 'b'}, {'start': 1, 'end': 2, 'text': 'a'}, {'start': 9, 'end': 9.5, 'text': ' '}, {'start': 7, 'text': 'c'}]
        rows = R.story_rows(segs)
        self.assertEqual([(r['i'], r['text']) for r in rows], [(1, 'a'), (0, 'b'), (3, 'c')])      # empty line out, order by time
        self.assertEqual(rows[2]['b'], 7.0)                                                           # no end: it ends where it starts

    def test_a_row_line_is_number_time_text_and_a_bar_in_the_text_cannot_break_it(self):
        r = R.story_rows([{'start': 83.44, 'end': 86.06, 'text': 'a | b\nc'}])[0]
        self.assertEqual(R.row_line(r), '0|83.4-86.1|a / b c')

    def test_one_very_long_row_is_cut(self):
        self.assertLessEqual(len(R.story_rows([{'start': 0, 'end': 1, 'text': 'x' * 5000}])[0]['text']), R.STORY_LINE_CHARS)

    def test_the_clock(self):
        self.assertEqual(R.fmt_clock(0), '0:00')
        self.assertEqual(R.fmt_clock(125.9), '2:05')
        self.assertEqual(R.fmt_clock(3723), '1:02:03')
        self.assertEqual(R.fmt_clock(None), '0:00')


class StoryWindowsTests(unittest.TestCase):
    def test_a_film_that_fits_is_one_part(self):
        rows = rows_of(50)
        self.assertEqual(R.story_windows(rows, 10 ** 6, 10 ** 6), [rows])

    def test_parts_respect_the_character_limit_and_keep_every_row_once_in_order(self):
        rows = rows_of(100, text='x' * 50)
        parts = R.story_windows(rows, 1500, 10 ** 6)
        self.assertGreater(len(parts), 3)
        self.assertEqual([r['i'] for p in parts for r in p], [r['i'] for r in rows])
        for p in parts:
            self.assertLessEqual(sum(len(R.row_line(r)) + 1 for r in p), 1500)

    def test_parts_respect_the_time_limit(self):
        rows = rows_of(100)
        parts = R.story_windows(rows, 10 ** 6, 60)
        self.assertGreater(len(parts), 3)
        for p in parts:
            self.assertLessEqual(p[-1]['b'] - p[0]['a'], 60 + 3)

    def test_a_full_part_is_cut_at_a_pause_when_there_is_one_near_its_end(self):
        rows = rows_of(40, text='x' * 40)
        for r in rows[30:]:                           # a 20 s pause before row 30
            r['a'] += 20
            r['b'] += 20
        parts = R.story_windows(rows, len(R.row_line(rows[0])) * 33, 10 ** 6)
        self.assertEqual(parts[0][-1]['i'], 29)

    def test_no_rows_no_parts(self):
        self.assertEqual(R.story_windows([], 100, 100), [])

    def test_a_provider_with_a_small_output_limit_gets_short_parts(self):
        small, big = {'tokens': 4096}, {'tokens': 65000}
        self.assertLess(R.window_seconds(small, 5.0), 400)
        self.assertGreater(R.window_seconds(big, 5.0), 3000)
        self.assertGreaterEqual(R.window_seconds({'tokens': 1}, 5.0), 60)


class StoryParsingTests(unittest.TestCase):
    def test_a_clean_array(self):
        items, complete = R.parse_story_items(answer(piece(0, 1), piece(2, 3)))
        self.assertEqual(len(items), 2)
        self.assertTrue(complete)

    def test_a_code_fence_and_an_object_around_the_array(self):
        self.assertEqual(R.parse_story_items('```json\n' + answer(piece(0, 1)) + '\n```')[0][0]['to'], 1)
        items, complete = R.parse_story_items(json.dumps({'story': [piece(0, 1)]}))
        self.assertEqual(len(items), 1)
        self.assertTrue(complete)

    def test_a_cut_off_answer_keeps_every_whole_piece(self):
        text = answer(piece(0, 1, 'က'), piece(2, 3, 'ခ'))[:-1] + ', {"from": 4, "to": 5, "te'
        items, complete = R.parse_story_items(text)
        self.assertEqual([i['text'] for i in items], ['က', 'ခ'])
        self.assertFalse(complete)

    def test_text_that_is_not_an_answer(self):
        for bad in ('', None, 'sorry, I cannot', '{}', '[1, 2, 3]', '["a"]'):
            self.assertEqual(R.parse_story_items(bad)[0], [], repr(bad))


class StoryNormalizeTests(unittest.TestCase):
    def setUp(self):
        self.rows = rows_of(12)

    def norm(self, *pieces, rows=None):
        return R.normalize_story_items(list(pieces), rows or self.rows)

    def test_a_full_cover_stays_as_it_is(self):
        items, covered = self.norm(piece(0, 3, 'က'), piece(4, 11, 'ခ'))
        self.assertEqual([(i['from'], i['to'], i['text']) for i in items], [(0, 3, 'က'), (4, 11, 'ခ')])
        self.assertEqual(covered, 12)

    def test_a_small_gap_is_joined_to_the_piece_before_it(self):
        items, covered = self.norm(piece(0, 2), piece(5, 11))
        self.assertEqual([(i['from'], i['to']) for i in items], [(0, 4), (5, 11)])
        self.assertEqual(covered, 12)

    def test_the_first_piece_starts_at_the_first_row(self):
        items, covered = self.norm(piece(2, 11))
        self.assertEqual((items[0]['from'], covered), (0, 12))

    def test_a_big_gap_or_a_missing_end_is_not_told_yet(self):
        items, covered = self.norm(piece(0, 3), piece(9, 11))                  # rows 4-8 are missing
        self.assertEqual(([(i['from'], i['to']) for i in items], covered), ([(0, 3)], 4))
        items, covered = self.norm(piece(0, 5))                               # stopped early
        self.assertEqual(covered, 6)

    def test_overlaps_and_going_back_in_time_are_trimmed(self):
        items, covered = self.norm(piece(0, 5, 'က'), piece(3, 8, 'ခ'), piece(2, 4, 'ဂ'), piece(9, 11, 'ဃ'))
        self.assertEqual([(i['from'], i['to'], i['text']) for i in items], [(0, 5, 'က'), (6, 8, 'ခ'), (9, 11, 'ဃ')])
        self.assertEqual(covered, 12)

    def test_pieces_in_the_wrong_order_are_put_in_time_order(self):
        items, _ = self.norm(piece(6, 11, 'ခ'), piece(0, 5, 'က'))
        self.assertEqual([i['text'] for i in items], ['က', 'ခ'])

    def test_numbers_as_text_and_swapped_numbers_and_one_number_only(self):
        items, covered = self.norm({'from': '0', 'to': '2.0', 'text': 'က'}, {'from': 5, 'to': 3, 'text': 'ခ'}, {'to': 6, 'text': 'ဂ'}, {'from': 7})
        self.assertEqual([(i['from'], i['to']) for i in items], [(0, 2), (3, 5), (6, 6), (7, 7)])
        self.assertEqual(items[3]['text'], '')

    def test_numbers_that_are_not_rows_snap_to_the_rows_that_exist(self):
        rows = R.story_rows([{'start': 0, 'end': 1, 'text': 'a'}, {'start': 1, 'end': 2, 'text': ' '}, {'start': 2, 'end': 3, 'text': 'c'}, {'start': 3, 'end': 4, 'text': 'd'}])
        items, covered = R.normalize_story_items([piece(0, 1, 'x'), piece(2, 9, 'y')], rows)          # row 1 has no text
        self.assertEqual([(i['from'], i['to']) for i in items], [(0, 0), (2, 3)])
        self.assertEqual(covered, 3)

    def test_pieces_with_no_usable_numbers_or_outside_the_rows_are_dropped(self):
        items, covered = self.norm({'text': 'x'}, piece(50, 60), {'from': 'a', 'to': 'b'}, 'junk', None)
        self.assertEqual((items, covered), ([], 0))

    def test_text_is_cleaned_and_other_keys_are_accepted(self):
        items, _ = self.norm({'from': 0, 'to': 11, 'burmese': '  ဟုတ်   တယ် \n'})
        self.assertEqual(items[0]['text'], 'ဟုတ် တယ်')


class StoryAttemptTests(unittest.TestCase):
    def test_the_request_carries_every_row_the_pace_context_and_the_answer_limits(self):
        rows = rows_of(6)
        ai = FakeAI([answer(piece(0, 5))])
        items, covered = R.story_attempt(ai, 'SYS', rows, 'en', 125, True, True, ['earlier piece'], LIMITS)
        self.assertEqual(covered, 6)
        sent = ai.calls[0]
        self.assertIn('Source language: en', sent)
        self.assertIn('Length of the whole film: 2:05', sent)
        self.assertIn('WHOLE film', sent)
        self.assertIn('STORY SO FAR', sent)
        self.assertIn('earlier piece', sent)
        self.assertEqual(numbers(sent), [0, 1, 2, 3, 4, 5])
        self.assertIn('0|0.0-2.5|hello there 0', sent)
        self.assertEqual((ai.kwargs[0]['max_tokens'], ai.kwargs[0]['timeout'], ai.kwargs[0]['partial']), (4096, 60, True))

    def test_the_position_of_a_part_is_told(self):
        rows = rows_of(6)
        for first, last, word in ((True, False, 'BEGINNING'), (False, False, 'MIDDLE'), (False, True, 'END')):
            ai = FakeAI([answer(piece(0, 5))])
            R.story_attempt(ai, 'S', rows, 'en', 20, first, last, None, LIMITS)
            self.assertIn(word, ai.calls[0])
            self.assertNotIn('STORY SO FAR', ai.calls[0])

    def test_pieces_without_any_words_are_not_an_answer(self):
        ai = FakeAI([answer(piece(0, 5, ''))])
        self.assertEqual(R.story_attempt(ai, 'S', rows_of(6, text='a long enough line of speech'), 'en', 20, True, True, None, LIMITS), ([], 0))

    def test_the_strict_retry_repeats_the_format(self):
        ai = FakeAI([answer(piece(0, 5))])
        R.story_attempt(ai, 'S', rows_of(6), 'en', 20, True, True, None, LIMITS, strict=True)
        self.assertIn('could not be used', ai.calls[0])
        self.assertIn('start with row 0', ai.calls[0])


class TellRowsTests(unittest.TestCase):
    def tell(self, ai, rows, **kw):
        return R.tell_rows(ai, 'SYS', rows, 'en', 100, kw.pop('context', None), kw.pop('first', True), kw.pop('last', True), LIMITS, **kw)

    def assert_covers(self, items, rows):
        got = [(i['from'], i['to']) for i in items]
        self.assertEqual(got[0][0], rows[0]['i'])
        self.assertEqual(got[-1][1], rows[-1]['i'])
        self.assertTrue(all(b[0] == a[1] + 1 for a, b in zip(got, got[1:])), got)

    def test_one_request_for_the_whole_film(self):
        ai, rows = FakeAI([echo(3)]), rows_of(12)
        items = self.tell(ai, rows)
        self.assertEqual(len(ai.calls), 1)
        self.assert_covers(items, rows)
        self.assertEqual(len(items), 4)

    def test_an_answer_that_was_cut_off_keeps_what_arrived_and_asks_for_the_rest(self):
        rows = rows_of(12)
        ai = FakeAI([Cut(answer(piece(0, 3, 'က'), piece(4, 6, 'ခ'))[:-12]), echo(3)])
        items = self.tell(ai, rows)
        self.assertEqual(len(ai.calls), 2)
        self.assertEqual(numbers(ai.calls[1]), list(range(4, 12)))            # the second request holds only what was not told yet
        self.assertIn('STORY SO FAR', ai.calls[1])
        self.assertIn('က', ai.calls[1])                                       # ... and what was told so far
        self.assertEqual(items[0]['text'], 'က')
        self.assert_covers(items, rows)

    def test_an_answer_that_stops_early_is_continued(self):
        rows = rows_of(12)
        ai = FakeAI([answer(piece(0, 5)), echo(3)])
        items = self.tell(ai, rows)
        self.assertEqual(numbers(ai.calls[1]), list(range(6, 12)))
        self.assert_covers(items, rows)

    def test_an_unusable_answer_is_asked_again_strictly_once(self):
        rows = rows_of(8)
        ai = FakeAI(['sorry I cannot do that', echo(4)])
        hooks = []
        items = self.tell(ai, rows, note=hooks.append)
        self.assertEqual(len(ai.calls), 2)
        self.assertNotIn('could not be used', ai.calls[0])
        self.assertIn('could not be used', ai.calls[1])
        self.assertTrue(hooks)
        self.assert_covers(items, rows)

    def test_two_unusable_answers_split_the_rows_in_two(self):
        rows = rows_of(8)
        ai = FakeAI(['garbage', 'garbage', echo(4), echo(4)])
        items = self.tell(ai, rows)
        self.assertEqual([numbers(c) for c in ai.calls[2:]], [[0, 1, 2, 3], [4, 5, 6, 7]])
        self.assert_covers(items, rows)

    def test_too_big_and_refused_requests_split_at_once(self):
        for exc in (G.GeminiTooLarge('413'), G.GeminiBlocked('SAFETY'), G.GeminiTruncated('cut')):
            rows = rows_of(6)
            ai = FakeAI([exc, echo(3), echo(3)])
            items = self.tell(ai, rows)
            self.assertEqual(len(ai.calls), 3, exc)
            self.assert_covers(items, rows)

    def test_a_single_row_nobody_can_tell_is_skipped_so_nothing_stalls(self):
        rows = rows_of(3)
        ai = FakeAI([G.GeminiBlocked('x')] * 40)
        items = self.tell(ai, rows)
        self.assertEqual([(i['from'], i['to'], i['text']) for i in items], [(0, 0, ''), (1, 1, ''), (2, 2, '')])

    def test_a_key_problem_is_not_swallowed(self):
        with self.assertRaises(G.GeminiNeedKey):
            self.tell(FakeAI([G.GeminiNeedKey('credit', 'exhausted')]), rows_of(4))

    def test_another_error_is_raised(self):
        with self.assertRaises(G.GeminiError):
            self.tell(FakeAI([G.GeminiError('Gemini API 400: bad')]), rows_of(4))

    def test_cancel_is_checked_between_requests(self):
        class Stop(Exception):
            pass

        def check():
            raise Stop()
        with self.assertRaises(Stop):
            self.tell(FakeAI([echo()]), rows_of(4), check=check)


class TellStoryTests(unittest.TestCase):
    def setUp(self):
        self.rows = rows_of(40, text='w' * 60)
        self.limits = {'chars': 2100, 'tokens': 4096, 'timeout': 60}

    def tell(self, ai, **kw):
        return R.tell_story(ai, 'SYS', self.rows, 'en', 120, self.limits, 5.0, **kw)

    def test_a_long_film_is_told_in_parts_that_follow_each_other(self):
        ai, seen = FakeAI([echo()] * 10), []
        items = self.tell(ai, progress=lambda k, n, its: seen.append((k, n, len(its))))
        self.assertEqual(len(ai.calls), 2)
        self.assertEqual([s[:2] for s in seen], [(1, 2), (2, 2)])
        self.assertIn('BEGINNING', ai.calls[0])
        self.assertIn('END', ai.calls[1])
        self.assertIn('STORY SO FAR', ai.calls[1])                           # the second part knows how the first one ended
        self.assertNotIn('STORY SO FAR', ai.calls[0])
        got = [(i['from'], i['to']) for i in items]
        self.assertEqual((got[0][0], got[-1][1]), (0, 39))
        self.assertTrue(all(b[0] == a[1] + 1 for a, b in zip(got, got[1:])))
        # every row went to the AI exactly once
        self.assertEqual(sorted(n for c in ai.calls for n in numbers(c)), list(range(40)))

    def test_a_film_that_fits_is_one_request(self):
        self.limits['chars'] = 10 ** 6
        ai = FakeAI([echo(5)])
        items = self.tell(ai)
        self.assertEqual(len(ai.calls), 1)
        self.assertIn('WHOLE film', ai.calls[0])
        self.assertEqual(len(items), 8)

    def test_a_resumed_job_continues_after_the_last_piece_it_has(self):
        first = self.tell(FakeAI([echo()] * 10))
        done = first[:len(first) // 2]
        ai = FakeAI([echo()] * 10)
        items = self.tell(ai, done=done)
        self.assertEqual(items[:len(done)], done)
        self.assertEqual(min(numbers(ai.calls[0])), done[-1]['to'] + 1)
        self.assertEqual(sorted(n for c in ai.calls for n in numbers(c)), list(range(done[-1]['to'] + 1, 40)))
        self.assertIn('STORY SO FAR', ai.calls[0])
        got = [(i['from'], i['to']) for i in items]                          # (the new parts may be cut elsewhere than before)
        self.assertEqual((got[0][0], got[-1][1]), (0, 39))
        self.assertTrue(all(b[0] == a[1] + 1 for a, b in zip(got, got[1:])))

    def test_a_finished_story_asks_for_nothing(self):
        first = self.tell(FakeAI([echo()] * 10))
        ai = FakeAI()
        self.assertEqual(self.tell(ai, done=first), first)
        self.assertEqual(ai.calls, [])


class StorySegmentsTests(unittest.TestCase):
    def test_one_line_per_piece_with_the_time_and_text_of_its_rows(self):
        segs = [{'start': i * 3.0, 'end': i * 3.0 + 2.5, 'text': f'line {i}', 'speech_start': i * 3.0 + 0.2, 'speech_end': i * 3.0 + 2.0} for i in range(6)]
        segs[3]['text'] = ''
        new, lines, src = R.story_segments(segs, [piece(0, 2, 'က'), piece(3, 5, 'ခ')])
        self.assertEqual(lines, ['က', 'ခ'])
        self.assertEqual(src, ['line 0 line 1 line 2', 'line 4 line 5'])
        self.assertEqual(new[0], {'start': 0.0, 'end': 8.5, 'text': 'line 0 line 1 line 2', 'speech_start': 0.2, 'speech_end': 8.0})
        self.assertEqual((new[1]['start'], new[1]['end']), (9.0, 17.5))      # the empty line 3 is part of the piece's time
        self.assertTrue(all(a['end'] <= b['start'] + 1e-9 for a, b in zip(new, new[1:])))

    def test_lines_without_speech_marks_stay_without_them(self):
        new, _, _ = R.story_segments(segs_of(4), [piece(0, 3)])
        self.assertNotIn('speech_start', new[0])

    def test_numbers_outside_the_film_are_clamped_and_empty_pieces_dropped(self):
        new, lines, _ = R.story_segments(segs_of(3), [piece(0, 99, 'က'), piece(50, 60, 'ခ')])
        self.assertEqual((len(new), lines), (1, ['က']))

    def test_an_empty_piece_stays_a_silent_line(self):
        new, lines, _ = R.story_segments(segs_of(4), [piece(0, 1, ''), piece(2, 3, 'က')])
        self.assertEqual(lines, ['', 'က'])
        self.assertEqual(len(new), 2)


class StoryOverHttpTests(unittest.TestCase):
    """The whole thing through the (fake) Gemini HTTP API: ONE request carries the whole transcript."""

    def test_the_transcript_goes_out_in_one_request_and_the_pieces_come_back(self):
        segs = segs_of(30)
        rows = R.story_rows(segs)
        system = P.build_story_prompt(True, 5.0)
        limits = {'chars': 150000, 'tokens': 65000, 'timeout': 900}
        with M.MockGemini() as g:
            items = R.tell_story(make_client(), system, rows, 'en', 90, limits, 5.0)
        self.assertEqual(g.state.count(action='generateContent'), 1)
        payload = g.state.requests[0]['payload']
        self.assertIn('charismatic Burmese storyteller', payload['systemInstruction']['parts'][0]['text'])
        sent = payload['contents'][0]['parts'][0]['text']
        self.assertEqual(numbers(sent), list(range(30)))
        self.assertEqual(payload['generationConfig']['maxOutputTokens'], 65000)
        self.assertEqual((items[0]['from'], items[-1]['to']), (0, 29))
        self.assertEqual(len(items), 10)
        new, lines, src = R.story_segments(segs, items)
        self.assertEqual(len(new), 10)
        self.assertTrue(all(lines))

    def test_a_cut_off_http_answer_keeps_the_whole_pieces(self):
        segs = segs_of(12)
        rows = R.story_rows(segs)
        with M.MockGemini() as g:
            first = json.dumps([piece(0, 3, 'က'), piece(4, 5, 'ခ'), piece(6, 7, 'ဂ')], ensure_ascii=False)[:-30]
            g.state.push((200, {'candidates': [{'finishReason': 'MAX_TOKENS', 'content': {'parts': [{'text': first}]}}]}), times=1)
            items = R.tell_story(make_client(), P.build_story_prompt(True, 5.0), rows, 'en', 40, LIMITS, 5.0)
        self.assertEqual(g.state.count(action='generateContent'), 2)
        self.assertEqual(items[0]['text'], 'က')
        self.assertEqual((items[0]['from'], items[-1]['to']), (0, 11))


if __name__ == '__main__':
    unittest.main()
