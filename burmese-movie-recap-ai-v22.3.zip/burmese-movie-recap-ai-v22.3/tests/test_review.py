"""The review stage (V21.1): a job started with "review" stops after the Burmese text is written, waits (no thread) while the
person edits the text and sets the look of the subtitles / the blur, and only then makes the voice from the EDITED text.
V21.2 adds the time of every single line: the person may move a line earlier / later ("shifts"), and the voice, the room of each
line and the subtitle all follow that new time.

Real FastAPI on a real local port, fake Gemini / Whisper / Edge TTS, real ffmpeg - nothing uses the network or any credit."""
import json
import os
import random
import re
import shutil
import subprocess
import sys
import time
import unittest
from pathlib import Path

import numpy as np

HERE = os.path.dirname(__file__)
sys.path.insert(0, os.path.join(HERE, '..', 'backend'))
sys.path.insert(0, HERE)

from test_app import AppTestBase, Client, fastapi  # noqa: E402
from test_pipeline import FakeEdge, TOTAL_LINES, VIDEO_SECONDS, decode_mono, dominant_hz, unique_generate  # noqa: E402
import jobs as J                   # noqa: E402
import media                       # noqa: E402
import mock_gemini as M            # noqa: E402
import review                      # noqa: E402
import timing as T                 # noqa: E402
import voices as V                 # noqa: E402

LOOK = {'font': 130, 'bottom': 12, 'colour': '#00ffaa', 'box': True, 'box_alpha': 70, 'offset': 1.5}
BLUR = {'on': True, 'top': 60, 'height': 16, 'strength': 200, 'dark': 50}


def srt_start(srt, n=0):
    """Start of cue number n (0 based) of an .srt, in seconds."""
    m = re.findall(r'(\d+):(\d+):(\d+),(\d+) -->', srt)[n]
    return int(m[0]) * 3600 + int(m[1]) * 60 + int(m[2]) + int(m[3]) / 1000.0


def srt_cues(srt):
    """Every cue of an .srt as (start, end, text), in seconds."""
    cues = []
    for block in re.split(r'\n\s*\n', srt.strip()):
        m = re.match(r'\s*\d+\s*\n(\d+):(\d+):(\d+),(\d+) --> (\d+):(\d+):(\d+),(\d+)\s*\n(.*)', block, re.S)
        if m:
            g = [int(x) for x in m.groups()[:8]]
            cues.append((g[0] * 3600 + g[1] * 60 + g[2] + g[3] / 1000.0, g[4] * 3600 + g[5] * 60 + g[6] + g[7] / 1000.0, m.group(9).strip()))
    return cues


# ====================================================================================================== the files (no web server needed)
class AssLookTests(unittest.TestCase):
    """build_ass(): the classic look is exactly what V21 made; the new look only changes what the person asked to change."""
    SEG = [{'start': 1.0, 'end': 3.0, 'burmese': 'မင်္ဂလာပါ ဒီနေ့ ရာသီဥတု ကောင်းတယ်'}]

    def test_the_classic_look_is_unchanged(self):
        ass = media.build_ass(self.SEG, 1280, 720, 'Padauk', None)
        self.assertIn('Style: Default,Padauk,40,&H0000FFFF,&H000000FF,&H00000000,&H80000000,0,0,0,0,100,100,0,0,1,2.8,1,2,76,76,50,1', ass)
        band = media.blur_band(720, 70, 18)
        ass = media.build_ass(self.SEG, 1280, 720, 'Padauk', band)
        self.assertRegex(ass, r'\{\\an5\\pos\(640,\d+\)\\fs\d+\\bord[\d.]+\}')
        self.assertEqual(ass, media.build_ass(self.SEG, 1280, 720, 'Padauk', band, None))

    def test_an_empty_look_means_the_same_sizes(self):
        a = media.build_ass(self.SEG, 1280, 720, 'Padauk', media.blur_band(720, 70, 18))
        b = media.build_ass(self.SEG, 1280, 720, 'Padauk', media.blur_band(720, 70, 18), {})
        self.assertEqual(a, b)                                  # font 100 %, automatic place, yellow, no box

    def test_size_colour_box_and_place(self):
        look = {'font': 150, 'colour': '#00FFAA', 'box': True, 'box_alpha': 70, 'bottom': 10}
        ass = media.build_ass(self.SEG, 1280, 720, 'Padauk', media.blur_band(720, 70, 18), look)
        style = [x for x in ass.splitlines() if x.startswith('Style:')][0]
        size = int(style.split(',')[2])
        self.assertEqual(size, 59)                              # round(720 * 0.055 * 1.5) = 59, no longer held back by the band
        self.assertIn('&H00AAFF00', style)                      # the colour, in ASS order (BBGGRR)
        fields = style.split(',')
        self.assertEqual(fields[5], '&H4C000000')               # box colour = the outline colour, 70 % solid (alpha 76 of 255)
        self.assertEqual(fields[15], '3')                       # BorderStyle 3 = opaque box
        self.assertRegex(ass, r'\{\\an2\\pos\(640,(\d+)\)\\fs59\\bord\d+(\.\d)?\}')
        y = int(re.search(r'\\pos\(640,(\d+)\)', ass).group(1))
        self.assertLess(abs(y - (720 - 72 - 15)), 2)            # 10 % above the bottom edge, minus the box padding

    def test_the_automatic_place_stays_in_the_band(self):
        ass = media.build_ass(self.SEG, 1280, 720, 'Padauk', media.blur_band(720, 70, 18), {'font': 100, 'bottom': None})
        y0, h = media.blur_band(720, 70, 18)
        self.assertIn('\\an5\\pos(640,%d)' % (y0 + h // 2), ass)

    def test_bad_values_never_reach_the_file(self):
        look = media.clean_look({'font': 'abc', 'bottom': 'x', 'colour': 'red; rm -rf', 'box': 'no', 'box_alpha': 1e9, 'offset': float('nan')})
        self.assertEqual(look, {'font': 100.0, 'bottom': None, 'colour': None, 'box': False, 'box_alpha': 100.0, 'offset': 0.0})
        self.assertEqual(media.clean_look({'font': 9999})['font'], 250.0)
        self.assertEqual(media.clean_look({'font': 1})['font'], 40.0)
        self.assertEqual(media.clean_look({'bottom': 500})['bottom'], 80.0)
        self.assertEqual(media.clean_look({'colour': '#abcdef'})['colour'], '#ABCDEF')
        self.assertEqual(media.clean_look(None), media.clean_look({}))
        self.assertIsNone(media.clean_blur(None))
        self.assertEqual(media.clean_blur({'height': 999, 'strength': 1, 'dark': 500, 'top': -3}),
                         {'top': None, 'height': 60.0, 'strength': 20.0, 'dark': 100.0})
        # hostile text inside a subtitle cannot add ASS commands
        ass = media.build_ass([{'start': 0, 'end': 1, 'burmese': 'a{\\fs999}b\\N'}], 640, 360, 'Padauk', None, {})
        self.assertNotIn('{\\fs999}', ass)

    def test_blur_strength_and_darkness(self):
        classic = media.build_video_filter(1280, 720, (540, 130))
        self.assertIn('luma_power=3', classic)
        self.assertIn('black@0.30', classic)
        strong = media.build_video_filter(1280, 720, (540, 130), 250, 70)
        self.assertIn('luma_power=8', strong)
        self.assertIn('black@0.70', strong)
        self.assertIn('luma_power=1', media.build_video_filter(1280, 720, (540, 130), 20, 0))
        self.assertIn('luma_power=3', media.build_video_filter(1280, 720, (540, 130), 100, 30))

    def test_shifting_the_subtitles(self):
        segs = [{'start': 0.0, 'end': 2.0, 'burmese': 'a'}, {'start': 5.0, 'end': 8.0, 'burmese': 'b'}, {'start': 9.0, 'end': 10.0, 'burmese': 'c'}]
        same = media.shift_segments(segs, 0, 10.0)
        self.assertEqual([(x['start'], x['end']) for x in same], [(0.0, 2.0), (5.0, 8.0), (9.0, 10.0)])
        late = media.shift_segments(segs, 1.5, 10.0)
        self.assertEqual([(x['start'], x['end']) for x in late], [(1.5, 3.5), (6.5, 9.5)])      # the last line now starts after the video ended: dropped
        clipped = media.shift_segments(segs, 0.5, 10.0)
        self.assertEqual([(x['start'], x['end']) for x in clipped], [(0.5, 2.5), (5.5, 8.5), (9.5, 10.0)])   # what runs past the end is cut
        early = media.shift_segments(segs, -1.0, 10.0)
        self.assertEqual([(x['start'], x['end']) for x in early], [(0.0, 1.0), (4.0, 7.0), (8.0, 9.0)])
        self.assertEqual(len(media.shift_segments(segs, -9.5, 10.0)), 1)         # what leaves the video is dropped
        self.assertEqual(segs[0]['start'], 0.0)                                  # the input is not changed

    def test_font_scale_matches_what_libass_does(self):
        font, _ = media.find_burmese_font()
        scale = media.font_metric_scale(font)
        self.assertTrue(scale and 0.3 < scale < 1.5, scale)


class ReviewFilesTests(unittest.TestCase):
    def setUp(self):
        import tempfile
        self.dir = Path(tempfile.mkdtemp(prefix='recap_rev_'))
        (self.dir / 'work').mkdir()
        self.addCleanup(shutil.rmtree, self.dir, True)
        segs = [{'start': i * 4.0, 'end': i * 4.0 + 2.5, 'text': f'line {i}'} for i in range(5)]
        (self.dir / 'work' / 'rewrite.json').write_text(json.dumps({'sig': 'abc', 'lines': [f'မြန်မာ {i}' for i in range(5)],
                                                                    'src': [s['text'] for s in segs]}, ensure_ascii=False), encoding='utf-8')
        review.save(self.dir, {'v': 1, 'segs': segs, 'duration': 20.0, 'size': [640, 360], 'preview': 'original', 'sps': 5.0,
                               'settings': None, 'edited': [], 'done': False, 'ai': [f'မြန်မာ {i}' for i in range(5)]})

    def test_edits_are_clean_and_only_real_changes_count(self):
        changed = review.apply_edits(self.dir, {'1': '  ပြင်ထား\n\tတယ်  ', '2': 'မြန်မာ 2', '9': 'x', 'q': 'y', '-1': 'z', '3': 'a' * 5000})
        self.assertEqual(changed, [1, 3])
        lines, _ = review.read_lines(self.dir)
        self.assertEqual(lines[1], 'ပြင်ထား တယ်')
        self.assertEqual(len(lines[3]), review.MAX_LINE)
        self.assertEqual(lines[2], 'မြန်မာ 2')
        self.assertEqual(review.load(self.dir)['edited'], [1, 3])
        review.apply_edits(self.dir, {'4': 'နောက်ထပ်'})
        self.assertEqual(review.load(self.dir)['edited'], [1, 3, 4])           # edited lines stay "edited"
        doc = json.loads((self.dir / 'work' / 'rewrite.json').read_text(encoding='utf-8'))
        self.assertEqual(len(doc['lines']), len(doc['src']))                   # the pipeline's own file is still valid

    def test_payload_carries_the_ai_text_only_where_it_differs(self):
        review.apply_edits(self.dir, {'0': 'ပြင်ထား'})
        d = review.payload(self.dir, {'make_voice': True, 'make_subs': False})
        self.assertEqual(d['lines'][0]['my'], 'ပြင်ထား')
        self.assertEqual(d['lines'][0]['ai'], 'မြန်မာ 0')
        self.assertNotIn('ai', d['lines'][1])
        self.assertEqual((d['lines'][1]['a'], d['lines'][1]['b'], d['lines'][1]['nx']), (4.0, 6.5, 8.0))
        self.assertEqual(d['lines'][4]['nx'], 20.0)                            # the last line has room up to the end of the video
        self.assertTrue(d['make_voice'])

    def test_settings_start_from_what_was_chosen_at_upload(self):
        params = {'make_voice': False, 'make_subs': True, 'blur': {'top': 70, 'height': 20}}
        s = review.default_settings(params)
        self.assertEqual((s['subs'], s['blur']['on'], s['blur']['top'], s['blur']['height']), (True, True, 70.0, 20.0))
        self.assertEqual(s['look'], media.clean_look({}))
        no_blur = review.default_settings({'make_voice': False, 'make_subs': True, 'blur': None})
        self.assertFalse(no_blur['blur']['on'])
        voice_only = review.default_settings({'make_voice': True, 'make_subs': False, 'blur': None})
        self.assertFalse(voice_only['subs'])
        self.assertTrue(voice_only['blur']['on'])                              # switching the subtitles on starts with the blur

    def test_settings_become_job_parameters(self):
        params = {'make_voice': True, 'make_subs': False, 'blur': None, 'speed': 10}
        s = review.clean_settings({'subs': True, 'blur': BLUR, 'look': LOOK}, params)
        p = review.job_params(params, s)
        self.assertTrue(p['make_subs'])
        self.assertEqual(p['blur'], {'top': 60.0, 'height': 16.0, 'strength': 200.0, 'dark': 50.0})
        self.assertEqual(p['look']['font'], 130.0)
        self.assertEqual(p['speed'], 10)
        off = review.job_params(params, review.clean_settings({'subs': True, 'blur': {'on': False}}, params))
        self.assertIsNone(off['blur'])
        none = review.job_params(params, review.clean_settings({'subs': False}, params))
        self.assertFalse(none['make_subs'])
        self.assertIsNone(none['blur'])

    # ---------------------------------------------------------------- V21.2: lines moved in time
    def test_moved_lines_are_kept_with_the_review_and_reach_the_page(self):
        settings = review.clean_settings({}, {})
        review.remember(self.dir, settings, shifts={'1': 1.5, '3': -2.0, '9': 4, 'x': 1, '2': 0})
        self.assertEqual(review.load(self.dir)['shifts'], {'1': 1.5, '3': -2.0})           # only real moves of real lines
        d = review.payload(self.dir, {'make_voice': True, 'make_subs': False})
        self.assertEqual({x['i']: x['sh'] for x in d['lines'] if 'sh' in x}, {1: 1.5, 3: -2.0})
        self.assertEqual((d['lines'][1]['a'], d['lines'][1]['b'], d['lines'][1]['nx']), (4.0, 6.5, 8.0))   # the page gets the ORIGINAL times and adds the move itself
        self.assertEqual(d['shift'], {'max': 5.0, 'gap': 0.1, 'room': 0.3})                # the page uses the server's limits
        review.remember(self.dir, settings)                                                # only the look was saved: the moves stay
        review.apply_edits(self.dir, {'0': 'ပြင်ထား'})                                       # so does an edit of the text
        self.assertEqual(review.load(self.dir)['shifts'], {'1': 1.5, '3': -2.0})
        review.remember(self.dir, settings, shifts={})                                     # the person took every move back
        self.assertEqual(review.load(self.dir)['shifts'], {})
        self.assertFalse(any('sh' in x for x in review.payload(self.dir, {})['lines']))

    def test_a_move_that_does_not_fit_is_shortened_before_it_is_kept(self):
        review.remember(self.dir, review.clean_settings({}, {}), shifts={'4': 5, '0': -5, '2': 99})
        # the last line stays 0.3 s inside the 20 s video, the first line cannot go before 0, line 2 stops 0.1 s before line 3
        self.assertEqual(review.load(self.dir)['shifts'], {'4': 3.7, '2': 3.9})

    def test_the_page_and_the_pipeline_read_the_same_moves(self):
        state = review.load(self.dir)
        state['shifts'] = {'2': 99, '3': 'junk', '8': 1}                                   # a file damaged by hand
        review.save(self.dir, state)
        d = review.payload(self.dir, {})
        self.assertEqual({x['i']: x['sh'] for x in d['lines'] if 'sh' in x}, {2: 3.9})
        out = review.shifted_segments(state['segs'], state['shifts'], state['duration'])
        self.assertEqual([round(x['start'] - y['start'], 2) for x, y in zip(out, state['segs'])], [0, 0, 3.9, 0, 0])


class ShiftRulesTests(unittest.TestCase):
    """The rule that decides how far a line may be moved. The review page draws the very same rule (so the person sees what will
    happen); on the server it is the safety net for everything that does not come from that page."""
    STARTS = [0.0, 4.0, 8.0, 12.0, 16.0]

    def test_only_real_numbers_for_real_lines_are_kept(self):
        raw = {'1': 2, '2': '-1.5', 'x': 3, '9': 1, '-1': 1, '3': 'abc', '4': float('nan'), '0': 0.001, '1.0': 4, ' 3 ': None}
        self.assertEqual(review.clean_shifts(raw, 5), {1: 2.0, 2: -1.5})
        self.assertEqual(review.clean_shifts({'0': 99, '1': -99, '2': 1.23456, '3': float('inf'), '4': 10 ** 400, '9' * 5000: 1}, 5),
                         {0: 5.0, 1: -5.0, 2: 1.23, 3: 5.0})                                # never more than 5 s, two decimals, no crash
        for nothing in (None, [1, 2], 'nope', 7):
            self.assertEqual(review.clean_shifts(nothing, 5), {})

    def test_a_move_that_fits_is_made_as_asked(self):
        self.assertEqual(review.effective_shifts(self.STARTS, {'2': 1.5, '3': -0.5}, 20.0), {2: 1.5, 3: -0.5})
        self.assertEqual(review.effective_shifts(self.STARTS, {'0': 0.0, '1': 0.004}, 20.0), {})         # nothing moved is not a move
        for nothing in (None, {}, 'nope'):
            self.assertEqual(review.effective_shifts(self.STARTS, nothing, 20.0), {})
        self.assertEqual(review.effective_shifts([], {'0': 1}, 20.0), {})

    def test_a_line_stops_before_its_neighbours(self):
        self.assertEqual(review.effective_shifts(self.STARTS, {'2': 5}, 20.0), {2: 3.9})       # 12.0 (the next line) - 0.1 - 8.0
        self.assertEqual(review.effective_shifts(self.STARTS, {'2': -5}, 20.0), {2: -3.9})     # 4.0 (the line before) + 0.1 - 8.0

    def test_lines_that_move_together_make_room_for_each_other(self):
        self.assertEqual(review.effective_shifts(self.STARTS, {'1': 3, '2': 3}, 20.0), {1: 3.0, 2: 3.0})
        eff = review.effective_shifts(self.STARTS, {'1': 4.5, '2': -2.0}, 20.0)                 # they come towards each other
        at = [s + eff.get(i, 0.0) for i, s in enumerate(self.STARTS)]
        self.assertGreaterEqual(at[2] - at[1], review.MIN_GAP - 1e-9)
        self.assertEqual(eff[2], -2.0)
        self.assertAlmostEqual(eff[1], 1.9)

    def test_the_last_line_stays_inside_the_video(self):
        self.assertEqual(review.effective_shifts(self.STARTS, {'4': 5}, 20.0), {4: 3.7})       # 20.0 - 0.3 - 16.0
        self.assertEqual(review.effective_shifts(self.STARTS, {'4': 5}, 0), {4: 5.0})          # the length of the video is not known: no end to stop at

    def test_the_first_line_cannot_start_before_the_video(self):
        self.assertEqual(review.effective_shifts(self.STARTS, {'0': -3}, 20.0), {})
        self.assertEqual(review.effective_shifts([1.0, 5.0], {'0': -3}, 20.0), {0: -1.0})

    def test_a_line_that_is_already_too_close_is_not_pushed_around(self):
        close = [0.0, 0.05, 8.0]                                       # the second line starts 0.05 s after the first: closer than the gap
        self.assertEqual(review.effective_shifts(close, {'1': -1}, 20.0), {})                  # it stays where it is (it is not pushed up to 0.1 s)
        self.assertEqual(review.effective_shifts(close, {'1': 1}, 20.0), {1: 1.0})

    def test_whatever_is_asked_the_order_and_the_video_hold(self):
        """Random situations (fixed seed): lines nobody moved stay exactly where they are, moved lines keep their order (at least MIN_GAP
        between neighbouring starts, unless they were closer than that to begin with), nothing starts before 0 or too near the end of
        the video, and asking again for what was granted changes nothing."""
        rnd = random.Random(20261020)
        for case in range(4000):
            n = rnd.randint(1, 12)
            tight = rnd.random() < 0.3
            digits = rnd.choice([2, 3])                                # Whisper times come with 2 or 3 decimals
            t, starts = 0.0, []
            for _ in range(n):
                t += rnd.choice([0.0, 0.03, 0.08, 0.5, 1.0, 2.5, 4.0]) if tight else rnd.uniform(0.5, 6.0)
                starts.append(round(t, digits))
            total = round(starts[-1] + rnd.choice([0.1, 0.2, 0.5, 2.0, 10.0]), digits)
            raw = {str(i): rnd.choice([rnd.uniform(-8, 8), -5, -2.5, -1, -0.1, 0.1, 1, 2.5, 5, 9]) for i in range(n) if rnd.random() < 0.5}
            if rnd.random() < 0.1:
                raw.update({'99': 1.0, 'x': 2, '0': float('nan')})
            eff = review.effective_shifts(starts, raw, total)
            segs = [{'start': s, 'end': s + 1.0, 'text': 't'} for s in starts]
            out = review.shifted_segments(segs, raw, total)
            at = [o['start'] for o in out]
            ctx = (case, starts, total, raw, eff)
            for i in range(n):
                if i in eff:
                    self.assertAlmostEqual(at[i], starts[i] + eff[i], delta=0.0006, msg=ctx)
                else:
                    self.assertIs(out[i], segs[i], ctx)
                self.assertLessEqual(abs(eff.get(i, 0.0)), review.MAX_SHIFT + 1e-9, ctx)
                self.assertGreaterEqual(at[i], -1e-9, ctx)
            if eff.get(n - 1, 0.0) > 0:
                self.assertLessEqual(at[n - 1], total - review.END_ROOM + 1e-6, ctx)
            for i in range(1, n):
                if i in eff or i - 1 in eff:
                    self.assertGreaterEqual(at[i] - at[i - 1], min(review.MIN_GAP, starts[i] - starts[i - 1]) - 1e-6, ctx)
            self.assertEqual(review.effective_shifts(starts, {str(k): v for k, v in eff.items()}, total), eff, ctx)


class ShiftedSegmentsTests(unittest.TestCase):
    """shifted_segments(): the Whisper lines with the moved ones moved - what the voice, the room of each line and the subtitles are built from."""

    @staticmethod
    def lines():
        return [{'start': i * 4.0, 'end': i * 4.0 + 2.5, 'text': f't{i}', 'speech_start': i * 4.0 + 0.2, 'speech_end': i * 4.0 + 2.3} for i in range(5)]

    def test_without_a_move_it_is_the_very_same_list(self):
        segs = self.lines()
        for raw in (None, {}, {'0': 0.001, '77': 3}, 'nope'):
            self.assertIs(review.shifted_segments(segs, raw, 20.0), segs)

    def test_a_moved_line_moves_as_a_whole_and_nothing_else_changes(self):
        segs = self.lines()
        before = json.loads(json.dumps(segs))
        out = review.shifted_segments(segs, {'2': 1.5}, 20.0)
        self.assertEqual(segs, before)                                 # the saved lines are never changed
        self.assertEqual([i for i, (a, b) in enumerate(zip(segs, out)) if a is not b], [2])      # every other line is the very same object
        self.assertEqual({k: out[2][k] for k in ('start', 'end', 'speech_start', 'speech_end')},
                         {'start': 9.5, 'end': 12.0, 'speech_start': 9.7, 'speech_end': 11.8})
        self.assertEqual(out[2]['text'], 't2')
        plain = [{'start': 1.0, 'end': 3.0, 'text': 'a'}, {'start': 5.0, 'end': 7.0, 'text': 'b'}]
        self.assertEqual(review.shifted_segments(plain, {'1': -1}, 20.0)[1], {'start': 4.0, 'end': 6.0, 'text': 'b'})   # no speech times out of nowhere

    def test_a_moved_line_never_ends_after_the_video(self):
        out = review.shifted_segments(self.lines(), {'4': 5}, 20.0)    # allowed: 3.7 s (the line then starts 0.3 s before the end)
        self.assertEqual((out[4]['start'], out[4]['end'], out[4]['speech_end']), (19.7, 20.0, 20.0))


# ====================================================================================================== the whole flow over HTTP
@unittest.skipUnless(fastapi and shutil.which('ffmpeg'), 'FastAPI and ffmpeg are needed')
class ReviewFlowTests(AppTestBase):
    NAME = 'app_review'

    @classmethod
    def setUpClass(cls):
        super().setUpClass()
        cls.c = Client(cls.server.url)

    def setUp(self):
        super().setUp()
        self.c.post('/api/settings', data={'gemini_api_key': 'KEY-A'})

    def make(self, **form):
        """Start a job with review ON and wait until it waits for the person."""
        form.setdefault('render_speed', 'ultrafast')
        form.setdefault('review', '1')
        r = self.c.upload(self.video, **form)
        self.assertEqual(r.status_code, 200, r.text)
        jid = r.json()['id']
        self.addCleanup(self.drop, jid)
        return jid

    def drop(self, jid):
        try:
            if self.c.get(f'/api/jobs/{jid}').json().get('status') in ('review', 'paused', 'queued', 'processing'):
                self.c.post(f'/api/jobs/{jid}/cancel')
            end = time.time() + 8
            while self.app.RUNNER.running(jid) and time.time() < end:
                time.sleep(0.05)
            self.c.delete(f'/api/jobs/{jid}')
        except Exception:
            pass

    def waiting(self, jid):
        j = self.c.wait_job(jid, ('review', 'failed', 'completed', 'paused'))
        self.assertEqual(j['status'], 'review', j.get('error') or j.get('detail'))
        end = time.time() + 5
        while self.app.RUNNER.running(jid) and time.time() < end:
            time.sleep(0.05)
        return self.c.get(f'/api/jobs/{jid}').json()

    # ---------------------------------------------------------------- voice jobs
    def test_voice_job_waits_and_speaks_the_edited_text_only_after_the_button(self):
        jid = self.make()
        j = self.waiting(jid)
        self.assertFalse(j['running'])                                         # nothing runs while the person reads
        self.assertTrue(j['can_cancel'])
        self.assertFalse(j['can_resume'])
        self.assertEqual(self.c.get('/api/jobs').json()['jobs'][0]['status'], 'review')
        spoken = [c[0] for c in FakeEdge.calls]
        self.assertTrue(all(t in V.CAL_SENTENCES for t in spoken), spoken)     # only the 3 calibration sentences: no line was spoken yet
        self.assertEqual(sorted(self.whisper.calls), [0, 1, 2])
        asked = self.mock.state.count(action='generateContent')                # what writing the Burmese text cost
        self.assertGreaterEqual(asked, 3)

        d = self.c.get(f'/api/jobs/{jid}/review').json()
        self.assertEqual(len(d['lines']), TOTAL_LINES)
        self.assertTrue(d['make_voice'])
        self.assertTrue(all(x['my'].strip() for x in d['lines']))
        self.assertEqual(d['lines'][1]['src'], 'source line 0-1')
        self.assertEqual((d['lines'][1]['a'], d['lines'][1]['nx']), (4.0, 8.0))
        self.assertEqual(d['video_url'], f'/api/files/{jid}/review-video')
        self.assertEqual(d['size'], [320, 240])
        self.assertAlmostEqual(d['duration'], VIDEO_SECONDS, delta=1)
        self.assertGreater(d['sps'], 1)
        self.assertEqual(d['voice_name'], V.resolve('thiha')['name'])
        self.assertTrue(d['font']['url'])
        self.assertTrue(d['subs_ok'])

        edited = 'ဒီစာကို လူက ပြင်ထားတာပါ'
        long_one = 'မင်္ဂလာပါ ' * 14                                           # far too long for its slot: Gemini must NOT shorten it
        r = self.c.post(f'/api/jobs/{jid}/review', json={'edits': {'3': edited, '99': 'x'}, 'settings': {'subs': False}})
        self.assertEqual(r.json(), {'ok': True, 'changed': [3]})
        self.assertEqual(self.c.get(f'/api/jobs/{jid}/review').json()['lines'][3]['my'], edited)       # kept on the server
        self.assertEqual(self.c.get(f'/api/jobs/{jid}').json()['status'], 'review')
        self.assertEqual(self.mock.state.count(action='generateContent'), asked)                # saving an edit costs no request at all

        r = self.c.post(f'/api/jobs/{jid}/review/continue', json={'edits': {'5': '', '7': long_one.strip()}, 'settings': {'subs': False}})
        self.assertEqual(r.status_code, 200, r.text)
        j = self.c.wait_job(jid, ('completed', 'failed'))
        self.assertEqual(j['status'], 'completed', j.get('error'))
        spoken = [c[0] for c in FakeEdge.calls]
        self.assertEqual(spoken.count(edited), 1)                              # spoken once, exactly as typed
        self.assertIn(long_one.strip(), spoken)                                # the edited long line was not shortened behind the person's back
        self.assertNotIn('', spoken)
        text = self.c.get(f'/api/files/{jid}/burmese.txt').text.split('\n')
        self.assertIn(edited, text)
        self.assertIn(long_one.strip(), text)
        self.assertEqual(len(text), TOTAL_LINES - 1)                           # the emptied line 5 is neither spoken nor shown
        self.assertEqual(j['stats']['lines'], TOTAL_LINES)
        self.assertEqual(j['stats']['shortened'], 0)
        self.assertEqual(j['params']['make_subs'], False)
        self.assertEqual(self.c.get(j['output_url']).status_code, 200)

    def test_voice_and_subtitles_together_with_the_look(self):
        jid = self.make(make_subtitles='1', blur_original='1', blur_top='70', blur_height='18')
        self.waiting(jid)
        d = self.c.get(f'/api/jobs/{jid}/review').json()
        self.assertTrue(d['settings']['subs'] and d['settings']['blur']['on'])
        r = self.c.post(f'/api/jobs/{jid}/review/continue', json={'edits': {}, 'settings': {'subs': True, 'blur': BLUR, 'look': LOOK}})
        self.assertEqual(r.status_code, 200, r.text)
        j = self.c.wait_job(jid, ('completed', 'failed'))
        self.assertEqual(j['status'], 'completed', j.get('error'))
        self.assertEqual(j['params']['look']['font'], 130.0)
        self.assertEqual(j['params']['blur']['strength'], 200.0)
        self.assertTrue(j['srt_url'])
        srt = self.c.get(j['srt_url']).text
        self.assertGreaterEqual(srt_start(srt, 0), 1.5)                        # shifted 1.5 s later
        p = subprocess.run(['ffprobe', '-v', 'error', '-show_entries', 'stream=codec_type', '-of', 'csv=p=0', '-'], input=self.c.get(j['output_url']).content,
                           capture_output=True)
        self.assertEqual(sorted(p.stdout.decode().split()), ['audio', 'video'])

    def test_switching_the_subtitles_on_for_a_voice_only_job(self):
        jid = self.make()                                                      # voice only: no subtitles were asked for
        self.waiting(jid)
        r = self.c.post(f'/api/jobs/{jid}/review/continue', json={'edits': {}, 'settings': {'subs': True, 'blur': {'on': False}, 'look': {'offset': -0.5}}})
        self.assertEqual(r.status_code, 200, r.text)
        j = self.c.wait_job(jid, ('completed', 'failed'))
        self.assertEqual(j['status'], 'completed', j.get('error'))
        self.assertTrue(j['params']['make_subs'])
        self.assertIsNone(j['params']['blur'])
        self.assertTrue(j['srt_url'])

    # ---------------------------------------------------------------- subtitle-only jobs
    def test_subtitle_only_job_needs_no_voice_and_follows_the_look_and_offset(self):
        jid = self.make(make_voice='0', make_subtitles='1', blur_original='1', blur_top='70', blur_height='20')
        self.waiting(jid)
        self.assertEqual(FakeEdge.calls, [])                                   # no voice at all
        d = self.c.get(f'/api/jobs/{jid}/review').json()
        self.assertFalse(d['make_voice'])
        self.assertEqual((d['settings']['subs'], d['settings']['blur']['on'], d['settings']['blur']['top'], d['settings']['blur']['height']),
                         (True, True, 70.0, 20.0))
        # a subtitle-only job cannot switch its only output off
        r = self.c.post(f'/api/jobs/{jid}/review/continue', json={'edits': {}, 'settings': {'subs': False}})
        self.assertEqual(r.status_code, 400)
        self.assertEqual(self.c.get(f'/api/jobs/{jid}').json()['status'], 'review')
        # the Gemini key is not needed any more once the text is written
        self.c.delete('/api/settings')
        r = self.c.post(f'/api/jobs/{jid}/review/continue', json={'edits': {'0': 'ပထမဆုံး စာတန်း'}, 'settings': {'subs': True, 'blur': BLUR, 'look': LOOK}})
        self.assertEqual(r.status_code, 200, r.text)
        j = self.c.wait_job(jid, ('completed', 'failed'))
        self.assertEqual(j['status'], 'completed', j.get('error'))
        srt = self.c.get(j['srt_url']).text
        self.assertAlmostEqual(srt_start(srt, 0), 1.5, delta=0.02)             # line 0 started at 0.0 -> +1.5 s
        self.assertIn('ပထမဆုံး စာတန်း', srt)
        self.assertEqual(FakeEdge.calls, [])
        self.assertTrue(j['stats']['gemini_requests'] >= 3)                    # what phase 1 used is still counted
        self.assertNotIn('အချိန်ညှိထားတဲ့', j['detail'])                          # nobody moved a line: nothing to say about it

    # ---------------------------------------------------------------- V21.2: single lines moved in time
    def test_a_moved_line_gets_its_subtitle_at_the_new_time(self):
        jid = self.make(make_voice='0', make_subtitles='1')
        self.waiting(jid)
        url = f'/api/jobs/{jid}/review'
        d = self.c.get(url).json()
        self.assertEqual(d['shift'], {'max': 5.0, 'gap': 0.1, 'room': 0.3})
        self.assertFalse(any('sh' in x for x in d['lines']))                   # nothing is moved yet
        moves = {'2': -1.0, '6': -2.0}                                         # line 2: 8.0 -> 7.0; line 6: 24.0 -> 22.0 (close to line 5, which stays at 20.0)
        r = self.c.post(url, json={'edits': {}, 'shifts': moves})              # what the page saves by itself every few seconds
        self.assertEqual(r.json(), {'ok': True, 'changed': []})
        d = self.c.get(url).json()
        self.assertEqual({x['i']: x['sh'] for x in d['lines'] if 'sh' in x}, {2: -1.0, 6: -2.0})
        self.assertEqual((d['lines'][2]['a'], d['lines'][2]['b'], d['lines'][2]['nx']), (8.0, 10.5, 12.0))   # the video's own times stay as they were

        r = self.c.post(url + '/continue', json={'edits': {}, 'settings': {'subs': True}, 'shifts': moves})
        self.assertEqual(r.status_code, 200, r.text)
        j = self.c.wait_job(jid, ('completed', 'failed'))
        self.assertEqual(j['status'], 'completed', j.get('error'))
        self.assertIn('အချိန်ညှိထားတဲ့ စာကြောင်း 2', j['detail'])
        cues = srt_cues(self.c.get(j['srt_url']).text)
        self.assertEqual(len(cues), TOTAL_LINES)
        at = lambda i: (round(cues[i][0], 2), round(cues[i][1], 2))            # noqa: E731
        # a subtitle shows from 0.05 s before the line to 0.2 s after it (and at least 0.8 s)
        self.assertEqual(at(0), (0.0, 2.7))
        self.assertEqual(at(1), (3.95, 6.7))                                   # the line before the moved one is where it was
        self.assertEqual(at(2), (6.95, 9.7))                                   # 7.0 - 0.05 .. 7.0 + 2.5 + 0.2
        self.assertEqual(at(3), (11.95, 14.7))                                 # the line after it too
        self.assertEqual(at(5), (19.95, 21.93))                                # cut off 0.02 s before the moved line 6, so the two never overlap
        self.assertEqual(at(6), (21.95, 24.7))
        self.assertEqual(at(7)[0], 27.95)
        self.assertTrue(all(a[1] <= b[0] for a, b in zip(cues, cues[1:])))     # still in order, never on top of each other
        segs = json.loads((Path(self.app.STORE.dir(jid)) / 'out' / 'segments.json').read_text(encoding='utf-8'))
        self.assertEqual([round(x['start'], 2) for x in segs[1:4]], [3.95, 6.95, 11.95])
        self.assertEqual(FakeEdge.calls, [])

    def test_a_moved_line_is_spoken_and_shown_at_the_new_time(self):
        jid = self.make(make_subtitles='1')                                    # voice and subtitles
        self.waiting(jid)
        moves = {'1': -1.0, '3': 1.0}                                          # line 1: 4.0 -> 3.0; line 3: 12.0 -> 13.0
        r = self.c.post(f'/api/jobs/{jid}/review/continue', json={'edits': {}, 'settings': {'subs': True}, 'shifts': moves})
        self.assertEqual(r.status_code, 200, r.text)
        j = self.c.wait_job(jid, ('completed', 'failed'))
        self.assertEqual(j['status'], 'completed', j.get('error'))
        self.assertIn('အချိန်ညှိထားတဲ့ စာကြောင်း 2', j['detail'])
        self.assertEqual(j['stats']['spoken'], TOTAL_LINES)
        # the subtitles follow the voice, and the voice starts at the new time of the line
        cues = srt_cues(self.c.get(j['srt_url']).text)
        self.assertEqual([round(c[0], 2) for c in cues[:5]], [0.0, 3.0, 8.0, 13.0, 16.0])
        segs = json.loads((Path(self.app.STORE.dir(jid)) / 'out' / 'segments.json').read_text(encoding='utf-8'))
        self.assertEqual([round(x['start'], 2) for x in segs[:5]], [0.0, 3.0, 8.0, 13.0, 16.0])
        # ... and in the sound itself (the fake voice is a 220 Hz tone, 2 s long for these lines; its silence is trimmed to 0.03 s before it)
        film = Path(self.tmp) / f'{jid}.mp4'
        film.write_bytes(self.c.get(j['output_url']).content)
        audio = decode_mono(film)

        def heard(a, b):
            x = audio[int(a * 24000):int(b * 24000)]
            return float(np.sqrt(np.mean(x ** 2)))
        for start in (3.0, 13.0):
            self.assertGreater(heard(start + 0.3, start + 1.3), 0.03, start)                  # spoken at the new time
            self.assertAlmostEqual(dominant_hz(audio[int((start + 0.3) * 24000):int((start + 1.3) * 24000)]), 220, delta=25)
        self.assertLess(heard(5.3, 5.95), 0.01)                                               # line 1 is gone from where it used to be (4.0 - 6.1)
        self.assertLess(heard(12.2, 12.9), 0.01)                                              # and line 3 from where it used to be (12.0 - 14.1)
        self.assertGreater(heard(8.3, 9.3), 0.03)                                             # a line nobody moved is where it was

    def test_what_the_page_says_about_moved_lines_is_checked(self):
        jid = self.make(make_voice='0', make_subtitles='1')
        self.waiting(jid)
        url = f'/api/jobs/{jid}/review'
        moved = lambda: {x['i']: x['sh'] for x in self.c.get(url).json()['lines'] if 'sh' in x}      # noqa: E731
        for bad in ('nope', [1, 2], 5):
            self.assertEqual(self.c.post(url, json={'shifts': bad}).status_code, 400, bad)
            self.assertEqual(self.c.post(url + '/continue', json={'shifts': bad}).status_code, 400, bad)
        self.assertEqual(self.c.get(f'/api/jobs/{jid}').json()['status'], 'review')            # a refused request changes nothing
        # rubbish inside the map is dropped, a move that is too long is shortened to what fits (line 2 stops 0.1 s before line 3)
        r = self.c.post(url, json={'shifts': {'abc': 1, '999': 2, '1': 'x', '2': 99, '5': 0.001}})
        self.assertEqual(r.status_code, 200, r.text)
        self.assertEqual(moved(), {2: 3.9})
        # no "shifts" (or null) says nothing about the moves: they stay. An empty map takes every move back.
        self.assertEqual(self.c.post(url, json={'edits': {'0': 'ပြင်ထား'}}).status_code, 200)
        self.assertEqual(self.c.post(url, json={'shifts': None}).status_code, 200)
        self.assertEqual(moved(), {2: 3.9})
        self.assertEqual(self.c.post(url, json={'shifts': {}}).status_code, 200)
        self.assertEqual(moved(), {})
        # moves do not change what makes a job impossible to continue
        r = self.c.post(url + '/continue', json={'edits': {str(i): '' for i in range(TOTAL_LINES)}, 'settings': {'subs': True}, 'shifts': {'2': 1}})
        self.assertEqual(r.status_code, 400)
        self.assertEqual(self.c.get(f'/api/jobs/{jid}').json()['status'], 'review')

    # ---------------------------------------------------------------- the files, restarts, cancel
    def test_a_job_in_review_survives_a_restart_and_counts_as_unfinished(self):
        jid = self.make(make_voice='0', make_subtitles='1')
        self.waiting(jid)
        # what a restarted server finds on the disk: a copy of the jobs folder (the running server keeps its own store untouched)
        import tempfile
        root = Path(tempfile.mkdtemp(prefix='recap_restart_')) / 'jobs'
        self.addCleanup(shutil.rmtree, root.parent, True)
        shutil.copytree(self.app.STORE.root, root)
        again = J.JobStore(root)
        again.load_existing()
        self.assertEqual(again.get(jid)['status'], 'review')                   # not turned into "interrupted": it was not running
        self.assertGreaterEqual(again.count_active('local'), 1)
        self.assertIsNotNone(review.load(again.dir(jid)))
        self.assertEqual(review.payload(again.dir(jid), again.get(jid)['params'])['lines'][0]['i'], 0)
        self.assertEqual(again.cleanup({}, finished_hours=0.0001, stale_hours=72), [])        # too young to be tidied away
        again._jobs[jid]['updated'] = time.time() - 80 * 3600
        self.assertEqual(again.cleanup({}, finished_hours=48, stale_hours=72), [jid])         # nobody came back for 3 days: tidied away
        self.assertIsNone(again.get(jid))
        self.assertFalse(again.dir(jid).exists())
        self.assertEqual(self.c.get(f'/api/jobs/{jid}').json()['status'], 'review')           # the real job is not affected

    def test_cancel_in_review_throws_everything_away(self):
        jid = self.make(make_voice='0', make_subtitles='1')
        self.waiting(jid)
        self.assertEqual(self.c.post(f'/api/jobs/{jid}/cancel').json()['job']['status'], 'cancelled')
        self.assertEqual({p.name for p in Path(self.app.STORE.dir(jid)).iterdir()}, {'job.json'})
        self.assertEqual(self.c.get(f'/api/jobs/{jid}/review').status_code, 409)

    def test_the_preview_video_is_streamed_with_ranges(self):
        jid = self.make(make_voice='0', make_subtitles='1')
        self.waiting(jid)
        url = f'/api/files/{jid}/review-video'
        size = (Path(self.app.STORE.dir(jid)) / self.app.STORE.get(jid)['input']).stat().st_size
        whole = self.c.get(url)
        self.assertEqual((whole.status_code, whole.headers['content-type'], int(whole.headers['content-length'])), (200, 'video/mp4', size))
        self.assertEqual(whole.headers['accept-ranges'], 'bytes')
        self.assertNotIn('no-store', whole.headers.get('cache-control', ''))
        part = self.c.get(url, headers={'Range': 'bytes=0-99'})
        self.assertEqual((part.status_code, len(part.content)), (206, 100))
        self.assertEqual(part.headers['content-range'], f'bytes 0-99/{size}')
        self.assertEqual(part.content, whole.content[:100])
        tail = self.c.get(url, headers={'Range': 'bytes=-50'})
        self.assertEqual((tail.status_code, tail.content), (206, whole.content[-50:]))
        open_end = self.c.get(url, headers={'Range': f'bytes={size - 10}-'})
        self.assertEqual((open_end.status_code, len(open_end.content)), (206, 10))
        self.assertEqual(self.c.get(url, headers={'Range': f'bytes={size + 5}-'}).status_code, 416)
        self.assertEqual(self.c.get(url, headers={'Range': 'bytes=abc'}).status_code, 200)    # a header we do not understand: the whole file
        self.assertEqual(self.c.get(f'/api/files/{"a" * 32}/review-video').status_code, 404)
        self.assertEqual(self.c.get(f'/api/files/{jid}/job.json').status_code, 404)           # the whitelist of real downloads still holds

    def test_a_video_a_browser_cannot_play_gets_a_small_copy(self):
        mkv = Path(self.tmp) / 'odd.mkv'
        subprocess.run(['ffmpeg', '-y', '-v', 'error', '-f', 'lavfi', '-i', 'testsrc=size=320x240:rate=10', '-f', 'lavfi', '-i', 'sine=frequency=330',
                        '-t', '60', '-c:v', 'libx264', '-preset', 'ultrafast', '-pix_fmt', 'yuv420p', '-c:a', 'aac', '-shortest', str(mkv)], check=True)
        self.assertFalse(media.browser_playable(mkv))
        self.assertTrue(media.browser_playable(self.video))
        with open(mkv, 'rb') as f:
            r = self.c.post('/api/jobs', data={'voice': 'thiha', 'make_voice': '0', 'make_subtitles': '1', 'review': '1', 'render_speed': 'ultrafast'},
                            files={'video': ('odd.mkv', f, 'video/x-matroska')})
        self.assertEqual(r.status_code, 200, r.text)
        jid = r.json()['id']
        self.addCleanup(self.drop, jid)
        self.waiting(jid)
        self.assertTrue((Path(self.app.STORE.dir(jid)) / 'work' / 'preview.mp4').is_file())
        d = self.c.get(f'/api/jobs/{jid}/review').json()
        self.assertEqual(d['preview'], 'copy')
        got = self.c.get(d['video_url'], headers={'Range': 'bytes=0-7'})
        self.assertEqual(got.status_code, 206)
        self.assertEqual(got.content[4:8], b'ftyp')                              # a real MP4

    def test_one_real_picture_of_the_finished_look(self):
        jid = self.make(make_voice='0', make_subtitles='1')
        self.waiting(jid)
        look1 = {'subs': True, 'blur': BLUR, 'look': LOOK}
        a = self.c.post(f'/api/jobs/{jid}/review/frame', json={'t': 3.0, 'text': 'မင်္ဂလာပါ ဒီနေ့ ရာသီဥတု ကောင်းတယ်', 'settings': look1})
        self.assertEqual((a.status_code, a.headers['content-type']), (200, 'image/jpeg'), a.text[:200])
        self.assertEqual(a.content[:2], b'\xff\xd8')
        b = self.c.post(f'/api/jobs/{jid}/review/frame', json={'t': 3.0, 'text': 'မင်္ဂလာပါ ဒီနေ့ ရာသီဥတု ကောင်းတယ်', 'settings': {'subs': True, 'blur': {'on': False}, 'look': {'font': 200}}})
        self.assertEqual(b.status_code, 200)
        self.assertNotEqual(a.content, b.content)
        c = self.c.post(f'/api/jobs/{jid}/review/frame', json={'t': 9999, 'text': '', 'settings': None})          # nonsense is tidied, not fatal
        self.assertEqual(c.status_code, 200, c.text[:200])
        self.assertEqual(list((Path(self.app.STORE.dir(jid)) / 'work' / 'frame').glob('*.jpg')), [])             # no picture files are left behind
        self.assertEqual(self.c.post(f'/api/jobs/{jid}/review/frame', data='nope').status_code in (400, 422), True)

    def test_what_the_browser_sends_is_checked(self):
        jid = self.make(make_voice='0', make_subtitles='1')
        self.waiting(jid)
        url = f'/api/jobs/{jid}/review'
        self.assertIn(self.c.post(url, json=[1, 2]).status_code, (400, 422))
        self.assertEqual(self.c.post(url, json={'edits': 'nope'}).status_code, 400)
        self.assertEqual(self.c.post(url, json={'edits': {'0': 'a' * 5000}}).status_code, 200)
        d = self.c.get(url).json()
        self.assertEqual(len(d['lines'][0]['my']), review.MAX_LINE)
        r = self.c.post(url, json={'edits': {}, 'settings': {'look': {'font': 'abc', 'colour': 'javascript:1'}, 'blur': {'height': 999, 'top': 'zzz'}}})
        self.assertEqual(r.status_code, 200)
        s = self.c.get(url).json()['settings']
        self.assertEqual((s['look']['font'], s['look']['colour'], s['blur']['height']), (100.0, None, 60.0))
        # every line emptied: nothing to make
        empty = {str(i): '' for i in range(TOTAL_LINES)}
        r = self.c.post(url + '/continue', json={'edits': empty, 'settings': {'subs': True}})
        self.assertEqual(r.status_code, 400)
        self.assertEqual(self.c.get(f'/api/jobs/{jid}').json()['status'], 'review')

    def test_nothing_of_the_review_works_for_a_job_that_is_not_waiting(self):
        r = self.c.upload(self.video, render_speed='ultrafast')                # an ordinary job: review is off
        jid = r.json()['id']
        self.addCleanup(self.drop, jid)
        j = self.c.wait_job(jid, ('completed', 'failed', 'review'))
        self.assertEqual(j['status'], 'completed', j.get('error'))             # the old behaviour is untouched: no stop on the way
        self.assertFalse(j['params']['review'])
        for method, path in (('get', f'/api/jobs/{jid}/review'), ('post', f'/api/jobs/{jid}/review'), ('post', f'/api/jobs/{jid}/review/continue'),
                             ('post', f'/api/jobs/{jid}/review/frame'), ('get', f'/api/files/{jid}/review-video')):
            r = getattr(self.c, method)(path, **({'json': {}} if method == 'post' else {}))
            self.assertEqual(r.status_code, 409, (path, r.status_code))
        self.assertEqual(self.c.get(f'/api/jobs/{"b" * 32}/review').status_code, 404)

    def test_review_font_is_served_and_cacheable(self):
        r = self.c.get('/api/review-font')
        self.assertEqual(r.status_code, 200)
        self.assertIn(r.headers['content-type'], ('font/ttf', 'font/otf'))
        self.assertNotIn('no-store', r.headers.get('cache-control', ''))
        self.assertIn(r.content[:4], (b'\x00\x01\x00\x00', b'OTTO', b'true'))

    # ---------------------------------------------------------------- phase 2 is as robust as the first phase
    def test_phase_two_can_stop_and_continue_without_repeating_anything(self):
        """The shorten step of phase 2 fails once (a Gemini error): the job stops as "failed" with all finished work kept, and
        "continue" picks up the review again from disk (the edited text is still there, nothing is written again)."""
        base = unique_generate(long_every=3)
        state = {'fail': False}

        def gen(system, user):
            if state['fail'] and 'timing editor' in (system or ''):
                return 400, M.err(400, 'Request contains an invalid argument.', 'INVALID_ARGUMENT')
            return base(system, user)
        self.mock.state.generate = gen
        jid = self.make()
        self.waiting(jid)
        asked = len([q for q in self.mock.state.requests if q['action'] == 'generateContent'])
        edited = 'ဒီစာကို လူက ပြင်ထားတာပါ'
        state['fail'] = True
        self.assertEqual(self.c.post(f'/api/jobs/{jid}/review/continue', json={'edits': {'0': edited}, 'settings': {'subs': False}}).status_code, 200)
        j = self.c.wait_job(jid, ('failed', 'completed'))
        self.assertEqual(j['status'], 'failed')
        end = time.time() + 5
        while self.app.RUNNER.running(jid) and time.time() < end:
            time.sleep(0.05)
        self.assertTrue(self.c.get(f'/api/jobs/{jid}').json()['can_resume'])
        state['fail'] = False
        self.assertEqual(self.c.post(f'/api/jobs/{jid}/resume').status_code, 200)
        j = self.c.wait_job(jid, ('completed', 'failed'))
        self.assertEqual(j['status'], 'completed', j.get('error'))
        self.assertEqual(sorted(self.whisper.calls), [0, 1, 2])                # Whisper ran once for the whole job
        self.assertIn(edited, self.c.get(f'/api/files/{jid}/burmese.txt').text)
        writes = [q for q in self.mock.state.requests if q['action'] == 'generateContent']
        self.assertEqual(len([q for q in writes[:asked]]), asked)              # the text was written in phase 1 only


if __name__ == '__main__':
    unittest.main()
