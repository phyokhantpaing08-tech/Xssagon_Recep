import os, sys, unittest
import numpy as np
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', 'backend'))
import timing as T


class SyllableTests(unittest.TestCase):
    def test_known_words(self):
        cases = {'မင်္ဂလာပါ': 4, 'ကျွန်တော်': 2, 'ပြောပြမယ်': 3, 'ဗုဒ္ဓ': 2, 'ပစ္စည်း': 2, 'သင်္ကြန်': 2, '': 0}
        for word, expect in cases.items():
            self.assertEqual(T.syllables(word), expect, word)

    def test_sentence(self):
        # "သူက အိမ်ကို ပြန်လာပြီး ညစာကို ချက်ပြုတ်ခဲ့တယ်။" = သူ က အိမ် ကို ပြန် လာ ပြီး ည စာ ကို ချက် ပြုတ် ခဲ့ တယ်
        self.assertEqual(T.syllables('သူက အိမ်ကို ပြန်လာပြီး ညစာကို ချက်ပြုတ်ခဲ့တယ်။'), 14)

    def test_pauses(self):
        self.assertAlmostEqual(T.pause_seconds('က၊ ခ။'), T.COMMA_PAUSE + T.STOP_PAUSE)
        self.assertFalse(T.has_speech('။ ၊ ...'))
        self.assertTrue(T.has_speech('ဟုတ်တယ်'))


class CalibrationTests(unittest.TestCase):
    def test_learns_rate(self):
        c = T.Calibration(prior_sps=5.0)
        text = 'သူက အိမ်ကို ပြန်လာပြီး ညစာကို ချက်ပြုတ်ခဲ့တယ်။'          # 14 syllables + one stop pause
        for _ in range(8):
            c.update(text, 14 / 4.0 + T.STOP_PAUSE)                      # a voice that speaks 4 syllables / second
        self.assertLess(abs(c.sps - 4.0), 0.35)
        self.assertGreater(c.max_syllables(3.0), 6)
        self.assertLess(c.max_syllables(3.0), 12)


class SlotTests(unittest.TestCase):
    def test_budget_uses_gap_to_next_line_but_is_capped(self):
        anchors, ends = [0.0, 3.0, 40.0], [2.0, 4.0, 41.0]
        b = T.slot_budgets(anchors, ends, 60.0)
        self.assertAlmostEqual(b[0], min(3.0 - T.GAP, max(2.0 * 1.8, 5.0)), places=2)   # room is 2.88, cap is 5
        self.assertLessEqual(b[1], 4.0 + 1e-9)                                           # cap = max(1.8, 4.0) = 4.0 < room 36.9
        self.assertGreaterEqual(min(b), 0.6)
        self.assertLessEqual(b[2], 60.0 - 40.0)

    def test_overlapping_whisper_segments_never_overlap_budget(self):
        b = T.slot_budgets([0.0, 0.5], [3.0, 2.0], 10.0)
        self.assertLessEqual(b[0], 0.6 + 1e-9 if 0.5 - T.GAP < 0.6 else 0.5 - T.GAP)


class ScheduleTests(unittest.TestCase):
    def test_no_overlap_never_early_never_cut(self):
        anchors = [0.0, 2.0, 4.0, 4.5, 10.0]
        durs = [1.5, 3.0, 0.6, 1.0, 2.0]
        out = T.schedule(durs, anchors, 20.0)
        prev_end = -1
        for a, d, s in zip(anchors, durs, out):
            start, end, speed = s
            self.assertGreaterEqual(start, a - 1e-9)             # never earlier than the original line
            self.assertGreaterEqual(start, prev_end + T.GAP - 1e-9 if prev_end > 0 else 0)
            self.assertAlmostEqual(end - start, d / speed, places=6)
            self.assertGreaterEqual(speed, 1.0)
            self.assertLessEqual(speed, T.MAX_SPEEDUP + 1e-9)
            prev_end = end

    def test_lag_recovers_in_pauses(self):
        anchors = [0.0, 2.0, 12.0]
        durs = [2.7, 1.0, 1.0]                                    # first line overruns by 0.7 s (within MAX_END_LAG), then a long pause
        out = T.schedule(durs, anchors, 30.0)
        self.assertEqual(out[0][2], 1.0)                          # not sped up
        self.assertAlmostEqual(out[1][0], 2.7 + T.GAP, places=6)  # pushed a little
        self.assertAlmostEqual(out[2][0], 12.0, places=6)         # back on time after the pause

    def test_speedup_only_when_lag_would_grow(self):
        anchors = [0.0, 1.0, 2.0]
        durs = [3.0, 3.0, 3.0]                                    # hopeless: everything overruns
        out = T.schedule(durs, anchors, 30.0)
        self.assertTrue(all(o[2] > 1.0 for o in out[:2]))
        self.assertTrue(all(o[2] <= T.MAX_SPEEDUP + 1e-9 for o in out))

    def test_empty_slots_skipped(self):
        out = T.schedule([1.0, 0, 1.0], [0.0, 1.0, 2.0], 10.0)
        self.assertIsNone(out[1])
        self.assertIsNotNone(out[0]); self.assertIsNotNone(out[2])


class AudioTests(unittest.TestCase):
    def tone(self, seconds, sr=T.SR, amp=0.3):
        t = np.arange(int(seconds * sr)) / sr
        return (amp * np.sin(2 * np.pi * 220 * t)).astype(np.float32)

    def test_trim_silence(self):
        sr = T.SR
        x = np.concatenate([np.zeros(int(0.4 * sr), np.float32), self.tone(1.0), np.zeros(int(0.5 * sr), np.float32)])
        y = T.trim_silence(x, sr)
        self.assertLess(abs(len(y) / sr - (1.0 + 0.03 + 0.06)), 0.03)
        self.assertEqual(len(T.trim_silence(np.zeros(1000, np.float32))), 0)

    def test_fade_and_normalize(self):
        x = self.tone(1.0, amp=0.02)
        y = T.normalize_rms(x)
        self.assertGreater(float(np.abs(y).max()), float(np.abs(x).max()) * 2)
        z = T.fade(y)
        self.assertAlmostEqual(float(z[0]), 0.0, places=5)
        self.assertAlmostEqual(float(z[-1]), 0.0, places=3)
        self.assertLessEqual(float(np.abs(T.normalize_rms(self.tone(1.0, amp=0.9))).max()), 0.951)

    def test_mix_places_clips(self):
        a, b = self.tone(0.5), self.tone(0.5)
        m = T.mix([(a, 1.0), (b, 3.0)], 5.0)
        sr = T.SR
        self.assertEqual(len(m), 5 * sr)
        self.assertEqual(float(np.abs(m[:int(0.99 * sr)]).max()), 0.0)
        self.assertGreater(float(np.abs(m[int(1.1 * sr):int(1.4 * sr)]).max()), 0.1)
        self.assertEqual(float(np.abs(m[int(2.0 * sr):int(2.9 * sr)]).max()), 0.0)
        self.assertGreater(float(np.abs(m[int(3.1 * sr):int(3.4 * sr)]).max()), 0.1)
        self.assertEqual(len(T.mix([(a, 4.9)], 5.0)), int(round(4.9 * sr)) + len(a))      # a late clip extends the track

    def test_wav_roundtrip_and_stretch(self):
        import tempfile, shutil
        ff = shutil.which('ffmpeg')
        x = self.tone(1.0)
        with tempfile.TemporaryDirectory() as d:
            p = os.path.join(d, 'a.wav')
            T.write_wav(p, x)
            y, sr = T.read_wav(p)
            self.assertEqual(sr, T.SR)
            self.assertEqual(len(y), len(x))
            self.assertLess(float(np.abs(y - x).max()), 1e-3)
            if ff:
                z = T.time_stretch(ff, x, T.SR, 1.25)
                self.assertLess(abs(len(z) / T.SR - 0.8), 0.06)
                self.assertEqual(len(T.decode_audio(ff, p)), len(x))
                self.assertEqual(len(T.time_stretch(ff, x, T.SR, 1.0)), len(x))

    def test_resample(self):
        x = self.tone(1.0, sr=16000)
        y = T.resample(x, 16000, 24000)
        self.assertEqual(len(y), 24000)


if __name__ == '__main__':
    unittest.main()


class RoomAndStreamingMixTests(unittest.TestCase):
    def test_slot_rooms(self):
        rooms = T.slot_rooms([0.0, 2.0, 2.2, 10.0], 12.0)
        self.assertAlmostEqual(rooms[0], 2.0 - T.GAP)
        self.assertAlmostEqual(rooms[1], 0.5)                 # never below 0.5 s
        self.assertAlmostEqual(rooms[2], 10.0 - 2.2 - T.GAP)
        self.assertAlmostEqual(rooms[3], 12.0 - 10.0 - 0.05)   # the last line may run to the end of the video

    def test_wav_seconds_reads_only_the_header(self):
        import tempfile
        with tempfile.TemporaryDirectory() as d:
            p = os.path.join(d, 'a.wav')
            T.write_wav(p, np.zeros(T.SR * 3 // 2, dtype=np.float32))
            self.assertAlmostEqual(T.wav_seconds(p), 1.5, places=3)

    def test_streaming_mix_equals_in_memory_mix_and_crosses_windows(self):
        import tempfile
        rng = np.random.default_rng(1)
        clips = {k: (rng.uniform(-0.3, 0.3, int(T.SR * d))).astype(np.float32) for k, d in {'a': 2.0, 'b': 3.5, 'c': 1.0, 'd': 4.0}.items()}
        starts = {'a': 0.5, 'b': 3.0, 'c': 9.2, 'd': 9.8}      # b crosses the 5 s window border, c and d are in the last window
        placements = [(starts[k], starts[k] + len(clips[k]) / T.SR, k) for k in clips]
        loads = []

        def load(k):
            loads.append(k)
            return clips[k]
        with tempfile.TemporaryDirectory() as d:
            p = os.path.join(d, 'mix.wav')
            total = T.mix_to_wav(p, 14.0, placements, load, window_seconds=5.0)
            self.assertAlmostEqual(total, 14.0)
            got, sr = T.read_wav(p)
        self.assertEqual(sr, T.SR)
        self.assertEqual(len(got), 14 * T.SR)
        want = T.mix([(clips[k], starts[k]) for k in clips], 14.0)
        self.assertLess(float(np.abs(got - want[:len(got)]).max()), 2.0 / 32767)   # only 16-bit rounding differs
        self.assertGreaterEqual(loads.count('b'), 2)                                 # straddles two windows
        self.assertLess(loads.count('a'), 2)                                         # but a clip is not loaded for windows it misses

    def test_streaming_mix_of_nothing_is_silence_of_the_right_length(self):
        import tempfile
        with tempfile.TemporaryDirectory() as d:
            p = os.path.join(d, 'm.wav')
            T.mix_to_wav(p, 3.0, [], lambda k: None)
            x, sr = T.read_wav(p)
            self.assertEqual(len(x), 3 * T.SR)
            self.assertEqual(float(np.abs(x).max()), 0.0)
