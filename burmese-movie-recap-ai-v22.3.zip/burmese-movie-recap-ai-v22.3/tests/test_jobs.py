import json
import os
import sys
import tempfile
import threading
import time
import unittest
from pathlib import Path

sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', 'backend'))

import jobs as J  # noqa: E402


def wait_for(cond, timeout=5.0):
    end = time.time() + timeout
    while time.time() < end:
        if cond():
            return True
        time.sleep(0.01)
    return False


class StoreTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.root = Path(self.tmp.name) / 'jobs'

    def tearDown(self):
        self.tmp.cleanup()

    def test_create_update_persist_and_reload(self):
        s = J.JobStore(self.root)
        job = s.create('u1', {'voice': 'thiha'}, 'film.mp4', '.mp4')
        jid = job['id']
        s.update(jid, status='processing', progress=40, stage='Writing')
        s.update(jid, status='paused', pause={'kind': 'quota', 'message': 'x'})
        data = json.loads((self.root / jid / 'job.json').read_text(encoding='utf-8'))
        self.assertEqual(data['status'], 'paused')                      # status changes are written at once
        s2 = J.JobStore(self.root)
        s2.load_existing()
        got = s2.get(jid)
        self.assertEqual(got['status'], 'interrupted')                  # its thread died with the old server
        self.assertIsNone(got['pause'])
        self.assertEqual(got['params'], {'voice': 'thiha'})
        self.assertEqual(got['owner'], 'u1')

    def test_finished_jobs_stay_finished_on_reload(self):
        s = J.JobStore(self.root)
        a = s.create('u', {}, 'a.mp4', '.mp4')['id']
        s.update(a, status='completed')
        b = s.create('u', {}, 'b.mp4', '.mp4')['id']
        s.update(b, status='failed', error='x')
        s2 = J.JobStore(self.root)
        s2.load_existing()
        self.assertEqual(s2.get(a)['status'], 'completed')
        self.assertEqual(s2.get(b)['status'], 'failed')

    def test_a_job_that_was_working_when_the_server_stopped_is_marked_for_automatic_restart(self):
        s = J.JobStore(self.root)
        working = s.create('u', {}, 'a.mp4', '.mp4')['id']
        s.update(working, status='processing', _force=True)
        queued = s.create('u', {}, 'b.mp4', '.mp4')['id']                       # (still "queued": it had not started)
        paused = s.create('u', {}, 'c.mp4', '.mp4')['id']
        s.update(paused, status='paused', pause={'kind': 'quota', 'message': 'x'}, _force=True)
        review = s.create('u', {}, 'd.mp4', '.mp4')['id']
        s.update(review, status='review', _force=True)
        done = s.create('u', {}, 'e.mp4', '.mp4')['id']
        s.update(done, status='completed', _force=True)
        s2 = J.JobStore(self.root)
        s2.load_existing()
        self.assertEqual(sorted(s2.auto_resumable()), sorted([working, queued]))
        self.assertEqual(s2.get(working)['status'], 'interrupted')              # until the server has started it again
        self.assertEqual(s2.get(paused)['status'], 'interrupted')               # a paused job waits for a PERSON (new key / credit)
        self.assertNotIn(paused, s2.auto_resumable())
        self.assertEqual(s2.get(review)['status'], 'review')                    # waiting for the person, nothing to restart
        self.assertEqual(s2.get(done)['status'], 'completed')

    def test_a_job_that_keeps_stopping_the_server_is_given_up(self):
        s = J.JobStore(self.root)
        jid = s.create('u', {}, 'a.mp4', '.mp4')['id']
        for turn in range(J.AUTO_RESUME_TRIES + 2):
            s.update(jid, status='processing', _force=True)
            s2 = J.JobStore(self.root)
            s2.load_existing()
            if jid not in s2.auto_resumable():
                break
            s2.update(jid, auto_resume=False, auto_tries=int(s2.get(jid).get('auto_tries') or 0) + 1, _force=True)   # what the server does when it restarts the job
            s = s2
        self.assertEqual(s2.get(jid)['auto_tries'], J.AUTO_RESUME_TRIES)
        self.assertNotIn(jid, s2.auto_resumable())                              # a person decides now: it stays "interrupted"
        self.assertEqual(s2.get(jid)['status'], 'interrupted')

    def test_a_started_job_is_not_listed_again(self):
        s = J.JobStore(self.root)
        jid = s.create('u', {}, 'a.mp4', '.mp4')['id']
        s.update(jid, status='processing', _force=True)
        s2 = J.JobStore(self.root)
        s2.load_existing()
        self.assertEqual(s2.auto_resumable(), [jid])
        s2.update(jid, auto_resume=False, _force=True)
        self.assertEqual(s2.auto_resumable(), [])

    def test_private_underscore_force_is_not_stored(self):
        s = J.JobStore(self.root)
        jid = s.create('u', {}, 'a.mp4', '.mp4')['id']
        s.update(jid, status='processing', _force=True)
        self.assertNotIn('_force', s.get(jid))

    def test_list_only_my_jobs_newest_first_without_big_fields(self):
        s = J.JobStore(self.root)
        a = s.create('me', {}, 'a.mp4', '.mp4')['id']
        time.sleep(0.01)
        b = s.create('me', {}, 'b.mp4', '.mp4')['id']
        s.create('other', {}, 'c.mp4', '.mp4')
        s.update(a, source_text='x' * 1000)
        lst = s.list_for('me')
        self.assertEqual([j['id'] for j in lst], [b, a])
        self.assertNotIn('source_text', lst[0])
        self.assertEqual(s.count_active('me'), 2)
        self.assertEqual(s.count_active('nobody'), 0)

    def test_bad_ids_are_refused(self):
        s = J.JobStore(self.root)
        for bad in ('', '..', '../x', 'a/b', 'a b'):
            with self.assertRaises(ValueError):
                s.dir(bad)

    def test_cleanup_removes_old_finished_jobs_but_not_running_ones(self):
        s = J.JobStore(self.root)
        old = s.create('u', {}, 'a.mp4', '.mp4')['id']
        s.update(old, status='completed')
        run = s.create('u', {}, 'b.mp4', '.mp4')['id']
        s.update(run, status='completed')
        s._jobs[old]['updated'] = time.time() - 100 * 3600
        s._jobs[run]['updated'] = time.time() - 100 * 3600
        gone = s.cleanup({run: object()}, finished_hours=48, stale_hours=72)
        self.assertEqual(gone, [old])
        self.assertFalse((self.root / old).exists())
        self.assertTrue((self.root / run).exists())


class ControlTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.store = J.JobStore(Path(self.tmp.name))
        self.jid = self.store.create('u', {}, 'a.mp4', '.mp4')['id']
        self.store.update(self.jid, status='processing')
        self.ctl = J.JobControl(self.store, self.jid)

    def tearDown(self):
        self.tmp.cleanup()

    def test_ask_pauses_until_answered(self):
        out = []
        t = threading.Thread(target=lambda: out.append(self.ctl.ask('quota', 'credit used up', model='m')))
        t.start()
        self.assertTrue(wait_for(lambda: self.store.get(self.jid)['status'] == 'paused'))
        job = self.store.get(self.jid)
        self.assertEqual(job['pause']['kind'], 'quota')
        self.assertEqual(job['pause']['model'], 'm')
        self.assertTrue(self.ctl.answer({'key': 'NEW'}))
        t.join(3)
        self.assertEqual(out, [{'key': 'NEW'}])
        job = self.store.get(self.jid)
        self.assertEqual(job['status'], 'processing')
        self.assertIsNone(job['pause'])

    def test_answer_when_not_paused_is_refused(self):
        self.assertFalse(self.ctl.answer({'key': 'x'}))

    def test_cancel_while_paused(self):
        errs = []

        def work():
            try:
                self.ctl.ask('quota', 'x')
            except J.JobCancelled:
                errs.append('cancelled')
        t = threading.Thread(target=work)
        t.start()
        self.assertTrue(wait_for(lambda: self.ctl.paused))
        self.ctl.cancel()
        t.join(3)
        self.assertEqual(errs, ['cancelled'])

    def test_sleep_ends_early_on_cancel(self):
        errs = []

        def work():
            t0 = time.time()
            try:
                self.ctl.sleep(30, 'overloaded')
            except J.JobCancelled:
                errs.append(time.time() - t0)
        t = threading.Thread(target=work)
        t.start()
        self.assertTrue(wait_for(lambda: self.store.get(self.jid).get('wait')))
        self.assertEqual(self.store.get(self.jid)['wait']['why'], 'overloaded')
        self.ctl.cancel()
        t.join(3)
        self.assertEqual(len(errs), 1)
        self.assertLess(errs[0], 2.0)
        self.assertIsNone(self.store.get(self.jid)['wait'])

    def test_note_sets_detail(self):
        self.ctl.note('Gemini ကျပ်နေပါတယ်')
        self.assertEqual(self.store.get(self.jid)['detail'], 'Gemini ကျပ်နေပါတယ်')


class SlotTests(unittest.TestCase):
    def test_limit_and_fifo_order(self):
        slots = J.FifoSlots(1)
        order, running, peak = [], [0], [0]
        lock = threading.Lock()

        def worker(i):
            with slots.hold():
                with lock:
                    running[0] += 1
                    peak[0] = max(peak[0], running[0])
                    order.append(i)
                time.sleep(0.03)
                with lock:
                    running[0] -= 1
        ts = []
        for i in range(5):
            t = threading.Thread(target=worker, args=(i,))
            t.start()
            ts.append(t)
            time.sleep(0.01)                    # arrival order is 0..4
        [t.join(5) for t in ts]
        self.assertEqual(peak[0], 1)
        self.assertEqual(order, [0, 1, 2, 3, 4])

    def test_cancel_while_waiting_leaves_the_queue_clean(self):
        slots = J.FifoSlots(1)
        gate = threading.Event()
        res = []

        def holder():
            with slots.hold():
                gate.wait(5)
        h = threading.Thread(target=holder)
        h.start()
        time.sleep(0.05)
        cancelled = threading.Event()

        def check():
            if cancelled.is_set():
                raise J.JobCancelled()

        def waiter():
            try:
                with slots.hold(check=check):
                    res.append('got it')
            except J.JobCancelled:
                res.append('cancelled')
        w = threading.Thread(target=waiter)
        w.start()
        time.sleep(0.05)
        self.assertEqual(slots.waiting(), 1)
        cancelled.set()
        w.join(3)
        self.assertEqual(res, ['cancelled'])
        self.assertEqual(slots.waiting(), 0)
        gate.set()
        h.join(3)
        with slots.hold():                       # the slot is usable again
            pass


class RunnerTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.store = J.JobStore(Path(self.tmp.name))
        self.runner = J.Runner(self.store, max_jobs=1)

    def tearDown(self):
        self.tmp.cleanup()

    def new(self):
        return self.store.create('u', {}, 'a.mp4', '.mp4')['id']

    def test_runs_and_releases(self):
        jid = self.new()
        done = threading.Event()

        def work(ctl):
            self.store.update(jid, status='completed', stage='Complete', progress=100)
            done.set()
        self.runner.start(jid, work)
        self.assertTrue(done.wait(3))
        self.assertTrue(wait_for(lambda: not self.runner.running(jid)))
        self.assertEqual(self.store.get(jid)['status'], 'completed')

    def test_unexpected_exception_marks_failed(self):
        jid = self.new()

        def work(ctl):
            raise RuntimeError('boom')
        self.runner.start(jid, work)
        self.assertTrue(wait_for(lambda: self.store.get(jid)['status'] == 'failed'))
        self.assertEqual(self.store.get(jid)['error'], 'boom')

    def test_cancel_running_job(self):
        jid = self.new()

        def work(ctl):
            while True:
                ctl.sleep(0.05)
        self.runner.start(jid, work)
        self.assertTrue(wait_for(lambda: self.store.get(jid)['status'] == 'processing'))
        self.assertTrue(self.runner.cancel(jid))
        self.assertTrue(wait_for(lambda: self.store.get(jid)['status'] == 'cancelled'))
        self.assertFalse(self.runner.cancel(jid))

    def test_second_job_waits_for_the_first(self):
        a, b = self.new(), self.new()
        gate = threading.Event()
        started = []

        def work_a(ctl):
            started.append('a')
            gate.wait(5)
            self.store.update(a, status='completed')

        def work_b(ctl):
            started.append('b')
            self.store.update(b, status='completed')
        self.runner.start(a, work_a)
        self.assertTrue(wait_for(lambda: started == ['a']))
        self.runner.start(b, work_b)
        time.sleep(0.2)
        self.assertEqual(self.store.get(b)['status'], 'queued')
        self.assertIn('စောင့်', self.store.get(b)['detail'])
        gate.set()
        self.assertTrue(wait_for(lambda: self.store.get(b)['status'] == 'completed'))

    def test_pause_and_resume_through_the_runner(self):
        jid = self.new()
        got = []

        def work(ctl):
            got.append(ctl.ask('quota', 'used up'))
            self.store.update(jid, status='completed')
        self.runner.start(jid, work)
        self.assertTrue(wait_for(lambda: self.store.get(jid)['status'] == 'paused'))
        self.assertTrue(self.runner.answer(jid, {'key': 'K2'}))
        self.assertTrue(wait_for(lambda: self.store.get(jid)['status'] == 'completed'))
        self.assertEqual(got, [{'key': 'K2'}])


if __name__ == '__main__':
    unittest.main()
