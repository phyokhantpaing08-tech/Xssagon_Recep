import math
import os
import shutil
import sys
import tempfile
import threading
import time
import unittest
import wave
from pathlib import Path

import numpy as np

HERE = os.path.dirname(__file__)
sys.path.insert(0, os.path.join(HERE, '..', 'backend'))
sys.path.insert(0, HERE)

import timing as T       # noqa: E402
import voices as V       # noqa: E402
import gemini_client as G  # noqa: E402
import mock_gemini as M  # noqa: E402

FFMPEG = shutil.which('ffmpeg')


def write_tone_wav(path, seconds, lead=0.2, tail=0.3, sr=24000, amp=0.3):
    n = int(seconds * sr)
    t = np.arange(n) / sr
    tone = (amp * np.sin(2 * math.pi * 220 * t) * (0.6 + 0.4 * np.sin(2 * math.pi * 3 * t))).astype(np.float32)
    x = np.concatenate([np.zeros(int(lead * sr), np.float32), tone, np.zeros(int(tail * sr), np.float32)])
    with wave.open(str(path), 'wb') as w:
        w.setnchannels(1)
        w.setsampwidth(2)
        w.setframerate(sr)
        w.writeframes((x * 32767).astype('<i2').tobytes())


class FakeEdge:
    """Stands in for the edge_tts package: speaks len(syllables)/5 seconds of tone."""
    calls = []
    fail_first = 0
    lock = threading.Lock()
    active = 0
    peak = 0

    class Communicate:
        def __init__(self, text, voice, rate='+0%', pitch='+0Hz'):
            self.text, self.voice, self.rate, self.pitch = text, voice, rate, pitch

        async def save(self, path):
            import asyncio
            cls = FakeEdge
            with cls.lock:
                cls.calls.append((self.text, self.voice, self.rate, self.pitch))
                n = len(cls.calls)
                cls.active += 1
                cls.peak = max(cls.peak, cls.active)
            try:
                await asyncio.sleep(0.03)
                if n <= cls.fail_first:
                    raise RuntimeError('No audio was received')
                write_tone_wav(path, max(0.4, T.syllables(self.text) / 5.0))
            finally:
                with cls.lock:
                    cls.active -= 1

    @classmethod
    def reset(cls, fail_first=0):
        cls.calls = []
        cls.fail_first = fail_first
        cls.active = 0
        cls.peak = 0


class FastHooks:
    def __init__(self):
        self.sleeps = []
        self.cancelled = False

    def check(self):
        if self.cancelled:
            raise RuntimeError('cancelled')

    def sleep(self, seconds, why=''):
        self.sleeps.append((seconds, why))


class CatalogueTests(unittest.TestCase):
    def test_one_nilar_one_thiha_and_no_variants(self):
        native = [v for v in V.VOICES.values() if v['group'] == 'native']
        self.assertEqual(sorted(v['id'] for v in native), ['nilar', 'thiha'])
        self.assertEqual({v['voice'] for v in native}, {'my-MM-NilarNeural', 'my-MM-ThihaNeural'})
        ids = set(V.VOICES)
        for old in ('thiha-deep', 'thiha-bright', 'nilar-soft', 'nilar-bright'):
            self.assertNotIn(old, ids)
            self.assertEqual(V.resolve(old)['id'], old.split('-')[0])

    def test_experimental_and_credit_flags(self):
        for v in V.VOICES.values():
            if v['group'] == 'native':
                self.assertFalse(v['experimental'])
                self.assertFalse(v['credit'])
            if v['group'] == 'gemini':
                self.assertTrue(v['credit'])
                self.assertEqual(v['engine'], 'gemini')
        self.assertEqual(len([v for v in V.VOICES.values() if v['group'] == 'gemini']), 30)
        self.assertEqual(len({v['voice'] for v in V.VOICES.values() if v['group'] == 'gemini'}), 30)

    def test_ids_are_unique_and_url_safe(self):
        for vid in V.VOICES:
            self.assertRegex(vid, r'^[a-z0-9_]+$')

    def test_public_list_hides_edge_voices_the_service_does_not_have(self):
        live = {'my-MM-NilarNeural', 'my-MM-ThihaNeural', 'en-US-AvaMultilingualNeural'}
        ids = [v['id'] for v in V.public_list(edge_live=live) if v['group'] != 'gemini']
        self.assertEqual(ids, ['nilar', 'thiha', 'x_ava'])
        allv = [v['id'] for v in V.public_list(edge_live=None) if v['group'] == 'edge']
        self.assertGreaterEqual(len(allv), 10)

    def test_speed_mapping(self):
        self.assertEqual(V.speed_to_rate(10), '+10%')
        self.assertEqual(V.speed_to_rate(-5), '-5%')
        self.assertEqual(V.speed_to_rate(0), '+0%')
        self.assertEqual(V.speed_to_rate(500), '+60%')
        self.assertEqual(V.speed_to_rate('abc'), '+10%')
        self.assertEqual(V.clamp_speed(-99), -20)

    def test_env_extra_voice(self):
        os.environ['EDGE_EXTRA_VOICES'] = 'en-US-AriaNeural:Aria:female, bad name'
        try:
            V._load_env_extras()
            self.assertIn('x_aria', V.VOICES)
            self.assertEqual(V.VOICES['x_aria']['voice'], 'en-US-AriaNeural')
        finally:
            os.environ.pop('EDGE_EXTRA_VOICES')
            V.VOICES.pop('x_aria', None)


@unittest.skipUnless(FFMPEG, 'ffmpeg needed')
class EngineTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.dir = Path(self.tmp.name)
        FakeEdge.reset()
        self.engine = V.EdgeTTS(module=FakeEdge, concurrency=4)
        self.voice = V.VOICES['thiha']

    def tearDown(self):
        self.tmp.cleanup()

    def test_synth_retries_transient_failures(self):
        FakeEdge.reset(fail_first=2)
        h = FastHooks()
        out = self.dir / 'a.mp3'
        self.engine.synth('သူ ပြန်လာတယ်။', 'my-MM-ThihaNeural', '+10%', '+0Hz', out, hooks=h)
        self.assertTrue(out.exists())
        self.assertEqual(len(FakeEdge.calls), 3)
        self.assertEqual([w for _, w in h.sleeps], ['tts', 'tts'])
        self.assertEqual(FakeEdge.calls[-1][2], '+10%')

    def test_synth_gives_up_with_a_clear_error(self):
        FakeEdge.reset(fail_first=99)
        with self.assertRaises(V.TtsError) as cm:
            self.engine.synth('စာ', 'my-MM-ThihaNeural', '+0%', '+0Hz', self.dir / 'a.mp3', hooks=FastHooks(), attempts=3)
        self.assertIn('3 tries', str(cm.exception))

    def test_cancel_stops_retrying(self):
        FakeEdge.reset(fail_first=99)
        h = FastHooks()
        h.cancelled = True
        with self.assertRaises(RuntimeError):
            self.engine.synth('စာ', 'v', '+0%', '+0Hz', self.dir / 'a.mp3', hooks=h)
        self.assertEqual(len(FakeEdge.calls), 0)

    def test_many_lines_are_synthesised_concurrently(self):
        errs = []

        def one(i):
            try:
                self.engine.synth(f'စာကြောင်း {i} ပါ', 'v', '+0%', '+0Hz', self.dir / f'{i}.mp3')
            except Exception as e:
                errs.append(e)
        ts = [threading.Thread(target=one, args=(i,)) for i in range(12)]
        [t.start() for t in ts]
        [t.join(10) for t in ts]
        self.assertEqual(errs, [])
        self.assertGreater(FakeEdge.peak, 1)
        self.assertLessEqual(FakeEdge.peak, 4)               # the semaphore limit

    def test_clip_is_trimmed_normalised_and_cached(self):
        cm = V.ClipMaker(FFMPEG, self.engine, self.voice, 10, self.dir / 'tts')
        text = 'ပြီးတော့ သူက လမ်းထိပ်က ဈေးကို လျှောက်သွားတယ်။'
        x = cm.audio(text)
        speech = T.syllables(text) / 5.0
        # the fake adds 0.2 s before and 0.3 s after the speech: trimming removes (almost) all of it
        self.assertAlmostEqual(len(x) / T.SR, speech, delta=0.25)
        self.assertGreater(float(np.abs(x).max()), 0.05)
        self.assertLessEqual(float(np.abs(x).max()), 0.96)
        n_calls = len(FakeEdge.calls)
        y = cm.audio(text)                                    # second time: from the disk cache
        self.assertEqual(len(FakeEdge.calls), n_calls)
        self.assertEqual(len(x), len(y))
        self.assertEqual(FakeEdge.calls[-1][2], '+10%')
        cm2 = V.ClipMaker(FFMPEG, self.engine, self.voice, 20, self.dir / 'tts')   # another speed = another clip
        cm2.audio(text)
        self.assertEqual(len(FakeEdge.calls), n_calls + 1)
        self.assertEqual(FakeEdge.calls[-1][2], '+20%')

    def test_every_line_uses_the_same_speed_parameter(self):
        cm = V.ClipMaker(FFMPEG, self.engine, self.voice, 15, self.dir / 'tts')
        for i in range(5):
            cm.make(f'ဒီနေ့ မိုးတွေ ရွာတယ် {i}။')
        self.assertEqual({c[2] for c in FakeEdge.calls}, {'+15%'})
        self.assertEqual({c[3] for c in FakeEdge.calls}, {'+0Hz'})


class CalibrationStoreTests(unittest.TestCase):
    def test_roundtrip_and_sanity_limits(self):
        with tempfile.TemporaryDirectory() as d:
            st = V.CalibrationStore(Path(d) / 'cal.json')
            v = V.VOICES['nilar']
            self.assertIsNone(st.get(v, 10))
            st.put(v, 10, 4.7, 20)
            self.assertEqual(st.get(v, 10), (4.7, 20))
            self.assertIsNone(st.get(v, 20))                  # another speed
            st.put(v, 10, 99.0, 50)                           # nonsense is ignored
            st.put(v, 10, 4.0, 1)                             # too few samples is ignored
            self.assertEqual(st.get(v, 10), (4.7, 20))


class SampleCheckTests(unittest.TestCase):
    TEXT = 'မင်္ဂလာပါ၊ ကျွန်တော့်နာမည် သီဟပါ။ ဒီနေ့ ရုပ်ရှင်ဇာတ်လမ်းလေး ပြောပြပေးမယ်နော်။'

    def clip(self, seconds, amp=0.3):
        return (amp * np.sin(np.linspace(0, 400 * seconds, int(seconds * T.SR)))).astype(np.float32)

    def test_plausible_clip_passes(self):
        expect = T.Calibration().seconds(self.TEXT)
        ok, msg = V.check_sample(self.TEXT, self.clip(expect))
        self.assertTrue(ok, msg)

    def test_silence_too_short_and_too_long_are_flagged(self):
        expect = T.Calibration().seconds(self.TEXT)
        self.assertFalse(V.check_sample(self.TEXT, self.clip(expect, amp=0.0))[0])
        self.assertFalse(V.check_sample(self.TEXT, self.clip(expect * 0.2))[0])
        self.assertFalse(V.check_sample(self.TEXT, self.clip(expect * 4))[0])
        self.assertFalse(V.check_sample(self.TEXT, np.zeros(0, np.float32))[0])


@unittest.skipUnless(FFMPEG, 'ffmpeg needed')
class GeminiVoiceTests(unittest.TestCase):
    def test_gemini_voice_clip_through_the_mock_api(self):
        with M.MockGemini() as mg, tempfile.TemporaryDirectory() as d:
            client = G.GeminiClient('KEY', 'gemini-flash-latest', [], hooks=G.NullHooks())
            engine = V.GeminiTTS(client, ['gemini-3.8-flash-tts'])
            voice = V.VOICES['g_kore']
            cm = V.ClipMaker(FFMPEG, engine, voice, 10, Path(d) / 'tts')
            self.assertAlmostEqual(cm.tempo, 1.10)             # no rate parameter: the same fixed factor for every clip
            x = cm.audio('သူက မနက်စောစောထပြီး ဈေးကို သွားတယ်။')
            self.assertGreater(len(x), T.SR // 2)
            req = [r for r in mg.state.requests if r['action'] == 'generateContent'][0]
            self.assertEqual(req['payload']['generationConfig']['speechConfig']['voiceConfig']['prebuiltVoiceConfig']['voiceName'], 'Kore')
            n = len(mg.state.requests)
            cm.make('သူက မနက်စောစောထပြီး ဈေးကို သွားတယ်။')
            self.assertEqual(len(mg.state.requests), n)       # cached


if __name__ == '__main__':
    unittest.main()
