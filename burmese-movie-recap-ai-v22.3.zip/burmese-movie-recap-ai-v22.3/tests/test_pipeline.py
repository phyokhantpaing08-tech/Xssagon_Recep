"""End-to-end tests of the processing pipeline with REAL ffmpeg but fake Whisper, fake Edge TTS and a fake Gemini server
(nothing here uses the network or any credit)."""
import contextlib
import hashlib
import json
import os
import re
import shutil
import subprocess
import sys
import tempfile
import threading
import time
import unittest
import wave
from pathlib import Path
from unittest import mock

import numpy as np

HERE = os.path.dirname(__file__)
sys.path.insert(0, os.path.join(HERE, '..', 'backend'))
sys.path.insert(0, HERE)


def _find_font():
    cands = [os.getenv('TEST_BURMESE_FONT') or '',
             os.path.join(HERE, '..', 'fonts', 'Padauk-Regular.ttf'),                  # the font that ships with the project
             '/usr/share/fonts/truetype/noto/NotoSansMyanmar-Regular.ttf',
             '/usr/share/fonts/truetype/padauk/Padauk-Regular.ttf']
    return next((c for c in cands if c and os.path.isfile(c)), '')


FONT = _find_font()
if FONT:
    os.environ['SUBTITLE_FONT'] = FONT
os.environ['GEMINI_API_KEY'] = 'KEY-A'
os.environ['GEMINI_THINKING_BUDGET'] = ''
os.environ['WHISPER_CHUNK_SECONDS'] = '20'
os.environ['RENDER_PRESET'] = 'ultrafast'

import asr                      # noqa: E402
import auth                     # noqa: E402
import gemini_client as G       # noqa: E402
import jobs                     # noqa: E402
import media                    # noqa: E402
import mock_gemini as M         # noqa: E402
import pipeline                 # noqa: E402
import presets as P             # noqa: E402
import rewrite as R             # noqa: E402
import timing as T              # noqa: E402
import voices as V              # noqa: E402
from test_voices import FakeEdge  # noqa: E402

VIDEO_SECONDS = 60
CHUNK = 20
PER_CHUNK = 5                                   # lines per chunk: starts 0, 4, 8, 12, 16 (+ chunk offset), 2.5 s long
TOTAL_LINES = 3 * PER_CHUNK


def burmese_digits(n):
    return ''.join('၀၁၂၃၄၅၆၇၈၉'[int(c)] for c in str(n))


class FakeWhisper:
    def __init__(self):
        self.calls = []
        self.lock = threading.Lock()

    def __call__(self, wav_path, lang_hint=None, check=None, want_spans=True):
        i = int(re.search(r'chunk_(\d+)', Path(wav_path).name).group(1))
        with self.lock:
            self.calls.append(i)
        with wave.open(str(wav_path), 'rb') as w:
            dur = w.getnframes() / float(w.getframerate())
        segs = []
        for k in range(PER_CHUNK):
            if k * 4.0 + 2.5 <= dur + 0.01:
                segs.append({'start': k * 4.0, 'end': k * 4.0 + 2.5, 'text': f'source line {i}-{k}'})
        return segs, 'en', 'fake-whisper', 0.99


def line_index(user_text_item):
    """'source line 1-3' -> 8"""
    text = user_text_item.get('text') if isinstance(user_text_item, dict) else str(user_text_item)
    m = re.search(r'source line (\d+)-(\d+)', text or '')
    return int(m.group(1)) * PER_CHUNK + int(m.group(2)) if m else None


def unique_generate(long_every=0):
    """A fake Gemini 'writer': one distinct Burmese line per source line. With long_every=N, every N-th line is written far
    too long (ignoring its time budget) in the rewrite step; the shorten step then complies."""
    def gen(system, user):
        items = M._parse_input(user)
        shorten = 'timing editor' in (system or '')
        out = []
        for it in items:
            if shorten:
                limit = int(it.get('max_syllables') or 999)
                out.append(M._choose(limit, 0))
                continue
            idx = line_index(it)
            if idx is None:
                out.append('')
                continue
            if long_every and idx % long_every == 2:
                out.append(M.POOL[5] + ' ' + burmese_digits(idx))
            else:
                out.append(M.POOL[2] + ' ' + burmese_digits(idx))
        return out
    return gen


class FakeDrive:
    """Same functions as drive_store, but 'uploads' into a folder."""

    class DriveError(RuntimeError):
        pass

    def __init__(self, root, fail_video=False, connected=True):
        self.root = Path(root)
        self.root.mkdir(parents=True, exist_ok=True)
        self.fail_video = fail_video
        self.connected = connected
        self.dirs, self.uploaded, self.deleted = [], [], []

    @contextlib.contextmanager
    def use_dir(self, path):
        self.dirs.append(str(path) if path else None)
        yield

    def is_connected(self):
        return self.connected

    def ensure_folder(self, name=None):
        return 'FOLDER'

    def read_settings(self):
        return {'share_anyone': False, 'folder_name': 'Recaps', 'folder_id': 'FOLDER'}

    def md5_file(self, path):
        return hashlib.md5(Path(path).read_bytes()).hexdigest()

    def upload_file(self, path, name, mime, folder_id, on_progress=None, chunk=None):
        if self.fail_video and name.endswith('.mp4'):
            raise self.DriveError('Google Drive နေရာ ပြည့်နေပါတယ်။')
        data = Path(path).read_bytes()
        fid = hashlib.md5((name + str(len(self.uploaded))).encode()).hexdigest()[:12]
        (self.root / fid).write_bytes(data)
        self.uploaded.append(name)
        if on_progress:
            on_progress(len(data), len(data))
        return {'id': fid, 'name': name, 'size': str(len(data)), 'md5Checksum': hashlib.md5(data).hexdigest()}

    def verify(self, meta, local_size, local_md5=None):
        if int(meta['size']) != int(local_size):
            raise self.DriveError('size mismatch')

    def make_public(self, fid):
        pass

    def delete_remote(self, fid):
        self.deleted.append(fid)
        try:
            (self.root / fid).unlink()
        except OSError:
            pass

    def view_url(self, meta):
        return 'https://drive.example/view/' + meta['id']

    def download_url(self, meta):
        return 'https://drive.example/dl/' + meta['id']

    def folder_url(self, fid):
        return 'https://drive.example/folder/' + fid


def make_video(path, seconds=VIDEO_SECONDS, audio=True):
    args = ['ffmpeg', '-y', '-v', 'error', '-f', 'lavfi', '-i', 'testsrc=size=320x240:rate=10']
    if audio:
        args += ['-f', 'lavfi', '-i', 'sine=frequency=330:sample_rate=44100']
    args += ['-t', str(seconds), '-c:v', 'libx264', '-preset', 'ultrafast', '-pix_fmt', 'yuv420p']
    args += ['-c:a', 'aac', '-shortest'] if audio else ['-an']
    subprocess.run(args + [str(path)], check=True)


def probe_streams(path):
    p = subprocess.run(['ffprobe', '-v', 'error', '-show_entries', 'stream=codec_type,duration', '-of', 'json', str(path)],
                       capture_output=True, text=True, check=True)
    return json.loads(p.stdout)['streams']


def decode_mono(path, sr=24000):
    p = subprocess.run(['ffmpeg', '-v', 'error', '-i', str(path), '-vn', '-f', 's16le', '-ac', '1', '-ar', str(sr), '-'],
                       capture_output=True, check=True)
    return np.frombuffer(p.stdout, dtype='<i2').astype(np.float32) / 32768.0


def dominant_hz(x, sr=24000):
    spec = np.abs(np.fft.rfft(x * np.hanning(len(x))))
    return float(np.argmax(spec)) * sr / len(x)


class Env:
    def __init__(self, tmp, drive=None):
        self.data = Path(tmp) / 'data'
        self.data.mkdir(parents=True, exist_ok=True)
        self.users = auth.UserStore(self.data)
        self.store = jobs.JobStore(self.data / 'jobs')
        self.edge = V.EdgeTTS(module=FakeEdge, concurrency=4)
        self.svc = pipeline.Services(self.store, self.data, jobs.FifoSlots(1), self.users, drive=drive, edge=self.edge)
        self.runner = jobs.Runner(self.store, max_jobs=2)

    def job(self, video, owner='local', **params):
        p = {'voice': 'thiha', 'style': 'direct', 'make_voice': True, 'make_subs': True, 'speed': 10, 'blur': None,
             'render_preset': 'ultrafast'}
        p.update(params)
        j = self.store.create(owner, p, 'movie.mp4', '.mp4')
        shutil.copy(video, self.store.dir(j['id']) / 'input.mp4')
        return j['id']

    def start(self, jid):
        return self.runner.start(jid, lambda ctl: pipeline.run_job(self.svc, jid, ctl))

    def wait(self, jid, states, timeout=120):
        end = time.time() + timeout
        j = None
        while time.time() < end:
            j = self.store.get(jid)
            if j['status'] in states:
                return j
            time.sleep(0.05)
        raise AssertionError(f'timeout waiting for {states}: status={j["status"]} stage={j.get("stage")} '
                             f'detail={j.get("detail")} error={j.get("error")}')

    def wait_idle(self, jid, timeout=30):
        end = time.time() + timeout
        while time.time() < end and self.runner.running(jid):
            time.sleep(0.05)

    def files(self, jid):
        d = self.store.dir(jid)
        return {str(p.relative_to(d)) for p in d.rglob('*') if p.is_file()}


@unittest.skipUnless(shutil.which('ffmpeg') and shutil.which('ffprobe'), 'ffmpeg is needed')
class PipelineBase(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.tmp_all = tempfile.mkdtemp(prefix='recap_pipe_')
        cls.video = Path(cls.tmp_all) / 'video.mp4'
        make_video(cls.video)
        cls.silent = Path(cls.tmp_all) / 'silent.mp4'
        make_video(cls.silent, seconds=10, audio=False)

    @classmethod
    def tearDownClass(cls):
        shutil.rmtree(cls.tmp_all, ignore_errors=True)

    def setUp(self):
        self.tmp = tempfile.mkdtemp(prefix='recap_env_')
        self.addCleanup(shutil.rmtree, self.tmp, ignore_errors=True)
        FakeEdge.reset()
        self.whisper = FakeWhisper()
        for patcher in (mock.patch.object(asr, 'transcribe_wav', self.whisper), mock.patch.object(R, 'BATCH', 4)):
            patcher.start()
            self.addCleanup(patcher.stop)
        os.environ['GEMINI_API_KEY'] = 'KEY-A'
        self.mock = M.MockGemini()
        self.mock.__enter__()
        self.addCleanup(self.mock.__exit__, None, None, None)
        self.mock.state.generate = unique_generate()
        self.env = Env(self.tmp)
        self.addCleanup(self.stop_all)

    def stop_all(self):
        for jid in list(self.env.runner.controls):
            self.env.runner.cancel(jid)
        for jid in list(self.env.runner.controls):
            self.env.wait_idle(jid, 10)


class HappyPathTests(PipelineBase):
    @unittest.skipUnless(FONT, 'a Burmese font is needed to burn subtitles')
    def test_voice_and_subtitles_complete(self):
        env = self.env
        jid = env.job(self.video)
        env.start(jid)
        job = env.wait(jid, ('completed', 'failed'))
        self.assertEqual(job['status'], 'completed', job.get('error'))
        self.assertEqual(job['progress'], 100)
        self.assertEqual(job['output_url'], f'/api/files/{jid}/final_burmese.mp4')
        self.assertEqual(job['srt_url'], f'/api/files/{jid}/burmese.srt')
        out = env.store.dir(jid) / 'out'
        self.assertTrue((out / 'final_burmese.mp4').stat().st_size > 1000)
        kinds = {s['codec_type'] for s in probe_streams(out / 'final_burmese.mp4')}
        self.assertEqual(kinds, {'video', 'audio'})
        self.assertAlmostEqual(media.duration(out / 'final_burmese.mp4'), VIDEO_SECONDS, delta=1.5)
        srt = (out / 'burmese.srt').read_text(encoding='utf-8')
        self.assertEqual(len(re.findall(r'-->', srt)), TOTAL_LINES)
        self.assertIn('WEBVTT', (out / 'burmese.vtt').read_text(encoding='utf-8'))
        # every Whisper chunk exactly once, and the caches of a finished job are gone
        self.assertEqual(sorted(self.whisper.calls), [0, 1, 2])
        self.assertFalse((env.store.dir(jid) / 'work').exists())
        self.assertFalse(list(env.store.dir(jid).glob('input.*')))
        self.assertEqual(job['stats']['lines'], TOTAL_LINES)
        self.assertEqual(job['stats']['spoken'], TOTAL_LINES)
        self.assertEqual(job['stats']['shortened'], 0)
        self.assertEqual(job['stats']['sped_up'], 0)
        self.assertIn('Voice=Thiha', job['detail'])

    def test_batches_and_context_requests(self):
        env = self.env
        jid = env.job(self.video, make_subs=False)
        env.start(jid)
        job = env.wait(jid, ('completed', 'failed'))
        self.assertEqual(job['status'], 'completed', job.get('error'))
        rewrites = [r for r in self.mock.state.requests if r['action'] == 'generateContent']
        self.assertEqual(len(rewrites), 4)                              # 4 + 4 + 4 + 3 lines
        prompts = [r['payload']['contents'][0]['parts'][0]['text'] for r in rewrites]
        self.assertNotIn('PREVIOUS NARRATION', prompts[0])
        self.assertIn('PREVIOUS NARRATION', prompts[1])                 # the story continues across batch borders
        self.assertEqual(len([r for r in self.mock.state.requests if r['method'] == 'POST' and 'countTokens' in r['path']]), 0)
        # every request carries a time budget for every line
        for p in prompts:
            for it in M._parse_input(p):
                self.assertIn('max_syllables', it)

    def test_voice_only_keeps_the_picture_untouched_and_replaces_audio(self):
        env = self.env
        jid = env.job(self.video, make_subs=False)
        env.start(jid)
        job = env.wait(jid, ('completed', 'failed'))
        self.assertEqual(job['status'], 'completed', job.get('error'))
        self.assertNotIn('srt_url', job)
        out = env.store.dir(jid) / 'out' / 'final_burmese.mp4'
        audio = decode_mono(out)
        self.assertAlmostEqual(len(audio) / 24000.0, VIDEO_SECONDS, delta=1.0)
        segs = json.loads((env.store.dir(jid) / 'out' / 'segments.json').read_text(encoding='utf-8'))
        self.assertEqual(len(segs), TOTAL_LINES)
        # the narration (a 220 Hz tone from the fake voice) sits at the line starts and is silent in the gaps
        for s in segs[:6]:
            a = int((s['start'] + 0.3) * 24000)
            speech = audio[a:a + int(1.0 * 24000)]
            self.assertGreater(float(np.sqrt(np.mean(speech ** 2))), 0.03)
            self.assertAlmostEqual(dominant_hz(speech), 220, delta=25)
            gap = audio[int((s['end'] + 0.35) * 24000):int((s['end'] + 0.65) * 24000)]
            if s['end'] + 0.65 < s['start'] + 3.8:
                self.assertLess(float(np.sqrt(np.mean(gap ** 2))), 0.01)

    @unittest.skipUnless(FONT, 'a Burmese font is needed to burn subtitles')
    def test_subtitles_only_keeps_the_original_audio(self):
        env = self.env
        jid = env.job(self.video, make_voice=False)
        env.start(jid)
        job = env.wait(jid, ('completed', 'failed'))
        self.assertEqual(job['status'], 'completed', job.get('error'))
        self.assertEqual(len(FakeEdge.calls), 0)                         # no voice was made
        out = env.store.dir(jid) / 'out' / 'final_burmese.mp4'
        audio = decode_mono(out, 16000)
        self.assertAlmostEqual(dominant_hz(audio[16000 * 5:16000 * 6], 16000), 330, delta=15)   # the original sine
        rewrites = [r for r in self.mock.state.requests if r['action'] == 'generateContent']
        first = M._parse_input(rewrites[0]['payload']['contents'][0]['parts'][0]['text'])
        self.assertTrue(all(isinstance(x, str) for x in first))          # plain lines: no budgets without a voice

    def test_overlong_lines_are_shortened_in_one_batched_request_not_sped_up(self):
        self.mock.state.generate = unique_generate(long_every=5)
        env = self.env
        jid = env.job(self.video, make_subs=False)
        env.start(jid)
        job = env.wait(jid, ('completed', 'failed'))
        self.assertEqual(job['status'], 'completed', job.get('error'))
        self.assertGreaterEqual(job['stats']['shortened'], 3)
        self.assertEqual(job['stats']['sped_up'], 0)
        shorten = [r for r in self.mock.state.requests if r['action'] == 'generateContent'
                   and 'timing editor' in json.dumps(r['payload'].get('systemInstruction') or {})]
        self.assertEqual(len(shorten), 1)                               # ONE request for all of them
        segs = json.loads((env.store.dir(jid) / 'out' / 'segments.json').read_text(encoding='utf-8'))
        for a, b in zip(segs, segs[1:]):
            self.assertLessEqual(a['end'], b['start'] + 1e-6)           # nothing overlaps, nothing is cut

    def test_gemini_voice_path(self):
        env = self.env
        jid = env.job(self.video, make_subs=False, voice='g_kore')
        env.start(jid)
        job = env.wait(jid, ('completed', 'failed'))
        self.assertEqual(job['status'], 'completed', job.get('error'))
        tts = [r for r in self.mock.state.requests if 'responseModalities' in json.dumps(r['payload'])]
        self.assertGreaterEqual(len(tts), TOTAL_LINES)
        self.assertEqual(len(FakeEdge.calls), 0)

    def test_second_job_reuses_the_voice_calibration(self):
        env = self.env
        j1 = env.job(self.video, make_subs=False)
        env.start(j1)
        self.assertEqual(env.wait(j1, ('completed', 'failed'))['status'], 'completed')
        stored = json.loads((env.data / 'calibration.json').read_text())
        self.assertEqual(len(stored), 1)
        before = len(FakeEdge.calls)
        self.assertGreaterEqual(before, TOTAL_LINES + 3)               # the 3 calibration sentences were spoken
        j2 = env.job(self.video, make_subs=False)
        env.start(j2)
        self.assertEqual(env.wait(j2, ('completed', 'failed'))['status'], 'completed')
        # job folders are separate, so the 15 lines are spoken again - but the 3 calibration sentences are not
        self.assertEqual(len(FakeEdge.calls), before + TOTAL_LINES)


class FailureTests(PipelineBase):
    def test_video_without_audio_gives_a_friendly_error(self):
        env = self.env
        jid = env.job(self.silent, make_subs=False)
        env.start(jid)
        job = env.wait(jid, ('completed', 'failed'))
        self.assertEqual(job['status'], 'failed')
        self.assertIn('အသံ', job['error'])

    def test_no_key_gives_a_friendly_error(self):
        os.environ.pop('GEMINI_API_KEY', None)
        env = self.env
        jid = env.job(self.video, make_subs=False)
        env.start(jid)
        job = env.wait(jid, ('completed', 'failed'))
        self.assertEqual(job['status'], 'failed')
        self.assertIn('Gemini API key', job['error'])

    def test_nothing_chosen(self):
        env = self.env
        jid = env.job(self.video, make_subs=False, make_voice=False)
        env.start(jid)
        job = env.wait(jid, ('completed', 'failed'))
        self.assertEqual(job['status'], 'failed')


class PauseResumeTests(PipelineBase):
    def exhausted_after(self, n_ok):
        calls = {'n': 0}
        lock = threading.Lock()
        base = unique_generate()

        def gen(system, user, key):
            if key == 'KEY-A':
                with lock:
                    calls['n'] += 1
                    broken = calls['n'] > n_ok
                if broken:
                    return M.e429_prepay()
            return base(system, user)
        self.mock.state.generate = gen

    def test_credit_runs_out_pause_new_key_continue_without_redo(self):
        self.exhausted_after(1)
        env = self.env
        jid = env.job(self.video, make_subs=False)
        env.start(jid)
        job = env.wait(jid, ('paused', 'completed', 'failed'))
        self.assertEqual(job['status'], 'paused', job.get('error'))
        self.assertEqual(job['pause']['kind'], 'quota')
        self.assertIn('credit', job['pause']['message'].lower())
        time.sleep(0.5)
        self.assertEqual(env.store.get(jid)['status'], 'paused')           # it waits, it does not give up
        done_before = json.loads((env.store.dir(jid) / 'work' / 'rewrite.json').read_text(encoding='utf-8'))['lines']
        self.assertEqual(len(done_before), 4)                              # the first batch is saved on disk
        self.assertTrue(env.runner.answer(jid, {'key': 'KEY-B'}))
        job = env.wait(jid, ('completed', 'failed'))
        self.assertEqual(job['status'], 'completed', job.get('error'))
        with_b = [r for r in self.mock.state.requests if r['key'] == 'KEY-B' and r['action'] == 'generateContent'
                  and 'responseModalities' not in json.dumps(r['payload'])]
        self.assertEqual(len(with_b), 3)                                   # only the 3 remaining batches
        for r in with_b:
            self.assertNotIn('source line 0-0', r['payload']['contents'][0]['parts'][0]['text'])
        self.assertEqual(sorted(self.whisper.calls), [0, 1, 2])            # Whisper was not repeated either
        spoken = [c[0] for c in FakeEdge.calls]
        self.assertEqual(len(spoken), len(set(spoken)))                    # no line was spoken twice

    def test_cancel_while_paused_deletes_everything(self):
        self.exhausted_after(0)
        env = self.env
        jid = env.job(self.video, make_subs=False)
        env.start(jid)
        job = env.wait(jid, ('paused', 'completed', 'failed'))
        self.assertEqual(job['status'], 'paused')
        self.assertTrue(env.runner.cancel(jid))
        job = env.wait(jid, ('cancelled', 'failed'))
        self.assertEqual(job['status'], 'cancelled')
        env.wait_idle(jid)
        self.assertEqual(env.files(jid), {'job.json'})

    def test_try_again_with_the_same_key(self):
        self.exhausted_after(1)
        env = self.env
        jid = env.job(self.video, make_subs=False)
        env.start(jid)
        env.wait(jid, ('paused',))
        # the person tops up the credit and presses "try again" (no new key)
        base = unique_generate()
        self.mock.state.generate = lambda s, u: base(s, u)
        self.assertTrue(env.runner.answer(jid, {}))
        job = env.wait(jid, ('completed', 'failed'))
        self.assertEqual(job['status'], 'completed', job.get('error'))

    def test_hard_failure_keeps_the_work_and_resume_continues(self):
        env = self.env
        base = unique_generate()
        calls = {'n': 0}

        def gen(system, user):
            calls['n'] += 1
            if calls['n'] == 3:
                return 400, M.err(400, 'Request contains an invalid argument.', 'INVALID_ARGUMENT')
            return base(system, user)
        self.mock.state.generate = gen
        jid = env.job(self.video, make_subs=False)
        env.start(jid)
        job = env.wait(jid, ('failed', 'completed'))
        self.assertEqual(job['status'], 'failed')
        self.assertIn('invalid argument', job['error'])
        env.wait_idle(jid)
        saved = json.loads((env.store.dir(jid) / 'work' / 'rewrite.json').read_text(encoding='utf-8'))['lines']
        self.assertEqual(len(saved), 8)                                    # two batches survived
        gemini_before = len([r for r in self.mock.state.requests if r['action'] == 'generateContent'])
        spoken_before = len(FakeEdge.calls)
        # resume (the same call the website's "continue" button makes)
        self.mock.state.generate = base
        env.start(jid)
        job = env.wait(jid, ('completed', 'failed'))
        self.assertEqual(job['status'], 'completed', job.get('error'))
        gemini_after = len([r for r in self.mock.state.requests if r['action'] == 'generateContent']) - gemini_before
        self.assertEqual(gemini_after, 2)                                  # only the 2 missing batches (lines 8-11, 12-14)
        self.assertEqual(sorted(self.whisper.calls), [0, 1, 2])            # each chunk transcribed once in total
        spoken = [c[0] for c in FakeEdge.calls]
        # every finished line is spoken once in total; only clips that were still being made (a few worker threads) when the first
        # run failed may be made again
        self.assertLessEqual(len(spoken) - len(set(spoken)), 4)
        self.assertGreater(len(FakeEdge.calls), spoken_before)

    def test_server_restart_marks_running_job_interrupted_and_it_can_resume(self):
        self.exhausted_after(1)
        env = self.env
        jid = env.job(self.video, make_subs=False)
        env.start(jid)
        env.wait(jid, ('paused',))
        # "restart": a new store reads job.json; the old thread is gone
        env.runner.cancel(jid)
        env.wait_idle(jid)
        raw = json.loads((env.store.dir(jid) / 'job.json').read_text(encoding='utf-8'))
        raw['status'] = 'paused'
        (env.store.dir(jid) / 'job.json').write_text(json.dumps(raw), encoding='utf-8')
        (env.store.dir(jid) / 'work').mkdir(exist_ok=True)
        store2 = jobs.JobStore(env.data / 'jobs')
        store2.load_existing()
        self.assertEqual(store2.get(jid)['status'], 'interrupted')


class DriveTests(PipelineBase):
    def test_upload_verified_then_server_copy_removed(self):
        drive = FakeDrive(Path(self.tmp) / 'drive')
        self.env = Env(self.tmp, drive=drive)
        self.env.users.set_key(auth.LOCAL_USER, 'KEY-A')                         # the key typed on the website
        jid = self.env.job(self.video, make_subs=False)
        self.env.start(jid)
        job = self.env.wait(jid, ('completed', 'failed'))
        self.assertEqual(job['status'], 'completed', job.get('error'))
        self.assertTrue(job['drive']['server_cleaned'])
        self.assertEqual(job['stream_url'], f'/api/drive/stream/{jid}')
        self.assertEqual(job['drive']['video']['view_url'], 'https://drive.example/view/' + job['drive']['video']['id'])
        self.assertEqual(self.env.files(jid), {'job.json'})
        self.assertIn(None, drive.dirs)                                            # the one Drive login stays where V20 kept it (data/)
        self.assertEqual(len(drive.uploaded), 1)

    def test_failed_upload_keeps_the_local_file(self):
        drive = FakeDrive(Path(self.tmp) / 'drive', fail_video=True)
        self.env = Env(self.tmp, drive=drive)
        jid = self.env.job(self.video, make_subs=False)
        self.env.start(jid)
        job = self.env.wait(jid, ('completed', 'failed'))
        self.assertEqual(job['status'], 'completed', job.get('error'))
        self.assertIn('ပြည့်နေ', job['drive_error'])
        self.assertEqual(job['output_url'], f'/api/files/{jid}/final_burmese.mp4')
        self.assertTrue((self.env.store.dir(jid) / 'out' / 'final_burmese.mp4').exists())


class ProgressTests(unittest.TestCase):
    def test_progress_is_monotonic_and_stays_below_100(self):
        class Store:
            def __init__(self):
                self.values = []

            def update(self, jid, **kw):
                self.values.append(kw['progress'])
        s = Store()
        p = pipeline.Progress(s, 'x', [('prep', 3), ('write', 62), ('mix', 3), ('render', 22), ('deliver', 5)])
        for key, fr in [('prep', 0), ('prep', 1), ('write', 0.3), ('write', 0.1), ('write', 1.0), ('mix', 1), ('render', 0.5),
                        ('render', 1.0), ('deliver', 1.0)]:
            p.set(key, fr)
        self.assertEqual(s.values, sorted(s.values))
        self.assertLess(max(s.values), 100)
        self.assertGreaterEqual(max(s.values), 97)


class RewriteCacheTests(unittest.TestCase):
    def test_roundtrip_signature_and_truncate(self):
        with tempfile.TemporaryDirectory() as d:
            c = pipeline.RewriteCache(Path(d) / 'r.json', 'sigA')
            c.lines += ['a', 'b', 'c']
            c.src += ['A', 'B', 'C']
            c.save()
            c2 = pipeline.RewriteCache(Path(d) / 'r.json', 'sigA')
            self.assertEqual(c2.lines, ['a', 'b', 'c'])
            c2.truncate(1)
            self.assertEqual(pipeline.RewriteCache(Path(d) / 'r.json', 'sigA').lines, ['a'])
            self.assertEqual(pipeline.RewriteCache(Path(d) / 'r.json', 'other-style').lines, [])


# ------------------------------------------------------------------------------------------------ V22: the story style
def with_story(base, log=None, notes=None, group=3, story=None):
    """A fake AI that also answers the story requests: the storyteller (`group` rows per piece; `story` = a function to answer
    them differently) and the story analyst (the notes). `log` collects what the storyteller was sent."""
    def gen(system, user):
        if 'story analyst' in (system or ''):
            return list(M.STORY_NOTES) if notes is None else notes
        if 'charismatic Burmese storyteller' in (system or ''):
            if log is not None:
                log.append(user)
            return story(system, user) if story else M.story_generate(system, user, group)
        return base(system, user)
    return gen


def text_requests(state):
    return [r for r in state.requests if r['action'] == 'generateContent' and 'responseModalities' not in (r['payload'].get('generationConfig') or {})]


def system_of(r):
    return ((r['payload'].get('systemInstruction') or {}).get('parts') or [{}])[0].get('text', '')


def user_of(r):
    return r['payload']['contents'][0]['parts'][0]['text']


def is_story(r):
    return 'charismatic Burmese storyteller' in system_of(r)


def is_notes(r):
    return 'story analyst' in system_of(r)


def row_numbers(user):
    return [int(x) for x in re.findall(r'^(\d+)\|', user, re.M)]


class SlowWhisper(FakeWhisper):
    """The last chunk takes a while; `finished` remembers when each chunk was ready."""

    def __init__(self, slow_chunk=2, seconds=0.8):
        super().__init__()
        self.slow_chunk, self.seconds, self.finished = slow_chunk, seconds, {}

    def __call__(self, wav_path, lang_hint=None, check=None, want_spans=True):
        i = int(re.search(r'chunk_(\d+)', Path(wav_path).name).group(1))
        if i == self.slow_chunk:
            time.sleep(self.seconds)
        out = super().__call__(wav_path, lang_hint, check, want_spans)
        with self.lock:
            self.finished[i] = time.time()
        return out


def small_parts(chars=200):
    """Story limits so small that the 15 lines of the test film have to be told in several parts."""
    return mock.patch.object(pipeline.R, 'story_limits', lambda: {'chars': chars, 'tokens': 4096, 'timeout': 60})


class StoryPipelineTests(PipelineBase):
    def run_job(self, **params):
        env = self.env
        params.setdefault('make_subs', False)
        jid = env.job(self.video, **params)
        env.start(jid)
        return jid, env.wait(jid, ('completed', 'failed', 'paused', 'review'))

    def test_all_the_text_goes_to_the_ai_in_one_request_and_the_story_comes_back(self):
        log = []
        self.mock.state.generate = with_story(unique_generate(), log)
        jid, job = self.run_job(style='story')
        self.assertEqual(job['status'], 'completed', job.get('error'))
        reqs = text_requests(self.mock.state)
        self.assertEqual(len(reqs), 1)                                   # ONE request for the whole film (the pieces fit their time)
        self.assertTrue(is_story(reqs[0]))
        self.assertEqual(row_numbers(user_of(reqs[0])), list(range(TOTAL_LINES)))      # every line of the film, in time order
        for k in range(TOTAL_LINES):
            self.assertIn(f'source line {k // PER_CHUNK}-{k % PER_CHUNK}', user_of(reqs[0]))
        self.assertNotIn('REQUIRED OUTPUT COUNT', user_of(reqs[0]))      # not translated line by line
        self.assertNotIn('INPUT JSON ARRAY', user_of(reqs[0]))
        self.assertIn('WHOLE film', user_of(reqs[0]))
        self.assertEqual(job['stats']['source_lines'], TOTAL_LINES)
        self.assertEqual(job['stats']['lines'], TOTAL_LINES // 3)       # what is spoken are the 5 pieces of the story
        self.assertEqual(job['stats']['spoken'], TOTAL_LINES // 3)
        self.assertEqual(job['stats']['story_parts'], 1)
        self.assertEqual(sorted(self.whisper.calls), [0, 1, 2])

    def test_the_direct_style_still_translates_line_by_line_in_batches(self):
        self.mock.state.generate = with_story(unique_generate())
        jid, job = self.run_job(style='direct')
        self.assertEqual(job['status'], 'completed', job.get('error'))
        reqs = text_requests(self.mock.state)
        self.assertEqual(len(reqs), 4)                                   # 4 + 4 + 4 + 3 lines
        for r in reqs:
            self.assertFalse(is_story(r) or is_notes(r))
            self.assertIn('REQUIRED OUTPUT COUNT', user_of(r))
            self.assertNotIn('NEXT SOURCE LINES', user_of(r))
        self.assertEqual(job['stats']['lines'], TOTAL_LINES)

    def test_an_old_style_name_is_the_direct_style(self):
        self.mock.state.generate = with_story(unique_generate())
        jid, job = self.run_job(style='dub')
        self.assertEqual(job['status'], 'completed', job.get('error'))
        self.assertEqual(len(text_requests(self.mock.state)), 4)

    def test_the_story_waits_for_whisper_to_finish_the_direct_style_does_not(self):
        times = {}
        for style in ('story', 'direct'):
            slow = SlowWhisper(slow_chunk=2, seconds=0.9)
            self.mock.state.requests.clear()
            self.mock.state.generate = with_story(unique_generate())
            with mock.patch.object(asr, 'transcribe_wav', slow):
                jid, job = self.run_job(style=style)
            self.assertEqual(job['status'], 'completed', job.get('error'))
            times[style] = (min(r['time'] for r in text_requests(self.mock.state)), slow.finished[2])
        first, last_chunk_ready = times['story']
        self.assertGreaterEqual(first, last_chunk_ready)                # nothing is asked before the whole film is transcribed
        first, last_chunk_ready = times['direct']
        self.assertLess(first, last_chunk_ready)                        # the direct style still works while Whisper is busy

    def test_the_pieces_replace_the_whisper_lines_on_the_review_page(self):
        import review
        self.mock.state.generate = with_story(unique_generate())
        jid, job = self.run_job(style='story', review=True)
        self.assertEqual(job['status'], 'review', job.get('error'))
        d = self.env.store.dir(jid)
        state = review.load(d)
        self.assertEqual(len(state['segs']), TOTAL_LINES // 3)
        lines, doc = review.read_lines(d)
        self.assertEqual(len(lines), TOTAL_LINES // 3)
        self.assertTrue(all(lines))
        self.assertEqual(doc['src'][0], 'source line 0-0 source line 0-1 source line 0-2')
        page = review.payload(d, job['params'])
        self.assertEqual(page['lines'][0]['src'], doc['src'][0])
        self.assertEqual(page['lines'][0]['my'], lines[0])
        self.assertEqual((page['lines'][0]['a'], page['lines'][1]['a']), (0.0, 12.0))   # a piece starts with its first row
        self.assertEqual(page['lines'][0]['b'], 10.5)                                   # ... and ends with its last row
        # continuing makes the voice from the (edited) pieces only
        review.apply_edits(d, {0: 'ပြင်ထားတဲ့ စာ'})
        review.remember(d, review.default_settings(job['params']), done=True)
        self.env.start(jid)
        job = self.env.wait(jid, ('completed', 'failed'))
        self.assertEqual(job['status'], 'completed', job.get('error'))
        self.assertEqual(len(text_requests(self.mock.state)), 1)         # nothing was asked again after the review
        self.assertIn('ပြင်ထားတဲ့ စာ', [c[0] for c in FakeEdge.calls])
        self.assertEqual(sorted(self.whisper.calls), [0, 1, 2])

    def test_a_long_film_is_told_in_parts_after_one_notes_request(self):
        log = []
        self.mock.state.generate = with_story(unique_generate(), log)
        with small_parts(200):
            jid, job = self.run_job(style='story')
        self.assertEqual(job['status'], 'completed', job.get('error'))
        reqs = text_requests(self.mock.state)
        self.assertTrue(is_notes(reqs[0]))                               # the film is read first ...
        story = [r for r in reqs if is_story(r)]
        self.assertGreaterEqual(len(story), 3)
        for r in story:                                                  # ... and every part is told with the notes
            self.assertIn(M.STORY_NOTES[0], system_of(r))
        self.assertIn('BEGINNING', user_of(story[0]))
        self.assertIn('END', user_of(story[-1]))
        self.assertIn('STORY SO FAR', user_of(story[1]))
        self.assertNotIn('STORY SO FAR', user_of(story[0]))
        self.assertEqual(sorted(n for r in story for n in row_numbers(user_of(r))), list(range(TOTAL_LINES)))   # each row once
        self.assertEqual(job['stats']['story_parts'], len(story))
        self.assertEqual(job['stats']['story_notes'], len(M.STORY_NOTES))
        self.assertEqual(job['stats']['spoken'], job['stats']['lines'])

    def test_a_refused_notes_request_only_means_no_notes(self):
        self.mock.state.generate = with_story(unique_generate(), notes=(200, {'promptFeedback': {'blockReason': 'SAFETY'}}))
        with small_parts(200):
            jid, job = self.run_job(style='story')
        self.assertEqual(job['status'], 'completed', job.get('error'))
        for r in text_requests(self.mock.state):
            if is_story(r):
                self.assertNotIn(P.STORY_NOTES_HEADER, system_of(r))
        self.assertEqual(job['stats']['story_notes'], 0)

    def test_a_cut_off_answer_is_continued_with_the_rest_of_the_film(self):
        base = with_story(unique_generate())
        calls = {'n': 0}

        def story(system, user):
            calls['n'] += 1
            rows = M.story_rows(user)
            if calls['n'] == 1:                                          # the first answer stops after row 5
                return [{'from': rows[0][0], 'to': rows[2][0], 'text': M.POOL[2] + ' ၁'}, {'from': rows[3][0], 'to': rows[5][0], 'text': M.POOL[2] + ' ၂'}]
            return M.story_generate(system, user)
        self.mock.state.generate = with_story(unique_generate(), story=story)
        jid, job = self.run_job(style='story')
        self.assertEqual(job['status'], 'completed', job.get('error'))
        story_reqs = [r for r in text_requests(self.mock.state) if is_story(r)]
        self.assertEqual(len(story_reqs), 2)
        self.assertEqual(row_numbers(user_of(story_reqs[1])), list(range(6, TOTAL_LINES)))
        self.assertEqual(job['stats']['lines'], TOTAL_LINES // 3)

    def test_a_credit_problem_pauses_the_job_and_the_new_key_goes_on_with_the_same_story(self):
        base = with_story(unique_generate())

        def gen(system, user, key):
            if is_story_text(system) and key == 'KEY-A':
                return M.e429_prepay()
            return base(system, user)
        self.mock.state.generate = gen
        env = self.env
        jid = env.job(self.video, make_subs=False, style='story')
        env.start(jid)
        job = env.wait(jid, ('paused', 'completed', 'failed'))
        self.assertEqual(job['status'], 'paused', job.get('error'))
        self.assertEqual(job['pause']['kind'], 'quota')
        self.assertNotIn('provider', job['pause'])
        self.assertTrue(env.runner.answer(jid, {'key': 'KEY-B'}))
        job = env.wait(jid, ('completed', 'failed'))
        self.assertEqual(job['status'], 'completed', job.get('error'))
        with_b = [r for r in text_requests(self.mock.state) if r['key'] == 'KEY-B']
        self.assertEqual(len(with_b), 1)
        self.assertEqual(row_numbers(user_of(with_b[0])), list(range(TOTAL_LINES)))
        self.assertEqual(sorted(self.whisper.calls), [0, 1, 2])         # Whisper was not repeated

    def test_a_failed_part_keeps_the_finished_parts_and_resume_asks_only_for_the_rest(self):
        env = self.env
        log = []
        calls = {'n': 0}
        base = with_story(unique_generate(), log)

        def gen(system, user):
            if is_story_text(system):
                calls['n'] += 1
                if calls['n'] == 3:                                      # notes + 2 parts are fine, the 3rd part fails
                    return 400, M.err(400, 'Request contains an invalid argument.', 'INVALID_ARGUMENT')
            return base(system, user)
        self.mock.state.generate = gen
        with small_parts(200):
            jid = env.job(self.video, make_subs=False, style='story')
            env.start(jid)
            job = env.wait(jid, ('failed', 'completed'))
            self.assertEqual(job['status'], 'failed')
            env.wait_idle(jid)
            saved = json.loads((env.store.dir(jid) / 'work' / 'story.json').read_text(encoding='utf-8'))
            self.assertEqual(saved['notes'], M.STORY_NOTES)
            told = saved['items'][-1]['to']
            self.assertGreater(told, 0)
            self.assertLess(told, TOTAL_LINES - 1)
            before = len(text_requests(self.mock.state))
            n_before = len(log)
            self.mock.state.generate = with_story(unique_generate(), log)
            env.start(jid)                                               # resume (what the website's "continue" button does)
            job = env.wait(jid, ('completed', 'failed'))
        self.assertEqual(job['status'], 'completed', job.get('error'))
        after = text_requests(self.mock.state)[before:]
        self.assertFalse(any(is_notes(r) for r in after))                # the film was read only once
        self.assertEqual(min(row_numbers(user_of(after[0]))), told + 1)  # the story goes on after the last finished piece
        self.assertEqual(sorted(n for u in log[n_before:] for n in row_numbers(u)), list(range(told + 1, TOTAL_LINES)))
        self.assertIn('STORY SO FAR', user_of(after[0]))
        self.assertEqual(sorted(self.whisper.calls), [0, 1, 2])

    def test_a_story_that_cannot_be_told_at_all_ends_with_the_pieces_it_could(self):
        self.mock.state.generate = with_story(unique_generate(), story=lambda s, u: 'I am sorry, I cannot help with that.')
        jid, job = self.run_job(style='story')
        self.assertEqual(job['status'], 'failed')                        # every row skipped -> not one line of story
        self.assertIn('Gemini', job['error'])

    def test_pieces_that_are_clearly_too_long_are_shortened_once_before_the_voice(self):
        base = unique_generate()
        long_text = M.POOL[5] * 3

        def story(system, user):
            rows = M.story_rows(user)
            return [{'from': rows[k][0], 'to': rows[min(k + 3, len(rows)) - 1][0], 'text': long_text if k == 3 else M.POOL[2] + ' ' + burmese_digits(k)}
                    for k in range(0, len(rows), 3)]
        self.mock.state.generate = with_story(base, story=story)
        jid, job = self.run_job(style='story')
        self.assertEqual(job['status'], 'completed', job.get('error'))
        reqs = text_requests(self.mock.state)
        shorten = [r for r in reqs if 'timing editor' in system_of(r)]
        self.assertEqual(len(shorten), 1)
        self.assertEqual(job['stats']['fitted'], 1)
        self.assertNotIn(long_text, [c[0] for c in FakeEdge.calls])      # the long text was never spoken

    @unittest.skipUnless(FONT, 'a Burmese font is needed to burn subtitles')
    def test_subtitles_only_shows_one_subtitle_per_piece_of_the_story(self):
        self.mock.state.generate = with_story(unique_generate())
        jid, job = self.run_job(style='story', make_voice=False, make_subs=True)
        self.assertEqual(job['status'], 'completed', job.get('error'))
        self.assertEqual(len(text_requests(self.mock.state)), 1)
        srt = (self.env.store.dir(jid) / 'out' / 'burmese.srt').read_text(encoding='utf-8')
        self.assertEqual(len(re.findall(r'-->', srt)), TOTAL_LINES // 3)


def is_story_text(system):
    return 'charismatic Burmese storyteller' in (system or '')


class StorySigTests(PipelineBase):
    def test_the_story_of_a_different_transcript_is_not_reused(self):
        env = self.env
        jid = env.job(self.video, make_subs=False, style='story')
        run = pipeline.Run(env.svc, jid, mock.Mock())
        run.segs = [{'start': 0.0, 'end': 2.0, 'text': 'one'}, {'start': 3.0, 'end': 5.0, 'text': 'two'}]
        run.lang = 'en'
        a = run.story_sig()
        run.segs[1]['text'] = 'two!'
        self.assertNotEqual(a, run.story_sig())
        run.segs[1]['text'] = 'two'
        run.lang = 'fr'
        self.assertNotEqual(a, run.story_sig())
        run.lang = 'en'
        self.assertEqual(a, run.story_sig())

    def test_a_job_of_v21_started_with_translate_keeps_its_cache_after_the_update(self):
        import hashlib
        env = self.env
        jid = env.job(self.video, make_subs=False, style='translate')                  # what V21.x stored for the line-by-line style
        run = pipeline.Run(env.svc, jid, mock.Mock())
        self.assertEqual(run.style, 'direct')                                         # it is written with the "direct" prompt now
        old = hashlib.sha1(json.dumps(['translate', run.make_voice, 'v21']).encode()).hexdigest()[:12]
        self.assertEqual(run.cache_sig(), old)                                        # ... and the lines saved by V21 are found again
        new_job = pipeline.Run(env.svc, env.job(self.video, make_subs=False, style='direct'), mock.Mock())
        self.assertNotEqual(new_job.cache_sig(), old)

    def test_a_damaged_or_foreign_story_file_is_ignored(self):
        env = self.env
        jid = env.job(self.video, make_subs=False, style='story')
        run = pipeline.Run(env.svc, jid, mock.Mock())
        run.work.mkdir(parents=True, exist_ok=True)
        good = {'sig': 'S', 'notes': ['n'], 'items': [{'from': 0, 'to': 2, 'text': 'a'}, {'from': 3, 'to': 4, 'text': 'b'}]}
        (run.work / 'story.json').write_text(json.dumps(good), encoding='utf-8')
        self.assertEqual(run.load_story('S')['items'], good['items'])
        self.assertEqual(run.load_story('S')['notes'], ['n'])
        self.assertEqual(run.load_story('other')['items'], [])
        for bad in ('not json', json.dumps({'sig': 'S', 'items': [{'from': 3, 'to': 1, 'text': 'x'}]}),
                    json.dumps({'sig': 'S', 'items': [{'from': 0, 'to': 3, 'text': 'x'}, {'from': 2, 'to': 5, 'text': 'y'}]}),
                    json.dumps({'sig': 'S', 'items': ['x']})):
            (run.work / 'story.json').write_text(bad, encoding='utf-8')
            self.assertEqual(run.load_story('S'), {'sig': 'S', 'notes': None, 'items': []})


if __name__ == '__main__':
    unittest.main()
