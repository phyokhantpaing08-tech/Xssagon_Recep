"""V22.1 / V22.2: a job that was working when the server stopped (crash, out of memory, reboot, deploy) goes on by itself after the restart.
Runs the real app module in a child process (the job store is read when the module is imported); skipped without FastAPI."""
import os
import subprocess
import sys
import unittest

try:
    import fastapi  # noqa: F401
except ImportError:
    fastapi = None

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))

CHILD = r'''
import os, sys, tempfile, importlib.util, json
ROOT = sys.argv[1]
sys.path.insert(0, ROOT + '/backend')
tmp = tempfile.mkdtemp()
MODE = sys.argv[2]                                    # 'key' = a Gemini key is set, 'nokey' = none
for k in ('GEMINI_API_KEY', 'GOOGLE_API_KEY', 'GEMINI_MODEL'):
    os.environ.pop(k, None)
os.environ.update({'DATA_DIR': tmp + '/data', 'RECAP_NO_WARMUP': '1'})
if MODE == 'key':
    os.environ['GEMINI_API_KEY'] = 'AIzaTESTKEY123456'
jobs = tmp + '/data/jobs'
def mk(jid, status, provider='gemini', with_input=True):
    d = f'{jobs}/{jid}'; os.makedirs(d, exist_ok=True)
    if with_input: open(d + '/input.mp4', 'wb').write(b'x' * 100)
    json.dump({'id': jid, 'owner': 'local', 'status': status, 'stage': 's', 'progress': 5, 'detail': '', 'error': '', 'params': {'provider': provider}, 'orig_name': 'a.mp4',
               'input': 'input.mp4', 'created': 1, 'updated': 1, 'pause': None, 'wait': None}, open(d + '/job.json', 'w'))
mk('aaaa1111', 'processing'); mk('bbbb2222', 'queued'); mk('cccc3333', 'paused'); mk('dddd4444', 'processing', with_input=False)
mk('eeee5555', 'processing', provider='claude')      # a job of V22.1 that named Claude: Gemini is the only AI now, it goes on with Gemini
mk('ffff6666', 'completed')
spec = importlib.util.spec_from_file_location('appx', ROOT + '/backend/app.py')
app = importlib.util.module_from_spec(spec); sys.modules['appx'] = app; spec.loader.exec_module(app)
started = []
app.start_job = lambda jid: started.append(jid)
app.resume_after_restart()
print('started', sorted(started))
if MODE == 'nokey':
    assert started == [], started                                                                                  # no Gemini key: left for a person
    for jid in ('aaaa1111', 'bbbb2222', 'eeee5555'):
        assert not app.STORE.get(jid).get('auto_resume') and app.STORE.get(jid).get('auto_tries') is None, jid
    print('OK resume_after_restart')
    sys.exit(0)
assert sorted(started) == ['aaaa1111', 'bbbb2222', 'eeee5555'], started
for jid in started:
    j = app.STORE.get(jid); assert j['auto_tries'] == 1 and not j.get('auto_resume'), j
assert not app.STORE.get('dddd4444').get('auto_resume') and app.STORE.get('dddd4444').get('auto_tries') is None   # no video: left for a person
assert app.STORE.get('cccc3333')['status'] == 'interrupted' and 'cccc3333' not in started
app.resume_after_restart()                                                                                         # asking twice does nothing more
assert sorted(started) == ['aaaa1111', 'bbbb2222', 'eeee5555']
about = app.about(); assert about['boot'] and len(about['boot']) == 12, about
print('about', about)
print('OK resume_after_restart')
'''


@unittest.skipUnless(fastapi, 'FastAPI is not installed')
class RestartTests(unittest.TestCase):
    def test_working_jobs_are_continued_by_the_server_itself(self):
        r = subprocess.run([sys.executable, '-c', CHILD, ROOT, 'key'], capture_output=True, text=True, timeout=120)
        self.assertEqual(r.returncode, 0, r.stdout + r.stderr)
        self.assertIn('OK resume_after_restart', r.stdout)

    def test_without_a_gemini_key_nothing_is_started_by_itself(self):
        r = subprocess.run([sys.executable, '-c', CHILD, ROOT, 'nokey'], capture_output=True, text=True, timeout=120)
        self.assertEqual(r.returncode, 0, r.stdout + r.stderr)
        self.assertIn('OK resume_after_restart', r.stdout)


if __name__ == '__main__':
    unittest.main()
