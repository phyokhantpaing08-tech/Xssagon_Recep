This folder is filled by the program while it runs (jobs, the saved Gemini key, Google Drive login, caches).
Do not share it with anybody: it holds your Gemini key and your Drive login. Back it up together with secret.key (if it exists).
ဒီ folder ကို program က run နေတုန်း ဖြည့်ပါတယ် (job၊ သိမ်းထားတဲ့ Gemini key၊ Drive login၊ cache)။ တခြားသူကို မပေးပါနဲ့။ Backup လုပ်ရင် secret.key ရှိရင် ပါထည့်ပါ။
