# Burmese Movie Recap AI V22.3

ဗီဒီယိုထဲက စကားကို Whisper နဲ့ စာဖြစ်အောင်ယူ → Gemini နဲ့ မြန်မာလို ရေး → မြန်မာ AI အသံ / မြန်မာစာတန်းနဲ့ ဗီဒီယိုပြန်ထုတ်ပေးတဲ့ website ပါ။

## V22.3 — "အသံနဲ့ စာမညီဘူး" ပြင် · Whisper model ကောင်းကောင်းရွေး · စကားလုံးအချိန်နဲ့ စာတန်း · တိတ်ဆိတ်တဲ့နေရာမှာ ဖြတ်

> **English summary.** Complaint: *"when Whisper / ffmpeg capture the sound and the subtitles are made, the sound and the text do not match; the video is not captured properly"*. Root causes found in the code: (1) the default Whisper model was `base`, the weakest usable one, and a copy of `.env.example` pinned it (`WHISPER_MODEL=base`), (2) line times were Whisper's loose *segment* times (no word timestamps), and the Burmese voice and the subtitle are placed on them, (3) the audio was cut every 300 s at a fixed time - in the middle of a word, (4) the language was guessed from the first 30 s only, (5) a film with several audio tracks gave whichever track ffmpeg picked. **V22.3:** `WHISPER_MODEL=auto` (GPU -> `large-v3-turbo` float16 beam 5; CPU -> `small` int8 beam 1; explicit names honoured; fallback small -> base -> tiny), word-level timestamps (a line starts at its first word and ends at its last word; stretched words are cut back; `hallucination_silence_threshold`), cuts at the quietest moment within +-20 s of the 300 s mark, language from the first 4 pieces of speech (`WHISPER_LANGUAGE` to force it), `AUDIO_TRACK=N`, and `python backend/asr.py check film.mp4`. Measured with ffmpeg: a fixed cut tears a tone in two and it is heard twice (26 instead of 25); the silence-aware cut gives 25 / 25 within 0.1 ms. **Not measured: the real Whisper (faster-whisper is not installed in my sandbox) - the model choice rests on the published benchmarks, not on a run with your films.** Claude / Groq stay deleted; Paste 1 / Paste 2 prompts, the two styles and every Burmese UI string are untouched.

### ၁။ အကြောင်းရင်း (code ထဲမှာ တွေ့တာ)
| # | ပြဿနာ | ဘာဖြစ်လဲ |
|---|---|---|
| 1 | Whisper model က **`base`** (default) — `.env.example` ကိုကူးထားရင် `WHISPER_MODEL=base` လည်း ပါနေ | base က စကားလုံး မှားကြား၊ စာကြောင်းအချိန်လည်း ဖောက်ပြန်လွယ် |
| 2 | စာကြောင်းအချိန်က Whisper ရဲ့ **segment အချိန်** (စကားလုံးအချိန်မပါ) | စာကြောင်းက စကားမစခင် စက္ကန့်ချီ စောပြီး စ၊ ပြီးတာတောင် ဆက်ကပ်နေတတ်။ မြန်မာအသံနဲ့ စာတန်းက အဲဒီအချိန်မှာ ထည့်တာမို့ တိုက်ရိုက် မညီဖြစ် |
| 3 | အသံကို **၃၀၀ စက္ကန့်တိတိ** ဖြတ် (စကားလုံးအလယ်မှာ ကျနိုင်) | ဖြတ်ချက်ကျတဲ့ စကားလုံးက နှစ်ပိုင်းပြတ် → မှားကြား / ထပ်ကြား / အချိန် ~၁၀၀ ms လွဲ (အောက်မှာ တိုင်းထား) |
| 4 | ဘာသာစကားကို **ပထမ ၃၀ စက္ကန့်** ကနေပဲ ခန့်မှန်း | ဇာတ်ကားအစက ဂီတ / တိတ်ဆိတ်ရင် ဘာသာစကား မှား → ကားတစ်ခုလုံး မှား |
| 5 | audio track အများကြီးပါတဲ့ ကား (dub + မူရင်း) က ffmpeg ရွေးတာကိုပဲ ယူ | ကိုယ်ကြားတဲ့ track မဟုတ်နိုင် |

### ၂။ ဘာတွေ ပြင်ထားလဲ (`backend/asr.py`၊ `media.py`၊ `pipeline.py`၊ `app.py`)
| ပြင်ထားတာ | အသေးစိတ် |
|---|---|
| **Model auto** | `WHISPER_MODEL=auto` (default): **GPU** → `large-v3-turbo` (float16၊ beam 5)၊ **CPU** → `small` (int8၊ beam 1)။ ကိုယ်ကြိုက်တဲ့ နာမည် (`medium`၊ `large-v3` …) ကို `.env` မှာ ထည့်ရင် အဲဒီအတိုင်းသုံး။ ဖွင့်မရရင် `small → base → tiny` ဆက်ကူး၊ log ထဲ ပြောမယ်၊ `base`/`tiny` ဆိုရင် "weak model" သတိပေး။ `/api/health` မှာ `whisper_model` / `whisper_device` ပေါ်။ |
| **စကားလုံးအချိန်** | `word_timestamps=True` — စာကြောင်းတစ်ကြောင်းက **ပထမစကားလုံးမှာ စ၊ နောက်ဆုံးစကားလုံးမှာ ဆုံး**။ တိတ်ဆိတ်တဲ့နေရာကို ဆွဲဆန့်ထားတဲ့ စကားလုံး (> ၁.၆ s) ကို ယုံနိုင်တဲ့ အရှည်ဆီ ပြန်ဖြတ်။ `hallucination_silence_threshold=2` — တိတ်ဆိတ် / ဂီတပေါ်မှာ Whisper တီထွင်တဲ့ စာကြောင်းတွေ ဖယ်။ `WHISPER_WORDS=0` နဲ့ ပိတ်လို့ရ။ |
| **တိတ်ဆိတ်တဲ့နေရာမှာ ဖြတ်** | ၃၀၀ s အနီး ±၂၀ s အတွင်း **အတိတ်ဆိတ်ဆုံး** အချိန် (၂၀ ms စစ်၊ ၃၀၀ ms ညှိ) မှာ sample တစ်ခုအတိ ဖြတ်။ အပိုင်းတွေ ပေါင်းရင် မူရင်းနဲ့ sample တစ်ခုချင်း တူ၊ chunk စချိန် = အရင် chunk တွေရဲ့ အရှည်ပေါင်း။ အဆုံးက ၁၅ s အောက် အပိုင်းကို ရှေ့အပိုင်းနဲ့ ပေါင်း။ numpy မရှိ / 16 kHz mono မဟုတ်ရင် ffmpeg နည်းဟောင်း (အလိုအလျောက်)။ |
| **ဘာသာစကား** | ပထမ **စကားပြော ၄ ပိုင်း** ကနေ ခန့်မှန်း (`language_detection_segments=4`)။ သိရင် `.env` မှာ `WHISPER_LANGUAGE=en` (ko၊ ja၊ th …) ထည့်ရင် ခန့်မှန်းမနေဘဲ အတိအကျသုံး။ |
| **Audio track** | `AUDIO_TRACK=1` (၀ = ပထမ) — track အများကြီးပါတဲ့ ကားအတွက်။ ဘာမှမထည့်ရင် အရင်အတိုင်း။ (`ffprobe film.mp4` နဲ့ track စာရင်းကြည့်)။ မရှိတဲ့ နံပါတ်ထည့်ရင် မြန်မာလို ရှင်းရှင်းပြောမယ်။ |
| **ကိုယ့်ကားမှာ စစ်ကြည့်ဖို့** | `cd backend && ../venv/bin/python asr.py check ~/film.mp4 90` — ပထမ ၉၀ စက္ကန့်မှာ Whisper ကြားတာကို **ပုံရဲ့ အချိန်** နဲ့ ထုတ်ပြ (`[00:12.340 -> 00:15.020] စာသား`)။ ၁ မိနစ်နဲ့ ကိုယ့် server မှာ အချိန်ညီမညီ ကိုယ်တိုင်ကြည့်လို့ရ။ |
| **အဟောင်း version နဲ့ တွဲသုံး** | faster-whisper အဟောင်းက မသိတဲ့ option (`hallucination_silence_threshold`၊ `language_detection_*`) ကို `inspect.signature` နဲ့ စစ်ပြီး **မပို့ဘဲ ကျော်** — error မတက်။ |
| **မပြောင်းတာ** | Paste 1 / Paste 2 prompt၊ စာသားပုံစံ ၂ မျိုး၊ မြန်မာ UI စာသား၊ Gemini လမ်းကြောင်း၊ V22.2 ရဲ့ ffmpeg timing အားလုံး၊ resume (`work/whisper/chunk_NNNN.json`)။ |

### ၃။ Model ကို ဘာကြောင့် ဒါရွေးလဲ (ရှာဖွေတွေ့ရှိချက် — ကျွန်ုပ်မတိုင်းထားဘူး၊ ထုတ်ပြန်ထားတာကို ကိုးကား)
- **faster-whisper** ကို ဆက်သုံး (CTranslate2)။ WhisperX (wav2vec2 နဲ့ <100 ms ညှိ) က torch / CUDA လိုလို့ ၂-၄ vCPU server အတွက် လေးလွန်းတယ် — မယူ။
- faster-whisper README ရဲ့ benchmark: **small, int8, CPU 8 thread, beam 5 → အသံ ၁၃ မိနစ်ကို ၁ မိနစ် ၄၂ စက္ကန့်၊ RAM ၁၄၇၇ MB**။ ဒါကြောင့် CPU မှာ `small` က ကောင်းမွန်မှု / အမြန်နှုန်း အမျှတဆုံး။ (`base` ထက် parameter ~၃.၃ ဆ — 74 M → 244 M — ဖြစ်လို့ ၂ vCPU server မှာ `base` ထက် ပိုနှေးမယ်၊ **အဲဒါကို ကျွန်ုပ် မတိုင်းထားပါ** — `asr.py check` နဲ့ ကိုယ့် server မှာ ကြည့်ပါ။)
- **`large-v3-turbo`** (809 M parameter): decoder ၄ လွှာပဲ ကျန်ပေမဲ့ encoder အပြည့် (၃၂ လွှာ) ရှိလို့ CPU မှာ အရမ်းမမြန်၊ ဒါကြောင့် **GPU ရှိမှသာ** auto ရွေး။ Model card အရ turbo က ရှားပါးတဲ့ (low-resource) ဘာသာစကားတွေမှာ large-v3 ထက် အားနည်းတတ် — မူရင်းကားက အဲဒီလိုဘာသာစကားဆို `medium` / `large-v3` ကို `.env` မှာ တိုက်ရိုက်ထည့်ပါ။
- faster-whisper ≥ 1.1.0 လိုတယ် (`requirements.txt` မှာ ပြီးသား `>=1.1.0`) — turbo၊ language-detection option တွေအတွက်။

### ၄။ တိုင်းပြီး သက်သေပြတာ (ffmpeg အစစ်၊ Whisper အတု)
Test film (`tests/ffmpeg_fixtures.py`: ၂ စက္ကန့်တိုင်း ၁ kHz beep ၀.၂ s) ကို MKV (+၂ s စ)၊ MPEG-TS၊ အသံ ၀.၃ s နောက်ကျ၊ ပုံ ၀.၅ s နောက်ကျ ဆိုပြီး ထုတ် → `extract_audio_wav` → `split_audio` → `transcribe_chunks` (Whisper အစား "beep ကြားရင် စာကြောင်းတစ်ကြောင်း" အတု) → ပုံရဲ့ timeline ပေါ် beep တိုင်း၏ အချိန်ကို တိုင်း။

| တိုင်းတာချက် | V22.2 (ပုံသေ ဖြတ်) | V22.3 (တိတ်ဆိတ်မှာ ဖြတ်) |
|---|---|---|
| Chunk ၁၂.၁ s (beep ၁၂.၀–၁၂.၂ ကြား ကျ) — MKV +၂ s၊ TS | beep **၂၅ ခု ရှိတာကို ၂၆ ခု ကြား** (ပြတ်သွားတဲ့ beep ကို ၂ ခါ) | **၂၅ / ၂၅**၊ အချိန်လွဲ **၀.၀ – ၀.၁ ms** |
| MKV +၂ s၊ TS၊ အသံနောက်ကျ၊ ပုံနောက်ကျ (chunk ၁၂ s) — beep တိုင်း၏ အချိန် | — | beep ၂၅ / ၂၅ / ၂၅ / ၂၄ ခု အကုန်တွေ့၊ အချိန်လွဲ **≤ ၀.၁ ms** (စမ်းသပ်ချက်ရဲ့ ပစ်မှတ် ≤ ၂၀ ms) |
| Chunk ဖြတ်ချက်ရဲ့ တည်နေရာ | — | beep (၀.၂ s) ကြားက တိတ်ဆိတ်ချိန်ထဲမှာပဲ ကျ |
| အပိုင်းတွေ ပေါင်းရင် | — | မူရင်းနဲ့ **sample တစ်ခုချင်း တူ** (`np.array_equal`) |
| Audio track ရွေး (`AUDIO_TRACK`) | — | track ၀ = beep၊ track ၁ = ပုံသေအသံ၊ track ၇ = "matches no streams" error |

`tests/test_asr_timing.py` (**အသစ်၊ ၄၇ ခု**): model ရွေးချယ်မှု (CPU/GPU/ကိုယ်ပိုင်နာမည်/ဖွင့်မရရင် ကူး)၊ စကားလုံးအချိန် (ဆွဲဆန့်ထားတဲ့ ပထမ / နောက်ဆုံး / တစ်လုံးတည်း / မရှိ)၊ option စစ်ထုတ် (အသစ် / အဟောင်း / `**kwargs` model)၊ splitter၊ ဘာသာစကား (force / auto / reuse / resume)၊ ffmpeg အစစ်နဲ့ အထက်က တိုင်းတာမှု၊ `AUDIO_TRACK` ရွေးရင် စာတန်းသက်သက် render / preview မှာလည်း အဲဒီ track ကို ကြားရတာ။

**Test အားလုံး:** `python -m pytest tests -q` → **379 ခု အောင်၊ 51 ခု skip** (V22.2: 332 / 51)။ skip ဖြစ်တာအားလုံးက `fastapi` မရှိတဲ့ ကျွန်ုပ်ရဲ့ sandbox မှာ မပြေးနိုင်တာပါ။

### ၅။ Update လုပ်နည်း (VPS) — ⚠️ `.env` ကိုပါ ပြင်ရမယ်
1. Job မပြေးနေတုန်း (ပြေးနေရင် ပြီးအောင်စောင့်) — `backend/` နဲ့ `frontend/` ကို `/root/burmese-movie-recap-ai-v21` ပေါ် ကူးထည့် (`.env`၊ `data/`၊ `venv/` မထိ) — `deploy/DEPLOY_MY.md` ရဲ့ "Update လုပ်နည်း" မှာ command အပြည့်ပါ။
2. ⚠️ **`.env` ထဲမှာ `WHISPER_MODEL=base` ရှိနေရင် code အသစ်က အဲဒါကို ဆက်လိုက်လိမ့်မယ်** (ကိုယ်ပိုင်တန်ဖိုးကို မထိဘူး)။ ဒါကြောင့်: `sed -i 's/^WHISPER_MODEL=.*/WHISPER_MODEL=auto/; s/^WHISPER_DEVICE=.*/WHISPER_DEVICE=auto/' .env`
3. `sudo systemctl restart recap` → `curl http://<ip>:8000/api/health` မှာ `"version":"V22.3"`၊ `"whisper_model":"small"` ပေါ်ရမယ်။ ပထမကြိမ် `small` model ကို download လုပ်မယ် (≈ ၅၀၀ MB၊ အင်တာနက်လိုတယ်)။
4. ကားတစ်ခုနဲ့ `asr.py check` ပြေးကြည့် (အပေါ် ၂ မှာ ဖော်ပြ)။

### ၆။ ⚠️ မစမ်းနိုင်ခဲ့တာ (သေချာဖတ်ပါ)
- **တကယ့် Whisper မပြေးနိုင်ခဲ့** — sandbox မှာ `faster-whisper` / `ctranslate2` မရှိ၊ pip ပိတ်ထား။ **စာသားမှန်ကန်မှု (WER)၊ တကယ့်စကားလုံးအချိန်၊ ပြေးချိန် (speed)** ကို တစ်ခုမှ မတိုင်းနိုင်ပါ။ အပေါ်က တိုင်းတာမှုအားလုံးက ffmpeg + beep နဲ့ ဖြတ်တာ / အချိန်တွက်တာကိုပဲ သက်သေပြတာပါ။
- **Model ရွေးတာက ထုတ်ပြန်ထားတဲ့ benchmark / model card အပေါ် အခြေခံ** — ကိုယ့်ကားတွေ၊ ကိုယ့် server မှာ မတိုင်းရသေး။ `small` က `base` ထက် ပိုကောင်းလိမ့်မယ်လို့ မျှော်လင့်ပေမဲ့ ၂ vCPU server မှာ ဘယ်လောက်ပိုနှေးလဲ မသိ။ ဘာသာစကားတချို့မှာ `medium` ပိုကောင်းနိုင်။
- **စကားလုံးအချိန်ရဲ့ clamp (၁.၆ s) ကို** Whisper ရဲ့ တကယ့်ထွက်ကို မကြည့်ဘဲ သတ်မှတ်ထား (ပုံမှန်စကားလုံးကို မထိအောင် ကျယ်ကျယ်ထား)။ မကိုက်ရင် `WHISPER_WORDS=0` နဲ့ ပိတ်လို့ရ။
- `fastapi` မရှိတဲ့ sandbox မှာ `fastapi` လိုတဲ့ test (၅၁ ခု) မပြေးနိုင် — `tests/test_app.py` ထဲ version `V22.3` နဲ့ `/api/health` field အသစ်တွေကို VPS မှာ `curl` နဲ့ အတည်ပြုပါ။
- GPU path (`large-v3-turbo` float16) ကို မစမ်းနိုင် — GPU မရှိ။

---

## V22.2 — Claude / Groq ဖျက်ပြီး (Gemini ပဲ) · Gemini စောင့်ပုံ ပြင် · ffmpeg တိကျစွာ ဖြတ်

> **English summary.** (A) **Claude and Groq are deleted completely - Gemini is the only AI.** (This was the owner's instruction in the chat; it overrides the spec's line "do not change the provider-selection logic".) (B) **Gemini waiting / time-outs:** `GEMINI_REWRITE_TIMEOUT` (default 300 s, replaces the fixed 120 s; connect time-out still 15 s), `REWRITE_BATCH` (default 15, was 30), after 2 time-outs / connection failures in a row on one model the client hops to the next model, a request that keeps timing out is split in two halves (every line exactly once), all models cooling down = wait until the earliest cooldown ends and show the model and the time on the page, every AI request is logged, and the job notes show the current model and the retry count. The model chain, the prompts, the 2 styles and the Burmese UI strings are untouched. (C) **ffmpeg cuts at exactly the right position** - measured on generated films with a burned-in frame number and audio beeps: narration starts at the first picture (<= 1 ms, limit 20 ms), no picture lost or repeated, the file ends with the picture, also when the narration is shorter / longer and when the file starts at an offset (MKV, MPEG-TS) or the sound and picture do not start together. Look and quality settings are unchanged.

### ၁။ Claude / Groq ကို ဖျက်ပြီး
- `backend/providers.py`၊ Claude / Groq test နဲ့ အတု server တွေ ဖျက်၊ page ပေါ်က Claude / Groq block၊ "သုံးမယ်" ခလုတ်၊ Gemini အသံ lock တွေ ဖျက်။ **"Gemini API"** card တစ်ခုပဲ ကျန် (key / model / Save / Test / Model စာရင်း / Clear)။
- V22.1 က Claude / Groq အတွက် သိမ်းထားတဲ့ key၊ model၊ "ရွေးထားတဲ့ AI" ကို **server စတက်ချိန်မှာ အလိုအလျောက် ဖျက်** (`app.purge_removed_ai`)။ Gemini key က ကျန်။ အဟောင်း job တွေက Gemini နဲ့ပဲ ဆက်လုပ်။
- ⚠️ ဒီဟာက spec ထဲက "provider ရွေးချယ်မှု logic မပြောင်းနဲ့" ဆိုတာနဲ့ ကွဲလွဲပါတယ် — chat မှာ "Claude API၊ Groq API မသုံးတော့ဘူး ဖျက်လိုက်" လို့ ပြောထားတာကို ဦးစားပေးပါတယ်။ ဒါကြောင့် spec မှာ မပါတဲ့ `frontend/index.html`၊ `auth.py`၊ `app.py`၊ `pipeline.py`၊ `jobs.py`၊ tests၊ docs တွေကိုပါ ပြင်ရပါတယ် (provider ကို ဒီဖိုင်တွေက ရည်ညွှန်းနေလို့ — `grep -i "claude\|groq\|provider"` နဲ့ တွေ့ရတာ)။

### ၂။ Gemini စောင့်ချိန် / timeout (Task 1)
| ပြင်ထားတာ | အသေးစိတ် |
|---|---|
| Timeout | `GEMINI_REWRITE_TIMEOUT` (default **300 s**) က ပုံသေ `timeout=120` ကို အစားထိုး။ ချိတ်ဆက်ချိန် (connect) 15 s မပြောင်း။ |
| Batch | `REWRITE_BATCH` (default **15**) — အရင် ပုံသေ 30။ |
| Model ပြောင်း | model တစ်ခုမှာ **ဆက်တိုက် ၂ ကြိမ်** ချိတ်ဆက်မရ / ကြာလွန်းရင် နောက် model ကို ကူး။ Model အားလုံး ကျမှသာ ရပ် (pause)။ |
| ခွဲပို့ | request တစ်ခု ထပ်ကြာရင် စာကြောင်းတွေကို **နှစ်ပိုင်းခွဲ** ပို့ — ဘယ်စာကြောင်းမှ မပျောက်၊ မထပ် (ဘယ်ဘက်ပိုင်းကို `rewrite.json` ထဲ အရင်သိမ်း)။ ချိတ်ဆက်မရတာ (server ငြင်းတာ) ကို မခွဲ။ |
| 503 | ချက်ချင်း နောက် model ကို ကူးတာ မပြောင်း။ **model အားလုံး cooldown ဖြစ်နေရင်** အစောဆုံး cooldown ပြီးတဲ့အထိ စောင့်ပြီး page ပေါ်မှာ **လက်ရှိ model + ပြန်စမ်းမယ့်အချိန်** ပြ။ |
| ပြီးသားအလုပ် | `rewrite.json` cache၊ ဆက်လုပ်၊ auto-resume (အများဆုံး ၃ ကြိမ်) မပျက်။ ပြန်စမ်း / ခွဲတဲ့ batch က ပြီးသားစာကြောင်းကို ပြန်မရေး။ |
| Log | AI request တိုင်းကို log (`[gemini] request model=… label=… lines=… latency=…s outcome=… retry=…`)၊ job notes မှာ `Gemini model: X (ပြန်စမ်းမှု N)`။ |
| မပြောင်း | model chain (`gemini-3.8-flash → 3.6-flash → 3.5-flash-lite → 3.1-flash-lite`၊ DEFAULT_FALLBACKS ထဲ `2.5-flash`)၊ Paste 1 / Paste 2 prompt၊ စာသားပုံစံ ၂ မျိုး၊ မြန်မာ UI စာသား၊ package အသစ်မရှိ။ Streaming မလုပ် (လိုအပ်မလာလို့)။ |

### ၃။ ffmpeg တိကျစွာ ဖြတ်ခြင်း (Task 2) — တိုင်းပြီး သက်သေပြ
**စမ်းတဲ့နည်း:** ffmpeg နဲ့ test ရုပ်ရှင်ကို ထုတ် (`tests/ffmpeg_fixtures.py`) — ပုံတိုင်းရဲ့ ဘယ်ထောင့်မှာ **frame နံပါတ်ကို barcode** နဲ့ ရိုက်ထား၊ အသံမှာ **၂ စက္ကန့်တစ်ခါ beep**။ ဖိုင် ၆ မျိုး: MP4၊ MKV (၂ s ကနေစ)၊ MKV (၃၆၀၀ s ကနေစ)၊ MPEG-TS (~၁.၄ s ကနေစ)၊ အသံက ပုံထက် ၀.၃ s နောက်ကျ၊ ပုံက အသံထက် ၀.၅ s နောက်ကျ။ ပြီးရင် ထွက်လာတဲ့ ဖိုင်ကို ပြန်ဖတ်တိုင်း (barcode → frame နံပါတ်၊ beep → စက္ကန့်)။

| တိုင်းတာချက် | V22.1 (အရင်) | V22.2 (ယခု) | ပစ်မှတ် |
|---|---|---|---|
| Narration စချိန် — mux (`-c:v copy`) | MKV ၂s: **−21 ms**၊ ပုံနောက်ကျ: **−541 ms** | **≤ 1 ms** (၆ မျိုးလုံး) | ≤ 20 ms |
| Narration စချိန် — render | narration ကို ၀ မှာ ထည့်ပေမယ့် **ပုံက** MKV ၂s မှာ ၂၁ ms၊ ပုံနောက်ကျမှာ ၅၄၁ ms **နောက်ကျ** (ပထမ frame ကို ထပ်ပြီးဖြည့်)၊ ဆုံးမှာ frame ၁–၁၄ ခု ပျောက် (`setpts` မပါတဲ့ render နဲ့ တိုင်းတာ) | **≤ 1 ms** (၆ မျိုးလုံး)၊ ပထမပုံ = ၀.၀၀၀ s | ≤ 20 ms |
| Frame အရေအတွက် (၃၀၀) | `-shortest` ကြောင့် narration တို → **၂၅၀**၊ MKV ၂s → **၂၉၉**၊ ပုံနောက်ကျ → **၂၈၄** | **၃၀၀ / ၃၀၀** အကုန်၊ frame နံပါတ် ၀…၂၉၉ တစ်ခုမကျ၊ မထပ် | ±၁ frame |
| ဖိုင်အရှည် (ပုံ ၁၂.၀၀ s) | narration ၁၀ s → ဖိုင် ၁၀ s (ပုံ ၂ s ပျောက်)၊ ၁၄ s → ၁၁.၉၈၉ s | **ပုံနဲ့ တူတူ** (mux ၁၂.၀၂၂ = AAC priming ၂၁ ms ပါ၊ render ၁၂.၀၀၀)၊ narration တို / ရှည် နှစ်ခုလုံးမှာလည်း | ±၁ frame (၄၀ ms) |
| Whisper ဆီပို့တဲ့ အသံ စချိန် (extract) | MKV / TS: **+22 ms**၊ အသံနောက်ကျ: **၀.၂၇၈ s လွဲ**၊ ပုံနောက်ကျ: **၀.၅၄ s လွဲ** | **≤ 1 ms** | ပုံရဲ့ ပထမ frame |
| Whisper chunk စချိန် | chunk တိုင်း **+၃၂ ms** စုပုံ (၂ နာရီကား, chunk ၂၄ ခု ≈ +၀.၇ s) | စစ်မှန်တဲ့ အရှည်ကို ပေါင်း → **≤ 1 ms** | — |
| `time_stretch` အရှည် | **±၁၆၀ sample (၆.၇ ms)** လွဲ | **အတိအကျ** `round(n / factor)` | — |
| စာတန်း ပေါ် / ပျောက်ချိန် | — | seg အချိန်ကနေ **≤ ၂၀ ms** (frame ၁ ခုအတွင်း) (MP4 / MKV / TS / ပုံနောက်ကျ) | ±၁ frame |
| Thumbnail (key-frame မဟုတ်တဲ့ အချိန်၊ gop ၂၅၀) | `-ss` ကို container စချိန်နဲ့ရေတွက်ပြီး ပုံရဲ့ offset မထည့် → ပုံနောက်ကျဖိုင်မှာ ≈၀.၅၄ s (၁၃ frame) လွဲမယ့်ပုံစံ (offset ဖယ်ကြည့်တဲ့ test ကျတာနဲ့ အတည်ပြု) | ကိုယ်တောင်းတဲ့ အချိန်ရဲ့ **အနီးဆုံး frame (±၁ frame)** | ±၁ frame |
| SRT / VTT | ms အတိ (ဥပမာ `3599.9996 → 01:00:00,000`) | မပြောင်း — စမ်းပြီး အတည်ပြု | ms |

**ဘာကို ဘယ်လို ပြင်ထားလဲ** (`backend/media.py` / `timing.py` / `pipeline.py`):
- `media.probe_timing()` — ffprobe နဲ့ ပထမပုံရဲ့ စချိန်၊ အသံစချိန်၊ container စချိန်၊ **ပုံရဲ့ အရှည်**၊ fps ကို ဖတ်။ `pipeline` က `video_total` ကို container အရှည်အစား **ပုံရဲ့ အရှည်** (`media.picture_duration`) နဲ့ တိုင်း။
- **mux (`-c:v copy`):** `-copyts` + narration ကို `-itsoffset <ပထမပုံစချိန်>` နဲ့ ထည့် + `-avoid_negative_ts make_zero` + `-t <ပုံစချိန် + ပုံအရှည်>`၊ **`-shortest` ဖယ်**။ ရှင်းပြချက်ကို code comment ထဲ ရေး (`mux_narration`)။
- **render:** video filter ရှေ့ဆုံးမှာ `setpts=PTS-STARTPTS` (ပထမပုံ = ၀)၊ မူရင်းအသံ (narration မပါ) ကိုလည်း ပုံနဲ့ အကွာအဝေးမပြောင်းအောင် `atrim` / `asetpts`၊ `-shortest` ဖယ်ပြီး `-t <ပုံအရှည်>`။
- **narration ကို sample တစ်ခုအတိ ဖြတ်/ဖြည့်:** `timing.fit_wav()` (ရှည်ရင်ဖြတ်၊ တိုရင် တိတ်ဆိတ်ဖြည့်၊ အရှည်မှန်ပြီးသားဆိုရင် ဖိုင်မထိ)။ `time_stretch` ကိုလည်း `round(n / factor)` sample အတိ။
- **အသံထုတ် (`media.extract_audio_wav`):** `-itsoffset` + `aresample=async=1:first_pts=0` — WAV ရဲ့ sample ၀ = ပထမပုံ။
- Thumbnail (`render_frame`) — `-ss` ကို ၂ ဆင့် (ကြိုခုန် `-ss` အရင် `-i` + အတိအကျ `-ss` နောက် `-i`)၊ ပုံရဲ့ offset ပေါင်း၊ frame ဝက်စာ စောပြီး အနီးဆုံး frame ကို ယူ။ Review preview copy (`make_preview_copy`) ကိုလည်း တူညီတဲ့ ညှိမှုနဲ့။
- `asr.py` (**spec မှာ မပါတဲ့ ဖိုင်**): Whisper chunk စချိန်ကို `i × ၃၀၀` အစား chunk ဖိုင်တွေရဲ့ အရှည်ပေါင်း (`chunk_starts`) နဲ့ — ffmpeg segment muxer က packet နယ်မှာ ဖြတ်လို့ chunk တစ်ခု ၃၀၀.၀၃၂ s ရှိတာ တိုင်းပြီး သက်သေရှိလို့ ထိရတာပါ။
- **မပြောင်းတာ:** libx264 preset / CRF၊ yuv420p၊ AAC ၁၉၂k / ၄၈kHz / stereo၊ faststart၊ ASS / blur ပုံစံ။ (ဒီ ၂ ဖိုင်က ပုံကို တိုက်ရိုက်မထိပါ။)

**Mutation စစ်ဆေးမှု:** မှန်တဲ့ code ကို တမင် ၁၁ နည်းနဲ့ ပြန်ဖျက်ကြည့် (`-copyts` ဖယ်၊ `setpts` ဖယ်၊ မူရင်းအသံ offset ဖယ်၊ extract offset ဖယ်၊ thumbnail offset ဖယ်၊ probe က container အရှည်ယူ၊ time_stretch မဖြတ်၊ chunk offset ပုံသေ၊ `fit_wav` + `-shortest` ပြန်ထည့်၊ `fit_wav` + `-t` ဖယ် …) — **၁၀ ခုမှာ test တွေ ကျ** (ဖမ်းနိုင်တဲ့ test ဖြစ်ကြောင်း)။ ကျန်တစ်ခု — `-shortest` ကို **တစ်ခုတည်း** ပြန်ထည့်ရင် မကျ၊ ဘာကြောင့်လဲဆိုတော့ `fit_wav` က narration ကို ပုံအရှည်အတိ ဖြည့်ထားလို့ `-shortest` က ဘာမှ မဖြတ်တော့တာပါ (ကာကွယ်မှု ၂ ထပ်)။

### ၄။ Update လုပ်နည်း (VPS)
Job မပြေးနေတုန်း — `backend/` နဲ့ `frontend/` ကို `/root/burmese-movie-recap-ai-v21` ပေါ် ကူးထည့် (`.env`၊ `data/`၊ `venv/` မထိ) → `sudo systemctl restart recap` → `curl http://127.0.0.1:8000/api/health` မှာ `"version":"V22.2"`။ package အသစ်မရှိ။ အသေးစိတ် — [deploy/DEPLOY_MY.md](deploy/DEPLOY_MY.md) ရဲ့ "Update လုပ်နည်း"။

### ၅။ စမ်းသပ်ချက်
`python -m pytest tests -q` → **332 ခု အောင်၊ 51 ခု skip** (skip ဖြစ်တာက `fastapi` မရှိတဲ့ ကျွန်ုပ်ရဲ့ sandbox မှာ မပြေးနိုင်တဲ့ HTTP test တွေ — ကိုယ့် VPS မှာ `fastapi` ရှိရင် အကုန်ပြေး၊ **ပထမဆုံး `python -m pytest tests/test_app.py` ကိုယ်တိုင်ပြေးကြည့်ပါ**)။ V22.1 က 343 ခု အောင် / 49 skip — Claude / Groq test (`test_providers.py`၊ `test_pipeline_providers.py`၊ `mock_llm.py`) ကို ဖျက်လို့ အရေအတွက် ကျပြီး `tests/test_timeouts.py` (၂၂ ခု) နဲ့ `tests/test_ffmpeg_timing.py` (၂၁ ခု) ကို ထည့်ထားပါတယ်။ **မစမ်းနိုင်တာ:** တကယ့် Gemini API ကို မခေါ်နိုင် (အတု HTTP server နဲ့ပဲ)၊ `test_app.py` ထဲ ပြင်ရေးထားတာတွေ (fastapi မရှိလို့) မပြေးနိုင် — `app.py` ကို fastapi အတုနဲ့ ခေါ်စစ်ထား၊ တကယ့် ဗီဒီယိုကြီး (ရှည် / 4K / HEVC / VFR) နဲ့ မစမ်းရသေး — စမ်းထားတာက အသေးစား ရုပ်ရှင်ဖန်တီးထားတာ (၁၀ s၊ 25 fps၊ H.264)။

---

> **V22 (English summary - history: V22.2 removed Claude and Groq, Gemini is the only AI now).** (1) **Three API-key places - Gemini, Claude (Anthropic), Groq.** Keys for all three can be saved at the same time, but exactly **one** is chosen ("သုံးမယ်" radio button on the page) and **only the chosen one is ever called**; the choice is checked on the server and pinned to every job when it starts (resuming a job keeps its AI). (2) **All old writing styles were deleted. Only two remain:** "🔤 တိုက်ရိုက်စာတန်းထိုးဟန်" (direct, line by line - exactly the old translation prompt) and "📖 ဇာတ်လမ်းပြောဟန်" (story). (3) **Story style does not translate line by line:** Whisper runs to the end -> every line is put in time order -> ALL the text is sent to the chosen AI, which is asked to tell it as a story (pieces that cover whole ranges of source rows) -> the pipeline (voice / subtitles / mix / render / review) continues with what the AI returned. Details below. Nothing of V22 was tested with the real Gemini / Claude / Groq services (fake HTTP servers only) - see "⚠️ မစမ်းနိုင်ခဲ့တာတွေ", item 12.
>
> *(Earlier versions, kept for history:)* **English summary of V21.** V21 = V20 + (1) a 503 "high demand" from Gemini is never fatal any more (retry with back-off, automatic fallback models, then the job *pauses* instead of failing); (2) a **free** "Test API" (it never generates text); (3) when the Gemini credit ends the job pauses, you paste a **new key** and it continues where it stopped (or you press Cancel); (4) one uniform speaking speed and Gemini *condenses* the Burmese text to the time that is available (nothing is cut off, nothing is sped up line by line); (5) one Nilar, one Thiha + more character voices (experimental Edge multilingual voices, 30 Gemini voices); (6) faster processing (Whisper used one CPU core in V20). There is **no Google sign-in** (it was removed on request): like V20 you open `http://<server-ip>:<port>`; keep strangers out with the AWS security group (port 8000 -> "My IP") and/or the optional `APP_PASSWORD`. Everything was tested with a *fake* Gemini server, not with the real services - see the section "⚠️ မစမ်းနိုင်ခဲ့တာတွေ".
>
> **V21.1** adds an optional **review stage** (tick box "စာကို အရင်ပြင်မယ်", on by default): after the Burmese text is written the job *waits* (no CPU, no Gemini, no voice; it survives a server restart) while you read the video with the subtitle on top, edit any line, and set the look of the subtitles (size, distance from the bottom, colour, background box, timing offset) and of the blur band (position, height, strength, darkness, auto-detect of the burned-in original text). One button then continues: for voice jobs "make the voice from the **edited** text" (the voice is made only after you press it), for subtitle-only jobs "make the video". Untick the box and the job runs straight through exactly like V21. Not built (and why): see the last bullet of the new section below.
>
> **V21.2** adds a small **time bar** beside the text box of every line on the review page: move that one line earlier / later (up to 5 s; the − / + buttons move it by 0.1 s; ↺ puts it back). For subtitle-only jobs the subtitle then shows at the new time; for voice jobs the Burmese voice starts there and the subtitle follows the voice. A line cannot pass its neighbours (0.1 s apart) and the last line stays inside the video; the page and the server use the very same rule. The original Whisper times are never changed, so ↺ always brings them back. A job in which nothing is moved behaves exactly like V21.1.
>
> **V21.3** adds a new text style **"🗣️ စကားပြော (Dub)"** (offered first on the page and selected by default) for the complaint "the Burmese sounds like a direct translation". It was designed after studying two Burmese TikTok recap videos: one continuous script instead of translated fragments, the characters speak in their own words (နင် / မင်း / ငါ / သမီး / မေမေ ...), short sentences, a fast steady pace. Changes: (1) the writing prompt of the new style (continuous script, direct speech for the characters, narration only where needed, spoken endings, the same spelling for a name every time); (2) **the whole film is read first** - the rewrite waits until Whisper has finished, then ONE extra Gemini request reads the whole transcript and returns story notes (story, tone, characters with their Burmese spellings, forms of address) that are added to every batch, and every batch also sees the next 4 source lines and the last 6 written lines; (3) the "extremely short" rule is dropped for this style (the per-line `max_syllables` time limit stays); (4) the speed slider now reaches **+60 %** (a 19-second sample of one reference video was about 1.7 times faster than the app's default pace; the page offers a one-click "+30 %"). The seven older styles, the API default (`recap`) and everything else behave exactly as in V21.2 (a test compares their prompts with the V21.2 ones). **Not tested with the real Gemini** (blocked in the sandbox): whether the Dub text really sounds natural must be judged by listening to a 1-2 minute clip. One small fix besides: on a phone the page could be dragged sideways for about 2 seconds while the "RECAP" watermark slid in.

---


## V22.1 — ပြင်ထားတာ (blur box / prompt ၂ ခု / Groq / Claude key / server ချိတ်ဆက်မှု / background) *(Claude / Groq ကို V22.2 မှာ ဖျက်ပြီး — သမိုင်းအနေနဲ့ပဲ ကျန်)*

> **English summary.** (1) **Blur box:** the subtitle size now follows the HEIGHT of the blur box (before, it stayed at 5.5 % of the picture, so a big box held tiny text with empty space above and below); a long subtitle is shrunk only until its lines just fit. (2) **Prompts:** the two prompts written by the owner ("Paste 1" = expert subtitle translator, "Paste 2" = charismatic storyteller) are used word for word for **every** AI (Gemini, Claude, Groq). (3) **Groq:** default model `qwen/qwen3.8-27b`, JSON mode forced (the array is wrapped in `{"result": [...]}` and unwrapped again), temperature 0.7 / top_p 0.8, `reasoning_effort` tried as none -> low -> default. (4) **Claude:** the app no longer looks at the first letters of the key (`sk-ant-`, `sk-ai-v1-`, ...): the key is sent as `Authorization: Bearer` and `x-api-key`, and the API decides. (5) **Server connection:** requests have time limits, the page retries by itself, uploads that fail before anything arrived are retried 3 times, the error says whether the server restarted / is down / only the upload broke, and uvicorn keeps idle connections 75 s instead of 5 s. (6) **Background:** jobs always ran on the server (closing the browser never stopped them); now a job that was working when the server stopped (crash, out of memory, reboot) is **continued by the server itself** after the restart (up to 3 times), and the page reconnects without hanging on "loading".

| | |
|---|---|
| **Blur box ကြီးပြီး စာသေးနေတာ** | စာအရွယ်ကို blur box ရဲ့ **အမြင့်** နဲ့ လိုက်အောင် ပြောင်းထားပါတယ် (အရင်က video ရဲ့ 5.5 % ပုံသေမို့ box ကြီးရင် စာသေးသေးလေး၊ အပေါ်အောက် အလွတ်တွေ ကျန်တာ)။ စာတစ်ကြောင်းတည်းဆို box အမြင့်ရဲ့ ၂/၃ ခန့်၊ ကြောင်းများလာရင် ကြောင်းအားလုံး box ထဲ **ကွက်တိဝင်တဲ့ အကြီးဆုံး** အရွယ်အထိပဲ ချုံ့ပါတယ်။ အရင်ရှိတဲ့ အပေါ်အောက် ၂၀ % + ၄ % ကျန်ခွင့်ကို ဖြုတ်ပြီး libass က စာကြောင်းတစ်ကြောင်းကို font size အတိအကျ နေရာယူတာ (Padauk နဲ့ တိုင်းထား) ကို သုံးထားပါတယ်။ ဘောင် (background box) ကို ✔ ထားရင် ဘောင်ရဲ့ padding ကိုပါ ထည့်တွက်ပါတယ်။ Review page ရဲ့ preview နဲ့ ထွက်လာတဲ့ video တူအောင် Python / JS နှစ်ခုလုံး တူညီတဲ့ တွက်နည်း (၁၉၂ ချက်နဲ့ တိုက်စစ်ထား၊ ကွာတာ ၀)။ "စာအရွယ်" slider ကတော့ ဆက်ရှိ — 100 % = ပုံမှန်၊ လျှော့ချင်ရင် လျှော့၊ တစ်ကြောင်းတည်း စာတိုတွေကို ပိုကြီးချင်ရင် တိုး။ |
| **Prompt ၂ ခု** | **Paste 1** ("expert Burmese film subtitle translator") ကို **🔤 တိုက်ရိုက်စာတန်းထိုးဟန်** မှာ၊ **Paste 2** ("charismatic Burmese storyteller") ကို **📖 ဇာတ်လမ်းပြောဟန်** မှာ **စာလုံးမပြောင်းဘဲ** ထည့်ထားပါတယ် (`backend/presets.py` ထဲ `TRANSLATE_PROMPT` / `STORY_PROMPT`)။ **Gemini / Claude / Groq သုံးခုလုံး တူညီတဲ့ စာသားကိုပဲ** ပို့ပါတယ်။ အပိုထည့်တာက output ပုံစံ (JSON array) နဲ့ အချိန်ကန့်သတ်ချက်ပဲ — Paste 1 ရဲ့ "OUTPUT FORMAT" ကို JSON စည်းမျဉ်းက အစားထိုး (app က စာကြောင်းများများ တစ်ခါတည်းပို့ပြီး JSON array နဲ့ ပြန်ဖတ်လို့)၊ Paste 2 ရဲ့ "TIMING block" ကို စာတစ်ပိုင်းချင်းစီ ကိုယ့်အချိန်အတိုင်းကို နှုန်း (syllable/စက္ကန့်) အတိုင်း **ဖြည့်ပြီး မကျော်ရ** ဆိုတဲ့ စည်းမျဉ်း၊ စာအလွတ် (empty text) လုံးဝ မခွင့်ပြုတော့ပါ။ |
| **Groq** | Default model **`qwen/qwen3.8-27b`** (အရန် `openai/gpt-oss-120b`၊ `llama-3.3-70b-versatile`)။ **JSON mode အတင်းကြပ်** (`response_format: json_object` — JSON mode က object ပဲ ပြန်လို့ array ကို `{"result":[…]}` ထဲထည့်ခိုင်းပြီး app က ပြန်ထုတ်ယူ)၊ **temperature 0.7 / top_p 0.8** ပုံသေ (`GROQ_TEMPERATURE` / `GROQ_TOP_P` နဲ့ ပြောင်းလို့ရ)၊ `reasoning_effort` ကို `none` → `low` → မထည့် ဆိုပြီး model က လက်ခံတာကိုရှာပြီး မှတ်ထား၊ JSON mode မရတဲ့ model ဆိုရင် ရိုးရိုး request နဲ့ ပြန်စမ်း။ |
| **Claude key** | Key ရဲ့ စာလုံးအစ (`sk-ant-`၊ `sk-ai-v1-`၊ နောက်ထပ် ဘာပဲဖြစ်ဖြစ်) ကို app က **လုံးဝ မစစ်တော့ပါ**။ Key ကို `Authorization: Bearer` နဲ့ `x-api-key` နှစ်နည်းလုံးနဲ့ ပို့ပြီး API ကပဲ ဆုံးဖြတ်ပါတယ်။ "Test" ကို model စာရင်းကနေ စစ်ပြီး မရရင် (gateway တချို့မှာ မရှိတတ်လို့) token ၈ ခုပဲသုံးတဲ့ တကယ့် request သေးသေးလေးနဲ့ စစ်ပါတယ်။ ပယ်ချခံရရင် (401/403) ဒုတိယ request မပို့ပါ။ Gateway key ဆိုရင် `.env` မှာ `CLAUDE_BASE_URL`၊ workspace မချထားတဲ့ key ဆိုရင် `ANTHROPIC_WORKSPACE_ID` လိုနိုင်ပါတယ်။ |
| **"Server ချိတ်ဆက်မရ"** | တကယ့်အကြောင်းရင်းကို ကျွန်ုပ်ရဲ့ sandbox မှာ **ပြန်မဖြစ်စေနိုင်ခဲ့ပါ** (အောက်က ⚠️ ကြည့်ပါ)။ အဖြစ်နိုင်ဆုံး အကြောင်းရင်း ၂ ခုကို ပြင်ထားပါတယ်: (က) uvicorn က idle connection ကို ၅ စက္ကန့်နဲ့ ပိတ်ပြီး page ရဲ့ ၅ စက္ကန့် polling နဲ့ တိုက်မိရင် upload စတာနဲ့ ပြတ်နိုင် → ၇၅ စက္ကန့် (`KEEP_ALIVE_SECONDS`)၊ (ခ) server ကို OOM / crash နဲ့ systemd က ပြန်စတာ။ Page ဘက်: request တိုင်းမှာ အချိန်ကန့်သတ်၊ upload မစခင် server စစ်၊ ဘာမှ မရောက်သေးခင် ပြတ်ရင် ကိုယ့်ဟာကိုယ် ၃ ကြိမ်ထိ ပြန်စမ်း၊ ပြီးတဲ့ job ရဲ့ video ကို နောက် job စတာနဲ့ ရပ်ပစ် (connection မကိုင်ထားအောင်)၊ ဆက်မရရင် **server ပြန်စသွားလို့လား / server ပိတ်နေလို့လား / upload ပဲ ပြတ်တာလား** ကို ခွဲပြောပါတယ်။ |
| **Browser ပိတ်လည်း background မှာ ဆက်လုပ်** | Job တွေက **server ပေါ်က thread** မှာ run တာမို့ browser ပိတ်လည်း **ဘယ်တုန်းကမှ မရပ်ပါ** (upload ပြီးသွားတဲ့ job ဆိုရင်)။ ဒီ version မှာ ထပ်ထည့်တာ: (၁) **Server ပြန်စသွားရင်တောင်** (crash / memory ကုန် / reboot / deploy) အလုပ်လုပ်နေတဲ့ job ကို server က **သူ့ဟာသူ ဆက်လုပ်** (လုပ်ပြီးသားအပိုင်းတွေကနေ၊ အများဆုံး ၃ ကြိမ် — server ကို ထပ်ထပ်ရပ်စေတဲ့ job ကို လက်လျှော့)၊ key မရှိ / video ပျက်နေရင်တော့ လူကို စောင့်၊ (၂) Page ပြန်ဖွင့်ရင် **loading မှာ မတန့်ဘဲ** server မရရင် ကိုယ့်ဟာကိုယ် ပြန်ချိတ်၊ ချိတ်မိရင် လုပ်နေတဲ့ job ကို ပြန်ပြ။ **Upload ကိုတော့ background မှာ မလုပ်နိုင်ပါ** — Video ဖိုင်က ကိုယ့်ကွန်ပျူတာကနေ server ကို ရောက်ပြီးမှ ဒီအလုပ်တွေ စတာမို့ upload ပြီးတဲ့အထိ page ကို မပိတ်ပါနဲ့ (တင်နေစဉ် ပိတ်ဖို့ ကြိုးစားရင် browser က သတိပေးပါမယ်)။ |

---

## V22 — API ၃ နေရာ (Gemini / Claude / Groq) + စာသားပုံစံ ၂ မျိုးပဲ + ဇာတ်လမ်းပြောဟန် (စာအားလုံးကို API ဆီ တစ်ခါတည်းပို့) *(API ၃ နေရာအပိုင်းကို V22.2 မှာ ဖျက်ပြီး Gemini ပဲ ကျန် — သမိုင်းအနေနဲ့ပဲ ဖတ်ပါ)*

### ၁။ API ၃ နေရာ — ရွေးထားတဲ့ တစ်ခုပဲ အလုပ်လုပ်မယ်

| | |
|---|---|
| Page ပေါ်မှာ | **"AI API"** card ထဲမှာ **Gemini**၊ **Claude**၊ **Groq** ဆိုပြီး block ၃ ခု။ တစ်ခုချင်းစီမှာ key ကွက်၊ model ကွက်၊ **Save**၊ **Test (အလကား)**၊ **Model စာရင်း**၊ **Clear**။ key ၃ ခုလုံး ထည့်ထားလို့ရပါတယ်။ |
| ဘယ်ဟာ အလုပ်လုပ်မလဲ | block တစ်ခုချင်းစီရဲ့ **"သုံးမယ်" ○ ခလုတ်** (radio) နဲ့ ရွေးထားတဲ့ **တစ်ခုတည်း**။ ကျန်တဲ့ နှစ်ခုကို request တစ်ခုမှ မပို့ပါ။ key မရှိတဲ့ AI ကို ရွေးလို့မရ ("key အရင်ထည့်ပါ" လို့ ပြ)။ |
| Server ဘက်က အတည်ပြု | ရွေးထားတာကို server မှာ သိမ်း (`data/` ထဲ user ဖိုင်၊ `provider` field) ပြီး **Start လုပ်တဲ့အချိန်မှာ job တစ်ခုချင်းစီထဲ ပုံသေထည့်** (`params.provider`) ထားပါတယ်။ Job ကို **ဆက်လုပ်** (resume) ရင်လည်း အဲဒီ job ရဲ့ AI ကိုပဲ သုံးပါတယ် — ကြားထဲ ရွေးချယ်မှု ပြောင်းထားလည်း မရောပါ။ Page ကို ကျော်ပြီး တခြား provider နာမည် ပို့လာရင်လည်း server က ငြင်း / ရွေးထားတာကိုပဲ သုံး။ |
| Key အသစ်လိုတဲ့အခါ | Credit / quota ကုန်၊ key မှား၊ AI ကျပ်နေ → job က **ရပ်ထား** ပြီး panel ပေါ်ပါတယ် (**ရပ်နေတဲ့ AI ရဲ့ နာမည်နဲ့**) — key အသစ်ထည့် / model ပြောင်းပြီး ဆက်လုပ်၊ ဒါမှမဟုတ် Cancel။ လုပ်ပြီးသားအပိုင်းတွေ မပျက်ပါ။ |
| အသံ | **Gemini အသံ ၃၀** (Gemini TTS) က **Gemini ကို ရွေးထားမှ** သုံးလို့ရ (Claude / Groq က အသံ မထုတ်နိုင်လို့)။ တခြားကို ရွေးထားရင် အဲဒီအသံတွေ မီးမှိန်ပြီး နှိပ်လို့မရ၊ server ကလည်း ငြင်းပါတယ်။ **Edge အသံ (နီလာ / သီဟ / …) က AI ဘယ်ဟာရွေးရွေး သုံးလို့ရ။** |
| Model default | Gemini `gemini-flash-latest`၊ Claude `claude-sonnet-5-5` (အရန် `claude-haiku-5-5`)၊ Groq `qwen/qwen3.8-27b` (အရန် `openai/gpt-oss-120b`၊ `llama-3.3-70b-versatile`)။ Page မှာ ပြောင်းလို့ရ၊ `.env` နဲ့လည်း ရ။ |
| ရှိပြီးသား လုပ်ဆောင်ချက်တွေ | 503 / 429 / quota ကို ခွဲခြား၊ တိုးလာတဲ့ စောင့်ချိန်နဲ့ ပြန်စမ်း၊ အရန် model၊ "ရပ်ထားပြီး key အသစ်စောင့်" — Gemini အတွက် V21 မှာ ရေးထားတဲ့ စနစ်တစ်ခုတည်းကို Claude / Groq အတွက်လည်း **အတူသုံး** ထားပါတယ် (Claude ရဲ့ "credit balance is too low"၊ Groq ရဲ့ "try again in 14m24s" စတဲ့ စာသားတွေကိုလည်း ခွဲခြားပါတယ်)။ |

**Key ယူရာ:** Gemini — [Google AI Studio](https://aistudio.google.com/apikey) · Claude — [Anthropic Console](https://platform.claude.com/settings/keys) · Groq — [GroqCloud](https://console.groq.com/keys)။

### ၂။ စာသားပုံစံ — ၂ မျိုးပဲ ကျန်

အရင်ပုံစံအားလုံး (Dub၊ ရုပ်ရှင် Recap၊ ပုံပြင်ပြောသလို၊ ဘာသာပြန်၊ စိတ်လှုပ်ရှားဖွယ်၊ ခံစားမှုနက်နက်၊ ဟာသ၊ သူငယ်ချင်းကို ပြောသလို) ကို **ဖျက်ပြီးပါပြီ** (`backend/presets.py` ကို ပြန်ရေး)။ အခု:

| ပုံစံ | ဘာလုပ်လဲ |
|---|---|
| **🔤 တိုက်ရိုက်စာတန်းထိုးဟန်** (`direct`၊ default) | စာကြောင်းတစ်ကြောင်းကို မြန်မာစာတစ်ကြောင်း (၁:၁) သဘာဝကျကျ ဘာသာပြန်။ Prompt က V21.3 ရဲ့ "ဘာသာပြန်" prompt နဲ့ **အက္ခရာတစ်လုံးမကွာ** တူပါတယ် (test က hash နဲ့ စစ်ထား)။ |
| **📖 ဇာတ်လမ်းပြောဟန်** (`story`) | အောက်က "ဇာတ်လမ်းပြောဟန် အလုပ်လုပ်ပုံ"။ |

အရင်ပုံစံနာမည် (`recap`၊ `dub` …) ကို API က လက်ခံမလား — **မလက်ခံပါ**: `POST /api/jobs` မှာ မသိတဲ့ style ကို 400 (`Unsupported style`) နဲ့ ငြင်းပါတယ်။ Browser မှာ သိမ်းထားတဲ့ အရင်ပုံစံက အလိုအလျောက် `direct` ပြန်ဖြစ်ပါတယ်။

### ၃။ ဇာတ်လမ်းပြောဟန် — အလုပ်လုပ်ပုံ

1. **စာတွေ အရင်ဆွဲထုတ်** — Whisper ကို ဗီဒီယိုအဆုံးထိ ပြီးအောင်စောင့်။
2. **အချိန်အလိုက်စီ** — စာကြောင်းတိုင်းကို `နံပါတ် | စ-ဆုံး (စက္ကန့်) | စာ` ပုံစံနဲ့ အချိန်အတိုင်း စီ။
3. **စာအားလုံးကို API ဆီ ပို့** — ဘာသာပြန်ခိုင်းတာ မဟုတ်ဘဲ "ဇာတ်လမ်းပြောပြနေသလို ရေးပါ" (`build_story_prompt`) လို့ ခိုင်းတယ်။ AI က **JSON array** `[{"from":၁,"to":၇,"text":"…"}, …]` ပြန်တယ် — စာတစ်ပိုင်းချင်းက မူရင်းစာကြောင်း **အပိုင်းအစ (from..to)** တစ်ခုကို ဖုံးတယ်၊ စာကြောင်းအားလုံးကို ဖုံးရမယ်၊ မထပ်ရ၊ မကျန်ရ။ မူရင်းမှာ မပါတာ ဖန်တီးထည့်ခွင့်မရှိ။
4. **ပြန်ရလာတာကို ပြန်စစ်** — ကျန်နေတဲ့ စာကြောင်း၊ ထပ်နေတာ၊ နံပါတ်မှား (၃ ကြောင်းအထိ ကွာတာကို ကပ်ပေါင်း)၊ အဆုံးမရောက်ရင် ကျန်တာကို ထပ်မေး၊ မှားရင် တင်းကျပ်တဲ့ စည်းမျဉ်းနဲ့ တစ်ခါထပ်၊ ပြီးရင် တစ်ဝက်ခွဲ၊ နောက်ဆုံး တစ်ကြောင်းတည်းအဖြစ် ကျော်။ ဖြတ်ပြီးပြန် (token limit) လာရင် ပြည့်စုံတဲ့ အပိုင်းထိ သိမ်းပြီး ကျန်တာကို ထပ်မေးတယ်။
5. **အချိန်** — မြန်မာစာအပိုင်းတစ်ခုချင်းက သူဖုံးတဲ့ မူရင်းစာကြောင်းတွေရဲ့ **စချိန် (ပထမကြောင်း) → ဆုံးချိန် (နောက်ဆုံးကြောင်း)** ကို ယူတယ်။ အသံပြောင်းမယ်ဆိုရင် အပိုင်းတစ်ခုရဲ့ ဖတ်ချိန် (ပုံမှန် ≤ ၁၅ စက္ကန့်၊ စာတန်းပဲဆိုရင် ≤ ၈ စက္ကန့်) ကို prompt ထဲ syllable အရေအတွက်နဲ့ ပြောထား၊ ရှည်လွန်းတာကို တစ်ခါတည်း request တစ်ခုနဲ့ ချုံ့ခိုင်း (`fit_story`)။
6. **ကျန်တာ ဆက်** — အသံထုတ် → လိုရင်ချုံ့ → အချိန်ဇယားချ → mix → (စာတန်း / blur) render → **review page** (အပိုင်းတစ်ခုချင်းစီရဲ့ မူရင်းစာ ပါလာ၊ စာပြင်လို့ရ၊ အချိန်ရွှေ့လို့ရ)။ ဒါတွေက V21.x နဲ့ အတူတူပါပဲ။

**စာ အရမ်းရှည်ရင်:** API တစ်ခုချင်းစီရဲ့ တစ်ခါပို့လို့ရတဲ့ ပမာဏအလိုက် **ခွဲပို့** ပါတယ် (Gemini ≈ စာလုံး ၁၅၀,၀၀၀ ၊ Claude ≈ ၃၀,၀၀၀ ၊ Groq အခမဲ့ ≈ ၅,၀၀၀ — `.env` မှာ ပြင်လို့ရ)။ တစ်ခုထက်ပိုခွဲရရင် ဇာတ်လမ်းတစ်ခုလုံးကို အရင်ဖတ်တဲ့ **မှတ်စု request ၁ ခု** (ဇာတ်ကောင်နာမည်၊ ခေါ်ပုံ၊ လေသံ) ကို ထပ်ပို့ပြီး အပိုင်းတိုင်းမှာ ထည့်ပေး၊ အပိုင်းတစ်ခုနဲ့ တစ်ခုကြား ရှေ့ ၄ ကြောင်း context ပါ။ **Groq အခမဲ့** key က limit သေးလို့ ရုပ်ရှင်တစ်ကား = request အများကြီး ဖြစ်ပြီး ကြာနိုင်ပါတယ်၊ Gemini က အများအားဖြင့် တစ်ခါတည်း။ ရလဒ်ကို `work/story.json` မှာ သိမ်းထားလို့ job ကို ဆက်လုပ်ရင် ပြီးသားအပိုင်းကို ပြန်မမေးပါ။

**မြန်မာစာအပိုင်း အရေအတွက်က မူရင်းစာကြောင်းနဲ့ မတူပါ** — ဒါက ရည်ရွယ်ချက်ပါ။ Result အနှစ်ချုပ်မှာ "ဇာတ်လမ်းပြောပြတဲ့ အပိုင်း N ပိုင်း (မူရင်း စာကြောင်း M ကြောင်းကနေ)" လို့ ပြပါတယ်။

### ၄။ ဘယ်လို စမ်းမလဲ

1. Page ကို **Ctrl + F5** နဲ့ ပြန်ဖွင့်။ "AI API" card မှာ ကိုယ်သုံးမယ့် AI ရဲ့ key ထည့် → **Save** → **Test (အလကား)** ✅ → အဲဒီ block ရဲ့ **"သုံးမယ်"** ကို ရွေး။
2. ဗီဒီယို **၁–၂ မိနစ်** အတို တစ်ခု၊ ပုံစံ = **📖 ဇာတ်လမ်းပြောဟန်**၊ "✍️ စာကို အရင်ပြင်မယ်" ✔။
3. Review page မှာ မြန်မာစာကို **အသံမထုတ်ခင်** ဖတ်ကြည့် — ဇာတ်လမ်းပြောသလို ဆက်စပ်လား၊ နာမည် စာလုံးပေါင်း တစ်သမတ်တည်းလား၊ မူရင်းမှာ မပါတာ ထပ်ထည့်ထားသလား။
4. နှိုင်းယှဉ်ချင်ရင် အတူတူ ဗီဒီယိုကို **🔤 တိုက်ရိုက်စာတန်းထိုးဟန်** နဲ့ ထပ်လုပ်ကြည့်ပါ။ AI တခြားတစ်ခုနဲ့ စမ်းချင်ရင် radio ပြောင်းပြီး ထပ်လုပ်။

**စာသားကို ကိုယ်စိတ်ကြိုက် ညှိချင်ရင်:** `backend/presets.py` ထဲက `STORY_PROMPT` (ဇာတ်လမ်းပြောဟန်)၊ `TRANSLATE_PROMPT` (တိုက်ရိုက်ဟန်) ကို ပြင်ပြီး `sudo systemctl restart recap`။

### ၅။ `.env` (အကုန် မလိုအပ်ပါ — `.env.example` ကြည့်ပါ)

V22.2: `GEMINI_API_KEY`၊ `GEMINI_MODEL`၊ `GEMINI_FALLBACK_MODELS`၊ `GEMINI_MIN_INTERVAL`၊ `GEMINI_COOLDOWN`၊ `GEMINI_OVERLOAD_PATIENCE`၊ **`GEMINI_REWRITE_TIMEOUT`** (default 300)၊ **`REWRITE_BATCH`** (default 15)၊ `GEMINI_STORY_CHARS` / `GEMINI_STORY_TOKENS` / `GEMINI_STORY_TIMEOUT`၊ `GEMINI_PROXY`။ (V22.1 က `AI_PROVIDER`၊ `CLAUDE_*`၊ `GROQ_*`၊ `LLM_PROXY` တွေ ဖျက်ပြီး — `.env` ထဲ ကျန်နေလည်း ဘာမှမဖြစ်၊ ဆက်ဖတ်တော့မယ်မဟုတ်ပါ။)

### ၆။ ပြင်ထားတာ / သိထားရမယ့်အချက်

- **စမ်းသပ်ချက်တစ်ခု ပျက်တတ်တာ ပြင်ထား:** `test_hard_failure_keeps_the_work_and_resume_continues` က အရင် V21.3 code မှာတောင် ၁၀ ခါမှာ ၂ ခါလောက် ပျက်တတ်တာ (ပျက်သွားတဲ့အချိန် ပြီးဆဲ အသံ clip တစ်ခုက ထပ်ထွက်တာ) တွေ့လို့ မျှော်လင့်ချက်ကို "ထပ်တာ ≤ ၄" လို့ ပြင်ထားတာပါ — app ကို မထိပါ။
- `GEMINI_MIN_INTERVAL` — free key က တစ်မိနစ် limit ကို ခဏခဏ ထိရင် `12` ထားပါ။
- ပထမ version တွေက Gemini key ကို `gemini_key_enc` နဲ့ သိမ်းခဲ့တာကို V22.2 က **အဟောင်းအတိုင်း ဆက်ဖတ်** ပါတယ် (key ပြန်ထည့်စရာ မလို)။ V22.1 က Claude / Groq အတွက် သိမ်းထားတာတွေ (key၊ model၊ "ရွေးထားတဲ့ AI") ကို server စတက်ချိန်မှာ **ဖျက်** ပါတယ်။ အဟောင်း job တွေက Gemini နဲ့ပဲ ဆက်လုပ်ပါတယ်။

---

## V21 မှာ ဘာတွေ ပြောင်းလဲ

| # | သင်တောင်းဆိုခဲ့တာ | V21 မှာ |
|---|---|---|
| 1 | `Gemini API 503 … high demand` နဲ့ ရပ်သွားတာ | 503 / 500 / 502 / 504 / timeout တွေကို **ဘယ်တော့မှ job ကို မပျက်စေပါဘူး**။ တိုးလာတဲ့ စောင့်ချိန် (၂ → ၆၀ စက္ကန့်) နဲ့ ပြန်စမ်း၊ ပြီးတော့ **အရန် model** တွေ (`gemini-3.6-flash` …) ကို အလိုအလျောက် ပြောင်းစမ်း။ ၁၀ မိနစ်ကြာတဲ့အထိ မရသေးရင် job က **ရပ်ထား (pause)** ပြီး "ဆက်လုပ်မယ်" ခလုတ် ပြပါတယ် — လုပ်ပြီးသားတွေ မပျက်ပါဘူး။ ဘယ် model ကျပ်နေလဲ၊ ဘယ်နှစ်စက္ကန့်နောက် ပြန်စမ်းမလဲ ဆိုတာ page မှာ ရေတွက်ပြပါတယ်။ |
| 2 | "Test API" က credit ဖြုန်းသလို ခံစားရတာ | **Test API (အလကား)** က စာမထုတ်ပါဘူး — `models.get` (key + model စစ်) နဲ့ `countTokens` (အလကားပေးထားတဲ့ token ရေတွက်) ၂ ခုပဲ ခေါ်ပါတယ်။ Generate request တစ်ခုမှ မသွားလို့ credit မကုန်ပါဘူး (test ထဲမှာ စစ်ထားတယ်)။ မသိမ်းရသေးတဲ့ key ကို ကွက်ထဲရိုက်ပြီး စမ်းလို့ရတယ်။ |
| 3 | Credit ကုန်ရင် အစကပြန်စရတာ | Credit / quota ကုန်ရင် job က **ရပ်ထား** ပြီး "Key အသစ်ထည့်ပါ" panel ပေါ်ပါတယ်။ Key အသစ်ထည့်ပြီး **ဆက်လုပ်မယ်** နှိပ်ရင် Whisper စာမှတ်တမ်း၊ ရေးပြီးသား မြန်မာစာ၊ ထုတ်ပြီးသား အသံ အားလုံး ပြန်မလုပ်ဘဲ **ကျန်တာကိုပဲ** လုပ်ပါတယ်။ ဆက်မလုပ်ချင်ရင် **Cancel** (ဖိုင်တွေ အားလုံး ဖျက်ပါတယ်)။ Server ပြန်စ / error ကြောင့် ရပ်သွားတဲ့ job တွေကိုလည်း "ဆက်လုပ်မယ်" နဲ့ ဆက်လို့ရတယ်။ ⚠️ Quota က Google Cloud **project** တစ်ခုချင်းစီအတွက်ပါ — key အသစ်ကို **project အသစ်** ကနေ ယူမှ ရပါမယ် (AI Studio → Create API key → *Create a new project*)။ |
| 4 | အသံ မြန်တဲ့နေရာမြန်၊ ပြတ်တဲ့နေရာပြတ် | အောက်က "အသံ timing" ကြည့်ပါ။ အကျဉ်းချုပ်: speed **တစ်ခုတည်း** (slider)၊ အချိန်မလောက်ရင် အသံကို မြန်အောင်မလုပ်ဘဲ **Gemini က စကားကို ချုံ့ရေး**၊ စာကြောင်းကို ဘယ်တော့မှ ဖြတ်မပစ်ပါဘူး။ |
| 5 | နီလာ၊ သီဟ ပဲလား၊ တခြား character အသံ | **နီလာ ၁ ခု၊ သီဟ ၁ ခု** (tone ကွဲတွေ ဖယ်ပြီးပါပြီ) + တခြား character အသံတွေ — အောက်က "အသံများ" ကြည့်ပါ။ |
| 6 | Processing ကြာတာ | အောက်က "ပိုမြန်အောင် ဘာလုပ်ထားလဲ" ကြည့်ပါ။ |
| 7 | Google login + လူတိုင်း ကိုယ်ပိုင် key | **ဖယ်လိုက်ပါပြီ** (သင် မလိုချင်တော့လို့)။ V20 လိုပဲ `http://VPS-IP:8000` ကို တိုက်ရိုက်ဖွင့်ရုံ၊ login မရှိပါ။ စိမ်းတဲ့သူတွေ မဝင်နိုင်အောင် **AWS Security Group မှာ port 8000 ကို "My IP" (ကိုယ့် IP) ကိုပဲ ဖွင့်** (အကောင်းဆုံး)၊ ဒါမှမဟုတ် `.env` မှာ **`APP_PASSWORD`** ထား (browser က password တစ်ခါမေးမယ်)။ အသေးစိတ်: **[deploy/DEPLOY_MY.md](deploy/DEPLOY_MY.md)**။ |

---

## V21.1 — စာကို အရင်ပြင်ပြီးမှ အသံထုတ်မယ် (review အဆင့်)

**ဘာအတွက်လဲ:** AI ရေးပေးတဲ့ မြန်မာစာကို မကြိုက်တဲ့နေရာ ပြင်ချင်တယ်၊ စာတန်းနဲ့ blur ကို video ပေါ်မှာ ကြည့်ပြီး ကိုယ့်စိတ်ကြိုက် ညှိချင်တယ် — ဒါတွေကို **video မထုတ်ခင်** လုပ်လို့ရအောင် ထည့်ထားပါတယ်။ ရွေးချယ်စရာပါ — **"✍️ စာကို အရင်ပြင်မယ်"** checkbox (အစကတည်းက ✔ ထားပြီးသား)။ မလိုရင် ✔ ဖြုတ်ပါ၊ ဖြုတ်ရင် V21 အတိုင်း စကနေ အဆုံးထိ တစ်ဆက်တည်း လုပ်ပါတယ်။

**အလုပ်လုပ်ပုံ**

1. Video တင်ပြီး Start နှိပ် → စာမှတ်တမ်းယူ (Whisper) → Gemini နဲ့ မြန်မာစာရေး။ **ဒီမှာ ရပ်ပြီး စောင့်ပါတယ်** (အခြေအနေ `✍️ စာပြင်ဖို့ စောင့်နေ`)။ စောင့်နေတုန်း CPU၊ Gemini credit၊ အသံ ဘာမှ မသုံးပါ။ Page ကို ပိတ်ထားလည်း၊ server ပြန်စလည်း (VPS reboot) job မပျောက်ပါ — "ကိုယ့် Job တွေ" စာရင်းထဲက **✍️ ပြင်မယ်** ကို နှိပ်ပြီး ပြန်ဝင်လို့ရပါတယ်။
2. Page ထဲမှာ စာနဲ့ ပုံစံကို ပြင် (အောက်ကဇယား)။ ပြင်တာတွေကို **အလိုအလျောက် သိမ်း** ပါတယ်။
3. **ခလုတ်တစ်ခုတည်း** နှိပ်မှ ဆက်လုပ်ပါတယ်:
   - မြန်မာသံပြောင်းမယ့် job → **🔊 ပြင်ပြီးတဲ့စာနဲ့ မြန်မာအသံ ထုတ်မယ်** — ဒီခလုတ်ကို နှိပ်မှ အသံစထုတ်ပါတယ် (ရိုက်ထားတဲ့စာအတိုင်း ဖတ်မယ်) → mix → video ထုတ်။ (အသံကို ခလုတ်နှိပ်ပြီးမှ ထုတ်တာမို့ ခလုတ်နှိပ်ပြီးနောက် အသံထုတ်တဲ့ အချိန်ကို ထပ်စောင့်ရပါမယ် — စာကို ပြင်ပြီးမှ ထုတ်ဖို့ ရည်ရွယ်ထားလို့ပါ။)
   - စာတန်းပဲ ထိုးမယ့် job → **🎬 သိမ်းပြီး Video ထုတ်မယ်** (အသံ မပါ)။

**Page ထဲမှာ ဘာတွေ ပါလဲ**

| | |
|---|---|
| Video preview | ကိုယ့် video ပေါ်မှာ မြန်မာစာတန်း (ရွေးထားတဲ့ အရွယ် / အရောင် / နောက်ခံနဲ့) နဲ့ blur ဘောင်ကို တန်းပြပါတယ်။ ▶ နှိပ်ရင် ဖွင့်ကြည့်လို့ရ၊ ပြောနေတဲ့ စာကြောင်းကို စာရင်းထဲမှာ မီးထိုးပြပါတယ်။ ဖုန်းမှာ preview က အပေါ်မှာ ကပ်နေတာမို့ အောက်က စာတွေ ပြင်နေရင်း ကြည့်လို့ရ၊ computer မှာဆိုရင် ဘယ်ဘက် (preview + ညှိစရာတွေ) က နေရာတကျ ကပ်နေပါတယ်။ |
| စာကြောင်းတစ်ကြောင်းချင်း ပြင် | မူရင်းစာ (အပေါ်) + မြန်မာစာ (ပြင်လို့ရတဲ့ ကွက်)။ **↺ AI စာအတိုင်း ပြန်ထား**၊ **✖ ဒီစာကြောင်း မထည့်ဘူး** (အသံလည်း မထုတ်၊ စာတန်းလည်း မပေါ်)၊ 🔎 ရှာကွက်။ အသံထုတ်မယ့် job မှာ `≈ 2.2 / 3.9s` (ခန့်မှန်းဖတ်ချိန် / ရနိုင်တဲ့အချိန်) ကို ပြပြီး မလောက်ရင် ⚠ ပြပါတယ်။ |
| စာတန်းပုံစံ | စာလုံးအရွယ် (50–200 %)၊ အောက်ခြေမှ အကွာ (0–40 %) — "အလိုအလျောက်" ကို ✔ ထားရင် blur ဘောင်ရဲ့ အလယ် (blur မလုပ်ရင် အောက်ခြေနား)၊ စာအရောင်၊ နောက်ခံဘောင် (အမည်း) + နောက်ခံအား၊ **စာတန်း အချိန်ညှိ** (−10 … +10 စက္ကန့်: − = စောစောပေါ်၊ + = နောက်ကျပေါ် — စာတန်း **အားလုံး**ကို တစ်ပြိုင်တည်း ရွှေ့တာပါ၊ တစ်ကြောင်းချင်းအတွက် အောက်က V21.2 ကို ကြည့်ပါ)။ |
| မူရင်းစာ blur | နေရာ၊ အမြင့်၊ blur အား၊ ဘောင်မှောင်မှု၊ ပုံထဲက **အနီရောင်ဘောင်ကို လက်နဲ့ ဆွဲရွှေ့** (အပေါ် / အောက်အစွန်းကို ဆွဲရင် အမြင့်ညှိ)၊ **🔍 မူရင်းစာတန်းကို အလိုအလျောက် ရှာမယ်** (video ထဲက စာတန်းပေါ်နေတဲ့ frame တွေကို ကြည့်ပြီး ဘောင်ကို အဲဒီနေရာ ချပေးတယ်)။ |
| 🖼 အစစ်အမှန် ပုံစံ ကြည့်မယ် | Final video ထဲမှာ ပေါ်မယ့် ပုံစံအတိုင်း ပုံတစ်ပုံကို ffmpeg နဲ့ အစစ် render ထုတ်ပြပါတယ် — preview ထက် တိကျပါတယ်။ |
| စာတန်း ဖွင့် / ပိတ် | အသံပြောင်းတဲ့ job မှာ "မြန်မာစာတန်း ပြမည်" ကို ဒီနေရာကနေ ဖွင့် / ပိတ်လို့ရ (အစက စာတန်းမထည့်ခဲ့ရင်တောင် ဖွင့်လို့ရ)။ စာတန်းပဲထိုးတဲ့ job မှာတော့ ပိတ်လို့မရ (လုပ်စရာ မကျန်တော့လို့)။ |

**သိထားရမယ့်အချက်များ**

- **ပြင်ထားတဲ့ စာကြောင်းကို Gemini က ထပ်မချုံ့ပါ** — ရိုက်ထားတဲ့အတိုင်း ဖတ်ပါတယ်။ အချိန်မလောက်ရင် ⚠ ပြပြီး (အပေါ်က "အသံ timing" အဆင့် ၅ အတိုင်း) နောက်စာကြောင်းတွေ နည်းနည်းနောက်ကျစေမယ်၊ နောက်ဆုံးနည်းလမ်းအနေနဲ့ အသံ အများဆုံး +18% မြန်မယ် — စာကို ချုံ့ရေးတာ ပိုကောင်းပါတယ်။ မပြင်ထားတဲ့ စာကြောင်းတွေကိုတော့ V21 အတိုင်း လိုရင် Gemini က ချုံ့ပေးပါတယ်။
- **Preview ထဲက စာတန်းအချိန်** — စာတန်းပဲထိုးတဲ့ job မှာ တကယ့်အချိန်အတိုင်းပါ၊ **အသံပြောင်းတဲ့ job မှာတော့ ခန့်မှန်းချိန်ပါ** (အသံထုတ်ပြီးမှ တိကျတဲ့အချိန် သိရလို့)။ Preview က blur ကို browser နဲ့ အနီးစပ်ဆုံး ပြတာမို့ အတိအကျ စစ်ချင်ရင် "🖼 အစစ်အမှန် ပုံစံ" ကို သုံးပါ။
- Browser က မဖွင့်နိုင်တဲ့ video (.mkv၊ HEVC စတာ) ဆိုရင် server က preview အတွက် **480p ကော်ပီသေးသေး** ကို ခဏစောင့်ပြီး ဖန်တီးပေးပါတယ် (final video ကို မထိပါ)။ Preview ပြလို့မရရင်လည်း စာတွေ ပြင်လို့ရတယ်၊ "🖼 အစစ်အမှန်" နဲ့ စစ်လို့ရ။
- အသံပြောင်းတဲ့ job မှာ ခလုတ်နှိပ်တဲ့အချိန် **Gemini API key ရှိရမယ်** (အသံ / ချုံ့ဖို့)။ စာတန်းပဲထိုးတဲ့ job က key မလိုတော့ပါ။
- စောင့်နေတဲ့ job ကို **၃ ရက် (၇၂ နာရီ)** ပြန်မလာရင် server က အလိုအလျောက် ဖျက်ပါတယ် (`RETENTION_HOURS` ကို ၄၈ ထက် ကြီးထားရင် ×၁.၅)။ မလိုတော့ရင် **✖ Cancel**။ စောင့်နေတဲ့ job က "မပြီးသေးတဲ့ job" အရေအတွက် (`MAX_JOBS_PER_USER`) ထဲ ပါပါတယ်။
- ဖန်သားပြင်ပုံထဲက **"🎯 စကားသံနဲ့ Auto-sync"** နဲ့ **"Video အသံ Volume"** slider ၂ ခုကိုတော့ **မထည့်ထားပါ** — စာတန်းအချိန်ကို စကားသံ (Whisper / VAD) ကနေ၊ အသံပြောင်းတဲ့ job မှာ ထုတ်လိုက်တဲ့ အသံရဲ့ အချိန်ကနေ တိုက်ရိုက်ယူထားပြီးသားမို့ Auto-sync လိုတာ မဟုတ်ဘဲ (လက်နဲ့ ညှိချင်ရင် "စာတန်း အချိန်ညှိ" ပါ)၊ အသံပြောင်းတဲ့ job မှာ မူရင်းအသံကို မြန်မာအသံနဲ့ **အစားထိုး** ထားပြီး စာတန်းပဲထိုးတဲ့ job မှာ မူရင်းအသံကို **မထိဘဲ** ထားလို့ volume ညှိစရာ မလိုဘူးလို့ ယူဆလို့ပါ။ လိုချင်ရင် ပြောပါ၊ ထပ်ထည့်ပေးပါမယ်။ ကျန်တာ (စာလုံးအရွယ်၊ အောက်ခြေအကွာ၊ စာအရောင်၊ နောက်ခံဘောင်၊ အချိန်ညှိ၊ blur နေရာ / အမြင့် / အား) အကုန် ပါပါတယ်။

## V21.2 — စာကြောင်းတစ်ကြောင်းချင်းစီကို video ရဲ့ ဘယ်စက္ကန့်မှာ ထားမလဲ ညှိလို့ရပြီ

**ဘာအတွက်လဲ:** Preview ကြည့်တဲ့အခါ စာတန်းတချို့ နောက်ကျပေါ်တာ တွေ့ရင် အဲဒီစာကြောင်း **တစ်ကြောင်းတည်း**ကိုပဲ စောစောပေါ်အောင် (ဒါမှမဟုတ် နောက်ကျပေါ်အောင်) ရွှေ့လို့ရပါပြီ။ အရင်ရှိပြီးသား **"စာတန်း အချိန်ညှိ"** slider က စာတန်း **အားလုံး**ကို တစ်ပြိုင်တည်း ရွှေ့တာဖြစ်ပြီး ဒီအသစ်က **တစ်ကြောင်းချင်း** ပါ။ ကျန်တာ (preview အထိ ပထမဆုံး သွားတာ၊ စာပြင်တဲ့ box၊ ပြီးတော့ ခလုတ်နှိပ်ပြီး ဆက်လုပ်တာ) အကုန် အရင်အတိုင်းပါပဲ — ဘာမှ မရွှေ့ထားရင် V21.1 နဲ့ အတိအကျ တူပါတယ်။

**ဘယ်မှာလဲ:** စာကြောင်းတိုင်းမှာ စာပြင်တဲ့ box ရဲ့ **ဘေးနားမှာ** `⏱ 0:08.0` ဆိုတဲ့ အချိန်ဘားလေး ပါလာပါတယ် (ဖုန်းလို ကျဉ်းတဲ့ screen မှာတော့ box ရဲ့ **အောက်မှာ** အကျယ်အပြည့် ပါမယ်):

| | |
|---|---|
| ဘားကို ဆွဲ | ဘယ်ဘက် = စောစောပေါ်၊ ညာဘက် = နောက်ကျပေါ် (အများဆုံး ±5 စက္ကန့်)။ ဆွဲနေတုန်း အချိန်ကို ချက်ချင်း ပြောင်းပြပြီး လက်လွှတ်လိုက်ရင် video က အဲဒီစာကြောင်း စမယ့်နေရာကို ခုန်သွားလို့ စာတန်းပေါ်လာတာ ချက်ချင်း မြင်ရပါတယ်။ |
| **−** / **+** | 0.1 စက္ကန့်စီ အတိအကျ ညှိ (နှိပ်တာနဲ့ video ကလည်း အဲဒီနေရာ ခုန်သွား)။ |
| `+1.5s` / `−0.8s` နဲ့ ↺ | ရွှေ့ထားတဲ့ စာကြောင်းကို ဘောင်ဝါရောင်နဲ့ ရွှေ့တဲ့ပမာဏ ပြပါတယ်။ ↺ နှိပ်ရင် မူလအချိန် ပြန်ရောက်။ စာရင်းထိပ်မှာလည်း "အချိန်ညှိထားတာ N" လို့ ပြပါတယ်။ |

**အလုပ်လုပ်ပုံ**

- **စာတန်းပဲထိုးတဲ့ job** → စာတန်းက ညှိထားတဲ့ အချိန်မှာ ပေါ်ပါမယ် (video ပေါ်က စာတန်း၊ `.srt`၊ `.vtt` အကုန်)။
- **အသံပြောင်းတဲ့ job** → **မြန်မာအသံကိုပါ** အဲဒီအချိန်ကနေ စပြောပါမယ်၊ စာတန်းက အသံကို လိုက်တာမို့ အတူတူ ရွှေ့ပါတယ်။ ဆိုလိုတာက အသံထုတ်တဲ့ လမ်းကြောင်း မပြောင်းပါဘူး — စာကြောင်းရဲ့ "စချိန်" နဲ့ "နောက်စာကြောင်းမတိုင်ခင် ရနိုင်တဲ့ အချိန်" ကိုပဲ ပြောင်းပေးတာပါ။
- **မူလအချိန် (Whisper ရတဲ့အချိန်) တွေကို ဘယ်တော့မှ မပြင်ပါ** — ရွှေ့တာတွေကို သီးသန့် မှတ်ထားတာ (`work/review.json` ထဲက `shifts`) မို့ ↺ နဲ့ အပြည့်အဝ ပြန်ရပါတယ်။ ပြင်တာတွေကို စာပြင်တာတွေနဲ့အတူ အလိုအလျောက် သိမ်းပြီး page ပိတ်လည်း၊ server ပြန်စလည်း မပျောက်ပါ။
- **ကန့်သတ်ချက်:** စာကြောင်းတစ်ကြောင်းက သူ့ရှေ့စာကြောင်းရဲ့ စချိန်ကို မကျော်ရ၊ နောက်စာကြောင်းရဲ့ စချိန်ကိုလည်း မကျော်ရ (နှစ်ကြောင်းကြား အနည်းဆုံး ၀.၁ စက္ကန့် ခြား)၊ ပထမစာကြောင်းက video အစထက် စောမရောက်ရ၊ နောက်ဆုံးစာကြောင်းက video ပြီးဖို့ ၀.၃ စက္ကန့်အလိုထက် မနောက်ကျရ။ ဘားက ဒီကန့်သတ်ချက်မှာ ရပ်ပေးပါတယ်။ Server ကလည်း **ထပ်စစ်ပါတယ်** (page ကို ကျော်ပြီး ပို့လာတာတွေကိုပါ ကာကွယ်ဖို့)၊ ရှည်လွန်းရင် ဆန့်တဲ့နေရာအထိ တိုပေးတာပါ။ ±5 စက္ကန့်ထက် ပိုလိုချင်ရင် `backend/review.py` ထဲက `MAX_SHIFT` ကိုပြင်ပါ (page က server ကို မေးယူလို့ တစ်နေရာတည်း ပြင်ရုံပါ)။
- **အသံပြောင်းတဲ့ job မှာ:** စာကြောင်းတစ်ကြောင်းကို နောက်စာကြောင်းနားကို ကပ်ရွှေ့ရင် အသံရှည်လို့ မလောက်တာ ဖြစ်နိုင်ပါတယ်။ ရနိုင်တဲ့အချိန်ကို (`≈ 2.2 / 1.8s` နဲ့ ⚠) ရွှေ့တာနဲ့အမျှ ပြန်တွက်ပြပါတယ်။ အချိန်မလောက်ရင် အရင်အတိုင်းပါပဲ — နောက်စာကြောင်းကို နည်းနည်း တွန်းပါမယ်၊ ဘာမှ မဖြတ်ပါဘူး။
- Job ပြီးသွားရင် အနှစ်ချုပ်မှာ "အချိန်ညှိထားတဲ့ စာကြောင်း N" လို့ ပြပါတယ်။

## V21.3 — "🗣️ စကားပြော (Dub)" ပုံစံ — ဇာတ်လမ်းတစ်ခုလုံးကို အရင်ဖတ်ပြီးမှ ရေးမယ်

> ⚠️ **V22 မှာ ဒီ ပုံစံ (နဲ့ ကျန်တဲ့ ပုံစံအဟောင်း ၇ မျိုးလုံး) ကို ဖျက်ပြီးပါပြီ** — အပေါ်က V22 အပိုင်းက ဇာတ်လမ်းပြောဟန် နဲ့ အစားထိုးထားပါတယ်။ အောက်က စာတွေက သမိုင်းအနေနဲ့ ကျန်ထားတာပါ။ (ဇာတ်လမ်းတစ်ခုလုံးကို ဖတ်ခိုင်းတဲ့ "မှတ်စု" စနစ်၊ speed slider +60 % ကတော့ ဆက်ရှိပါတယ်။)

**ဘာအတွက်လဲ:** "Website ရဲ့ စကားပြောက တိုက်ရိုက်ဘာသာပြန်သလို ဖြစ်နေတယ်၊ နားထောင်လို့ မကောင်းဘူး" ဆိုတာကို ပြင်ဖို့ပါ။ သင်ပေးတဲ့ TikTok recap video ၂ ခုကို ခွဲခြမ်းကြည့်တော့ (အစီရင်ခံစာကို ကျွန်ုပ် ပေးပြီးပါပြီ) ဒီလို တွေ့ရပါတယ် — စကားက ဇာတ်ဝင်ခန်းတစ်ခန်းချင်းနဲ့ မကိုက်ဘဲ **တစ်ဆက်တည်း ရေးထားတဲ့ script** လိုပဲ၊ ဇာတ်ကောင်တွေ ပြောတာကို **သူတို့ကိုယ်တိုင် ပြောသလို** ("နင် / မင်း / ငါ / သမီး / မေမေ …") ပြောပြီး "သူက … လို့ ပြောတယ်" ပုံစံ နည်းနည်းပဲ၊ စာကြောင်းတိုတို၊ အမြဲ **မြန်မြန်** ပြော၊ ရပ်နားတာ အရမ်းနည်း။ V21.2 ကတော့ Whisper စာတစ်ကြောင်းကို မြန်မာစာတစ်ကြောင်း (၁:၁) သီးသန့်ရေးပြီး "အလွန်တိုရမယ်" လို့ ခိုင်းထားတာမို့ တစ်ကြောင်းချင်းစီ ဘာသာပြန်ထားသလို ဖြစ်နေတာပါ။

> ⚠️ ရည်ညွှန်း video ၂ ခုကိုပဲ ကြည့်ထားတာမို့ အပေါ်က အချက်တွေက "ဒီ ၂ ခုမှာ တွေ့ရတာ" ပါ၊ TikTok recap အားလုံးရဲ့ စည်းမျဉ်း မဟုတ်ပါ။

**ဘာတွေ ပြောင်းလဲလဲ**

| | |
|---|---|
| ပုံစံအသစ် **🗣️ စကားပြော (Dub)** | စာသားပုံစံ စာရင်းရဲ့ ထိပ်ဆုံးမှာ "အသစ်" လို့ ပြပြီး စာမျက်နှာက အစကတည်းက ရွေးပေးထားပါတယ်။ ရေးခိုင်းတဲ့ စည်းမျဉ်း — **စာတစ်ကြောင်းချင်း ဘာသာမပြန်ဘဲ တစ်ဆက်တည်း script ရေး** (စာကြောင်းတစ်ကြောင်းက input ၂–၃ ကြောင်းကို ကျော်နိုင်၊ ရှေ့ကြောင်းတွေက "ပြီး / လို့ / ရင် / တော့" လို ဆက်စကားနဲ့ ပြီးပြီး နောက်ဆုံးကြောင်းကမှ "တယ် / ပါတယ် / မယ်" နဲ့ ပိတ်)၊ **ဇာတ်ကောင်ပြောတာကို သူတို့ကိုယ်တိုင် ပြောသလို** (ပြန်ပြောပုံ မသုံး)၊ ဇာတ်ကြောင်းပြောတာက လိုတဲ့နေရာမှာပဲ၊ **စကားပြော မြန်မာ** ("သည် / ၏ / မည်" မသုံး)၊ စာကြောင်းတိုတို (၅–၁၄ syllable)၊ နာမည်တွေကို အစကနေ အဆုံးထိ စာလုံးပေါင်း အတူတူ။ |
| **ဇာတ်လမ်းတစ်ခုလုံးကို အရင်ဖတ်** | ပုံစံအသစ်မှာ Whisper က အားလုံးပြီးတဲ့အထိ မြန်မာစာ **မရေးသေးဘဲ စောင့်ပါတယ်** (စာမျက်နှာမှာ "ဇာတ်လမ်းတစ်ခုလုံးကို အရင်ဖတ်နေပါတယ်" လို့ ပြ)။ ပြီးမှ Gemini ကို **request တစ်ခုတိတိ** ပို့ပြီး စာမှတ်တမ်းတစ်ခုလုံးကို ဖတ်ခိုင်း → မှတ်စုတိုတွေ ပြန်ရ (ဇာတ်လမ်းအကျဉ်း၊ လေသံ၊ ဇာတ်ကောင်တစ်ယောက်ချင်းစီရဲ့ မြန်မာစာလုံးပေါင်း + ဘယ်သူက ဘယ်သူ့ကို ဘယ်လိုခေါ်လဲ၊ နေရာ / စကားလုံးအထူး)။ ဒီမှတ်စုတွေကို **မြန်မာစာရေးတဲ့ request တိုင်း**ရဲ့ system prompt ထဲ ထည့်ပေးတာမို့ ဇာတ်ကောင်နာမည်၊ "နင် / မင်း / ငါ" လို ခေါ်ပုံတွေ ပထမကြောင်းကနေ နောက်ဆုံးထိ အတူတူဖြစ်ဖို့ ရည်ရွယ်ပါတယ်။ `work/story.json` မှာ သိမ်းထားလို့ job ကို ဆက်လုပ်ရင် ပြန်မမေးပါ။ မှတ်စု မရရင် (Gemini က မဖြေ / ဖြတ်ပြီးပြန် / ဖတ်မရတဲ့ပုံစံ) **မှတ်စုမပါဘဲ ဆက်ရေး** — job မပျက်ပါ။ Key / credit ပြဿနာဆိုရင်တော့ ပုံမှန်အတိုင်း "ရပ်ထား" ပြီး key အသစ်စောင့်ပါတယ်။ |
| **နောက်ကြောင်းတွေကိုပါ ကြည့်ပြီး ရေး** | Batch တစ်ခုချင်းစီက **ရှေ့မှာ ရေးပြီးသား ၆ ကြောင်း** (အရင်ပုံစံတွေက ၃ ကြောင်း) နဲ့ **နောက်မှာ လာမယ့် မူရင်းစာ ၄ ကြောင်း** ကို context အဖြစ် မြင်ရတာမို့ batch ရဲ့ နောက်ဆုံးစာကြောင်းတွေက ဇာတ်ကြောင်းနဲ့ ဆက်စပ်ပြီး ပိတ်နိုင်ပါတယ် (ဘာသာမပြန်ရ၊ output ထဲလည်း မထည့်ရဘူးလို့ ခိုင်းထား)။ |
| **"အလွန်တို" စည်းမျဉ်း ဖယ်** | ဒီပုံစံမှာ "extremely short" ဆိုတဲ့ ညွှန်ကြားချက်ကို မသုံးတော့ပါ (နှေးတဲ့အသံနဲ့ ပေါင်းပြီး စာကြောင်းတိုင်းကို ညှစ်ချုံ့တာကြောင့် "ညှစ်ထားတဲ့ ဘာသာပြန်" ဖြစ်စေတာလို့ ယူဆလို့ပါ)။ ဒါပေမယ့် **စာကြောင်းတစ်ကြောင်းချင်းရဲ့ အချိန်ကန့်သတ်ချက် (`max_syllables`)** ကတော့ အရင်အတိုင်း တင်းကျပ်ပါပဲ — အသံ မလွန်ဖို့။ |
| **Speed slider −20 % … +60 %** | အရင်က +40 % အထိပဲ။ ရည်ညွှန်း video က app ရဲ့ ပုံမှန်ထက် ~၁.၇ ဆ မြန်တယ်လို့ ခန့်မှန်းရလို့ (≈ ၈.၇ syllable/စက္ကန့် vs app ရဲ့ ကနဦးတန်ဖိုး ၅.၀) ချဲ့ထားပါတယ်။ Dub ပုံစံကို ရွေးထားရင် slider အောက်မှာ **"+30 % ထားမယ်"** ခလုတ်ပြပြီး တစ်ချက်နှိပ်ရင် +30 % ဖြစ်ပါတယ် (default က +10 % အတိုင်း ကျန်ပြီး ကိုယ်တိုင် မနှိပ်ရင် မပြောင်းပါ)။ |
| **အရင်ပုံစံ ၇ မျိုး** | **မပြောင်းပါ** — prompt တွေ၊ Gemini ဆီ ပို့တဲ့ request တွေ V21.2 အတိုင်းပဲ (V21.2 က ထုတ်ပေးတဲ့ prompt တွေနဲ့ အက္ခရာတစ်လုံးမကွာတာကို test နဲ့ စစ်ထားတယ်)။ API ကို style မပါဘဲ ခေါ်ရင်လည်း `recap` ကိုပဲ ဆက်သုံးပါတယ်။ |
| စာမျက်နှာ ရွေးချယ်မှု | အရင် V21.x မှာ `recap` ကို သိမ်းထားခဲ့တဲ့ browser ကို **တစ်ခါပဲ** Dub ကို ပြောင်းပေးပါတယ် (ကျန်တဲ့ ရွေးချယ်မှုတွေ — speed၊ အသံ၊ blur … — မပြောင်းပါ)။ နောက်ပိုင်း ကိုယ်တိုင် ရွေးထားတာကိုတော့ မှတ်ထားပါတယ်။ |
| ဖုန်းမှာ ဘေးကို ဆွဲရွှေ့လို့ရတာ | ဖုန်းမှာ စာမျက်နှာ ဖွင့်ပြီး ၂ စက္ကန့်လောက် "RECAP" နောက်ခံစာလုံးကြီး ရွေ့ဝင်လာနေတုန်း စာမျက်နှာကို ဘေးဘက်ကို ဆွဲရွှေ့လို့ရနေတာ (အရင် version တွေကတည်းက) ကို ပြင်ထားပါတယ်။ |

**ဘယ်လို စမ်းမလဲ**

1. `deploy/DEPLOY_MY.md` ရဲ့ "V21.3 သို့ update" အတိုင်း တင်ပြီး စာမျက်နှာကို ဖွင့်ပါ (browser က စာမျက်နှာအဟောင်းကို မှတ်ထားနိုင်လို့ **Ctrl + F5**)။
2. **Test API (အလကား)** ✅ ဖြစ်ပြီးရင် ဗီဒီယို **၁–၂ မိနစ်** အတို တစ်ခု တင်ပါ။
3. စာသားပုံစံ = **🗣️ စကားပြော (Dub)** (ထိပ်ဆုံးက "အသစ်")၊ အသံအမြန်နှုန်း = **+30 %** ("+30 % ထားမယ်" ခလုတ်)၊ "✍️ စာကို အရင်ပြင်မယ်" ကို ✔ ထားပါ။
4. Job က "ဇာတ်လမ်းတစ်ခုလုံးကို အရင်ဖတ်နေပါတယ်" လို့ ခဏပြပြီးမှ မြန်မာစာ ရေးပါလိမ့်မယ်။ ရေးပြီးရင် review page မှာ **အသံမထုတ်ခင် စာကို ဖတ်ကြည့်ပါ** — "နင် / မင်း / ငါ …" ခေါ်ပုံ၊ နာမည်စာလုံးပေါင်း တစ်သမတ်တည်းလား၊ စကားပြောလား စာပြောလား ကြည့်ပါ။ မကြိုက်တဲ့နေရာကို အဲဒီမှာ ပြင်လို့ရ။
5. အသံထုတ်ပြီး နားထောင်ပါ။ မြန်လွန်း / နှေးလွန်းရင် speed ကို ညှိပါ (+၂၀ … +၅၀ ကြား စမ်းကြည့်ပါ)။
6. နှိုင်းယှဉ်ချင်ရင် ဗီဒီယိုတူကိုပဲ "🎬 ရုပ်ရှင် Recap" နဲ့ တစ်ခါထပ်လုပ်ကြည့်ပါ။

**စာသားကို ကိုယ့်စိတ်ကြိုက် ညှိချင်ရင်:** `backend/presets.py` ထဲက `DUB_PROMPT` (စည်းမျဉ်း + နမူနာစာကြောင်း ၆ ခု) ကို ပြင်ပါ၊ ပြီးရင် `sudo systemctl restart recap`။ နမူနာတွေက "အသံနဲ့ စည်းချက်" ကို ပြဖို့ပဲ — ကိုယ်ကြိုက်တဲ့ တကယ့် ပြောပုံနမူနာနဲ့ အစားထိုးရင် ပိုကောင်းနိုင်ပါတယ်။

**သိထားရမယ့်အချက်များ**

- Dub ပုံစံမှာ ပထမဆုံး မြန်မာစာကြောင်း မပေါ်ခင် **Whisper အားလုံးပြီးတဲ့အထိ စောင့်ရပါတယ်** (ဗီဒီယိုရှည်ရင် အရင်ထက် ပိုကြာ)။ "ဇာတ်လမ်းတစ်ခုလုံးကို ဖတ်ပြီးမှ ရေး" တာရဲ့ တန်ဖိုးပါ။ ပြီးတဲ့နောက် ရေးတာ၊ အသံထုတ်တာ အရင်လိုပဲ တပြိုင်နက် ဆက်သွားပါတယ်။
- Gemini request **၁ ခု ပိုသုံးပါတယ်** (စာမှတ်တမ်းတစ်ခုလုံးကို ပို့ပါတယ်)။ ရုပ်ရှင်အရမ်းရှည်ရင် (စာ ၁၅၀,၀၀၀ လုံးကျော်) အကုန်မပို့ဘဲ အညီအမျှ ခြားရွေးပို့ပါတယ် (ပထမကြောင်းနဲ့ နောက်ဆုံးကြောင်း အမြဲပါ)။
- မှတ်စုထဲက ဇာတ်ကောင်နာမည်စာလုံးပေါင်းကို Gemini က ဆုံးဖြတ်တာမို့ မကြိုက်ရင် review page မှာ ပြင်ပါ။ မှတ်စုထဲမှာ ဘာပါလဲ ကြည့်ချင်ရင် `data/jobs/<id>/work/story.json`။
- အသံက အရင်လိုပဲ **စာကြောင်းတစ်ကြောင်းချင်း** ထုတ်တာမို့ (Edge TTS) ရည်ညွှန်း video လို တစ်ဆက်တည်း အသံနေအသံထား မရနိုင်ပါ — ဒါကို V21.3 မှာ မပြင်နိုင်ခဲ့ပါ။
- Dub ပုံစံကို **စာတန်းပဲထိုးတဲ့ job (အသံမပါ)** မှာလည်း သုံးလို့ရပါတယ် — ဇာတ်လမ်းကို အရင်ဖတ်တာ၊ ရေးပုံ စည်းမျဉ်းတွေ အတူတူပါပဲ၊ စာတန်းအတွက် "အချိန်ကန့်သတ်ချက်" ကိုပဲ မသုံးတာပါ။

---

## ဘယ်လို run မလဲ

### (က) ကိုယ့်ကွန်ပျူတာမှာ

0. **Python 3.10 နဲ့အထက်** လိုပါတယ် (ဒီ version ကို Python 3.13 မှာ စမ်းထားပါတယ်၊ ကုဒ်က Python 3.9 syntax အတွင်းပဲ ရေးထားပေမယ့် 3.9 / 3.10 / 3.11 မှာ မစမ်းရပါ)။
1. Gemini က မြန်မာ IP ကို လက်မခံပါဘူး — **VPN ကို ကွန်ပျူတာတစ်ခုလုံးအတွက် ဖွင့်ပါ** (browser extension VPN က Python ကို မသက်ရောက်ပါ)၊ ဒါမှမဟုတ် `.env` မှာ `GEMINI_PROXY` ထည့်ပါ၊ ဒါမှမဟုတ် Tokyo လို နိုင်ငံက VPS မှာ run ပါ။
2. **Windows:** `start_windows.bat` ကို နှစ်ချက်နှိပ်ပါ။ **Linux / macOS:** `./start_linux.sh`။
   (လက်နဲ့ဆိုရင်: `python -m pip install -r backend/requirements.txt` ပြီးမှ `python backend/app.py`။)
3. Browser မှာ `http://127.0.0.1:8000` ဖွင့်ပါ။
4. **Gemini API** card မှာ Gemini key ထည့် (<https://aistudio.google.com/apikey>) → **Save** → **Test (အလကား)** → ✅ ပေါ်ရင် အဆင်သင့်။
   (Google AI Studio က အခု **`AQ.` နဲ့ စတဲ့ key** ကိုပဲ ထုတ်ပေးပါတယ် — ပုံမှန်ပါပဲ၊ `AIza…` မဟုတ်လို့ မှားတာမဟုတ်ပါ။ ဒီ key နဲ့ 401 error ပေါ်ရင် app က ဘာစစ်ရမလဲ ရှင်းပြပါလိမ့်မယ်။)
5. ဗီဒီယို (ကိုယ်ပိုင် / လိုင်စင်ရတာပဲ) တင်၊ rights checkbox ကို အတည်ပြု၊ ရွေးချယ်စရာတွေ ရွေးပြီး **Start Processing**။

`.env.example` ကို `.env` အဖြစ် ကူးပြီး ပြင်လို့ရတယ် (ဘာမှ မပြင်လည်း ရတယ်)။

### (ခ) VPS မှာ (IP လိပ်စာ + port နံပါတ်နဲ့၊ login မလို)

**[deploy/DEPLOY_MY.md](deploy/DEPLOY_MY.md)** မှာ အဆင့်ဆင့် ရှိပါတယ်။ အကျဉ်းချုပ်:

1. zip ကို VPS ပေါ်တင်၊ `unzip`၊ `python3 -m venv venv`၊ `venv/bin/pip install -r backend/requirements.txt`၊ `venv/bin/python backend/app.py` (V20 လို `python -m uvicorn backend.app:app --host 0.0.0.0 --port 8000` နဲ့လည်း ရ)။
2. Browser မှာ `http://VPS-IP:8000` ကို ဖွင့်။
3. **စိမ်းတဲ့သူတွေ ဝင်မလာအောင် (အရေးကြီး):** AWS Security Group မှာ port 8000 ရဲ့ Source ကို **My IP** လုပ်ပါ၊ နှင့်/သို့ `.env` မှာ `APP_PASSWORD=…` ထားပါ။ ဘာမှ မလုပ်ရင် IP သိတဲ့ ဘယ်သူမဆို ကိုယ့် Gemini key (credit) နဲ့ VPS ကို သုံးလို့ရပါတယ်။ Program စတက်တဲ့အခါ password မထားရင် log ထဲမှာ `no password: …` ဆိုတဲ့ သတိပေးချက် ပေါ်ပါတယ်။

## လုံခြုံရေး — ဘာတွေ လုပ်ထားလဲ၊ ဘာတွေ မလုပ်ထားလဲ

**လုပ်ထားတာ**

- **`APP_PASSWORD`** (ရွေးချယ်စရာ) — HTTP Basic: browser က password တစ်ခါမေးမယ်၊ user name ဘာရိုက်ရိုက်ရ။ Upload လာရင် **video ကို မဖတ်ခင်ကတည်းက** စစ်တာမို့ မသိတဲ့သူက GB ချီ ဖိုင်ကို ပို့ပြီး disk ဖြည့်လို့ မရပါ။
- `MAX_UPLOAD_MB` ထားရင် ကျော်တဲ့ upload ကို မဖတ်ခင်ပဲ ငြင်း (ဖိုင်အရွယ်ကို ကြိုမပြောတဲ့ upload ဆိုရင် ကျော်တာနဲ့ ဖတ်တာရပ်)။ `MAX_JOBS_PER_USER` (6) — **တင်နေတုန်း upload တွေကိုပါ ရေတွက်** (အပြိုင်ဆယ်ခုတင်ပြီး limit ကျော်လို့ မရ)၊ Page ကလည်း video မပို့ခင် "job ပြည့်နေပါတယ်" လို့ ရှင်းပြ။ ဒီအားလုံးကို Playwright browser နဲ့ တကယ့် uvicorn server မှာ စမ်းထားပါတယ်။
- Video မဟုတ်တဲ့ ဖိုင် (ဥပမာ `movie.mp4` လို့ နာမည်ပေးထားတဲ့ playlist စာသား) ကို ffmpeg ဆီ မပို့ဘဲ ငြင်း — ဖိုင်ရဲ့ အစပိုင်း (mp4 / mov / mkv / webm / avi) ကို စစ်ပါတယ်။
- POST / PUT / DELETE တွေကို **တခြား website ကနေ လှမ်းလို့မရအောင်** Origin စစ် (`Origin: null` ပါ ပိတ်)၊ iframe ထဲ ထည့်လို့မရ (`frame-ancestors 'none'`)၊ `nosniff`၊ `/api/` ကို cache မလုပ်။ Download လို့ရတဲ့ ဖိုင်နာမည်တွေကို စာရင်းအတိအကျ (`final_burmese.mp4`၊ `burmese.srt` …) ပဲ ခွင့်ပြု။
- Model နာမည်ကို စာလုံး/ဂဏန်း/`-._` ပဲ လက်ခံ (request address ထဲ ဝင်သွားလို့၊ `..` မရ)၊ API key ကို URL ထဲ မထည့်ဘဲ header (`x-goog-api-key`) နဲ့ပို့ — log ထဲ မကျန်ရအောင်။
- သိမ်းထားတဲ့ Gemini key ကို `chmod 600` ဖိုင်ထဲ စာသားအတိုင်း မဖတ်ရအောင် လျှို့ဝှက် (`cryptography` သွင်းထားရင် encrypt)၊ page ကို ပြန်ပို့တာက `••••••abcd` လို နောက်ဆုံး ၄ လုံးပဲ ပြပြီး ကျန်တာ ဖုံးထားတာပါ။

**မလုပ်ထားတာ (သိထားပါ)**

- **HTTPS မရှိပါ** (plain `http://`) — password နဲ့ key ကို network ကို စောင့်ကြည့်နေသူက မြင်နိုင်ပါတယ်။ အလုံခြုံဆုံးက port ကို လုံးဝမဖွင့်ဘဲ SSH tunnel နဲ့ သုံးတာ (`deploy/DEPLOY_MY.md` ရဲ့ "ပိုလုံခြုံချင်ရင်")။
- **လူခွဲမထားပါ** — ဝင်ခွင့်ရသူ အားလုံးက ကိုယ်နဲ့ တူညီတဲ့ အခွင့်အရေး (key ပြောင်း၊ job ဖျက်၊ ဗီဒီယို download)။
- **လွတ်လပ်တဲ့ လုံခြုံရေး စစ်ဆေးမှု (security review / penetration test) မလုပ်ရသေးပါ** — ကိုယ်တိုင်ဖတ်စစ်ပြီး တွေ့တာတွေ ပြင်ထားပြီး test ထည့်ထားပါတယ်၊ ဒါပေမယ့် ဒါက ကျွမ်းကျင်သူ စစ်တာနဲ့ မတူပါဘူး။

---

## အသံ timing — ဘယ်လို ညှိထားလဲ

V20 မှာ စာကြောင်းတစ်ကြောင်း ရှည်လွန်းရင် အသံကို `atempo` နဲ့ မြန်အောင်လုပ်၊ မလောက်ရင် ဖြတ်ပစ်တာကြောင့် "မြန်တဲ့နေရာ မြန်၊ ပြတ်တဲ့နေရာ ပြတ်" ဖြစ်တာပါ။ V21 က လမ်းကြောင်းပြောင်းပါတယ်:

1. **Speed တစ်ခုတည်း** — "အသံအမြန်နှုန်း" slider (−20% … +60%၊ default **+10%**၊ V21.3 မှာ +40% ကနေ +60% အထိ ချဲ့) ကို စာကြောင်းအားလုံးမှာ အတူတူ သုံးပါတယ်။ စာကြောင်းအလိုက် မြန်လိုက်နှေးလိုက် မလုပ်ပါဘူး။
2. **အချိန်ကို syllable နဲ့ တွက်** — Whisper ပေးတဲ့ စကားတစ်ကြောင်းချင်းစီရဲ့ အချိန် (နောက်စကားမစခင်အထိ နေရာ) ကို မြန်မာစာ syllable အရေအတွက်အဖြစ် ပြောင်း၊ ကိုယ်ရွေးထားတဲ့ အသံ + speed ရဲ့ **တကယ်ဖတ်နှုန်း** (syllable/စက္ကန့်) ကို ထုတ်ပြီးသား အသံတွေကနေ တိုင်းပြီး `data/calibration.json` မှာ မှတ်ထားပါတယ်။
3. **Gemini ကို budget ပေး** — စာကြောင်းတိုင်းအတွက် `max_syllables` ပေးပြီး "ဒီထက်ပိုမရှည်စေနဲ့၊ ရှည်ရင် အဓိပ္ပါယ်မပျက်အောင် **ချုံ့ရေး**" လို့ ခိုင်းပါတယ်။
4. **အသံထုတ်ပြီး ပြန်တိုင်း** — တကယ်ထွက်လာတဲ့ အသံ အချိန်ထက် ကျော်နေတဲ့ စာကြောင်းတွေကို Gemini ဆီ **တစ်ခါတည်း (batch)** ပြန်ပို့ပြီး ပိုတိုအောင်ခိုင်း (အများဆုံး ၂ ကြိမ်)။
5. **ဖြတ်မပစ်၊ နောက်ဆုတ်ပေး** — ဒါတောင် မဆန့်သေးရင် နောက်စာကြောင်းတွေကို နည်းနည်းနောက်ကျပြီး စပါတယ် (စကားကြား အပြတ်တွေမှာ ပြန်မီလာ)။ **နောက်ဆုံး နည်းလမ်း** အနေနဲ့သာ အသံကို အများဆုံး **+18%** မြန်ပါတယ်။ Result card မှာ "ချုံ့ပေးထားတဲ့ စာကြောင်း / အနည်းငယ်မြန်ထားတဲ့ စာကြောင်း / နောက်ကျပြီးစတဲ့ စာကြောင်း" ဘယ်နှခုလဲ ပြပါတယ်။

ဒီနည်းနဲ့ အသံက တသမတ်တည်း ဖြစ်ပြီး ဗီဒီယိုနဲ့လည်း ကိုက်ပါတယ်၊ ဒါပေမယ့် **စကားက မူရင်းထက် တိုသွားနိုင်** ပါတယ် (ချုံ့ပြောတာမို့) — ရည်ရွယ်ချက်ကတော့ အဓိကအကြောင်းအရာ မပျက်ဘဲ တိုတာပါ။

## အသံများ

| အုပ်စု | အရေအတွက် | မှတ်ချက် |
|---|---|---|
| **မြန်မာ မူရင်းအသံ** (အလကား) | နီလာ ၁၊ သီဟ ၁ | Microsoft Edge မှာ တကယ်ရှိတဲ့ မြန်မာအသံ နှစ်ခုပဲ ရှိပါတယ်။ Tone ကွဲ (deep / soft…) တွေကို ဖယ်လိုက်ပါပြီ။ |
| **တခြား character အသံများ** (အလကား၊ 🧪 စမ်းသပ်ဆဲ) | ၁၆ | Microsoft ရဲ့ *Multilingual* အသံတွေ (Ava, Andrew, Emma, Brian, William, Vivienne, Remy, Seraphina, Florian, Dalia, Jorge, Giuseppe, Hyunsu, Thalita, Xiaoxiao, Yunyi)။ Microsoft ရဲ့ စာရင်းမှာ `my-MM` ကို multilingual အုပ်စုထဲ ထည့်ထားပေမယ့်၊ **အခမဲ့ Edge လမ်းကြောင်းမှာ မြန်မာစာကို ကောင်းကောင်းဖတ်မဖတ် ကျွန်ုပ် မစမ်းနိုင်ခဲ့ပါ**။ နမူနာ အရင်နားထောင်ပါ — နမူနာအသံက တိတ်နေ / တိုလွန်းရင် page က သတိပေးပါတယ်။ |
| **Gemini အသံ ၃၀** (💳 credit သုံး) | ၃၀ | Gemini TTS ရဲ့ prebuilt voices (Zephyr, Puck, Kore, …)။ စာကြောင်းတစ်ကြောင်းစီ Gemini request တစ်ခုစီ သုံးလို့ ဗီဒီယိုရှည်ရင် **paid key** လိုနိုင်ပါတယ်။ 👩/👨 က ခန့်မှန်းချက်ပါ။ **မစမ်းနိုင်ခဲ့ပါ**။ |

ထပ်ထည့်ချင်ရင် `.env` မှာ `EDGE_EXTRA_VOICES=en-US-AriaNeural:Aria:female, …`။ နမူနာ (🔊) ကို နှိပ်ရင် ကိုယ်ရွေးထားတဲ့ speed နဲ့ နားထောင်လို့ရပါတယ်။

## ပိုမြန်အောင် ဘာလုပ်ထားလဲ

- **Whisper CPU အားလုံးသုံး** — V20 က `OMP_NUM_THREADS=1` ကို အတင်းထားလို့ Whisper က CPU core **တစ်ခုတည်း** သုံးနေတာပါ။ V21 က core အားလုံးကို သုံးခွင့်ပေးပါတယ် (`WHISPER_THREADS`)၊ beam search ကို 1 (`WHISPER_BEAM`)၊ ဘာသာစကားကို တစ်ခါပဲ ရှာပြီး ကျန်တဲ့အပိုင်းတွေမှာ ပြန်သုံး၊ chunk တစ်ခုချင်း disk မှာ cache လုပ်။
- **အဆင့်တွေ ထပ်ပြီးအလုပ်လုပ်** — Whisper (chunk 1) ပြီးတာနဲ့ Gemini က ရေးနေ၊ ရေးပြီးတဲ့စာကြောင်းတွေကို အသံထုတ်နေ — ရှေ့အဆင့်ကို စောင့်မနေဘဲ pipeline အတိုင်း တပြိုင်နက်လုပ်။
- **Gemini request ကို အစုလိုက် (၃၀ ကြောင်း)** + **အသံထုတ်ကို တပြိုင်နက် ၆ ကြောင်း** (`EDGE_TTS_CONCURRENCY`)။
- **အသံ ပေါင်းစပ်တာကို streaming** — ဗီဒီယိုတစ်ခုလုံးရဲ့ အသံကို memory ထဲ တစ်ခါတည်း မထည့်ဘဲ တဖြည်းဖြည်း ရေး။
- **Video render preset** — default `veryfast` (V20 ထက်မြန်)၊ "Video ထုတ်တဲ့ အမြန်နှုန်း" ကနေ `ultrafast` ရွေးလို့ရ။ (အသံပဲ ပြောင်းမယ်ဆိုရင် ဗီဒီယိုကို ပြန် encode မလုပ်ပါ။)
- **ကြိုက်တဲ့အချိန် ဆက်လုပ်လို့ရတာကိုယ်တိုင်** — ပြီးသားအပိုင်း (Whisper chunk၊ ရေးပြီးသား မြန်မာစာ၊ ထုတ်ပြီးသား အသံ) ကို disk မှာ cache လုပ်ထားလို့ ဆက်လုပ်တဲ့အခါ ပြန်မလုပ်ရ။

> ⚠️ အချိန် **ဘယ်နှ % လျော့လဲ** ဆိုတာ ကျွန်ုပ် မတိုင်းနိုင်ခဲ့ပါ (တကယ့် Whisper နဲ့ ဗီဒီယိုရှည်တွေ မရှိလို့)။ CPU core များတဲ့ server မှာ ပိုသိသာပါလိမ့်မယ်။

---

## Google Drive (မလိုအပ်ပါ)

Drive ချိတ်ထားရင် video ပြီးတာနဲ့ **ကိုယ့် Drive** ထဲ အလိုအလျောက်တင် (`Burmese Movie Recap` folder) → size + MD5 တိုက်စစ် → **အားလုံး မှန်မှသာ** server ပေါ်က ဖိုင်တွေ ဖျက် → Drive ကနေပဲ ပြန်ပြပြီး Download link ပေး။ တင်မရရင် / မကိုက်ရင် **ဘာမှ မဖျက်ပါ**၊ server ပေါ်မှာ ကျန်ပြီး page က အကြောင်းပြချက်ပြပါတယ်။ ဖိုင်တွေက default အားဖြင့် **private** (ကိုယ့် Google account သာ)၊ "Anyone with the link" ကို Drive card မှာ ရွေးလို့ရ။ App က `drive.file` scope (ကိုယ်တိုင်ဖန်တီးတဲ့ ဖိုင်/folder ကိုပဲ မြင်) ကိုသာ တောင်းပါတယ်။

- Google Cloud မှာ **Drive API** ကို Enable လုပ်ပြီး **Desktop app** OAuth client လုပ်၊ JSON ကို `data/credentials.json` အဖြစ် သိမ်း (သို့ `.env` မှာ `GOOGLE_CLIENT_ID` / `GOOGLE_CLIENT_SECRET`)၊ ပြီးရင် Drive card မှာ **Connect Google Drive**။ Consent screen ကို **In production** လုပ်ထားပါ (Testing မှာ ဆိုရင် Drive login က ၇ ရက်နဲ့ ကုန်ပါတယ်)။ Disconnect က Google မှာပါ revoke လုပ်ပေးပါတယ်။
- **VPS မှာ run နေရင်:** Google က redirect လိပ်စာကို `https://` (သို့) `localhost` ပဲ လက်ခံလို့ `http://VPS-IP:8000` ကနေ Connect မရပါဘူး။ **တစ်ခါတည်း SSH tunnel** နဲ့ ချိတ်ပါ (`ssh -L 8000:127.0.0.1:8000 user@server` ပြီး ကိုယ့်ကွန်ပျူတာ browser မှာ `http://127.0.0.1:8000`) — `deploy/DEPLOY_MY.md` ရဲ့ "Google Drive ချိတ်ချင်ရင်"။ Token က server ပေါ်မှာ ကျန်ပြီး နောက်ပိုင်း IP:port ကနေ တင်တဲ့ job တွေမှာလည်း အလုပ်လုပ်ပါတယ်။ (V20 ရဲ့ နည်းအတိုင်းပါ၊ Google အစစ်နဲ့ မစမ်းနိုင်ခဲ့ပါ။)

## ဖိုင်တွေ ဘယ်မှာ သိမ်းလဲ (`data/`)

| | |
|---|---|
| `data/jobs/<id>/` | job တစ်ခုချင်းစီ: `job.json`၊ တင်ထားတဲ့ ဗီဒီယို၊ `work/` (cache — စာပြင်တဲ့အဆင့်မှာ `rewrite.json` = မြန်မာစာ၊ `review.json` = ပြင်ခဲ့တာ / ရွေးထားတဲ့ ပုံစံ၊ `preview.mp4` = browser မဖွင့်နိုင်တဲ့ video အတွက် preview ကော်ပီ)၊ `out/` (ပြီးတဲ့ဖိုင်) |
| `data/users/local/settings.json` | Website မှာ ထည့်ထားတဲ့ Gemini key (လျှို့ဝှက်ထား၊ `chmod 600`) နဲ့ model |
| `data/settings.json`၊ `drive_token.json`၊ `drive_settings.json`၊ `credentials.json` | V20 နဲ့ **နာမည်၊ နေရာ အတူတူ** — V20 ကနေ ကူးထည့်ရင် key နဲ့ Drive login ကို ဆက်သုံးလို့ရ (`settings.json` ကိုတော့ test နဲ့ စစ်ထားတယ်၊ Drive ဖိုင်တွေက ဖိုင်နာမည်တူတာကိုပဲ အခြေခံ) |
| `data/secret.key` | `cryptography` သွင်းထားမှသာ ဖန်တီး — key encrypt လျှို့ဝှက်ချက် (**ပျောက်ရင် သိမ်းထားတဲ့ key ပြန်ဖတ်မရ**၊ backup ထဲ ထည့်ပါ) |
| `data/calibration.json` | အသံ + speed တစ်ခုချင်းစီရဲ့ တကယ်ဖတ်နှုန်း |
| `data/samples/` | နမူနာအသံ cache |

## Website design

- `frontend/index.html` — black / violet ပုံစံ၊ film grain၊ ဖန်သားပြင် panel။ Result ထဲက မြန်မာစာ အရွယ်အစားကို `<style>` ထိပ်က `--tr-size` (15pt) ကိုပြောင်းပြီး ညှိပါ။
- Font (Anton, Manrope, Noto Sans Myanmar) ကို Google Fonts က load လုပ်ပါတယ် — အင်တာနက်မရှိရင် စနစ်ဖောင့်သုံးပါတယ်။
- ဗီဒီယိုထဲက မူရင်းစာတန်းကို blur လုပ်ပြီး အဝါရောင် မြန်မာစာတန်းထိုးတဲ့ **blur strip preview + 🔍 auto-detect** (V20 ကထဲက) ကို အတူတူ ထားထားပါတယ်။
- မြန်မာစာတန်း ဖောင့် **Padauk** ကို `fonts/` ထဲ ထည့်ပေးထားပါတယ် (SIL Open Font License) — Linux VPS မှာ ဖောင့်သွင်းစရာမလိုပါ။

## စာတန်း / စာသားပုံစံ / output ရွေးချယ်မှု (V18–V20 ကအတိုင်း)

- **စာတန်းထိုးမည် / မြန်မာသံပြောင်းမည်** — တစ်ခု သို့ နှစ်ခုလုံး ရွေးလို့ရ (အနည်းဆုံး တစ်ခု)။ စာတန်းထိုးရင် ဗီဒီယိုကို H.264 နဲ့ ပြန် encode လုပ်ရလို့ အသံပဲလုပ်တာထက် ကြာပါတယ်။ စာတန်းက ပြောနေတဲ့အချိန်မှာပဲ ပေါ်ပါတယ်။ `burmese.srt` / `burmese.vtt` ပါ ရပါတယ်။
- **စာသားပုံစံ ၂ မျိုးပဲ** (V22) — **🔤 တိုက်ရိုက်စာတန်းထိုးဟန်**၊ **📖 ဇာတ်လမ်းပြောဟန်** — `backend/presets.py` (`STYLE_PRESETS`) မှာ ပြင်လို့ရ။

---

## စမ်းသပ်ချက် (tests)

```bash
python -m unittest discover -s tests -p "test_*.py"
```

**V22.1:** `python -m pytest tests -q` → **343 ခု အောင်၊ 49 ခု skip** (skip ဖြစ်တာက `fastapi` မရှိတဲ့ ကျွန်ုပ်ရဲ့ sandbox မှာ မပြေးနိုင်တဲ့ HTTP test တွေ — `tests/test_app.py` နဲ့ တခြား၊ **ကိုယ့် VPS / ကွန်ပျူတာမှာ `fastapi` ရှိရင် အကုန် ပြေးပါလိမ့်မယ် — ပထမဆုံး run ရင် ဒီ ၄၈ ခု ကိုယ်တိုင် ပြေးကြည့်ပါ**)။ V22 အတွက် ထပ်ထည့်တာ: `test_presets.py` (ပုံစံ ၂ မျိုး၊ prompt hash)၊ `test_rewrite.py` (ဇာတ်လမ်း ၇၆ ချက် — ခွဲပို့၊ ဖြတ်ပြီးပြန်၊ ကျန်တာထပ်မေး၊ ကပ်ပေါင်း)၊ `test_providers.py` (Claude / Groq request ပုံစံ၊ error ခွဲခြားမှု — **အတု HTTP server** `tests/mock_llm.py`)၊ `test_pipeline_providers.py` (ရွေးထားတဲ့ AI ကိုပဲ ခေါ်ကြောင်း၊ တခြားနှစ်ခုကို request **၀ ခု** ကြောင်း)၊ `test_auth.py` (key ၃ ခု သိမ်းပုံ)။ `app.py` ရဲ့ settings / options / create_job / resume_job handler တွေကို fastapi အတုနဲ့ ခေါ်စစ်ခဲ့ပေမယ့် ဒါက တကယ့် fastapi နဲ့ ညီတာ မဟုတ်ပါ။ Page (`frontend/index.html`) ကို Playwright Chromium + အတု API နဲ့ နှိပ်စမ်း (key ၃ ခုသိမ်း၊ ရွေး၊ key မရှိတာကို ရွေးရင် ငြင်း၊ Gemini အသံ lock၊ ရပ်ထားတဲ့ Groq job panel)။

အောက်က အပိုင်းက V21.3 အချိန်က ရေးထားတာ (အရေအတွက် 239 ခု ...) — သမိုင်းအနေနဲ့ ကျန်ထားပါတယ်: အရေအတွက် 239 ခု (V21.1 ရဲ့ စာပြင်တဲ့ အဆင့်အတွက် 25 ခု၊ V21.2 ရဲ့ အချိန်ညှိတာအတွက် 17 ခု၊ V21.3 ရဲ့ Dub ပုံစံ / ဇာတ်လမ်းမှတ်စုအတွက် 39 ခု ပါ)၊ အားလုံး ကျွန်ုပ်ရဲ့ sandbox မှာ အောင်ခဲ့ပါတယ်။ Gemini ကို **အတု server** (`tests/mock_gemini.py`) နဲ့ အစားထိုးပြီး 503 / 429 per-minute / 429 daily / prepaid credit ကုန် / invalid key / quota ကုန်ပြီး key အသစ်နဲ့ ဆက်လုပ်၊ cancel၊ restart ပြီးဆက်လုပ်၊ timing, scheduler, Drive upload / verify / cleanup, password၊ upload ကန့်သတ်ချက်၊ HTTP API အကုန် စမ်းထားပါတယ်။ FFmpeg အစစ်ကို သုံးပါတယ်။ (Whisper နဲ့ Edge TTS ကို အတုနဲ့ အစားထိုးထားတယ်။) Test ပြေးဖို့ `fastapi`၊ `uvicorn`၊ `requests`၊ `numpy` နဲ့ `ffmpeg` လိုပါတယ် (`cryptography` ရှိမှ encrypt test ပြေး)။
ထပ်ပြီး **Playwright Chromium (browser အစစ်) + uvicorn server အစစ်** နဲ့ page ကို နှိပ်စမ်းတဲ့ script ၇ ခု (**V21.3 ရဲ့ Dub ပုံစံ ၅၂ ချက်** — Dub က ထိပ်ဆုံး / "အသစ်" စာတန်းနဲ့ ရွေးပြီးသား ဖြစ်လား၊ "+30 %" ခလုတ်က slider ကို ရွှေ့လား၊ slider က +60 % အထိပဲ ရောက်လား၊ အရင်သိမ်းထားတဲ့ ရွေးချယ်မှုကို တစ်ခါပဲ ပြောင်းလား၊ **Dub job တစ်ခုကို upload ကနေ result အထိ** (ဇာတ်လမ်းကို အရင်ဖတ်တဲ့ request ကို တစ်ခါတည်း ပို့လား၊ ရေးတဲ့ request ၄ ခုလုံးမှာ မှတ်စုပါလား)၊ ဖုန်းအကျယ် ၃၂၀ / ၃၆၀ / ၃၉၀ / ၄၁၂ px မှာ ဘေးကို လွန်မသွားဘူးလား၊ ပုံမှန် ၉၃ ချက်၊ password + ကန့်သတ်ချက် ၂၈ ချက်၊ server ပြန်စ ၈ ချက်၊ **စာပြင်တဲ့ အဆင့် ၉၉ ချက်** — slider တွေက video ပေါ်က ပုံကို တကယ်ပြောင်းလား၊ စာပြင်ရင် server မှာ သိမ်းလား၊ reload လုပ်ရင် ပြန်ရလား၊ ခလုတ်မနှိပ်ခင် အသံ မထုတ်ဘူးလား၊ ဖုန်းအရွယ်ရော computer အရွယ်ရော၊ **server ကို အတင်းသတ်ပြီး ပြန်စတာကို ခံနိုင်လား ၁၃ ချက်**၊ **စာကြောင်းတစ်ကြောင်းချင်း အချိန်ညှိ bar ၈၄ ချက်** — ဘားကို ဆွဲရင် / ခလုတ်နှိပ်ရင် အချိန်ပြောင်းလား၊ ကန့်သတ်ချက်မှာ ရပ်လား၊ သိမ်းပြီး reload လုပ်ရင် ပြန်ရလား၊ ဖုန်းအရွယ်မှာ ဘားက box အောက်ရောက်လား၊ တကယ်ထွက်တဲ့ SRT နဲ့ `segments.json` အချိန်တွေ မှန်လား) ပါ စမ်းပြီး အောင်ပါတယ်။ Unit test တွေထဲမှာလည်း "ရွှေ့တဲ့ rule က ဘယ်လိုတောင်းတောင်း စီစဉ်ပုံ မပျက်ဘူး" ကို **ကျပန်း အခြေအနေ ၄,၀၀၀** နဲ့ စစ်ထားပြီး၊ အသံပြောင်းတဲ့ job မှာ **ထွက်လာတဲ့ အသံထဲမှာ** စာကြောင်းက ရွှေ့ထားတဲ့အချိန်ကနေ တကယ်စပြောလား၊ မူလအချိန်မှာ တိတ်သွားလား ဆိုတာကို တိုင်းစစ်ပါတယ်။ ဒါ့အပြင် preview ထဲက စာဖြတ်ပုံ / အရွယ် / blur ဘောင် တွက်ချက်မှု (JavaScript) က server ရဲ့ တွက်ချက်မှု (Python) နဲ့ အတိအကျ တူလား ဆိုတာကို ကွဲပြားတဲ့ စာ ၃၁၅ ခုနဲ့ ၂၈,၄၄၀ ကြိမ် နှိုင်းယှဉ်စစ်ထားပြီး ကွာတာ ၀ ခု။ ဒါတွေက ကျွန်ုပ်ရဲ့ စမ်းသပ်ရေး tool မို့ zip ထဲ မပါပါ။

---

## ⚠️ မစမ်းနိုင်ခဲ့တာတွေ (သေချာဖတ်ပါ)

ဒီ version ကို တကယ့် Google / Microsoft service တွေကို ခေါ်လို့မရတဲ့ sandbox ထဲမှာ ရေးထားတာမို့ **အောက်ပါတို့ကို တကယ်မစမ်းရသေးပါ** — မူရင်း API စာရွက်စာတမ်းအတိုင်း ရေးထားပေမယ့် ပထမဆုံး run တဲ့အခါ ပြဿနာတက်နိုင်ပါတယ်:

1. **တကယ့် Gemini API** — request / response ပုံစံ၊ error စာသား (503 / 429 / quota) ကို ခွဲခြားတာ၊ `models.get` + `countTokens` နဲ့ key စစ်တာ အားလုံးကို အတု server နဲ့ပဲ စမ်းထားတာပါ။ **သင်ပေးခဲ့တဲ့ test key နဲ့လည်း စမ်းကြည့်ခဲ့ပေမယ့်** ကျွန်ုပ်ရဲ့ sandbox ရဲ့ network policy က `generativelanguage.googleapis.com` ကို ပိတ်ထား (403) လို့ request က Google ဆီ မရောက်ခဲ့ပါ — ဒါကြောင့် key အစစ်နဲ့ စမ်းချက်ကို **မပြီးစီးခဲ့ပါ**။ VPS မှာ ပထမဆုံး run တဲ့အခါ **Test API (အလကား)** ကို အရင်နှိပ်ပါ၊ ပြီးရင် ဗီဒီယို အတို (၁ မိနစ်) နဲ့ စမ်းပါ။ Google ရဲ့ error စာသား ပြောင်းသွားရင် "credit ကုန်ပြီ" လို့ မှန်မှန်ကန်ကန် မခွဲနိုင်တာ ဖြစ်နိုင်ပါတယ် (ဒီလိုဆိုရင် job က မပျက်ဘဲ "ဆက်လုပ်မယ်" panel နဲ့ ပေါ်မယ်)။
   **`AQ.` key အကြောင်း:** ပေးထားတဲ့ key က `AQ.` ပုံစံပါ။ Google ရဲ့ စာရွက်စာတမ်းအတိုင်း `x-goog-api-key` header နဲ့ပို့ပါတယ် (Google staff ကလည်း ဒီနည်းကို ညွှန်ထား)၊ ဒါပေမယ့် Google forum မှာ ဒီပုံစံ key နဲ့ `401 ACCESS_TOKEN_TYPE_UNSUPPORTED` ပေါ်တယ်ဆိုတဲ့ အစီရင်ခံစာတွေ ရှိပါတယ် (အကြောင်းရင်းက key မပြည့်စုံတာ၊ model အဟောင်းသုံးတာ စတာတွေလို့ ဆိုကြပေမယ့် Google က အတည်ပြုချက် မပေးထား)။ ဒါကြောင့် ပထမဆုံး **Test API (အလကား)** ကို နှိပ်ပါ၊ 401 ပေါ်ရင် app က စစ်စရာတွေကို မြန်မာလို ပြပါလိမ့်မယ်။
2. **Gemini TTS အသံ ၃၀** — အလုပ်လုပ်ပုံ (classic / interactions layout ကို ကိုယ်တိုင်ရှာ) ကို အတုနဲ့သာ စမ်း၊ မြန်မာစာကို ကောင်းကောင်းဖတ်မဖတ် မသိ။
3. **Edge multilingual အသံ ၁၆ ခု** မြန်မာစာဖတ်တာ — မသိ။ (နီလာ / သီဟ ကတော့ V20 ကထဲက သုံးလာတာ။)
4. **တကယ့် faster-whisper** — sandbox မှာ မရှိလို့ အတုနဲ့ စမ်းထား။ `cpu_threads`၊ `beam_size=1` အပါအဝင် V21 ရဲ့ ပြောင်းလဲမှုတွေ ကို တကယ့် model နဲ့ ပထမဆုံး run ရတဲ့အခါ စစ်ကြည့်ပါ။
5. **`pip install -r backend/requirements.txt`** — sandbox မှာ pip ပိတ်ထားလို့ package အားလုံးကို အပြည့်အစုံ သွင်းကြည့်ခြင်း မလုပ်နိုင်ခဲ့ပါ (V20 နဲ့ package တူတာပါ၊ `cryptography` ကိုတော့ ထပ်မလိုတော့)။ **VPS ပေါ်က `apt` / `systemd` အဆင့်တွေလည်း** ဒီ VPS အစစ်မှာ မစမ်းရပါ။
6. **တကယ့် Google Drive** — Google ဆီ တကယ်မခေါ်ရဘဲ အတု response နဲ့ စမ်းထား။ OAuth client မှန်မမှန်၊ SSH tunnel နဲ့ Connect လုပ်တာ အဆင်ပြေမပြေက ကိုယ့်ဘက်မှာ စစ်ရပါမယ်။
7. **အချိန် (speed) တိုင်းတာမှု** — မရှိပါ (တကယ့် Whisper နဲ့ ဗီဒီယိုရှည်တွေ မရှိလို့)။ CPU core များတဲ့ server မှာ ပိုသိသာပါလိမ့်မယ်။
8. Chrome / Edge / Safari **အစစ်** မှာ — Playwright Chromium (headless) မှာပဲ စမ်းထား။ H.264 ဗီဒီယိုရဲ့ ပရီဗျူး ပေါ်မပေါ်က browser codec ပေါ် မူတည်ပါတယ်။
9. **လုံခြုံရေး** — အပေါ်က "လုံခြုံရေး" အပိုင်းမှာ ရေးထားတဲ့အတိုင်း — ကိုယ်တိုင်စစ်ထားတာသာ ရှိပြီး လွတ်လပ်တဲ့ စစ်ဆေးမှု မရှိပါ။
10. **V21.1 စာပြင်တဲ့ page** — (က) ဖုန်းအစစ်၊ Safari / iPhone မှာ မစမ်းရပါ (Playwright Chromium ကို ၃၉၀ px နဲ့ ၁၂၀၀ px အရွယ်မှာပဲ စမ်းထား)။ (ခ) Preview ထဲက blur ကို browser ရဲ့ `backdrop-filter` နဲ့ ပြတာမို့ ffmpeg နဲ့ တကယ်ထွက်မယ့် blur နဲ့ အနည်းငယ် ကွာနိုင်ပါတယ် — အတိအကျ ကြည့်ချင်ရင် "🖼 အစစ်အမှန် ပုံစံ ကြည့်မယ်" ကို သုံးပါ။ (ဂ) အသံပြောင်းတဲ့ job မှာ preview ထဲက စာတန်းအချိန်က ခန့်မှန်းချိန်ပါ။ (ဃ) စာကြောင်း ၁၅၀၀ ရှိတဲ့ ရုပ်ရှင်ရှည်ကို computer ရဲ့ Chromium မှာ ဖန်တီးရတာ ~၀.၁၄ စက္ကန့် (V21.2 ရဲ့ အချိန်ဘားတွေ ပါပြီးနောက်)၊ စာတစ်လုံးရိုက်တာ ၁ ms အောက်၊ အချိန်ဘား တစ်ခု ရွှေ့တာ ၀.၄ ms ပဲ ကြာတာကို တိုင်းထားပေမယ့် ဖုန်းအစစ်မှာ မတိုင်းရသေးပါ။
    (င) **V21.2 အချိန်ညှိ bar** — ဖုန်းအစစ်မှာ မစမ်းရပါ (Chromium ကို ၃၉၀ px အရွယ်မှာ ဘားက box အောက်ရောက်တာ၊ ခလုတ်က လက်ချောင်းနဲ့ ထိလို့ကောင်းတဲ့ အရွယ်ဖြစ်တာ စစ်ထားပေမယ့် လက်နဲ့ တကယ်ထိတဲ့ ခံစားမှုကို မစမ်းရ)။ အသံပြောင်းတဲ့ job မှာ အသံ အရှည်ကို အသံမထုတ်ခင် မသိနိုင်လို့ preview ထဲက အချိန်က ခန့်မှန်းချိန်ပါ — ရွှေ့ထားတဲ့ စာကြောင်းရဲ့ အသံက နောက်စာကြောင်းစချိန်ထက် ရှည်နေရင် အရင်အတိုင်း နောက်စာကြောင်းကို တွန်းမှာမို့ တိကျတဲ့အချိန်ကို ပြီးမှ သိရပါမယ်။

11. **V21.3 "စကားပြော (Dub)" ပုံစံ** —
    (က) **တကယ့် Gemini နဲ့ မစမ်းနိုင်ခဲ့ပါ** (sandbox က Google ကို ပိတ်ထား)။ Dub prompt ကို Gemini က ဘယ်လောက်လိုက်နာမလဲ၊ ပြန်ရတဲ့ မြန်မာစာက ရည်ညွှန်း video လို သဘာဝကျမကျ ဆိုတာ **မသိပါ**။ ကျွန်ုပ် စစ်နိုင်ခဲ့တာက အတု Gemini နဲ့ request ပုံစံ၊ မှတ်စုကို batch တိုင်းမှာ ထည့်တာ၊ job အလုပ်လုပ်ပုံ ပဲ ဖြစ်ပါတယ်။ **VPS မှာ ၁–၂ မိနစ် video အတိုနဲ့ အရင်စမ်းပြီး နားထောင်ကြည့်ပါ** — မကြိုက်ရင် "🎬 ရုပ်ရှင် Recap" ကို ပြန်ရွေးလို့ရ။
    (ခ) Prompt ထဲက မြန်မာ **နမူနာစာကြောင်း ၆ ခု** ကို ကျွန်ုပ် အကောင်းဆုံး ကြိုးစားရေးထားတာပါ — မြန်မာစကား မူရင်းပြောသူ မဟုတ်လို့ စကားပြောပုံ တိတိကျကျ မှန်တာကို အာမမခံနိုင်ပါ။ ကိုယ့်နားနဲ့ နားထောင်ပြီး `DUB_PROMPT` ရဲ့ EXAMPLES ကို ကိုယ်ကြိုက်တဲ့ ပြောပုံနဲ့ ပြောင်းပါ။
    (ဂ) ရည်ညွှန်း video ၂ ခုကိုပဲ ကြည့်ထားတာ၊ "မြန်မြန်ပြော" ကိန်းဂဏန်း (≈ ၈.၇ syllable/စက္ကန့်) က **video တစ်ခုရဲ့ စာတန်း စာကြောင်း ၃၀ (၁၈.၆ စက္ကန့်)** ကို app ရဲ့ syllable ရေတွက်စနစ်နဲ့ ရေတွက်ထားတာပဲ — မြန်မာစကားသံကို စာအဖြစ်ပြောင်းတဲ့ tool မရှိလို့ အသံကို တိုက်ရိုက် မတိုင်းနိုင်ခဲ့ပါ။ ဒါကြောင့် "+30 %" က ခန့်မှန်းချက်ပါ၊ ကိုယ့်နားနဲ့ ညှိပါ။
    (ဃ) **အသံက စာကြောင်းတစ်ကြောင်းချင်း ထုတ်တာ** (Edge TTS) ဆက်ဖြစ်နေပါတယ် — ရည်ညွှန်း video လို တစ်ဆက်တည်း အသံနေအသံထား၊ အသက်ရှူကြား မရနိုင်ပါ။ စာကို ပိုကောင်းအောင် လုပ်ပေမယ့် အသံပိုင်းမှာ "ပြတ်ပြတ်သွားတာ" ကျန်နိုင်ပါတယ်။
    (င) ဇာတ်လမ်းမှတ်စုကြောင့် မြန်မာစာရေးတာ **Whisper ပြီးမှ စ** (ဗီဒီယိုရှည်ရင် စောင့်ချိန် ပိုကြာ) ပြီး Gemini request ၁ ခု ပိုသုံးပါတယ်။ ရုပ်ရှင်အရမ်းရှည်လို့ အညီအမျှ ရွေးပို့ရတဲ့ အခြေအနေကို တကယ့် Gemini နဲ့ မစမ်းရပါ။
    (စ) ရွေးချယ်စရာ စမ်းသပ်ချက် — စာသားက တင်းမာနေသလိုဆိုရင် `.env` မှာ `GEMINI_THINKING_BUDGET=auto` ထည့်ကြည့်နိုင်ပါတယ် (Gemini ရဲ့ မူလ "စဉ်းစား" အပြင်အဆင်ကို သုံးမယ် — ပိုနှေး၊ ဖြတ်ပြီးပြန်တာ ပိုဖြစ်နိုင်ပေမယ့် app က batch ကို ခွဲပြီး ပြန်စမ်းပါတယ်)။ နံပါတ် (`=1024` စသည်) ကို အသစ်ထွက်တဲ့ model တချို့က လက်မခံနိုင်လို့ `auto` ကိုပဲ အကြံပြုပါတယ်။ ဒါကို မစမ်းရသေးလို့ default (စဉ်းစားချိန်ပိတ်) ကို မပြောင်းထားပါ။
    (ဆ) ဖုန်းအစစ်၊ Safari မှာ မစမ်းရပါ (Playwright Chromium ကို ၃၂၀ / ၃၆၀ / ၃၉၀ / ၄၁၂ px အကျယ်မှာပဲ စမ်းထား)။

12. **V22 (ဇာတ်လမ်းပြောဟန်; Claude / Groq အပိုင်းကို V22.2 မှာ ဖျက်ပြီး)** —
    (က) **တကယ့် Gemini ကို တစ်ခါမှ မခေါ်နိုင်ခဲ့ပါ** (sandbox က ပိတ်ထား၊ key လည်း မရှိ)။ Request / response ပုံစံကို စာရွက်စာတမ်းအတိုင်း ရေးပြီး **ကျွန်ုပ်ကိုယ်တိုင်ရေးတဲ့ အတု HTTP server** နဲ့ပဲ စမ်းထားတာပါ။ Model နာမည် default က အကောင့်အလိုက် မရနိုင်ပါ — **Model စာရင်း** ခလုတ်နဲ့ ကိုယ့် key က မြင်တာကို ရွေးပါ။ ပထမဆုံး **Test (အလကား)** ကို နှိပ်ပါ။
    (ခ) **ဇာတ်လမ်းပြောဟန်ရဲ့ ရလဒ်အရည်အသွေး** (နားထောင်လို့ကောင်းလား၊ မူရင်းမှာမပါတာ ထည့်မရေးဘူးလား) ကို AI အစစ်နဲ့ မစမ်းရပါ — အတု AI က ပုံစံအတိုင်း ပြန်ပေးတာကိုပဲ စစ်ထားတာမို့ **၁–၂ မိနစ် ဗီဒီယိုအတိုနဲ့ အရင်စမ်းပြီး review page မှာ ဖတ်ကြည့်ပါ**။ မူရင်းစာကြောင်းအားလုံးကို ဖုံးတာ၊ မထပ်တာကိုတော့ ကျွန်ုပ်ရဲ့ code က ပြန်စစ်ပါတယ် (ကျန်တာကို ထပ်မေး)၊ ဒါပေမယ့် အဓိပ္ပါယ် မှန်/မမှန်ကို စစ်လို့မရပါ။
    (ဃ) `tests/test_app.py` အပါအဝင် `fastapi` လိုတဲ့ test တွေကို ကျွန်ုပ်ရဲ့ sandbox မှာ မပြေးနိုင်ခဲ့ပါ။ `app.py` ပြောင်းထားတာတွေ (settings / create_job / resume_job) ကို fastapi အတုနဲ့ ခေါ်စစ်ပေမယ့် **ကိုယ့်ဘက်မှာ `python -m pytest tests/test_app.py` ကို ပြေးကြည့်ပါ**။
    (စ) ဖုန်းအစစ်၊ Safari မှာ "AI API" card ကို မစမ်းရပါ (Chromium မှာပဲ)။

13. **V22.1 (ဒီ version မှာ ပြင်တာတွေ)** —
    (က) **"Server ချိတ်ဆက်မရ" (ဒုတိယ ဗီဒီယိုမှာ) ရဲ့ တကယ့်အကြောင်းရင်းကို ပြန်မဖြစ်စေနိုင်ခဲ့ပါ** — ကျွန်ုပ်ရဲ့ sandbox မှာ ကိုယ့် AWS server၊ ကိုယ့်အင်တာနက်၊ တကယ့်ဗီဒီယိုကြီးတွေ မရှိလို့ပါ။ Code ထဲက ဖြစ်နိုင်ချေတွေ (keep-alive ၅ စက္ကန့်၊ ပြီးတဲ့ video ကို browser က ဆက်ဖွင့်ထား၊ page မှာ အချိန်ကန့်သတ်မရှိ) ကို ပြင်ပြီး browser ကို connection ဖြတ်ပေးထားတဲ့ အတုနဲ့ (Playwright) ၆ ချက် စမ်းထားပါတယ် (`node tests/ui_flaky_server.js`)၊ ဒါပေမဲ့ **ပြင်ပြီးရင်လည်း ထပ်ဖြစ်သေးရင်** စာမျက်နှာပေါ်က **စာအတိအကျ** ကို ပြောပါ — အခု စာက ၃ မျိုး ခွဲပြောနေပြီ (server ပြန်စ / server ပိတ်နေ / upload ပဲပြတ်)၊ ပြီးရင် `journalctl -u recap -n 100` နဲ့ `free -m` (OOM ဖြစ်လား) ကို ကြည့်ပါ။ **Server RAM နည်းရင်** (2 GB အောက်) swap ထည့်ပါ: `sudo fallocate -l 4G /swapfile && sudo chmod 600 /swapfile && sudo mkswap /swapfile && sudo swapon /swapfile` (Whisper + ffmpeg က memory များပြီး OOM ဖြစ်ရင် Linux က server ကို ရပ်ပစ်တတ်ပါတယ်)။
    (ခ) **Server ပြန်စတာနဲ့ job ကို သူ့ဟာသူ ဆက်လုပ်တာ** ကို အစစ်အမှန် server (`fastapi` ပါတဲ့) နဲ့ မပြေးကြည့်နိုင်ပါ — fastapi အတုနဲ့ `app.py` ကို import ပြီး `resume_after_restart()` ကို စစ်ထားပါတယ် (`tests/test_restart.py` က fastapi ရှိတဲ့ စက်မှာ ပြေးပါလိမ့်မယ်)။ Pipeline က လုပ်ပြီးသားအပိုင်းကနေ ဆက်တာ (V21 ကတည်းက "ဆက်လုပ်မယ်" ခလုတ်နဲ့ စမ်းထားပြီးသား) ကိုတော့ ပြန်သုံးထားတာပါ။
    (ဂ) **Blur box စာအရွယ်** — ffmpeg / libass နဲ့ တကယ်ရိုက်ပြီး pixel တိုင်းထားပါတယ် (၁၉၂၀×၁၀၈၀၊ ၁၂၈၀×၇၂၀၊ ၁၀၈၀×၁၉၂၀ အချိုးတွေ၊ ဘောင်ရှိ/မရှိ၊ ရှည်/တို စာ — စာက box အပြင် မထွက်ကြောင်း `tests/test_blur_text.py`) ။ ဒါပေမဲ့ **Padauk font** (ဒီ app ထည့်ပေးထားတာ) နဲ့ပဲ၊ ကိုယ်ပိုင် font (`SUBTITLE_FONT`) သုံးရင် လိုင်းအကွာ မတူနိုင်ပါ။ **စာက ကိုယ်လိုချင်တာထက် ကြီးလွန်း/သေးလွန်းနေရင်** Review page ရဲ့ "စာအရွယ်" slider နဲ့ ညှိပါ (100 % ကို ပုံမှန်အဖြစ် ထားထားပါတယ်)။ ကျွန်ုပ်က "padding ဖျောက်မယ်" ကို "box အတွင်း စာက အပေါ်အောက် အလွတ်မကျန်ဘဲ box အမြင့်အတိုင်း ကြီးအောင်" လို့ နားလည်ပြီး လုပ်ထားပါတယ် — **blur box ကိုယ်တိုင်ကို စာအရွယ်အတိုင်း ကျုံ့ခိုင်းတာ** ဆိုရင် (box နေရာက မူရင်းစာကို ဖုံးဖို့ ကိုယ်ထားထားတဲ့ နေရာမို့ မလုပ်ထားပါ) ပြောပါ။
    (ဃ) (V22.2: Claude / Groq ကို ဖျက်ပြီးပါပြီ။) Chat ထဲ Claude key အစစ် ပို့ထားဖူးတာမို့ **အဲဒီ key ကို Anthropic Console မှာ ပယ်ဖျက် (rotate) ထားပါ** — ဒီ app က မသုံးတော့ပေမယ့် key က chat မှာ ကျန်နေလို့ပါ။

## ပြဿနာ ဖြေရှင်းနည်း

| စာသား | အဓိပ္ပါယ် |
|---|---|
| `User location is not supported for the API use` | Gemini က မပံ့ပိုးတဲ့ IP။ VPN ကို ကွန်ပျူတာတစ်ခုလုံးမှာ ဖွင့် / `GEMINI_PROXY` / Tokyo VPS။ |
| `API key not valid` / `Invalid API Key` | Key ကို ပြန်ကူးပြီး Save။ ရပ်ထားတဲ့ job မှာဆိုရင် "Key အသစ်နဲ့ ဆက်လုပ်မယ်"။ |
| `Gemini API key မထည့်ရသေးပါ` | Gemini API card မှာ key ထည့်ပြီး Save။ |
| `POST /api/jobs` မှာ `Unsupported style` | အရင်ပုံစံနာမည် (`recap` …) ကို ပို့လို့ — ယခု `direct` / `story` ပဲ ရှိပါတယ်။ |
| `503 … high demand` | Gemini က လူများနေတာ။ အလိုအလျောက် ပြန်စမ်း / model ပြောင်းစမ်းပါတယ်၊ ၁၀ မိနစ်မရရင် ရပ်ပြီး "ဆက်လုပ်မယ်" ပေါ်မယ်။ |
| `prepayment credits are depleted` / `RESOURCE_EXHAUSTED` (daily) | Credit / quota ကုန်။ **Project အသစ်** က key အသစ်ထည့်ပြီး ဆက်လုပ်၊ ဒါမှမဟုတ် Cancel။ |
| `RESOURCE_EXHAUSTED` (per minute) | တစ်မိနစ် limit — Gemini ပြောတဲ့ စက္ကန့်အတိုင်း စောင့်ပြီး ပြန်စမ်းပါတယ်။ Free key မှာ မကြာခဏဆိုရင် `GEMINI_MIN_INTERVAL=12`။ |
| `models/... is not found` | Model နာမည်မှား။ "Model စာရင်း" ခလုတ်နဲ့ ရတဲ့ model ကို ရွေးပါ။ |
| "စာတန်းထည့်ဖို့ libass မပါ" | `FFMPEG_PATH` ကို libass ပါတဲ့ ffmpeg ဆီ ညွှန်ပါ (Linux: `sudo apt install ffmpeg`)။ |
| Edge TTS `403` / `No audio was received` | Server နာရီ မှန်ရမယ် (`timedatectl` ကြည့် — Microsoft က နာရီလွဲရင် ပယ်တတ်တယ်)၊ ပြီးရင် `venv/bin/pip install -U edge-tts` ပြီး ပြန်စ။ ရပ်သွားတဲ့ job ကို "ဆက်လုပ်မယ်" နဲ့ ဆက်လို့ရတယ်။ |
| `ဒီဖိုင်က video ဖိုင် အစစ် မဟုတ်ပါဘူး` | ဖိုင်ရဲ့ အစပိုင်းက mp4 / mov / mkv / webm / avi မဟုတ်လို့ — နာမည်ကို `.mp4` လို့ ပြောင်းထားတာနဲ့ မရပါဘူး။ Video editor / HandBrake နဲ့ mp4 အဖြစ် ပြန် export လုပ်ပါ။ |
| Preview မပေါ် | Browser က အဲဒီ video format ကို မဖွင့်နိုင်လို့ (ဥပမာ .mkv)။ အောက်က ဂဏန်းတွေနဲ့ ညှိပါ။ |
| VPS-IP:8000 ကို browser မှာ ဖွင့်လို့မရ (timeout) | AWS Security Group မှာ port 8000 ရှိလား၊ Source က ကိုယ့်ရဲ့ **လက်ရှိ** IP လား (IP ပြောင်းသွားတတ်)၊ `sudo systemctl status recap`။ `deploy/DEPLOY_MY.md` ကြည့်ပါ။ |
| Password ထပ်ထပ်မေးနေ / `Password လိုပါတယ်` | `APP_PASSWORD` မမှန်ဘူး။ User name ကတော့ ဘာရိုက်ရိုက်ရ။ |
| `ဇာတ်လမ်းမှတ်စု မရလို့ မှတ်စုမပါဘဲ ဆက်ရေးပါမယ်။` | ဇာတ်လမ်းပြောဟန်မှာ ဇာတ်လမ်းတစ်ခုလုံးကို ဖတ်ခိုင်းတဲ့ request ကို AI က မဖြေ / ဖြတ်ပြီးပြန် / ဖတ်မရတဲ့ပုံစံနဲ့ ပြန်လို့ — job မပျက်ဘဲ မှတ်စုမပါဘဲ ဆက်ရေးနေတာပါ။ ဇာတ်ကောင်နာမည်၊ ခေါ်ပုံတွေ ကွဲနိုင်လို့ review page မှာ စစ်ပြီး ပြင်ပါ၊ ဒါမှမဟုတ် Cancel လုပ်ပြီး ပြန်တင်ကြည့်ပါ။ |
| ဇာတ်လမ်းပြောဟန်နဲ့ ရေးတဲ့အခါ "ဇာတ်လမ်းတစ်ခုလုံးကို အရင်ဖတ်နေပါတယ်" မှာ ကြာနေ | ပုံမှန်ပါ — Whisper ကို ဗီဒီယိုတစ်ခုလုံး ပြီးအောင် စောင့်ပြီးမှ မှတ်စု request ၁ ခု ပို့ပါတယ်။ ဗီဒီယိုရှည်ရင် ပိုကြာပါမယ်။ မိနစ်များစွာ တစ်ဆင့်တည်းမှာ ကပ်နေရင် "ကိုယ့် Job တွေ" ထဲက အခြေအနေနဲ့ `sudo journalctl -u recap -n 50` ကို ကြည့်ပါ။ |
