@echo off
cd /d "%~dp0"
echo Burmese Movie Recap AI V21 - installing / checking packages ...
python -m pip install -r backend\requirements.txt
echo.
echo Starting. When you see "Uvicorn running", open  http://127.0.0.1:8000  in your browser.
echo (Close this window to stop the program.)
echo.
set HOST=127.0.0.1
python backend\app.py
pause
