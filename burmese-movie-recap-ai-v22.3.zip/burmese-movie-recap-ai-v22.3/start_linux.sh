#!/usr/bin/env bash
# Burmese Movie Recap AI V22.3 - start on Linux / macOS (also fine for a first test on the VPS).
cd "$(dirname "$0")" || exit 1
if [ ! -d venv ]; then
  python3 -m venv venv || { echo "python3-venv is missing:  sudo apt install -y python3-venv"; exit 1; }
fi
. venv/bin/activate
pip install -r backend/requirements.txt
echo
echo "Open  http://127.0.0.1:8000  on this computer, or  http://<server-ip>:8000  on a VPS (see deploy/DEPLOY_MY.md)."
echo
exec python backend/app.py
