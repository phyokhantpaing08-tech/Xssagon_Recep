Burmese subtitle font / မြန်မာစာတန်း ဖောင့်
============================================

Burned-in subtitles (the "စာတန်းထိုးမည်" option) need a font that can draw Burmese (Myanmar Unicode).

V21 already contains one:  Padauk-Regular.ttf  (SIL Padauk, free under the SIL Open Font License 1.1 - the licence text is
in Padauk-OFL.txt, keep it next to the font).  So burned-in subtitles work out of the box on Windows, Linux (your VPS) and macOS.

* The first usable font found in THIS folder is used.
* You can use a different font: copy a Burmese Unicode .ttf / .otf (for example NotoSansMyanmar-Regular.ttf from Google Fonts)
  into this folder and delete Padauk-Regular.ttf (or point SUBTITLE_FONT=/path/to/font.ttf in the .env file; add
  SUBTITLE_FONT_NAME if the family name is not detected).
* Windows 10/11 "Myanmar Text" and the usual Linux locations (/usr/share/fonts/truetype/noto, /usr/share/fonts/truetype/padauk)
  are also searched, but only AFTER this folder.
* Put only ONE regular-weight font here (a Bold file next to it would be picked first, because of its name).
